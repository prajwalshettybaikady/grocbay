<?php

namespace AppBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class RestaurantsType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('restaurantName')->add('description')->add('restaurantAddress')->add('restaurantLat')->add('restaurantLong')->add('primaryMobile')->add('secondaryMobile')->add('primaryEmail')->add('secondaryEmail')->add('restaurantTerms')->add('iconFile')->add('bannerFile');

        $builder->add('isOpen')
                ->add('openTime',TextType::class)
                ->add('closeTime',TextType::class)
                ->add('taxType',ChoiceType::class,array(
                    'choices'=>array('Inclusive of tax'=>'inclusive','Exclusive of tax'=>'exclusive')
                ))
                ->add('tax')
                ->add('deliveryCharge')
                ->add('minOrderAmount')
                ->add('serviceFee');
        $builder->add('orderType',ChoiceType::class,array(
                    'choices'=>array('Cash on delivery'=>'code','Card on delivery'=>'card','Online paymeny'=>'online'),
                    'multiple'=>true,
                ));
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'AppBundle\Entity\Restaurants'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'appbundle_restaurants';
    }


}

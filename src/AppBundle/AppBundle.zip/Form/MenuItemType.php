<?php

namespace AppBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;

class MenuItemType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('itemName')
                ->add('itemShortDescription')
                ->add('itemDescription')
                ->add('itemFeaturedImageFile')
                ->add('regularPrice')
                ->add('salePrice')
                ->add('isActive')
                ->add('salesTax')
                ->add('category')
                ->add('vegType',ChoiceType::class,array(
                    'choices'=>array('Vegetarian'=>'veg','Non-vegetarian'=>'non')
                ));


        $builder->add('priceVariation', CollectionType::class, array(
                    'entry_type'   => PriceVariationType::class,
                    'allow_add'    => true,
                    'allow_delete' => true,
                    'required'   => true,
                    'by_reference' =>false,
                ));
        
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'AppBundle\Entity\MenuItem'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'appbundle_menuitem';
    }


}

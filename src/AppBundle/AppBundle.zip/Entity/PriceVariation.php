<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * PriceVariation
 *
 * @ORM\Table(name="price_variation")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\PriceVariationRepository")
 */
class PriceVariation
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="variationName", type="string", length=255)
     */
    private $variationName;

    /**
     * @var float
     *
     * @ORM\Column(name="price", type="float")
     */
    private $price;

    /**
     * @var int
     *
     * @ORM\Column(name="priority", type="integer")
     */
    private $priority;

    /**
     *@ORM\ManyToOne(targetEntity="MenuItem", inversedBy="priceVariation", cascade={"persist"})
     *@ORM\JoinColumn(name="menu_item_id", referencedColumnName="id")
     */
    private $menuItem;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set variationName
     *
     * @param string $variationName
     *
     * @return PriceVariation
     */
    public function setVariationName($variationName)
    {
        $this->variationName = $variationName;

        return $this;
    }

    /**
     * Get variationName
     *
     * @return string
     */
    public function getVariationName()
    {
        return $this->variationName;
    }

    /**
     * Set price
     *
     * @param float $price
     *
     * @return PriceVariation
     */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     * @return float
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set priority
     *
     * @param integer $priority
     *
     * @return PriceVariation
     */
    public function setPriority($priority)
    {
        $this->priority = $priority;

        return $this;
    }

    /**
     * Get priority
     *
     * @return int
     */
    public function getPriority()
    {
        return $this->priority;
    }

    /**
     * Set menuItem
     *
     * @param \AppBundle\Entity\MenuItem $menuItem
     *
     * @return PriceVariation
     */
    public function setMenuItem(\AppBundle\Entity\MenuItem $menuItem = null)
    {
        $this->menuItem = $menuItem;

        return $this;
    }

    /**
     * Get menuItem
     *
     * @return \AppBundle\Entity\MenuItem
     */
    public function getMenuItem()
    {
        return $this->menuItem;
    }
}

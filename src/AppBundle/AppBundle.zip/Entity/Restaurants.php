<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Filesystem\Filesystem;

/**
 * Restaurants
 *
 * @ORM\Table(name="restaurants")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\RestaurantsRepository")
 */
class Restaurants
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     */
    private $id=999;

    /**
     * @var string
     *
     * @ORM\Column(name="restaurantName", type="string", length=255, unique=true)
     */
    private $restaurantName;

    /**
     * @var string
     *
     * @ORM\Column(name="restaurantSlug", type="string", length=255, unique=true)
     */
    private $restaurantSlug;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="restaurantAddress", type="text", nullable=true)
     */
    private $restaurantAddress;

    /**
     * @var string
     *
     * @ORM\Column(name="restaurantLocation", type="text", nullable=true)
     */
    private $restaurantLocation="Udupi, Karnataka";

    /**
     * @var string
     *
     * @ORM\Column(name="restaurantLat", type="string", length=255, nullable=true)
     */
    private $restaurantLat="13.3318062";

    /**
     * @var string
     *
     * @ORM\Column(name="restaurantLong", type="string", length=255, nullable=true)
     */
    private $restaurantLong="74.7120715";

    /**
     * @var string
     *
     * @ORM\Column(name="primaryMobile", type="string", length=255, unique=true)
     */
    private $primaryMobile;

    /**
     * @var string
     *
     * @ORM\Column(name="secondaryMobile", type="string", length=255, nullable=true)
     */
    private $secondaryMobile;

    /**
     * @var string
     *
     * @ORM\Column(name="primaryEmail", type="string", length=255, unique=true)
     */
    private $primaryEmail;

    /**
     * @var string
     *
     * @ORM\Column(name="secondaryEmail", type="string", length=255, nullable=true)
     */
    private $secondaryEmail;

    /**
     * @var string
     *
     * @ORM\Column(name="vegType", type="string", length=255)
     */
    private $vegType="veg";

    /**
     * @var string
     *
     * @ORM\Column(name="openTime", type="time", nullable=true)
     */
    private $openTime;

    /**
     * @var string
     *
     * @ORM\Column(name="closeTime", type="time", nullable=true)
     */
    private $closeTime;

    /**
     * @var string
     *
     * @ORM\Column(name="isOpen", type="boolean")
     */
    private $isOpen=true;

    /**
     * @var string
     *
     * @ORM\Column(name="isFeatured", type="boolean")
     */
    private $isFeatured=false;

    /**
     * @var string
     *
     * @ORM\Column(name="taxType", type="string", length=255)
     */
    private $taxType="inclusive";

    /**
     * @var string
     *
     * @ORM\Column(name="tax", type="float")
     */
    private $tax=12.0;

    /**
     * @var string
     *
     * @ORM\Column(name="serviceFee", type="float")
     */
    private $serviceFee=10.0;

    /**
     * @var string
     *
     * @ORM\Column(name="popularity", type="float")
     */
    private $popularity=0.0;

    /**
     * @var string
     *
     * @ORM\Column(name="minOrderAmount", type="float")
     */
    private $minOrderAmount=0.0;

    /**
     * @var string
     *
     * @ORM\Column(name="deliveryCharge", type="float")
     */
    private $deliveryCharge=0.0;

    /**
     * @var string
     *
     * @ORM\Column(name="restaurantTerms", type="text", nullable=true)
     */
    private $restaurantTerms;

    /**
     * @var string
     *
     * @ORM\Column(name="iconImage", type="string", length=255, unique=true, nullable=true)
     */
    private $iconImage;

    /**
     * @Assert\Image()
     * @Assert\File(maxSize="6000000")
     */
    private $iconFile;

    /**
     * @var string
     *
     * @ORM\Column(name="bannerImage", type="string", length=255, unique=true, nullable=true)
     */
    private $bannerImage;

    /**
     * @Assert\Image()
     * @Assert\File(maxSize="6000000")
     */
    private $bannerFile;

    /**
     * @var string
     *
     * @ORM\Column(name="orderType", type="json_array")
     */
    private $orderType = [];

    
    public function __toString(){
        return $this->restaurantName;
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set restaurantName
     *
     * @param string $restaurantName
     *
     * @return Restaurants
     */
    public function setRestaurantName($restaurantName)
    {
        $this->restaurantName = $restaurantName;

        return $this;
    }

    /**
     * Get restaurantName
     *
     * @return string
     */
    public function getRestaurantName()
    {
        return $this->restaurantName;
    }

    /**
     * Set restaurantSlug
     *
     * @param string $restaurantSlug
     *
     * @return Restaurants
     */
    public function setRestaurantSlug($restaurantSlug)
    {
        $this->restaurantSlug = $restaurantSlug;

        return $this;
    }

    /**
     * Get restaurantSlug
     *
     * @return string
     */
    public function getRestaurantSlug()
    {
        return $this->restaurantSlug;
    }

    /**
     * Set restaurantAddress
     *
     * @param string $restaurantAddress
     *
     * @return Restaurants
     */
    public function setRestaurantAddress($restaurantAddress)
    {
        $this->restaurantAddress = $restaurantAddress;

        return $this;
    }

    /**
     * Get restaurantAddress
     *
     * @return string
     */
    public function getRestaurantAddress()
    {
        return $this->restaurantAddress;
    }

    /**
     * Set primaryMobile
     *
     * @param string $primaryMobile
     *
     * @return Restaurants
     */
    public function setPrimaryMobile($primaryMobile)
    {
        $this->primaryMobile = $primaryMobile;

        return $this;
    }

    /**
     * Get primaryMobile
     *
     * @return string
     */
    public function getPrimaryMobile()
    {
        return $this->primaryMobile;
    }

    /**
     * Set secondaryMobile
     *
     * @param string $secondaryMobile
     *
     * @return Restaurants
     */
    public function setSecondaryMobile($secondaryMobile)
    {
        $this->secondaryMobile = $secondaryMobile;

        return $this;
    }

    /**
     * Get secondaryMobile
     *
     * @return string
     */
    public function getSecondaryMobile()
    {
        return $this->secondaryMobile;
    }

    /**
     * Set primaryEmail
     *
     * @param string $primaryEmail
     *
     * @return Restaurants
     */
    public function setPrimaryEmail($primaryEmail)
    {
        $this->primaryEmail = $primaryEmail;

        return $this;
    }

    /**
     * Get primaryEmail
     *
     * @return string
     */
    public function getPrimaryEmail()
    {
        return $this->primaryEmail;
    }

    /**
     * Set secondaryEmail
     *
     * @param string $secondaryEmail
     *
     * @return Restaurants
     */
    public function setSecondaryEmail($secondaryEmail)
    {
        $this->secondaryEmail = $secondaryEmail;

        return $this;
    }

    /**
     * Get secondaryEmail
     *
     * @return string
     */
    public function getSecondaryEmail()
    {
        return $this->secondaryEmail;
    }

    /**
     * Set restaurantTerms
     *
     * @param string $restaurantTerms
     *
     * @return Restaurants
     */
    public function setRestaurantTerms($restaurantTerms)
    {
        $this->restaurantTerms = $restaurantTerms;

        return $this;
    }

    /**
     * Get restaurantTerms
     *
     * @return string
     */
    public function getRestaurantTerms()
    {
        return $this->restaurantTerms;
    }

    protected function getUploadRootDir()
    {
        // the absolute directory siteLogo where uploaded
        // documents should be saved
        return __DIR__.'/../../../uploads/restaurant/';
    }

    /**
     * Sets file.
     *
     * @param UploadedFile $file
     */
    public function setIconFile(UploadedFile $file)
    {
        $this->iconFile = $file;
    }

    /**
     * Get file.
     *
     * @return UploadedFile
     */
    public function getIconFile()
    {
        return $this->iconFile;
    }

    public function setIconImage($iconImage){
        $this->iconImage=$iconImage;
        return $this;
    }

    public function getIconImage()
    {
        return $this->iconImage;
    }

    public function preIconUpload()
    {
        if (null !== $this->iconFile) {
            // do whatever you want to generate a unique name
            $this->iconImage = $this->restaurantSlug.'.'.$this->iconFile->guessExtension();
        }
    }
    

    protected function getIconUploadDir()
    {
        // get rid of the __DIR__ so it doesn't screw up
        // when displaying uploaded doc/image in the view.
        return $this->getUploadRootDir()."icons/";
    }


    public function iconUpload()
    {
        $this->preIconUpload();
        // the file property can be empty if the field is not required
        if (null === $this->getIconFile()) {
            return;
        }
        $temp1=$this->getIconFile();
        
        
       // $this->siteLogo = uniqid().'.'.$this->file->guessExtension();
        // use the original file name here but you should
        // sanitize it at least to avoid any security issues

        // move takes the target directory and then the
        // target filename to move to
        
        
        $temp1->move(
            $this->getIconUploadDir(),
            $this->iconImage//getFile()->getClientOriginalName()
        );
        
        // clean up the file property as you won't need it anymore
        $this->iconFile = null;

        unset($this->iconFile);
    }


    public function getAbsoluteIconImagePath()
    {
        return null === $this->iconImage
            ? null
            : $this->getIconUploadDir().'/'.$this->iconImage;
    }

    public function removeIconUpload()
    {
        if($this->iconImage!="default.png" || $this->iconImage!=null)
            if ($file = $this->getAbsoluteIconImagePath()) {
                unlink($file);
            }
    }

    /**
     * Sets file.
     *
     * @param UploadedFile $file
     */
    public function setBannerFile(UploadedFile $file)
    {
        $this->bannerFile = $file;
    }

    /**
     * Get file.
     *
     * @return UploadedFile
     */
    public function getBannerFile()
    {
        return $this->bannerFile;
    }

    public function setBannerImage($bannerImage){
        $this->bannerImage=$bannerImage;
        return $this;
    }

    public function getBannerImage()
    {
        return $this->bannerImage;
    }

    public function preBannerUpload()
    {
        if (null !== $this->bannerFile) {
            // do whatever you want to generate a unique name
            $this->bannerImage = $this->restaurantSlug.'.'.$this->bannerFile->guessExtension();
        }
    }
    

    protected function getBannerUploadDir()
    {
        // get rid of the __DIR__ so it doesn't screw up
        // when displaying uploaded doc/image in the view.
        return $this->getUploadRootDir()."banners/";
    }


    public function bannerUpload()
    {
        $this->preBannerUpload();
        // the file property can be empty if the field is not required
        if (null === $this->getBannerFile()) {
            return;
        }
        $temp1=$this->getBannerFile();
        
        
       // $this->siteLogo = uniqid().'.'.$this->file->guessExtension();
        // use the original file name here but you should
        // sanitize it at least to avoid any security issues

        // move takes the target directory and then the
        // target filename to move to
        
        
        $temp1->move(
            $this->getBannerUploadDir(),
            $this->bannerImage//getFile()->getClientOriginalName()
        );
        
        // clean up the file property as you won't need it anymore
        $this->bannerFile = null;

        unset($this->bannerFile);
    }


    public function getAbsoluteBannerImagePath()
    {
        return null === $this->bannerImage
            ? null
            : $this->getBannerUploadDir().'/'.$this->bannerImage;
    }

    public function removeBannerUpload()
    {
        if($this->bannerImage!="default.png" || $this->bannerImage!=null)
            if ($file = $this->getAbsoluteBannerImagePath()) {
                unlink($file);
            }
    }

    /**
     * Set openTime
     *
     * @param \DateTime $openTime
     *
     * @return Restaurants
     */
    public function setOpenTime($openTime)
    {
        $this->openTime = $openTime;

        return $this;
    }

    /**
     * Get openTime
     *
     * @return \DateTime
     */
    public function getOpenTime()
    {
        return $this->openTime;
    }

    /**
     * Set closeTime
     *
     * @param \DateTime $closeTime
     *
     * @return Restaurants
     */
    public function setCloseTime($closeTime)
    {
        $this->closeTime = $closeTime;

        return $this;
    }

    /**
     * Get closeTime
     *
     * @return \DateTime
     */
    public function getCloseTime()
    {
        return $this->closeTime;
    }

    /**
     * Set isOpen
     *
     * @param boolean $isOpen
     *
     * @return Restaurants
     */
    public function setIsOpen($isOpen)
    {
        $this->isOpen = $isOpen;

        return $this;
    }

    /**
     * Get isOpen
     *
     * @return boolean
     */
    public function getIsOpen()
    {
        return $this->isOpen;
    }

    /**
     * Set tax
     *
     * @param  $tax
     *
     * @return Restaurants
     */
    public function setTax($tax)
    {
        $this->tax = $tax;

        return $this;
    }

    /**
     * Get tax
     *
     * @return \double
     */
    public function getTax()
    {
        return $this->tax;
    }

    /**
     * Set restaurantLocation
     *
     * @param string $restaurantLocation
     *
     * @return Restaurants
     */
    public function setRestaurantLocation($restaurantLocation)
    {
        $this->restaurantLocation = $restaurantLocation;

        return $this;
    }

    /**
     * Get restaurantLocation
     *
     * @return string
     */
    public function getRestaurantLocation()
    {
        return $this->restaurantLocation;
    }

    /**
     * Set restaurantLat
     *
     * @param string $restaurantLat
     *
     * @return Restaurants
     */
    public function setRestaurantLat($restaurantLat)
    {
        $this->restaurantLat = $restaurantLat;

        return $this;
    }

    /**
     * Get restaurantLat
     *
     * @return string
     */
    public function getRestaurantLat()
    {
        return $this->restaurantLat;
    }

    /**
     * Set restaurantLong
     *
     * @param string $restaurantLong
     *
     * @return Restaurants
     */
    public function setRestaurantLong($restaurantLong)
    {
        $this->restaurantLong = $restaurantLong;

        return $this;
    }

    /**
     * Get restaurantLong
     *
     * @return string
     */
    public function getRestaurantLong()
    {
        return $this->restaurantLong;
    }

    /**
     * Set taxType
     *
     * @param string $taxType
     *
     * @return Restaurants
     */
    public function setTaxType($taxType)
    {
        $this->taxType = $taxType;

        return $this;
    }

    /**
     * Get taxType
     *
     * @return string
     */
    public function getTaxType()
    {
        return $this->taxType;
    }
    
    /**
     * Set popularity
     *
     * @param float $popularity
     *
     * @return Restaurants
     */
    public function setPopularity($popularity)
    {
        $this->popularity = $popularity;

        return $this;
    }

    /**
     * Get popularity
     *
     * @return float
     */
    public function getPopularity()
    {
        return $this->popularity;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Restaurants
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set serviceFee
     *
     * @param float $serviceFee
     *
     * @return Restaurants
     */
    public function setServiceFee($serviceFee)
    {
        $this->serviceFee = $serviceFee;

        return $this;
    }

    /**
     * Get serviceFee
     *
     * @return float
     */
    public function getServiceFee()
    {
        return $this->serviceFee;
    }

    /**
     * Set minOrderAmount
     *
     * @param float $minOrderAmount
     *
     * @return Restaurants
     */
    public function setMinOrderAmount($minOrderAmount)
    {
        $this->minOrderAmount = $minOrderAmount;

        return $this;
    }

    /**
     * Get minOrderAmount
     *
     * @return float
     */
    public function getMinOrderAmount()
    {
        return $this->minOrderAmount;
    }

    /**
     * Set deliveryCharge
     *
     * @param float $deliveryCharge
     *
     * @return Restaurants
     */
    public function setDeliveryCharge($deliveryCharge)
    {
        $this->deliveryCharge = $deliveryCharge;

        return $this;
    }

    /**
     * Get deliveryCharge
     *
     * @return float
     */
    public function getDeliveryCharge()
    {
        return $this->deliveryCharge;
    }

    /**
     * Set isFeatured
     *
     * @param boolean $isFeatured
     *
     * @return Restaurants
     */
    public function setIsFeatured($isFeatured)
    {
        $this->isFeatured = $isFeatured;

        return $this;
    }

    /**
     * Get isFeatured
     *
     * @return boolean
     */
    public function getIsFeatured()
    {
        return $this->isFeatured;
    }

    /**
     * Set orderType
     *
     * @param array $orderType
     *
     * @return Restaurants
     */
    public function setOrderType($orderType)
    {
        $this->orderType = $orderType;

        return $this;
    }

    /**
     * Get orderType
     *
     * @return array
     */
    public function getOrderType()
    {
        return $this->orderType;
    }
}

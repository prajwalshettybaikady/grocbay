<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Filesystem\Filesystem;

/**
 * MenuItem
 *
 * @ORM\Table(name="menu_item")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\MenuItemRepository")
 */
class MenuItem
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="itemName", type="string", length=255)
     */
    private $itemName;

    /**
     * @var string
     *
     * @ORM\Column(name="itemSlug", type="string", length=255)
     */
    private $itemSlug;

    /**
     * @var string
     *
     * @ORM\Column(name="vegType", type="string", length=255)
     */
    private $vegType="veg";

    /**
     * @var string
     *
     * @ORM\Column(name="itemShortDescription", type="text", nullable=true)
     */
    private $itemShortDescription;

    /**
     * @var string
     *
     * @ORM\Column(name="itemDescription", type="text", nullable=true)
     */
    private $itemDescription;

    /**
     * @var string
     *
     * @ORM\Column(name="itemFeaturedImage", type="string", length=255, unique=true, nullable=true )
     */
    private $itemFeaturedImage;

    /**
     * @Assert\Image()
     * @Assert\File(maxSize="6000000")
     */
    private $itemFeaturedImageFile;

    /**
     * @var string
     *
     * @ORM\Column(name="regularPrice", type="float")
     */
    private $regularPrice=0.0;

    /**
     * @var string
     *
     * @ORM\Column(name="salePrice", type="float")
     */
    private $salePrice=0.0;

    /**
     * @var string
     *
     * @ORM\Column(name="isActive", type="boolean")
     */
    private $isActive=true;

    /**
     * @var string
     *
     * @ORM\Column(name="salesTax", type="float")
     */
    private $salesTax=12.0;

    /**
     *@ORM\OneToMany(targetEntity="PriceVariation", mappedBy="menuItem", cascade={"persist","remove"})
     */
    private $priceVariation;

    /**
     *@ORM\ManyToOne(targetEntity="SubCategory", inversedBy="menuItem", cascade={"persist"})
     *@ORM\JoinColumn(name="category_id", referencedColumnName="id")
     */
    private $category;

    /**
     *@ORM\OneToMany(targetEntity="ExtraPackage", mappedBy="menuItem", cascade={"persist","remove"})
     */
    private $extraPackage;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set itemName
     *
     * @param string $itemName
     *
     * @return MenuItem
     */
    public function setItemName($itemName)
    {
        $this->itemName = $itemName;

        return $this;
    }

    /**
     * Get itemName
     *
     * @return string
     */
    public function getItemName()
    {
        return $this->itemName;
    }

    /**
     * Set itemSlug
     *
     * @param string $itemSlug
     *
     * @return MenuItem
     */
    public function setItemSlug($itemSlug)
    {
        $this->itemSlug = $itemSlug;

        return $this;
    }

    /**
     * Get itemSlug
     *
     * @return string
     */
    public function getItemSlug()
    {
        return $this->itemSlug;
    }

    /**
     * Set itemShortDescription
     *
     * @param string $itemShortDescription
     *
     * @return MenuItem
     */
    public function setItemShortDescription($itemShortDescription)
    {
        $this->itemShortDescription = $itemShortDescription;

        return $this;
    }

    /**
     * Get itemShortDescription
     *
     * @return string
     */
    public function getItemShortDescription()
    {
        return $this->itemShortDescription;
    }

    /**
     * Set itemDescription
     *
     * @param string $itemDescription
     *
     * @return MenuItem
     */
    public function setItemDescription($itemDescription)
    {
        $this->itemDescription = $itemDescription;

        return $this;
    }

    /**
     * Get itemDescription
     *
     * @return string
     */
    public function getItemDescription()
    {
        return $this->itemDescription;
    }

    /**
     * Set regularPrice
     *
     * @param string $regularPrice
     *
     * @return MenuItem
     */
    public function setRegularPrice($regularPrice)
    {
        $this->regularPrice = $regularPrice;

        return $this;
    }

    /**
     * Get regularPrice
     *
     * @return string
     */
    public function getRegularPrice()
    {
        return $this->regularPrice;
    }

    /**
     * Set salePrice
     *
     * @param string $salePrice
     *
     * @return MenuItem
     */
    public function setSalePrice($salePrice)
    {
        $this->salePrice = $salePrice;

        return $this;
    }

    /**
     * Get salePrice
     *
     * @return string
     */
    public function getSalePrice()
    {
        return $this->salePrice;
    }

    /**
     * Set salesTax
     *
     * @param float $salesTax
     *
     * @return MenuItem
     */
    public function setSalesTax($salesTax)
    {
        $this->salesTax = $salesTax;

        return $this;
    }

    /**
     * Get salesTax
     *
     * @return float
     */
    public function getSalesTax()
    {
        return $this->salesTax;
    }

    protected function getUploadRootDir()
    {
        // the absolute directory siteLogo where uploaded
        // documents should be saved
        return __DIR__.'/../../../uploads/items/';
    }

    /**
     * Sets file.
     *
     * @param UploadedFile $file
     */
    public function setItemFeaturedImageFile(UploadedFile $file)
    {
        $this->itemFeaturedImageFile = $file;
    }

    /**
     * Get file.
     *
     * @return UploadedFile
     */
    public function getItemFeaturedImageFile()
    {
        return $this->itemFeaturedImageFile;
    }

    public function setItemFeaturedImage($itemFeaturedImage){
        $this->itemFeaturedImage=$itemFeaturedImage;
        return $this;
    }

    public function getItemFeaturedImage()
    {
        return $this->itemFeaturedImage;
    }

    public function preFeaturedImageUpload()
    {
        if (null !== $this->itemFeaturedImageFile) {
            // do whatever you want to generate a unique name
            $this->itemFeaturedImage = $this->itemSlug.'.'.$this->itemFeaturedImageFile->guessExtension();
        }
    }
    

    protected function getFeaturedImageUploadDir()
    {
        // get rid of the __DIR__ so it doesn't screw up
        // when displaying uploaded doc/image in the view.
        return $this->getUploadRootDir()."images/";
    }


    public function iconUpload()
    {
        $this->preFeaturedImageUpload();
        // the file property can be empty if the field is not required
        if (null === $this->getItemFeaturedImageFile()) {
            return;
        }
        $temp1=$this->getItemFeaturedImageFile();
        
        
       // $this->siteLogo = uniqid().'.'.$this->file->guessExtension();
        // use the original file name here but you should
        // sanitize it at least to avoid any security issues

        // move takes the target directory and then the
        // target filename to move to
        
        
        $temp1->move(
            $this->getFeaturedImageUploadDir(),
            $this->itemFeaturedImage//getFile()->getClientOriginalName()
        );
        
        // clean up the file property as you won't need it anymore
        $this->itemFeaturedImageFile = null;

        unset($this->itemFeaturedImageFile);
    }


    public function getAbsoluteItemFeaturedImagePath()
    {
        return null === $this->itemFeaturedImage
            ? null
            : $this->getFeaturedImageUploadDir().'/'.$this->itemFeaturedImage;
    }

    public function removeFeaturedImageUpload()
    {
        if($this->itemFeaturedImage!="default.png" || $this->itemFeaturedImage!=null)
            if ($file = $this->getAbsoluteItemFeaturedImagePath()) {
                unlink($file);
            }
    }

    /**
     * Set isActive
     *
     * @param boolean $isActive
     *
     * @return MenuItem
     */
    public function setIsActive($isActive)
    {
        $this->isActive = $isActive;

        return $this;
    }

    /**
     * Get isActive
     *
     * @return boolean
     */
    public function getIsActive()
    {
        return $this->isActive;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->priceVariation = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add priceVariation
     *
     * @param \AppBundle\Entity\PriceVariation $priceVariation
     *
     * @return MenuItem
     */
    public function addPriceVariation(\AppBundle\Entity\PriceVariation $priceVariation)
    {
        $priceVariation->setMenuItem($this);
        $this->priceVariation[] = $priceVariation;

        return $this;
    }

    /**
     * Remove priceVariation
     *
     * @param \AppBundle\Entity\PriceVariation $priceVariation
     */
    public function removePriceVariation(\AppBundle\Entity\PriceVariation $priceVariation)
    {
        $this->priceVariation->removeElement($priceVariation);
    }

    /**
     * Get priceVariation
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPriceVariation()
    {
        return $this->priceVariation;
    }

    /**
     * Set category
     *
     * @param \AppBundle\Entity\SubCategory $category
     *
     * @return MenuItem
     */
    public function setCategory(\AppBundle\Entity\SubCategory $category = null)
    {
        $this->category = $category;

        return $this;
    }

    /**
     * Get category
     *
     * @return \AppBundle\Entity\SubCategory
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * Add extraPackage
     *
     * @param \AppBundle\Entity\ExtraPackage $extraPackage
     *
     * @return MenuItem
     */
    public function addExtraPackage(\AppBundle\Entity\ExtraPackage $extraPackage)
    {
        $this->extraPackage[] = $extraPackage;

        return $this;
    }

    /**
     * Remove extraPackage
     *
     * @param \AppBundle\Entity\ExtraPackage $extraPackage
     */
    public function removeExtraPackage(\AppBundle\Entity\ExtraPackage $extraPackage)
    {
        $this->extraPackage->removeElement($extraPackage);
    }

    /**
     * Get extraPackage
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getExtraPackage()
    {
        return $this->extraPackage;
    }

    /**
     * Set vegType
     *
     * @param string $vegType
     *
     * @return MenuItem
     */
    public function setVegType($vegType)
    {
        $this->vegType = $vegType;

        return $this;
    }

    /**
     * Get vegType
     *
     * @return string
     */
    public function getVegType()
    {
        return $this->vegType;
    }
}

<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CustomerOrderItems
 *
 * @ORM\Table(name="customer_order_items")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\CustomerOrderItemsRepository")
 */
class CustomerOrderItems
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="itemId", type="string", length=255)
     */
    private $itemId;

    /**
     * @var string
     *
     * @ORM\Column(name="itemName", type="string", length=255)
     */
    private $itemName;

    /**
     * @var string
     *
     * @ORM\Column(name="priceVariavtion", type="string", length=255, nullable=true)
     */
    private $priceVariavtion;

    /**
     * @var string
     *
     * @ORM\Column(name="price", type="string", length=255)
     */
    private $price;

    /**
     * @var string
     *
     * @ORM\Column(name="quantity", type="string", length=255)
     */
    private $quantity;

    /**
     * @var string
     *
     * @ORM\Column(name="actualAmount", type="string", length=255)
     */
    private $actualAmount;

    /**
     * @var string
     *
     * @ORM\Column(name="extraAmount", type="string", length=255)
     */
    private $extraAmount=0;

    /**
     * @var string
     *
     * @ORM\Column(name="tax", type="string", length=255)
     */
    private $tax="0";

    /**
     * @var string
     *
     * @ORM\Column(name="discount", type="string", length=255)
     */
    private $discount="0";

    /**
     * @var string
     *
     * @ORM\Column(name="subTotal", type="string", length=255)
     */
    private $subTotal;

    /**
     * @ORM\ManyToOne(targetEntity="CustomerOrder", inversedBy="customerOrderItems")
     *@ORM\JoinColumn(name="order_d", referencedColumnName="id")
     */
    private $customerOrder;

    /**
     *@ORM\OneToMany(targetEntity="OrderItemExtras", mappedBy="customerOrderItems", cascade={"persist","remove"})
     */
    private $orderItemExtras;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set itemId
     *
     * @param string $itemId
     *
     * @return CustomerOrderItems
     */
    public function setItemId($itemId)
    {
        $this->itemId = $itemId;

        return $this;
    }

    /**
     * Get itemId
     *
     * @return string
     */
    public function getItemId()
    {
        return $this->itemId;
    }

    /**
     * Set itemName
     *
     * @param string $itemName
     *
     * @return CustomerOrderItems
     */
    public function setItemName($itemName)
    {
        $this->itemName = $itemName;

        return $this;
    }

    /**
     * Get itemName
     *
     * @return string
     */
    public function getItemName()
    {
        return $this->itemName;
    }

    /**
     * Set priceVariavtion
     *
     * @param string $priceVariavtion
     *
     * @return CustomerOrderItems
     */
    public function setPriceVariavtion($priceVariavtion)
    {
        $this->priceVariavtion = $priceVariavtion;

        return $this;
    }

    /**
     * Get priceVariavtion
     *
     * @return string
     */
    public function getPriceVariavtion()
    {
        return $this->priceVariavtion;
    }

    /**
     * Set price
     *
     * @param string $price
     *
     * @return CustomerOrderItems
     */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     * @return string
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set quantity
     *
     * @param string $quantity
     *
     * @return CustomerOrderItems
     */
    public function setQuantity($quantity)
    {
        $this->quantity = $quantity;

        return $this;
    }

    /**
     * Get quantity
     *
     * @return string
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * Set tax
     *
     * @param string $tax
     *
     * @return CustomerOrderItems
     */
    public function setTax($tax)
    {
        $this->tax = $tax;

        return $this;
    }

    /**
     * Get tax
     *
     * @return string
     */
    public function getTax()
    {
        return $this->tax;
    }

    /**
     * Set discount
     *
     * @param string $discount
     *
     * @return CustomerOrderItems
     */
    public function setDiscount($discount)
    {
        $this->discount = $discount;

        return $this;
    }

    /**
     * Get discount
     *
     * @return string
     */
    public function getDiscount()
    {
        return $this->discount;
    }

    /**
     * Set subTotal
     *
     * @param string $subTotal
     *
     * @return CustomerOrderItems
     */
    public function setSubTotal($subTotal)
    {
        $this->subTotal = $subTotal;

        return $this;
    }

    /**
     * Get subTotal
     *
     * @return string
     */
    public function getSubTotal()
    {
        return $this->subTotal;
    }

    /**
     * Set customerOrder
     *
     * @param \AppBundle\Entity\CustomerOrder $customerOrder
     *
     * @return CustomerOrderItems
     */
    public function setCustomerOrder(\AppBundle\Entity\CustomerOrder $customerOrder = null)
    {
        $this->customerOrder = $customerOrder;

        return $this;
    }

    /**
     * Get customerOrder
     *
     * @return \AppBundle\Entity\CustomerOrder
     */
    public function getCustomerOrder()
    {
        return $this->customerOrder;
    }

    /**
     * Set actualAmount
     *
     * @param string $actualAmount
     *
     * @return CustomerOrderItems
     */
    public function setActualAmount($actualAmount)
    {
        $this->actualAmount = $actualAmount;

        return $this;
    }

    /**
     * Get actualAmount
     *
     * @return string
     */
    public function getActualAmount()
    {
        return $this->actualAmount;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->orderItemExtras = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add orderItemExtra
     *
     * @param \AppBundle\Entity\OrderItemExtras $orderItemExtra
     *
     * @return CustomerOrderItems
     */
    public function addOrderItemExtra(\AppBundle\Entity\OrderItemExtras $orderItemExtra)
    {
        $this->orderItemExtras[] = $orderItemExtra;

        return $this;
    }

    /**
     * Remove orderItemExtra
     *
     * @param \AppBundle\Entity\OrderItemExtras $orderItemExtra
     */
    public function removeOrderItemExtra(\AppBundle\Entity\OrderItemExtras $orderItemExtra)
    {
        $this->orderItemExtras->removeElement($orderItemExtra);
    }

    /**
     * Get orderItemExtras
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getOrderItemExtras()
    {
        return $this->orderItemExtras;
    }

    /**
     * Set extraAmount
     *
     * @param string $extraAmount
     *
     * @return CustomerOrderItems
     */
    public function setExtraAmount($extraAmount)
    {
        $this->extraAmount = $extraAmount;

        return $this;
    }

    /**
     * Get extraAmount
     *
     * @return string
     */
    public function getExtraAmount()
    {
        return $this->extraAmount;
    }
}

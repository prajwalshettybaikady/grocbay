<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class ReportsController extends Controller
{
    
    public function deliveryBoyAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('AppBundle:Admin:Reports/deliveryBoy.html.twig');
    }
    
    public function restaurantAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('AppBundle:Admin:Reports/restaurants.html.twig');
    }
    
    public function customerAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('AppBundle:Admin:Reports/customer.html.twig');
    }
    
    public function orderAction(Request $request)
    {  
        $myExtend="Admin";
        $user = $this->get('security.token_storage')->getToken()->getUser();
        if( $request->get('_route') == "manage_restaurant_order_report"){
            $myExtend="Restaurant";
        }
        // replace this example code with whatever you need
        return $this->render('AppBundle:Admin:Reports/order.html.twig',array(
            'myExtend'=>$myExtend
        ));
    }
}

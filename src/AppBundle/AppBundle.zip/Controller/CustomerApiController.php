<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Customer;
use AppBundle\Entity\BillingAddress;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class CustomerApiController extends Controller
{
    public function preRegisterAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $result['status']=false;
        $result['data']=[];
        $result['type']="new";
        $edit=false;
        //receive the data
        $mobileNumber=$request->get('mobileNumber');
        $tokenId=$request->get('tokenId');
        $helper=$this->container->get('function_helper');

        if($helper->testMobile($mobileNumber)){ $result['data'][]="Invalid mobile number"; }

        if($result['data'] == []){
           
            $customer=$em->getRepository('AppBundle:Customer')->findByMobileNumber($mobileNumber);
            $result['status']=true;
            $otp = mt_rand(1000,9999);
            $session = $request->getSession();
            $session->set($mobileNumber,$otp);
            $result['data']['otp']=$otp;
            $helper->sendOtp($mobileNumber,$otp);
            if($customer!=[]){
                $customer=$customer[0];
                $result['type']="old";
                if($customer->getIsActive()){
                    $result['active']=true;
                }else{
                    $result['active']=false;
                }
                $uniqueId=uniqid('customer',true);
                $customer->setApiKey($uniqueId);
                $customer->setOtp($otp);
                if($tokenId!=null){
                    $customer->setRegistrationKey($tokenId);
                }
                $result['data']['apiKey']=$customer->getApiKey();
                $em->flush();
            }
        }

        return $result;
    }

    public function resendOtpAction(Request $request){
        $em = $this->getDoctrine()->getManager();
        $result['status']=false;
        $result['data']=[];
        //receive the data
        $mobileNumber=$request->get('mobileNumber');
        $helper=$this->container->get('function_helper');

        if($helper->testMobile($mobileNumber)){ $result['data'][]="Invalid mobile number"; }

        if($result['data'] == []){
            $session = $request->getSession();
            if($session->get($mobileNumber)!=null){
                $helper->sendOtp($mobileNumber,$session->get($mobileNumber));
                $result['data'][]="resent successfully";
                $result['status']=true;
            }else{
                $result['data'][]="Session expired";
            }
        }
        return $result;
    }

    public function registerAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $result['status']=false;
        $result['data']=[];
        $edit=false;
        //receive the data
        $username=$request->get('username');
        $email=$request->get('email');
        $path=$request->get('path');
        $mobileNumber=$request->get('mobileNumber');
        $tokenId=$request->get('tokenId');
        $helper=$this->container->get('function_helper');
        $customer=new Customer();
        
        $helper=$this->container->get('function_helper');

        if($helper->testNull($username)){ $result['data'][]="Invalid user name"; }
        if($helper->testMobile($mobileNumber)){ $result['data'][]="Invalid mobile number"; }
        if($helper->testOptionalEmail($email)){ $result['data'][]="Invalid email"; }

        if($result['data'] == []){
            $customer->setUsername($username);
            $customer->setEmail($email);
            $customer->setPath($path);
            $customer->setMobileNumber($mobileNumber);
            $uniqueId=uniqid('customer',true);
            $customer->setApiKey($uniqueId);
            if($tokenId!=null){
                $customer->setRegistrationKey($tokenId);
            }

            try{
                $em->persist($customer);
                $em->flush();
                $result['status']=true;
                $result['data']['apiKey']=$customer->getApiKey();
            }catch(\Exception $e){
                $result['data'][]=$e->getMessage();
            }
        }

        return $result;
    }

    
    public function changePasswordAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $result['status']=false;
        $result['data']="";
        $apiKey=$request->get('apiKey');
        $helper=$this->container->get('function_helper');
        $customer=null;
        $apiResult=$helper->authenticateCustomer($apiKey);
        if($apiResult['data']==[]){
            $customer=$apiResult['customer'];
        }else{
            $result['data']=$apiResult['data'];
            return $result;
        }

        $password=$request->get('password');

        if($password!=null):
            if($customer->getIsActive()){
                $uniqueId=uniqid('customer',true);
                $customer->setApiKey($uniqueId);
                $customer->setPassword($password);
                $em->flush();
                $result['status']=true;
                $result['data'][]=$uniqueId;
            }else{
                $result['data'][]="Account disabled";
            }
        else:
            $result['data'][]="Invalid password";
        endif;

        return $result;
    }

    
    public function verifyMobileAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $result['status']=false;
        $result['data']=[];
        $mobileNumber = $request->get('mobileNumber');
        if($mobileNumber!=null){
            $customer=$em->getRepository('AppBundle:Customer')->findByMobileNumber($mobileNumber);
            if($customer==[]){
                $result['data'][]="Please provide valid mobile number";
            }else{
                $customer=$customer[0];
                $uniqueId=uniqid('reset',true);
                $customer->setApiKey($uniqueId);
                $otp = mt_rand(1000,9999);
                $customer->setOtp($otp);
                $em->flush();
                $result['data']['apiKey']=$uniqueId;
                $result['data']['otp']=$otp;
                $result['status']=true;
            }
        }else{
            $result['data'][]="Please provide valid mobile number";
        }
        return $result;
    }

    
    public function addAddressAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $helper=$this->container->get('function_helper');
        $result['status']=false;
        $result['data']=[];
        $edit=false;

        //receive data
        $addressType=$request->get('addressType');
        $fullName=$request->get('fullName');
        $address=$request->get('address');
        $lattittude=$request->get('latitude');
        $longitude=$request->get('longitude');
        $addressID=$request->get('addressId');
        $billingAddress=null;

        if($helper->testNull($addressType)){ $result['data'][]="Invalid address type"; }
        if($helper->testNull($fullName)){ $result['data'][]="Invalid full name"; }
        if($helper->testNull($address)){ $result['data'][]="Invalid address"; }
        if($helper->testNull($lattittude)){ $result['data'][]="Invalid lattittude"; }
        if($helper->testNull($longitude)){ $result['data'][]="Invalid longitude"; }

        //authentication
        $apiKey=$request->get('apiKey');

        $apiResult=$helper->authenticateCustomer($apiKey);
        if($apiResult['data']==[]){
            $customer=$apiResult['customer'];
        }else{
            $result['data']=$apiResult['data'];
            return $result;
        }

        //address edit authorise
        if($addressID!=null){
            $edit=true;
            $billingAddress=$em->getRepository('AppBundle:BillingAddress')->find($addressID);
            if($billingAddress==null){
                $result['data'][]="Invalide address id";
                return $result;
            }
        }else{
            $billingAddress = new BillingAddress();
            $billingAddress->setCustomer($customer);
        }
        $billingAddress->setAddressType($addressType);
        $billingAddress->setFullName($fullName);
        $billingAddress->setAddress($address);
        $billingAddress->setLattitude($lattittude);
        $billingAddress->setLogingitude($longitude);

        if($result['data']==[]){
            if(!$edit){
                $em->persist($billingAddress);
            }
            try{
                $em->flush();
                $result['data'][]="Address updated successfully";
                $result['addressId']=$billingAddress->getId();
                $result['status']=true;
            }catch(\Exception $e){
                $result['data'][]=$e->getMessage();
            }
        }
        return $result;
    }

    
    public function removeAddressAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $helper=$this->container->get('function_helper');
        $result['status']=false;
        $result['data']=[];
        $addressID=$request->get('addressId');

         //authentication
         $apiKey=$request->get('apiKey');

         $apiResult=$helper->authenticateCustomer($apiKey);
         if($apiResult['data']==[]){
             $customer=$apiResult['customer'];
         }else{
             $result['data']=$apiResult['data'];
             return $result;
         }
 

        if($addressID!=null){
            $edit=true;
            $billingAddress=$em->getRepository('AppBundle:BillingAddress')->find($addressID);
            if($billingAddress==null){
                $result['data'][]="Invalide address id";
            }else{
                $em->remove($billingAddress);
                $em->flush();
                $result['status']=true;
                $result['data'][]="Address removed successfully";
            }
        }else{
            $result['data'][]="Invalide address id";
        }
        return $result;
    }

    
    public function getBasicProfileAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $helper=$this->container->get('function_helper');
        $result['status']=false;
        $result['data']=[];

         //authentication
         $apiKey=$request->get('apiKey');
        $customer=null;
         $apiResult=$helper->authenticateCustomer($apiKey);
         if($apiResult['data']==[]){
             $customer=$apiResult['customer'];
         }else{
             $result['data']=$apiResult['data'];
             return $result;
         }

         $user=$em->createQueryBuilder()
                            ->select('customer','address')
                            ->from('AppBundle:Customer', 'customer')
                            ->leftJoin('customer.billingAddress','address')
                            ->andWhere('customer.id = :customerId')
                            ->setParameter('customerId',$customer->getId())
                            ->getQuery()
                            ->getArrayResult();
        if($user!=[]){
            $result['data'][]=$user[0];
            $result['status']=true;
        }else{
            $result['data'][]='something went wrong';
        }
        return $result;
    }

    public function getOrderListAction(Request $request){
        $em = $this->getDoctrine()->getManager();
        $helper=$this->container->get('function_helper');
        $result['status']=false;
        $result['data']=[];

        //receive the restaurant orders
        $status=$request->get('status');
        $customer=null;
        $apiKey=$request->get('apiKey');
        $apiResult=$helper->authenticateCustomer($apiKey);
        if($apiResult['data']==[]){
            $customer=$apiResult['customer'];
        }else{
            $result['data']=$apiResult['data'];
            return $result;
        }

        if($result['data']!=[]){
            return $result;
        }

        $order=$em->createQueryBuilder()
                ->select('customerOrder','item','customer')
                ->from('AppBundle:CustomerOrder', 'customerOrder')
                ->leftJoin('customerOrder.customer','customer')
                ->leftJoin('customerOrder.customerOrderItems','item')
                ->where('customer.id = :customerId')
                ->setParameter('customerId',$customer->getId());

        $order=$order->orderBy('customerOrder.orderDate','DESC')
                ->getQuery()
                ->getArrayResult();
        $result['status']=true;
        $result['data']=$order;
        return $result;
    }
}

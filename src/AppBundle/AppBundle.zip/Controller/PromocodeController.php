<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Promocode;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class PromocodeController extends Controller
{
    public function addnewAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $promocodeId=$request->get('edid');
        $promocode = new Promocode();
        if($promocodeId!=null){
            $promo = $em->getRepository('AppBundle:Promocode')->find($promocodeId);
            if($promo instanceof Promocode){
                $promocode = $promo;
                $promocode->setStartDate($promocode->getStartDate()->format('d-m-Y'));
                $promocode->setEndDate($promocode->getEndDate()->format('d-m-Y'));
            }else{
                $request->getSession()->getFlashBag()->add('error',"Invalid attempt.");
                return $this->redirectToRoute('add_new_promocode');
            }
        }
        $form = $this->createForm('AppBundle\Form\PromocodeType', $promocode);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            try{
                $promocode->setStartDate(new \Datetime($promocode->getStartDate()));
                $promocode->setEndDate(new \Datetime($promocode->getEndDate()));
                $em->persist($promocode);
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Promocode suucessfully updated to the list");
                return $this->redirectToRoute('add_new_promocode',array('edid'=>$promocode->getId()));
            }catch(\Exception $e){
                $request->getSession()->getFlashBag()->set('error',$e->getMessage());
            }
        }
        return $this->render('AppBundle:Admin:Promocode/promoForm.html.twig', [
            'form'=>$form->createView(),
            'promocode'=>$promocode
        ]);
    }

    public function listPromoAction(Request $request){
        $em = $this->getDoctrine()->getManager();
        $promocodes = $em->getRepository('AppBundle:Promocode')->findAll();
        
        return $this->render('AppBundle:Admin:Promocode/promoList.html.twig', [
            'promocodes'=>$promocodes
        ]);
    }
}

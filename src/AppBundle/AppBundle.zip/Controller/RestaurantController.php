<?php

namespace AppBundle\Controller;

use AppBundle\Entity\MenuItem;
use AppBundle\Entity\Restaurants;
use AppBundle\Entity\ExtraPackage;
use AppBundle\Entity\PackageExtras;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class RestaurantController extends Controller
{

    public function loginAction(Request $request){
        return $this->render('AppBundle:Restaurant:User/login.html.twig');
    }

    public function dashboardAction(Request $request){
        return $this->render('AppBundle:Restaurant:User/dashboard.html.twig');
    }

    public function addMenuItemAction(Request $request){
        $myExtend="Admin";
        $em = $this->getDoctrine()->getManager();
        $menuItem = new MenuItem();
        $form = $this->createForm('AppBundle\Form\MenuItemType', $menuItem);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            try{
                $menuItem->setItemSlug(str_replace(" ","-",strtolower($menuItem->getItemName())));
                $em->persist($menuItem);
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Menu item added suucessfully ");
                
            }catch(\Exception $e){
                $request->getSession()->getFlashBag()->add('error',$e->getMessage());
            }
        }

        return $this->render('AppBundle:Restaurant:Menu/addNew.html.twig',array(
            'form' => $form->createView(),
            'menuItem' => $menuItem,
            'myExtend' => $myExtend,
        ));
    }

    public function viewMenuItemAction(Request $request){
        $em = $this->getDoctrine()->getManager();

        $menus=$em->getRepository('AppBundle:MenuItem')->findAll();

        return $this->render('AppBundle:Restaurant:Menu/viewMenu.html.twig',array(
            'menuItems' => $menus,
        ));
    }

    public function viewMenuItemDetailAction(Request $request, MenuItem $menuItem){
        $myExtend="Admin";
        $em = $this->getDoctrine()->getManager();
        $flag=false;
        $editId=$request->get('editId');
        if($editId!=null){
            $extraPackage=$em->getRepository('AppBundle:ExtraPackage')->find($editId);
            if($extraPackage instanceof ExtraPackage){
                $flag=true;
            }
        }
        
        $deleteId=$request->get('deleteId');
        if($deleteId!=null){
            $extraPackage=$em->getRepository('AppBundle:ExtraPackage')->find($deleteId);
            if($extraPackage instanceof ExtraPackage){
                $em->remove($extraPackage);
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Extra package deleted suucessfully ");
                return $this->redirectToRoute('restaurant_view_single_menu_item',array('id'=>$menuItem->getId()));
            }
        }
        if($flag==false){
            $extraPackage = new ExtraPackage();
            $packageExtras = new PackageExtras();
            $extraPackage->addPackageExtra($packageExtras);
            $extraPackage->setMenuItem($menuItem);
        }
        $form = $this->createForm('AppBundle\Form\ExtraPackageType', $extraPackage);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            try{
                if($flag==false){
                    $em->persist($extraPackage);
                }
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Extra package updated suucessfully ");
                return $this->redirectToRoute($redLink,array('id'=>$menuItem->getId()));
            }catch(\Exception $e){
                $request->getSession()->getFlashBag()->add('error',$e->getMessage());
            }
        }
        $extraPackages=$menuItem->getExtraPackage();
        return $this->render('AppBundle:Restaurant:Menu/viewItem.html.twig',array(
            'menuItem' => $menuItem,
            'form' => $form->createView(),
            'myExtend'=>$myExtend,
            'extraPackages' => $extraPackages,
            'flag'=>$flag
        ));
    }

    public function editMenuItemAction(Request $request, MenuItem $menuItem){
        $myExtend="Admin";
        $em = $this->getDoctrine()->getManager();
        $form = $this->createForm('AppBundle\Form\MenuItemType', $menuItem);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            try{
                $menuItem->setItemSlug(str_replace(" ","-",strtolower($menuItem->getItemName())));
                $em->persist($menuItem);
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Menu item added suucessfully ");
                
            }catch(\Exception $e){
                $request->getSession()->getFlashBag()->add('error',$e->getMessage());
            }
        }

        return $this->render('AppBundle:Restaurant:Menu/addNew.html.twig',array(
            'form' => $form->createView(),
            'menuItem' => $menuItem,
            'myExtend'=>$myExtend
        ));
    }
}

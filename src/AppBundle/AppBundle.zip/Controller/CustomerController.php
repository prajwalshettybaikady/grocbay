<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Customer;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class CustomerController extends Controller
{
    
    public function listAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $customers = $em->getRepository('AppBundle:Customer')->findAll();
        return $this->render('AppBundle:Admin:Customers/customerList.html.twig', [
            'customers'=>$customers,
        ]);
    }
    
    public function viewAction(Request $request,Customer $customer)
    {
        $em = $this->getDoctrine()->getManager();
        return $this->render('AppBundle:Admin:Customers/customerView.html.twig', [
            'customer'=>$customer,
        ]);
    }
}

<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Restaurants;
use AppBundle\Entity\CustomerOrder;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class OrderController extends Controller
{
    
    public function reportAction(Request $request)
    {        
        $em = $this->getDoctrine()->getManager();
        $request->getSession()->set('prev-path',$request->getRequestUri());
        $result['data']=[];
        $message="All";
        $status=$request->get('status');
        if($status=="pending"){
            $status="received";
        }
        
        $order=$em->createQueryBuilder()
                ->select('customerOrder')
                ->from('AppBundle:CustomerOrder', 'customerOrder')
                ->leftJoin('customerOrder.customerOrderItems','item');
        if($status == "pending"){
            $message="Pending";
            $order=$order->andWhere('customerOrder.orderStatus = :status')
                                    ->setParameter('status','received');
        }elseif($status == "delayed"){
            $message="Delayed";
            $dateThreshold = new \DateTime();
            $dateThreshold->modify("-15minutes");
            $order=$order->andWhere('(customerOrder.orderStatus = :pending and customerOrder.orderDate < :timeGap) or (customerOrder.orderStatus = :processing and customerOrder.proccessTime < :timeGap) or (customerOrder.orderStatus = :dispatched and customerOrder.dispatchTime < :timeGap) or (customerOrder.orderStatus = :onway and customerOrder.onwayTime < :timeGap) or (customerOrder.orderStatus = :ready and customerOrder.readyTime < :timeGap)')
                                    ->setParameter('pending','received')
                                    ->setParameter('processing','processing')
                                    ->setParameter('dispatched','dispatched')
                                    ->setParameter('onway','onway')
                                    ->setParameter('ready','ready')
                                    ->setParameter('timeGap',$dateThreshold);
        }elseif($status == "processing"){
            $message="Processing";
            $order=$order->andWhere('customerOrder.orderStatus = :status')
                                    ->setParameter('status','processing');
        }elseif($status == "ready"){
            $message="Item ready";
            $order=$order->andWhere('customerOrder.orderStatus = :status')
                                    ->setParameter('status','ready');
        }elseif($status == "out-for-delivery"){
            $message="Out for delivery";
            $order=$order->andWhere('customerOrder.orderStatus = :status')
                                    ->setParameter('status','dispatched');
        }elseif($status == "onway"){
            $message="Item on the way";
            $order=$order->andWhere('customerOrder.orderStatus = :status')
                                    ->setParameter('status','onway');
        }elseif($status == "delivered"){
            $message="Delivered";
            $order=$order->andWhere('customerOrder.orderStatus = :status')
                                    ->setParameter('status','delivered');
        }elseif($status == "completed"){
            $message="Completed";
            $order=$order->andWhere('customerOrder.orderStatus = :status')
                                    ->setParameter('status','completed');
        }elseif($status == "cancelled"){
            $message="Cancelled";
            $order=$order->andWhere('customerOrder.orderStatus = :status')
                                    ->setParameter('status','cancelled');
        }else{

        }

        $order=$order->addOrderBy('customerOrder.sortTime','DESC')
                    ->getQuery()
                    ->getResult();

        if($result['data']!=[]){
            $order=[];
        }
        return $this->render('AppBundle:Admin:Orders/orderList.html.twig', [
            'message'=>$message,
            'orders'=>$order,
        ]);
    }

    public function editOrderAction(Request $request, CustomerOrder $customerOrder){
        $result['data']=[];
        $myExtend="Admin";
        $cancelledFlag=false;
        $helper=$this->container->get('function_helper');
        $trans=$this->container->get('transaction_helper');
        $oldOrderStatus=$customerOrder->getOrderStatus();
        $form = $this->createForm('AppBundle\Form\CustomerOrderType', $customerOrder);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            
            try{
                if($oldOrderStatus != $customerOrder->getOrderStatus()){
                    if($customerOrder->getOrderStatus() == 'processing'){
                        $customerOrder->setProccessTime(new \Datetime());
                        if($customerOrder->getCustomer()->getRegistrationKey()!=null){  
                            $helper->sendGCM('Your order is processing now.',$customerOrder->getCustomer()->getRegistrationKey(),'Hold on!');
                        }
                    }elseif($customerOrder->getOrderStatus() == 'ready'){
                        $customerOrder->setReadyTime(new \Datetime());
                    }elseif($customerOrder->getOrderStatus() == 'dispatched'){
                        $customerOrder->setDispatchTime(new \Datetime());
                    }elseif($customerOrder->getOrderStatus() == 'onway'){
                        $customerOrder->setDispatchTime(new \Datetime());
                        if($customerOrder->getCustomer()->getRegistrationKey()!=null){  
                            $helper->sendGCM('Your order is on the way.',$customerOrder->getCustomer()->getRegistrationKey(),'Hurray!');
                        }
                    }elseif($customerOrder->getOrderStatus() == 'delivered'){
                        $customerOrder->setDeliveryTime(new \Datetime());
                        $customerOrder->setPaymentStatus("paid");

                        if($customerOrder->getCustomer()->getRegistrationKey()!=null){  
                            $helper->sendGCM('Your order is delivered.',$customerOrder->getCustomer()->getRegistrationKey(),'Thank you!');
                        }
                    }elseif($customerOrder->getOrderStatus() == 'completed'){
                        $customerOrder->setCompleteTime(new \Datetime());
                    }elseif($customerOrder->getOrderStatus() == 'cancelled'){
                        $cancelledFlag=true;
                        $customerOrder->setCancelTime(new \Datetime());
                    }
                }

                $em = $this->getDoctrine()->getManager();
                $customerOrder->setSortTime(new \Datetime());
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Order updated successfully");
                return $this->redirectToRoute('restaurant_orders_panel_update',array('id'=>$customerOrder->getId()));
            }catch(\Exception $e){

                $request->getSession()->getFlashBag()->set('error',$e->getMessage());
              
            }
        }
        return $this->render('AppBundle:Admin:Orders/orderForm.html.twig', array(
            'order' => $customerOrder,
            'form' => $form->createView(),
            'myExtend'=>$myExtend,
        ));
     }
}

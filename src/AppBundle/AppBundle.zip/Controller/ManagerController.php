<?php

namespace AppBundle\Controller;

use AppBundle\Entity\WorkArea;
use AppBundle\Entity\OrderType;
use AppBundle\Entity\SubCategory;
use AppBundle\Entity\RestaurantType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class ManagerController extends Controller
{
    public function workAreaAction(Request $request){
        $em = $this->getDoctrine()->getManager();
        $editId=$request->get('editable');
        $deleteId=$request->get('deletable');
        $edit=false;
        $workArea = new WorkArea();
        if($editId!=null){
            $area = $em->getRepository('AppBundle:WorkArea')->find($editId);
            if($area instanceof WorkArea){
                $workArea = $area;
                $edit=true;
            }
        }
        
        if($deleteId!=null){
            $area = $em->getRepository('AppBundle:WorkArea')->find($deleteId);
            if($area instanceof WorkArea){
                $em->remove($area);
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Area suucessfully removed from the list");
                return $this->redirectToRoute('work_area_manager');
            }
        }
        $form = $this->createForm('AppBundle\Form\WorkAreaType', $workArea);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            try{
                if($edit == false){
                    $em->persist($workArea);
                }
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Area suucessfully updated in the list");
                return $this->redirectToRoute('work_area_manager');
            }catch(\Exception $e){

                    $request->getSession()->getFlashBag()->set('error',$e->getMessage());
            }
        }
        $areas = $em->getRepository('AppBundle:WorkArea')->findAll();
        return $this->render('AppBundle:Admin:AppManager/workArea.html.twig',array(
            'form'=>$form->createView(),
            'workArea'=>$workArea,
            'areas'=>$areas,
        ));
    }


    public function restaurantTypeAction(Request $request){
        $em = $this->getDoctrine()->getManager();
        $editId=$request->get('editable');
        $deleteId=$request->get('deletable');
        $edit=false;
        $restaurantType = new RestaurantType();
        if($editId!=null){
            $type = $em->getRepository('AppBundle:RestaurantType')->find($editId);
            if($type instanceof RestaurantType){
                $restaurantType = $type;
                $edit=true;
            }
        }
        
        if($deleteId!=null){
            $type = $em->getRepository('AppBundle:RestaurantType')->find($deleteId);
            if($type instanceof RestaurantType){
                $em->remove($type);
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Restaurant Type suucessfully removed from the list");
                return $this->redirectToRoute('work_restaurant_type_manager');
            }
        }
        $form = $this->createForm('AppBundle\Form\RestaurantTypeType', $restaurantType);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            try{
                if($restaurantType->getIconFile()!=null){
                    if($restaurantType->getIconImage()!=null){
                        $restaurantType->removeIconUpload();
                    }
                    $restaurantType->iconUpload();
                }
                if($edit == false){
                    $em->persist($restaurantType);
                }
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Restaurant type suucessfully updated in the list");
                return $this->redirectToRoute('work_restaurant_type_manager');
            }catch(\Exception $e){

                    $request->getSession()->getFlashBag()->set('error',$e->getMessage());
            }
        }
        $types = $em->getRepository('AppBundle:RestaurantType')->findAll();
        return $this->render('AppBundle:Admin:AppManager/restaurantType.html.twig',array(
            'form'=>$form->createView(),
            'restaurantType'=>$restaurantType,
            'types'=>$types,
        ));
    }


    public function orderTypeAction(Request $request){
        $em = $this->getDoctrine()->getManager();
        $editId=$request->get('editable');
        $deleteId=$request->get('deletable');
        $edit=false;
        $orderType = new OrderType();
        if($editId!=null){
            $type = $em->getRepository('AppBundle:OrderType')->find($editId);
            if($type instanceof OrderType){
                $orderType = $type;
                $edit=true;
            }
        }
        
        if($deleteId!=null){
            $type = $em->getRepository('AppBundle:OrderType')->find($deleteId);
            if($type instanceof OrderType){
                $em->remove($type);
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Order Type suucessfully removed from the list");
                return $this->redirectToRoute('work_order_type_manager');
            }
        }
        $form = $this->createForm('AppBundle\Form\OrderTypeType', $orderType);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            try{
                if($edit == false){
                    $em->persist($orderType);
                }
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Order type suucessfully updated in the list");
                return $this->redirectToRoute('work_order_type_manager');
            }catch(\Exception $e){

                    $request->getSession()->getFlashBag()->set('error',$e->getMessage());
            }
        }
        $types = $em->getRepository('AppBundle:OrderType')->findAll();
        return $this->render('AppBundle:Admin:AppManager/orderType.html.twig',array(
            'form'=>$form->createView(),
            'orderType'=>$orderType,
            'types'=>$types,
        ));
    }

    public function listCategoryAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $categories = $em->getRepository('AppBundle:SubCategory')->findAll();
        return $this->render('AppBundle:Admin:AppManager/categoryList.html.twig',array('categories'=>$categories));
    }
    public function createCategoryAction(Request $request)
    {
        $category = new SubCategory();
        $form = $this->createForm('AppBundle\Form\SubCategoryType', $category);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            try{
                $category->setCategorySlug(str_replace(" ","-",strtolower($category->getCategoryName())));
                if($category->getIconFile()!=null){
                    $category->iconUpload();
                }
                if($category->getBannerFile()!=null){
                    $category->bannerUpload();
                }
                $em->persist($category);
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Category suucessfully added to the list");
                return $this->redirectToRoute('category_edit',array('id'=>$category->getId()));
            }catch(\Exception $e){

                    $request->getSession()->getFlashBag()->set('error',$e->getMessage());
            }
        }
        return $this->render('AppBundle:Admin:AppManager/categoryCreate.html.twig', array(
            'category' => $category,
            'form' => $form->createView(),
        ));
    }
    
    public function editCategoryAction(Request $request, SubCategory $category)
    {
        $form = $this->createForm('AppBundle\Form\SubCategoryType', $category);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            try{
                $category->setCategorySlug(str_replace(" ","-",strtolower($category->getCategoryName())));
                if($category->getIconFile()!=null){
                    if($category->getIconImage()!=null){
                        $category->removeIconUpload();
                    }
                    $category->iconUpload();
                }
                if($category->getBannerFile()!=null){
                    if($category->getBannerImage()!=null){
                        $category->removeBannerUpload();
                    }
                    $category->bannerUpload();
                }
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Category suucessfully added to the list");
                return $this->redirectToRoute('category_edit',array('id'=>$category->getId()));
            }catch(\Exception $e){

                    $request->getSession()->getFlashBag()->set('error',$e->getMessage());
            }
        }
        return $this->render('AppBundle:Admin:AppManager/categoryCreate.html.twig', array(
            'category' => $category,
            'form' => $form->createView(),
        ));
    }
}

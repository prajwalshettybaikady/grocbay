<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Advertisement;
use AppBundle\Entity\AdvertisementType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class AdvertisementController extends Controller
{
    public function manageTypeAction(Request $request)
    {
        
        $em = $this->getDoctrine()->getManager();
        $editId=$request->get('editable');
        $deleteId=$request->get('deletable');
        $edit=false;
        $advertisementType = new AdvertisementType();
        if($editId!=null){
            $type = $em->getRepository('AppBundle:AdvertisementType')->find($editId);
            if($type instanceof AdvertisementType){
                $advertisementType = $type;
                $edit=true;
            }
        }
        
        if($deleteId!=null){
            $type = $em->getRepository('AppBundle:AdvertisementType')->find($deleteId);
            if($type instanceof AdvertisementType){
                $em->remove($type);
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Advertisement Type suucessfully removed from the list");
                return $this->redirectToRoute('advertisement_type_manager');
            }
        }
        $form = $this->createForm('AppBundle\Form\AdvertisementTypeType', $advertisementType);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            try{
                if($edit == false){
                    $em->persist($advertisementType);
                }
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Advertisement type suucessfully updated in the list");
                return $this->redirectToRoute('advertisement_type_manager');
            }catch(\Exception $e){

                    $request->getSession()->getFlashBag()->set('error',$e->getMessage());
            }
        }
        $types = $em->getRepository('AppBundle:AdvertisementType')->findAll();
        return $this->render('AppBundle:Advertisement:manageType.html.twig',array(
            'form'=>$form->createView(),
            'types'=>$types,
        ));
    }

    public function createBannerAction(Request $request){
        $editId=$request->get('editId');
        $em = $this->getDoctrine()->getManager();
        $newAd=true;
        if($editId!=null){
            $newAd=false;
            $ad = $em->getRepository('AppBundle:Advertisement')->find($editId);
            if($ad instanceof Advertisement){
                $advertisement = $ad;
            }else{
                return $this->redirectToRoute('advertisement_manager');
            }
        }else{
            $advertisement = new Advertisement();
        }
        $form = $this->createForm('AppBundle\Form\AdvertisementType', $advertisement);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            try{
                if($advertisement->getBannerFile()!=null){
                    if($advertisement->getBannerImage()!=null){
                        $advertisement->removeBannerUpload();
                    }
                    $advertisement->bannerUpload();
                }
                if($newAd){
                    $em->persist($advertisement);
                }
                $em->flush();
                $request->getSession()->getFlashBag()->add('success',"Banner suucessfully added to the list");
                return $this->redirectToRoute('advertisement_new',array('editId'=>$advertisement->getId()));
            }catch(\Exception $e){

                    $request->getSession()->getFlashBag()->set('error',$e->getMessage());
            }
        }
        return $this->render('AppBundle:Advertisement:adForm.html.twig', array(
            'advertisement' => $advertisement,
            'form' => $form->createView(),
        ));
    }

    public function viewBannerAction(Request $request){
        $em = $this->getDoctrine()->getManager();
        $ads = $em->getRepository('AppBundle:Advertisement')->findAll();


        return $this->render('AppBundle:Advertisement:adList.html.twig', array(
            'ads' => $ads,
        ));
    }
}

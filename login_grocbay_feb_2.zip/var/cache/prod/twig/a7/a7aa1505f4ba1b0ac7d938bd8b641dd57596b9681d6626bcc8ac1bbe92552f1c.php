<?php

/* AppBundle:Admin:Stock/stock.html.twig */
class __TwigTemplate_89123aea281517914b60eb147634a49be20d687cfce42d3dc0e7a97f7abf358a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Stock/stock.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_daa4d07daf220b67b70a59b4f19109d175cfe0a29a88c9fd2fd283f2e4ae7e53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_daa4d07daf220b67b70a59b4f19109d175cfe0a29a88c9fd2fd283f2e4ae7e53->enter($__internal_daa4d07daf220b67b70a59b4f19109d175cfe0a29a88c9fd2fd283f2e4ae7e53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Stock/stock.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_daa4d07daf220b67b70a59b4f19109d175cfe0a29a88c9fd2fd283f2e4ae7e53->leave($__internal_daa4d07daf220b67b70a59b4f19109d175cfe0a29a88c9fd2fd283f2e4ae7e53_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a6cb2a9e2be72d4cbf557813b0ca9ddb52af11b6a1c49e4d6ea07c6142c2444c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6cb2a9e2be72d4cbf557813b0ca9ddb52af11b6a1c49e4d6ea07c6142c2444c->enter($__internal_a6cb2a9e2be72d4cbf557813b0ca9ddb52af11b6a1c49e4d6ea07c6142c2444c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<!-- Modal -->
<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Upload Menu Items</h4>
      </div>
      <div class=\"modal-body\">
        <p>
              <form action=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_stock_csv");
        echo "\" method=\"post\" enctype=\"multipart/form-data\">
                        <div class=\"row\">
                            
                        <div class=\"form-group col-md-12\">
                            <label>Date *</label>
                            <input type=\"text\" name=\"date\" class=\"form-control\" required=\"\" id = \"datepicker-13\" >

                        </div>
                                          
 <div class=\"form-group col-md-12\">
                            <label>Select CSV File *</label>
                            <input type=\"file\" name=\"file\" class=\"form-control\" required=\"\"   accept=\".csv\" >

                        </div>
                    </div>
                
                    <br>
<button type=\"submit\" class=\"btn btn-primary\">Upload</button>


      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                        <h3>Purchase Inwards</h3>
                        <span class=\"pull-right\">
                        <a  class=\"btn btn-primary btn-sm\" href=\"";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("export_stock_inwards");
        echo "\">Download CSV File</a> 
                           <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\">Import From Csv</a> 
                            <a href=\"";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_add_stock");
        echo "\" class=\"btn btn-primary btn-sm\"> Add New Stock</a>
                        </span>
                    </div>
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Details</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                 ";
        // line 68
        $context["id"] = 1;
        // line 69
        echo "                                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["menuItems"] ?? $this->getContext($context, "menuItems")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 70
            echo "
                                <tr>
                                     <td>";
            // line 72
            echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
            echo "</td>
                                    <td>";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "date", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 74
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "description", array()), "html", null, true);
            echo "</td>
                                    <td>
                                        <a href=\"";
            // line 76
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_stock_detail", array("id" => $this->getAttribute($context["product"], "ref", array()))), "html", null, true);
            echo "\" title=\"Manage item\" class=\"btn btn-primary btn-sm\">
                                            <i class=\"fa fa-eye\"></i>
                                        </a>
                                      
                                    </td>
                                </tr>
                                 ";
            // line 82
            $context["id"] = (($context["id"] ?? $this->getContext($context, "id")) + 1);
            // line 83
            echo "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 84
        echo "                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
";
        
        $__internal_a6cb2a9e2be72d4cbf557813b0ca9ddb52af11b6a1c49e4d6ea07c6142c2444c->leave($__internal_a6cb2a9e2be72d4cbf557813b0ca9ddb52af11b6a1c49e4d6ea07c6142c2444c_prof);

    }

    // line 93
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_31a83ae0c5961db3819c2162abf9b9db7bc5251a4a473ebe71a0f65a131b13a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31a83ae0c5961db3819c2162abf9b9db7bc5251a4a473ebe71a0f65a131b13a5->enter($__internal_31a83ae0c5961db3819c2162abf9b9db7bc5251a4a473ebe71a0f65a131b13a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 94
        echo "
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
   
</script>
 <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
";
        
        $__internal_31a83ae0c5961db3819c2162abf9b9db7bc5251a4a473ebe71a0f65a131b13a5->leave($__internal_31a83ae0c5961db3819c2162abf9b9db7bc5251a4a473ebe71a0f65a131b13a5_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Stock/stock.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 94,  171 => 93,  157 => 84,  151 => 83,  149 => 82,  140 => 76,  135 => 74,  131 => 73,  127 => 72,  123 => 70,  118 => 69,  116 => 68,  99 => 54,  94 => 52,  56 => 17,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}

<!-- Modal -->
<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Upload Menu Items</h4>
      </div>
      <div class=\"modal-body\">
        <p>
              <form action=\"{{ path('add_stock_csv') }}\" method=\"post\" enctype=\"multipart/form-data\">
                        <div class=\"row\">
                            
                        <div class=\"form-group col-md-12\">
                            <label>Date *</label>
                            <input type=\"text\" name=\"date\" class=\"form-control\" required=\"\" id = \"datepicker-13\" >

                        </div>
                                          
 <div class=\"form-group col-md-12\">
                            <label>Select CSV File *</label>
                            <input type=\"file\" name=\"file\" class=\"form-control\" required=\"\"   accept=\".csv\" >

                        </div>
                    </div>
                
                    <br>
<button type=\"submit\" class=\"btn btn-primary\">Upload</button>


      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                        <h3>Purchase Inwards</h3>
                        <span class=\"pull-right\">
                        <a  class=\"btn btn-primary btn-sm\" href=\"{{ path('export_stock_inwards') }}\">Download CSV File</a> 
                           <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\">Import From Csv</a> 
                            <a href=\"{{ path('manage_restaurant_add_stock') }}\" class=\"btn btn-primary btn-sm\"> Add New Stock</a>
                        </span>
                    </div>
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Details</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                 {% set id = 1 %}
                                {% for product in menuItems %}

                                <tr>
                                     <td>{{ id }}</td>
                                    <td>{{ product.date }}</td>
                                    <td>{{ product.description }}</td>
                                    <td>
                                        <a href=\"{{ path('manage_restaurant_stock_detail',{'id':product.ref})}}\" title=\"Manage item\" class=\"btn btn-primary btn-sm\">
                                            <i class=\"fa fa-eye\"></i>
                                        </a>
                                      
                                    </td>
                                </tr>
                                 {% set id = id + 1 %}
                                {% endfor %}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
   
</script>
 <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
{% endblock %}
", "AppBundle:Admin:Stock/stock.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Stock/stock.html.twig");
    }
}

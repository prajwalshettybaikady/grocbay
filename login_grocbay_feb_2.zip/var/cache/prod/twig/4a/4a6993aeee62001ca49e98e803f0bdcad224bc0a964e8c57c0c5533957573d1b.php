<?php

/* AppBundle:Admin:Brands/brandCreate.html.twig */
class __TwigTemplate_2019033fd7f2cbe0e5d40ed43661a11eaa20ed71a636465178afd7d76b26444f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Brands/brandCreate.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c20db08799e7c56756732339ebb027a700600f957ed495e94a35ef9c41dd593 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c20db08799e7c56756732339ebb027a700600f957ed495e94a35ef9c41dd593->enter($__internal_7c20db08799e7c56756732339ebb027a700600f957ed495e94a35ef9c41dd593_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Brands/brandCreate.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7c20db08799e7c56756732339ebb027a700600f957ed495e94a35ef9c41dd593->leave($__internal_7c20db08799e7c56756732339ebb027a700600f957ed495e94a35ef9c41dd593_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_28e008c86de4e44c5967699b8aa3a58f38dab350a05bf7520fa990df4b59fdda = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_28e008c86de4e44c5967699b8aa3a58f38dab350a05bf7520fa990df4b59fdda->enter($__internal_28e008c86de4e44c5967699b8aa3a58f38dab350a05bf7520fa990df4b59fdda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">Brands Panel

                    </h4>
                </div>
                <div class=\"card-body\">
                    ";
        // line 12
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
                    ";
        // line 13
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/widget.html.twig"));
        // line 14
        echo "                        <div class=\"form-group\">
                            ";
        // line 15
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "categoryName", array()), 'label', array("label" => "Brand Name"));
        echo "
                            ";
        // line 16
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "categoryName", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Brand name
                            ")));
        // line 17
        echo "
                        </div>
<div class=\"form-group\">
\t\t <div class=\"row\">
                                           ";
        // line 26
        echo "                                           ";
        // line 27
        echo "                                        </div>
</div>
                     
                        <div class=\"row\">
                                           <div class=\"col-md-12\">
                                                <label class=\"d-block\">Featured Brand</label>
                                                <label class=\"switch s-success mr-2 mt-3\"> 
                                                    <input type=\"checkbox\" ";
        // line 34
        if (($this->getAttribute(($context["category"] ?? $this->getContext($context, "category")), "parentId", array()) == 1)) {
            echo "checked ";
        }
        echo " class=\"form-control form-control-sm\" name=\"parentid\"  value=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["category"] ?? $this->getContext($context, "category")), "parentId", array()), "html", null, true);
        echo "\">
                                                    <span class=\"slider round\"></span>
                                                </label>
                                            </div>
                                        </div>
                        ";
        // line 39
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/file.html.twig"));
        // line 40
        echo "                        <div class=\"row\">
                            <div class=\"col-lg-3 col-md-3\">
                                ";
        // line 42
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "iconFile", array()), 'label', array("label" => "Brand icon"));
        echo "
                                ";
        // line 43
        $context["iconImage"] = "";
        // line 44
        echo "                                ";
        if (($this->getAttribute(($context["category"] ?? $this->getContext($context, "category")), "iconImage", array()) != null)) {
            // line 45
            echo "                                    ";
            $context["iconImage"] = ("https://appinsight.tech/gbadmin/uploads/sub-category/icons/" . $this->getAttribute(($context["category"] ?? $this->getContext($context, "category")), "iconImage", array()));
            // line 46
            echo "                                ";
        }
        // line 47
        echo "                                ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "iconFile", array()), 'row', array("attr" => array("data-default-file" => ($context["iconImage"] ?? $this->getContext($context, "iconImage")))));
        echo "
                            </div>
                            
                        </div>
                        <div class=\"clearfix\"></div>
                        <button type=\"submit\" class=\"btn btn-primary pull-right\">Save</button>
                        ";
        // line 53
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
                        ";
        // line 54
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'rest');
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_28e008c86de4e44c5967699b8aa3a58f38dab350a05bf7520fa990df4b59fdda->leave($__internal_28e008c86de4e44c5967699b8aa3a58f38dab350a05bf7520fa990df4b59fdda_prof);

    }

    // line 61
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_639a2c0d9f92649fdaa05da1c06341fdec59bae19947cbdd3718e4e46b0affda = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_639a2c0d9f92649fdaa05da1c06341fdec59bae19947cbdd3718e4e46b0affda->enter($__internal_639a2c0d9f92649fdaa05da1c06341fdec59bae19947cbdd3718e4e46b0affda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 62
        echo "
<script>
    
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

";
        
        $__internal_639a2c0d9f92649fdaa05da1c06341fdec59bae19947cbdd3718e4e46b0affda->leave($__internal_639a2c0d9f92649fdaa05da1c06341fdec59bae19947cbdd3718e4e46b0affda_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Brands/brandCreate.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 62,  145 => 61,  132 => 54,  128 => 53,  118 => 47,  115 => 46,  112 => 45,  109 => 44,  107 => 43,  103 => 42,  99 => 40,  97 => 39,  85 => 34,  76 => 27,  74 => 26,  68 => 17,  65 => 16,  61 => 15,  58 => 14,  56 => 13,  52 => 12,  41 => 3,  35 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}
{% block body %}
    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">Brands Panel

                    </h4>
                </div>
                <div class=\"card-body\">
                    {{ form_start(form) }}
                    {% form_theme form '@AppBundle/Themes/widget.html.twig' %}
                        <div class=\"form-group\">
                            {{ form_label(form.categoryName, \"Brand Name\") }}
                            {{ form_row(form.categoryName,{'attr':{'class':'form-control','placeholder':'Brand name
                            '}}) }}
                        </div>
<div class=\"form-group\">
\t\t <div class=\"row\">
                                           {#  <div class=\"col-md-12\">
                                                <div class=\"form-group\">
                                                  
                                                </div>
                                            </div> #}
                                           {#  #}
                                        </div>
</div>
                     
                        <div class=\"row\">
                                           <div class=\"col-md-12\">
                                                <label class=\"d-block\">Featured Brand</label>
                                                <label class=\"switch s-success mr-2 mt-3\"> 
                                                    <input type=\"checkbox\" {% if category.parentId == 1 %}checked {% endif %} class=\"form-control form-control-sm\" name=\"parentid\"  value=\"{{ category.parentId }}\">
                                                    <span class=\"slider round\"></span>
                                                </label>
                                            </div>
                                        </div>
                        {% form_theme form '@AppBundle/Themes/file.html.twig' %}
                        <div class=\"row\">
                            <div class=\"col-lg-3 col-md-3\">
                                {{ form_label(form.iconFile, \"Brand icon\") }}
                                {% set iconImage = \"\" %}
                                {% if category.iconImage != null %}
                                    {% set iconImage = 'https://appinsight.tech/gbadmin/uploads/sub-category/icons/'~category.iconImage %}
                                {% endif %}
                                {{ form_row(form.iconFile,{'attr':{'data-default-file':iconImage}}) }}
                            </div>
                            
                        </div>
                        <div class=\"clearfix\"></div>
                        <button type=\"submit\" class=\"btn btn-primary pull-right\">Save</button>
                        {{ form_end(form) }}
                        {{ form_rest(form) }}
                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block scripts %}

<script>
    
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

{% endblock %}
", "AppBundle:Admin:Brands/brandCreate.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Brands/brandCreate.html.twig");
    }
}

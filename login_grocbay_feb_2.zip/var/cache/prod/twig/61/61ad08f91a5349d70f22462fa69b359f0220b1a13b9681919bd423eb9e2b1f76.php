<?php

/* AppBundle:Admin:Customers/listUser.html.twig */
class __TwigTemplate_7d0c7d9938cc71cae3d8baf12ac4ae8726cbf02fb9be8cbc54eacb174ff95f36 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Customers/listUser.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b295b3ca6c04ff9ba2d26a3816d59b235d1bb9d9ff9fe0d4ed3f3b8f0fa62f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b295b3ca6c04ff9ba2d26a3816d59b235d1bb9d9ff9fe0d4ed3f3b8f0fa62f2->enter($__internal_6b295b3ca6c04ff9ba2d26a3816d59b235d1bb9d9ff9fe0d4ed3f3b8f0fa62f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Customers/listUser.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6b295b3ca6c04ff9ba2d26a3816d59b235d1bb9d9ff9fe0d4ed3f3b8f0fa62f2->leave($__internal_6b295b3ca6c04ff9ba2d26a3816d59b235d1bb9d9ff9fe0d4ed3f3b8f0fa62f2_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_1fa713666924b84ff0df478f7005c3b012bdd090e8bdb6c5cf3c44ecaf45e897 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1fa713666924b84ff0df478f7005c3b012bdd090e8bdb6c5cf3c44ecaf45e897->enter($__internal_1fa713666924b84ff0df478f7005c3b012bdd090e8bdb6c5cf3c44ecaf45e897_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "            <div class=\"layout-px-spacing\">

                
                
                <div class=\"row layout-top-spacing\" id=\"cancel-row\">
                
                    <div class=\"col-xl-12 col-lg-12 col-sm-12  layout-spacing\">
                        <div class=\"widget-content widget-content-area br-6\">
                            <div class=\"table-responsive mb-4 mt-4\">
                                <table id=\"myTable\" class=\"table\" style=\"width:100%\">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Customer Name</th>
                                    <th>Email Id</th>
                                    <th>Mobile Number</th>
                                   <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            
                           
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
";
        
        $__internal_1fa713666924b84ff0df478f7005c3b012bdd090e8bdb6c5cf3c44ecaf45e897->leave($__internal_1fa713666924b84ff0df478f7005c3b012bdd090e8bdb6c5cf3c44ecaf45e897_prof);

    }

    // line 34
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_35b1cb01b97253dd4806fec626d0f10c85b2887af0199a8a496aecccd12e8b9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35b1cb01b97253dd4806fec626d0f10c85b2887af0199a8a496aecccd12e8b9c->enter($__internal_35b1cb01b97253dd4806fec626d0f10c85b2887af0199a8a496aecccd12e8b9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 35
        echo "
<script>
    \$(document).ready(function() {
      \$('#myTable').DataTable({   
         
      'processing': true,
      'serverSide': true,
      'serverMethod': 'post',
      \"aaSorting\": [[0, 'desc']],
      'ajax': {
          'url':\"";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("customer_page");
        echo "\",
          'type': \"post\",
      },
      'columns': [
         { data: 'id'},
         { data: 'username' },
         { data: 'email' },
         { data: 'mobileNo' },
         { data: 'isActive' },
         { data: 'actionid' },
      ],
   });
    });
</script>
";
        
        $__internal_35b1cb01b97253dd4806fec626d0f10c85b2887af0199a8a496aecccd12e8b9c->leave($__internal_35b1cb01b97253dd4806fec626d0f10c85b2887af0199a8a496aecccd12e8b9c_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Customers/listUser.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 45,  82 => 35,  76 => 34,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}
            <div class=\"layout-px-spacing\">

                
                
                <div class=\"row layout-top-spacing\" id=\"cancel-row\">
                
                    <div class=\"col-xl-12 col-lg-12 col-sm-12  layout-spacing\">
                        <div class=\"widget-content widget-content-area br-6\">
                            <div class=\"table-responsive mb-4 mt-4\">
                                <table id=\"myTable\" class=\"table\" style=\"width:100%\">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Customer Name</th>
                                    <th>Email Id</th>
                                    <th>Mobile Number</th>
                                   <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            
                           
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script>
    \$(document).ready(function() {
      \$('#myTable').DataTable({   
         
      'processing': true,
      'serverSide': true,
      'serverMethod': 'post',
      \"aaSorting\": [[0, 'desc']],
      'ajax': {
          'url':\"{{ path('customer_page')}}\",
          'type': \"post\",
      },
      'columns': [
         { data: 'id'},
         { data: 'username' },
         { data: 'email' },
         { data: 'mobileNo' },
         { data: 'isActive' },
         { data: 'actionid' },
      ],
   });
    });
</script>
{% endblock %}", "AppBundle:Admin:Customers/listUser.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Customers/listUser.html.twig");
    }
}

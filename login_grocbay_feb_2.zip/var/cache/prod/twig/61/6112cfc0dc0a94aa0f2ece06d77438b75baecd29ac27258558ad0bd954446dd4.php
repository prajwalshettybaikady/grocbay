<?php

/* AppBundle:Admin:Stock/allStockReports.html.twig */
class __TwigTemplate_8b8747f3bdbe5d497d4a10a646afab118c6c8d0e3545b3fbe8dfe0dcfe35b617 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((("@AppBundle/" . ($context["myExtend"] ?? $this->getContext($context, "myExtend"))) . "/base.html.twig"), "AppBundle:Admin:Stock/allStockReports.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af82872415493895f6a043d701d96b8048838a0b29ddbfa0c12e7d06412ecaaa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af82872415493895f6a043d701d96b8048838a0b29ddbfa0c12e7d06412ecaaa->enter($__internal_af82872415493895f6a043d701d96b8048838a0b29ddbfa0c12e7d06412ecaaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Stock/allStockReports.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_af82872415493895f6a043d701d96b8048838a0b29ddbfa0c12e7d06412ecaaa->leave($__internal_af82872415493895f6a043d701d96b8048838a0b29ddbfa0c12e7d06412ecaaa_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_4afe3e45b0f605f36fed914dd5fe43fc6bd22cee763a09a42a75a67d57f47f6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4afe3e45b0f605f36fed914dd5fe43fc6bd22cee763a09a42a75a67d57f47f6d->enter($__internal_4afe3e45b0f605f36fed914dd5fe43fc6bd22cee763a09a42a75a67d57f47f6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "
<link href=\"/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css\" rel=\"stylesheet\">
";
        
        $__internal_4afe3e45b0f605f36fed914dd5fe43fc6bd22cee763a09a42a75a67d57f47f6d->leave($__internal_4afe3e45b0f605f36fed914dd5fe43fc6bd22cee763a09a42a75a67d57f47f6d_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_955a4bccebb3e65be72d898cc8a443a258d19471aa52d4e7b7f228ce31564030 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_955a4bccebb3e65be72d898cc8a443a258d19471aa52d4e7b7f228ce31564030->enter($__internal_955a4bccebb3e65be72d898cc8a443a258d19471aa52d4e7b7f228ce31564030_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "
<div id=\"order-report-app\">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->


    
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">

                <div class=\"card-header\">

                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>  <h4 class=\"card-title m-b-0\">Stock Reports<a  class=\"btn btn-success btn-sm\" href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("export_stock");
        echo "\" style=\"float:right;width:150px;\">Download CSV File</a>
                       
                    </h4>   </div>
                 \t 
                    ";
        // line 26
        echo "
              
         

                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                            <tr>
                                <td>#</td>
                                <td>Name </td>
                                <td>Variation </td>
                                <td>Current Stock</td>
                                <td>status</td>
                                
                            </tr>
                        </thead>
                        <tbody>
                            ";
        // line 42
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["menu"] ?? $this->getContext($context, "menu")));
        foreach ($context['_seq'] as $context["_key"] => $context["st"]) {
            // line 43
            echo "                               
                                <tr>
                                 <td>";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "id", array()), "html", null, true);
            echo "</td>
                                 <td>
                                     
                                            <a href=\"";
            // line 48
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_edit_menu_item", array("id" => $this->getAttribute($context["st"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "itemName", array()), "html", null, true);
            echo "</a>
                                      
                                     
                                    </td>
                                       <td>
                                     
                                            <a href=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_edit_menu_item", array("id" => $this->getAttribute($context["st"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "variationName", array()), "html", null, true);
            echo "</a>
                                      
                                     
                                    </td>
                                    <td>";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "stock", array()), "html", null, true);
            echo "</td>
                                    <td>
                                       ";
            // line 60
            if (($this->getAttribute($context["st"], "stock", array()) <= $this->getAttribute($context["st"], "alert", array()))) {
                // line 61
                echo "                                        <b style=\"color:red;\">Out Of Stock</b>
                                         ";
            } else {
                // line 63
                echo "                                        <b style=\"color:red;\">In Stock</b>
                                       ";
            }
            // line 65
            echo "
                                    </td>
                                </tr>
                          
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['st'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo "</tbody>
                    </table>
                </div>
                <div class=\"card-body collapse show\">
                    
                </div>
            </div>
        </div>
    </div>

";
        
        $__internal_955a4bccebb3e65be72d898cc8a443a258d19471aa52d4e7b7f228ce31564030->leave($__internal_955a4bccebb3e65be72d898cc8a443a258d19471aa52d4e7b7f228ce31564030_prof);

    }

    // line 81
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_60433dc6472621ce14a4d2a2d5a2c5bdcb4f6ec7cfaca61ab55953147142c5ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60433dc6472621ce14a4d2a2d5a2c5bdcb4f6ec7cfaca61ab55953147142c5ba->enter($__internal_60433dc6472621ce14a4d2a2d5a2c5bdcb4f6ec7cfaca61ab55953147142c5ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 82
        echo "<script src=\"/assets/plugins/moment/moment.js\"></script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script src=\"/assets/plugins/iCheck/icheck.min.js\"></script>

<script>
    \$(document).ready(function() {
 \$('#myTable').DataTable();
    });  
    </script>
";
        
        $__internal_60433dc6472621ce14a4d2a2d5a2c5bdcb4f6ec7cfaca61ab55953147142c5ba->leave($__internal_60433dc6472621ce14a4d2a2d5a2c5bdcb4f6ec7cfaca61ab55953147142c5ba_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Stock/allStockReports.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  179 => 82,  173 => 81,  156 => 69,  146 => 65,  142 => 63,  138 => 61,  136 => 60,  131 => 58,  122 => 54,  111 => 48,  105 => 45,  101 => 43,  97 => 42,  79 => 26,  72 => 21,  56 => 7,  50 => 6,  41 => 3,  35 => 2,  20 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source(" {% extends \"@AppBundle/\"~ myExtend ~\"/base.html.twig\" %}
{% block styles %}

<link href=\"/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css\" rel=\"stylesheet\">
{% endblock %}
{% block body %}

<div id=\"order-report-app\">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->


    
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">

                <div class=\"card-header\">

                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>  <h4 class=\"card-title m-b-0\">Stock Reports<a  class=\"btn btn-success btn-sm\" href=\"{{ path('export_stock') }}\" style=\"float:right;width:150px;\">Download CSV File</a>
                       
                    </h4>   </div>
                 \t 
                    {# {{ dump(stock) }} #}

              
         

                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                            <tr>
                                <td>#</td>
                                <td>Name </td>
                                <td>Variation </td>
                                <td>Current Stock</td>
                                <td>status</td>
                                
                            </tr>
                        </thead>
                        <tbody>
                            {% for st in menu %}
                               
                                <tr>
                                 <td>{{ st.id }}</td>
                                 <td>
                                     
                                            <a href=\"{{ path('restaurant_edit_menu_item',{'id':st.id})}}\">{{ st.itemName }}</a>
                                      
                                     
                                    </td>
                                       <td>
                                     
                                            <a href=\"{{ path('restaurant_edit_menu_item',{'id':st.id})}}\">{{ st.variationName }}</a>
                                      
                                     
                                    </td>
                                    <td>{{ st.stock }}</td>
                                    <td>
                                       {% if st.stock <= st.alert %}
                                        <b style=\"color:red;\">Out Of Stock</b>
                                         {% else %}
                                        <b style=\"color:red;\">In Stock</b>
                                       {% endif %}

                                    </td>
                                </tr>
                          
                            {% endfor %}</tbody>
                    </table>
                </div>
                <div class=\"card-body collapse show\">
                    
                </div>
            </div>
        </div>
    </div>

{% endblock %}

{% block scripts %}
<script src=\"/assets/plugins/moment/moment.js\"></script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script src=\"/assets/plugins/iCheck/icheck.min.js\"></script>

<script>
    \$(document).ready(function() {
 \$('#myTable').DataTable();
    });  
    </script>
{% endblock %}", "AppBundle:Admin:Stock/allStockReports.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Stock/allStockReports.html.twig");
    }
}

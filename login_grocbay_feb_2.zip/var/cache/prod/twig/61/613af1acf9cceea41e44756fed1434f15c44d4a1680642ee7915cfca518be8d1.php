<?php

/* AppBundle:Admin:Promocode/promoList.html.twig */
class __TwigTemplate_d640d199e49bc3e5fb5e56b7886ffcdd85dd47fe2ce2f0a9f3311e3b2cc25d57 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Promocode/promoList.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb951b0b54fdd6e13bc998074536738998a08a72d79f83c70a4aae0ede1a4e1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb951b0b54fdd6e13bc998074536738998a08a72d79f83c70a4aae0ede1a4e1c->enter($__internal_bb951b0b54fdd6e13bc998074536738998a08a72d79f83c70a4aae0ede1a4e1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Promocode/promoList.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bb951b0b54fdd6e13bc998074536738998a08a72d79f83c70a4aae0ede1a4e1c->leave($__internal_bb951b0b54fdd6e13bc998074536738998a08a72d79f83c70a4aae0ede1a4e1c_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_6fe3a6f1505b73cbca008885c61fa6cb523fa6bbba5e68cfc61f85d9d6748fba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fe3a6f1505b73cbca008885c61fa6cb523fa6bbba5e68cfc61f85d9d6748fba->enter($__internal_6fe3a6f1505b73cbca008885c61fa6cb523fa6bbba5e68cfc61f85d9d6748fba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                            <thead>
                                <tr>
                                    <th>Promocode</th>
                                    <th>Start date</th>
                                    <th>End date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["promocodes"] ?? $this->getContext($context, "promocodes")));
        foreach ($context['_seq'] as $context["_key"] => $context["promo"]) {
            // line 21
            echo "                                <tr>
                                    <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["promo"], "promoCode", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 23
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["promo"], "startDate", array()), "d F Y"), "html", null, true);
            echo "</td>
                                    <td>";
            // line 24
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["promo"], "endDate", array()), "d F Y"), "html", null, true);
            echo "</td>
                                    <td>
                                        ";
            // line 26
            if ($this->getAttribute($context["promo"], "isActive", array())) {
                // line 27
                echo "                                            <a href=\"javascript:;\" class=\"badge badge-success\">active</a>
                                        ";
            } else {
                // line 29
                echo "                                            <a href=\"javascript:;\" class=\"badge badge-danger\">inactive</a>
                                        ";
            }
            // line 31
            echo "                                    </td>
                                    <td>
                                        <a href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_new_promocode", array("edid" => $this->getAttribute($context["promo"], "id", array()))), "html", null, true);
            echo "\" title=\"Edit\" class=\"badge badge-primary\">
                                            <i class=\"fa fa-edit\"></i>
                                        </a>
                                    </td>
                                </tr>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['promo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
";
        
        $__internal_6fe3a6f1505b73cbca008885c61fa6cb523fa6bbba5e68cfc61f85d9d6748fba->leave($__internal_6fe3a6f1505b73cbca008885c61fa6cb523fa6bbba5e68cfc61f85d9d6748fba_prof);

    }

    // line 48
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_f2fc8758050addd4bc60b2821e0c22f714ea35e530d8ee6d176650758cd54489 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2fc8758050addd4bc60b2821e0c22f714ea35e530d8ee6d176650758cd54489->enter($__internal_f2fc8758050addd4bc60b2821e0c22f714ea35e530d8ee6d176650758cd54489_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 49
        echo "
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
</script>
";
        
        $__internal_f2fc8758050addd4bc60b2821e0c22f714ea35e530d8ee6d176650758cd54489->leave($__internal_f2fc8758050addd4bc60b2821e0c22f714ea35e530d8ee6d176650758cd54489_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Promocode/promoList.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 49,  119 => 48,  105 => 39,  93 => 33,  89 => 31,  85 => 29,  81 => 27,  79 => 26,  74 => 24,  70 => 23,  66 => 22,  63 => 21,  59 => 20,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}
<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                            <thead>
                                <tr>
                                    <th>Promocode</th>
                                    <th>Start date</th>
                                    <th>End date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {% for promo in promocodes %}
                                <tr>
                                    <td>{{ promo.promoCode }}</td>
                                    <td>{{ promo.startDate|date('d F Y') }}</td>
                                    <td>{{ promo.endDate|date('d F Y') }}</td>
                                    <td>
                                        {% if promo.isActive %}
                                            <a href=\"javascript:;\" class=\"badge badge-success\">active</a>
                                        {% else %}
                                            <a href=\"javascript:;\" class=\"badge badge-danger\">inactive</a>
                                        {% endif %}
                                    </td>
                                    <td>
                                        <a href=\"{{ path('add_new_promocode',{'edid':promo.id})}}\" title=\"Edit\" class=\"badge badge-primary\">
                                            <i class=\"fa fa-edit\"></i>
                                        </a>
                                    </td>
                                </tr>
                                {% endfor %}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
</script>
{% endblock %}", "AppBundle:Admin:Promocode/promoList.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Promocode/promoList.html.twig");
    }
}

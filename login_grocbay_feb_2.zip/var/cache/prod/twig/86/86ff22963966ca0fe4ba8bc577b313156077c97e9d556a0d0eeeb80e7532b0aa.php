<?php

/* AppBundle:Admin:Pages/restaurantList.html.twig */
class __TwigTemplate_7cd374b154eacfc6d5ba466af2565368044c346a3e897543b5c9821a330a5725 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/restaurantList.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_73343db3dd90fca836d9ea03b6819dd2e77bfd57cb16af6a4728812b07cdcdd1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73343db3dd90fca836d9ea03b6819dd2e77bfd57cb16af6a4728812b07cdcdd1->enter($__internal_73343db3dd90fca836d9ea03b6819dd2e77bfd57cb16af6a4728812b07cdcdd1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/restaurantList.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_73343db3dd90fca836d9ea03b6819dd2e77bfd57cb16af6a4728812b07cdcdd1->leave($__internal_73343db3dd90fca836d9ea03b6819dd2e77bfd57cb16af6a4728812b07cdcdd1_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_15b03774747248edc901d56186ffa7ddfb1db9b74be3295aacaae200f8cf49b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_15b03774747248edc901d56186ffa7ddfb1db9b74be3295aacaae200f8cf49b0->enter($__internal_15b03774747248edc901d56186ffa7ddfb1db9b74be3295aacaae200f8cf49b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "<style>
    .hidden{
        display: none !important;
    }
</style>
";
        
        $__internal_15b03774747248edc901d56186ffa7ddfb1db9b74be3295aacaae200f8cf49b0->leave($__internal_15b03774747248edc901d56186ffa7ddfb1db9b74be3295aacaae200f8cf49b0_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_ef2746a1d40e059129275f8bfef2ae17e1d6fd9d199bbf7fa365f004c3b52ca7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef2746a1d40e059129275f8bfef2ae17e1d6fd9d199bbf7fa365f004c3b52ca7->enter($__internal_ef2746a1d40e059129275f8bfef2ae17e1d6fd9d199bbf7fa365f004c3b52ca7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"row\" id=\"vue-list\">
    <div class=\"col-12\">
        <div class=\"card\" >
                <div class=\"card-body\">
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                            <thead>
                                <tr>
                                    <td>#</td>
                                    <th>Branch Name</th>
                                    <th>Email</th>
                                    <th>Mobile Number</th>
                                    <th>Location</th>
                                    <th>Sales</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["restaurants"] ?? $this->getContext($context, "restaurants")));
        foreach ($context['_seq'] as $context["_key"] => $context["restaurant"]) {
            // line 30
            echo "                                <tr>
                                    <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["restaurant"], "id", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["restaurant"], "restaurantname", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["restaurant"], "primaryEmail", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["restaurant"], "primaryMobile", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["restaurant"], "restaurantLocation", array()), "html", null, true);
            echo " </td>
                                        <td>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["restaurant"], "sales", array()), "html", null, true);
            echo " <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("view_branch_report", array("id" => $this->getAttribute($context["restaurant"], "id", array()))), "html", null, true);
            echo "\">(view)</a> </td>
                                    <td> ";
            // line 37
            if ($this->getAttribute($context["restaurant"], "isOpen", array())) {
                // line 38
                echo "                                            <span class=\"badge badge-success\">active</span>
                                        ";
            } else {
                // line 40
                echo "                                            <span class=\"badge badge-danger\">inactive</span>
                                            </a>
                                        ";
            }
            // line 42
            echo "</td>
                                    <td>          
                                       <div class=\"dropdown custom-dropdown\">
                                                            <a class=\"dropdown-toggle\" href=\"#\" role=\"button\" id=\"dropdownMenuLink1\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-more-horizontal\"><circle cx=\"12\" cy=\"12\" r=\"1\"></circle><circle cx=\"19\" cy=\"12\" r=\"1\"></circle><circle cx=\"5\" cy=\"12\" r=\"1\"></circle></svg>
                                                            </a>

                                                            <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuLink1\" style=\"will-change: transform;\">
                                                                <a class=\"dropdown-item\" href=\"";
            // line 50
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_edit", array("id" => $this->getAttribute($context["restaurant"], "id", array()))), "html", null, true);
            echo "\">Edit</a>
                                                               
                                                                 <a class=\"dropdown-item\" href=\"";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("branch_activate", array("id" => $this->getAttribute($context["restaurant"], "id", array()))), "html", null, true);
            echo "\">Change Status</a>
                                                           </div>
                                                        </div>                           
                                    </td>
                                </tr>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['restaurant'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
";
        
        $__internal_ef2746a1d40e059129275f8bfef2ae17e1d6fd9d199bbf7fa365f004c3b52ca7->leave($__internal_ef2746a1d40e059129275f8bfef2ae17e1d6fd9d199bbf7fa365f004c3b52ca7_prof);

    }

    // line 67
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_cafd41295f726856bbf403ee0d6af8dcd25a349132950bd230b32cc2f5e7a640 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cafd41295f726856bbf403ee0d6af8dcd25a349132950bd230b32cc2f5e7a640->enter($__internal_cafd41295f726856bbf403ee0d6af8dcd25a349132950bd230b32cc2f5e7a640_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 68
        echo "
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script src=\"/assets/vue/custom/restaurantList.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
</script>
";
        
        $__internal_cafd41295f726856bbf403ee0d6af8dcd25a349132950bd230b32cc2f5e7a640->leave($__internal_cafd41295f726856bbf403ee0d6af8dcd25a349132950bd230b32cc2f5e7a640_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/restaurantList.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  172 => 68,  166 => 67,  152 => 58,  140 => 52,  135 => 50,  125 => 42,  120 => 40,  116 => 38,  114 => 37,  108 => 36,  104 => 35,  100 => 34,  96 => 33,  92 => 32,  88 => 31,  85 => 30,  81 => 29,  60 => 10,  54 => 9,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}
{% block styles %}
<style>
    .hidden{
        display: none !important;
    }
</style>
{% endblock %}
{% block body %}
<div class=\"row\" id=\"vue-list\">
    <div class=\"col-12\">
        <div class=\"card\" >
                <div class=\"card-body\">
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                            <thead>
                                <tr>
                                    <td>#</td>
                                    <th>Branch Name</th>
                                    <th>Email</th>
                                    <th>Mobile Number</th>
                                    <th>Location</th>
                                    <th>Sales</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {% for restaurant in restaurants %}
                                <tr>
                                    <td>{{ restaurant.id }}</td>
                                    <td>{{ restaurant.restaurantname }}</td>
                                    <td>{{ restaurant.primaryEmail }}</td>
                                    <td>{{ restaurant.primaryMobile }}</td>
                                    <td>{{ restaurant.restaurantLocation }} </td>
                                        <td>{{ restaurant.sales }} <a href=\"{{ path('view_branch_report',{'id':restaurant.id }) }}\">(view)</a> </td>
                                    <td> {% if restaurant.isOpen %}
                                            <span class=\"badge badge-success\">active</span>
                                        {% else %}
                                            <span class=\"badge badge-danger\">inactive</span>
                                            </a>
                                        {% endif %}</td>
                                    <td>          
                                       <div class=\"dropdown custom-dropdown\">
                                                            <a class=\"dropdown-toggle\" href=\"#\" role=\"button\" id=\"dropdownMenuLink1\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-more-horizontal\"><circle cx=\"12\" cy=\"12\" r=\"1\"></circle><circle cx=\"19\" cy=\"12\" r=\"1\"></circle><circle cx=\"5\" cy=\"12\" r=\"1\"></circle></svg>
                                                            </a>

                                                            <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuLink1\" style=\"will-change: transform;\">
                                                                <a class=\"dropdown-item\" href=\"{{ path('restaurant_edit',{'id':restaurant.id}) }}\">Edit</a>
                                                               
                                                                 <a class=\"dropdown-item\" href=\"{{ path('branch_activate',{'id':restaurant.id}) }}\">Change Status</a>
                                                           </div>
                                                        </div>                           
                                    </td>
                                </tr>
                                {% endfor %}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script src=\"/assets/vue/custom/restaurantList.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
</script>
{% endblock %}", "AppBundle:Admin:Pages/restaurantList.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/restaurantList.html.twig");
    }
}

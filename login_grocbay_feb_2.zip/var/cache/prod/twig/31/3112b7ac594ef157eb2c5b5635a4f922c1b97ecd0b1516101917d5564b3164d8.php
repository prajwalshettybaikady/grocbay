<?php

/* AppBundle:Admin:Orders/multithermal.html.twig */
class __TwigTemplate_bd2806d0e05fd867dac5175884d424b20597329080b1d41cc2793bb800e7117b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_401f7e8ec8e3806bbe91789274608f47ee87b809e5cf5dff49440347714e1739 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_401f7e8ec8e3806bbe91789274608f47ee87b809e5cf5dff49440347714e1739->enter($__internal_401f7e8ec8e3806bbe91789274608f47ee87b809e5cf5dff49440347714e1739_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Orders/multithermal.html.twig"));

        // line 1
        echo "        ";
        if ((($context["yes"] ?? $this->getContext($context, "yes")) == 1)) {
            // line 2
            echo "    <center>No Data Found!</center>
";
        }
        // line 4
        echo "
      <style type=\"text/css\">
    /* Our Font */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;700&display=swap');

/* Global */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins';
  color: #000 !important;
}
 
body {
  margin-top: 10px;
  height: 100vh;
}

/* The Receipt */
.receipt {
    width: 400px;
    background-color: white;
    border-radius: 30px;
    position: relative;
    /* top: 30%; */
    /* left: 50%; */
    /* margin-top: -360px; */
    /* margin-left: -180px; */
    padding: 20px;
    margin: 0px auto;
}
.body {
    width: 100%;
    display: inline-block;
    margin: 0 auto;
}
/* Heading */
.name {
  text-transform: uppercase;
  text-align: center;
  color: #6c8b8e;
  letter-spacing: 1px;
  font-size: 1.8em;
  margin-top: 10px
}

/* Big thank */
.greeting {
  font-size: 21px;
  text-transform: capitalize;
  text-align: center;
  color: #6f8d90;
  margin: 35px 0;
  letter-spacing: 1.2px
}

/* Order info */
.order p {
  font-size: 13px;
  color: #aaa;
  padding-left: 10px;
  letter-spacing: .7px
}

/* Our line */
hr {
  border: .7px solid #ddd;
  margin: 15px 0;
}

/* Order details */
.details {
  padding-left: 10px;
  margin-bottom: 3px;
  overflow: hidden
}

.details h3 {
  font-weight: 400;
  color: #6c8b8e;
  font-size: 1.5em;
  margin-bottom: 8px
}

/* Image and the info of the order */
.product {
  float: left;
  width: 83%
}

.product img {
  width: 65px;
  float: left
}

.product .info {
  float: left;
  margin-left: 15px
}

.product .info h4 {
  color: #6f8d90;
  font-weight: 400;
  text-transform: uppercase;
  margin-top: 5px
}

.product .info p {
  font-size: 12px;
  color: #aaa;
}

/* Net price */
.details > p {
  color: #6f8d90;
  margin-top: 25px;
  font-size: 15px
}

/* Total price */
.totalprice p {
  padding-left: 10px
}

.totalprice .sub,
.totalprice .del {
  font-size: 13px;
  color: #aaa
}

.totalprice span {
  float: right;
  margin-right: 17px
}

.totalprice .tot {
  color: #6f8d90;
  font-size: 15px
}

/* Footer */
footer {
  font-size: 10px;
  text-align: center;
  margin-top: 15px; /* You can make it with position try it */
  color: #aaa
}
.td
{
      padding-left: 24px !important;
    background: white;
    padding: 3px;
    font-size: 12px;
}
.tdd
{
    background: white;
    padding: 3px;
    font-size: 12px;
}
.tds {
    padding-left: 20px !important;
    background: white;
    padding: 3px;
    font-size: 12px;
    font-weight: bold;  
}
.tdds {
    background: white;
    padding: 3px;
    font-size: 12px;
    font-weight: bold;  
}
.tdss {
    padding-left: 18px !important;
    background: white;
    padding: 3px;
    font-size: 10px;
    font-weight: bold;  
}
.tdsss {
    padding-left: 50px !important;
    background: white;
    padding: 3px;
    font-size: 10px;
    font-weight: bold;  
}
hr {
    border: .7px solid #ddd;
    margin: 3px 0;
}
 @media print
      {
         @page {
           margin-top: 0;
           margin-bottom: 0;
         }
         body  {
           padding-top: 72px;
           padding-bottom: 72px ;
         }
      } 
    </style>
    ";
        // line 208
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["orders"] ?? $this->getContext($context, "orders")));
        foreach ($context['_seq'] as $context["_key"] => $context["order"]) {
            // line 209
            echo "
    ";
            // line 210
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["restaurant"] ?? $this->getContext($context, "restaurant")));
            foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
                // line 211
                echo "    ";
                $context["numberFormat"] = $this->getAttribute($context["res"], "number_format", array());
                // line 212
                echo "       <div class=\"body\">

    <div class=\"receipt\">
      <h2 class=\"name\"> ";
                // line 215
                echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantName", array()), "html", null, true);
                echo " </h2>
      
    <center>  
    <b>#";
                // line 218
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "id", array()), "html", null, true);
                echo "</b>
    <h4>";
                // line 219
                if (($this->getAttribute($context["order"], "orderType", array()) == "Delivery")) {
                    echo " Home Delivery ";
                } elseif (($this->getAttribute($context["order"], "orderType", array()) == "pickup")) {
                    echo " Pickup From Store ";
                } else {
                    echo " Express Delivery ";
                }
                echo "</h4>
 <div class=\"order\"><small>
                           ";
                // line 221
                echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantAddress", array()), "html", null, true);
                echo "<br>
                           ";
                // line 222
                echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantLocation", array()), "html", null, true);
                echo "<br>
                            Gst No:";
                // line 223
                echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "gst", array()), "html", null, true);
                echo "<br>

                           Mobile : ";
                // line 225
                echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "primaryMobile", array()), "html", null, true);
                echo "<br>
                           Email : ";
                // line 226
                echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "primaryEmail", array()), "html", null, true);
                echo " 
                         </small>
                         </div></center>
<hr>

      <!-- Order info -->
      <div class=\"order\">


      <p>Bill to/Ship to:<br>
                           <small>
                           ";
                // line 237
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "customerName", array()), "html", null, true);
                echo "<br>
                           ";
                // line 238
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "address", array()), "html", null, true);
                echo "<br>
                           ";
                // line 239
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "landmark", array()), "html", null, true);
                echo "<br>
                           Mobile : ";
                // line 240
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "mobileNo", array()), "html", null, true);
                echo "<br>
                           Email : ";
                // line 241
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "email", array()), "html", null, true);
                echo "<br>
                           Gst No: ";
                // line 242
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "gst", array()), "html", null, true);
                echo "<br>
                           Delivery Date :  ";
                // line 243
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "fixDate", array()), "html", null, true);
                echo "<br>
Delivery Time : ";
                // line 244
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "fixtime", array()), "html", null, true);
                echo "<br>
Promocode : ";
                // line 245
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "promocode", array()), "html", null, true);
                echo "<br>
Note : ";
                // line 246
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "note", array()), "html", null, true);
                echo "<br>
Order Date :";
                // line 247
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["order"], "orderDate", array()), "d-m-Y"), "html", null, true);
                echo " at ";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["order"], "orderDate", array()), "h-i A"), "html", null, true);
                echo "<br>
Payment Type : ";
                // line 248
                if (($this->getAttribute($context["order"], "paymentType", array()) == "cod")) {
                    echo "Cash On Delivery ";
                } elseif (($this->getAttribute($context["order"], "paymentType", array()) == "sod")) {
                    echo " Swipe On Delivery ";
                } else {
                    echo " ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "paymentType", array()), "html", null, true);
                    echo " ";
                }
                echo "<br>
                           </small>
      </div>

      <hr>

      <!-- Details -->
<table>
  <tr>
    <td class=\"tdds\">Item/Hsn</td>
      <td class=\"tds\">Net. Price</td>
    <td class=\"tds\">Qty</td>
    <td class=\"tds\">Total </td>
 </tr>
 ";
                // line 262
                $context["count"] = 0;
                // line 263
                echo " ";
                $context["sum"] = 0;
                // line 264
                echo "         ";
                $context["quantity"] = 0;
                // line 265
                echo "
";
                // line 266
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["items"] ?? $this->getContext($context, "items")));
                foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                    // line 267
                    if (($this->getAttribute($context["item"], "order_d", array()) == $this->getAttribute($context["order"], "id", array()))) {
                        // line 268
                        if ((($this->getAttribute($context["item"], "tax", array()) == 0) || ($this->getAttribute($context["item"], "tax", array()) == ""))) {
                            // line 269
                            $context["taxp"] = $this->getAttribute($context["item"], "tax", array());
                            echo " 
<tr>
    <td class=\"tdd\">";
                            // line 271
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
                            echo " - ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "priceVariavtion", array()), "html", null, true);
                            echo "</td>
  ";
                            // line 272
                            $context["dis"] = ($this->getAttribute($context["item"], "discount", array()) + $this->getAttribute($context["item"], "discountPrice", array()));
                            // line 273
                            echo "    <td class=\"td\">";
                            $context["final"] = $this->getAttribute($context["item"], "price", array());
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round(($context["final"] ?? $this->getContext($context, "final")), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["final"] ?? $this->getContext($context, "final")), 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
    <td class=\"td\">";
                            // line 274
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", array()), "html", null, true);
                            echo "</td>
    <td class=\"td\">";
                            // line 275
                            $context["x"] = ($this->getAttribute($context["item"], "price", array()) * $this->getAttribute($context["item"], "quantity", array()));
                            echo " ";
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["item"], "subTotal", array()), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["item"], "subTotal", array()), 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
 </tr>
";
                        } else {
                            // line 278
                            echo "<tr>
    <td class=\"tdd\">";
                            // line 279
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
                            echo " - ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "priceVariavtion", array()), "html", null, true);
                            echo " / ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "hsn", array()), "html", null, true);
                            echo "</td>
  ";
                            // line 280
                            $context["dis"] = ($this->getAttribute($context["item"], "discount", array()) + $this->getAttribute($context["item"], "discountPrice", array()));
                            // line 281
                            echo "    ";
                            if ((($context["orders"] ?? $this->getContext($context, "orders")) == "")) {
                                // line 282
                                echo "    <center>No Data Found!</center>
";
                            }
                            // line 283
                            echo "   ";
                            $context["taxp"] = ($this->getAttribute($context["item"], "price", array()) / $this->getAttribute($context["item"], "tax", array()));
                            echo " ";
                            $context["finals"] = $this->getAttribute($context["item"], "price", array());
                            echo " ";
                            $context["final"] = ($context["finals"] ?? $this->getContext($context, "finals"));
                            // line 284
                            echo "    <td class=\"td\">";
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round(($context["final"] ?? $this->getContext($context, "final")), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["final"] ?? $this->getContext($context, "final")), 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
  
    <td class=\"td\">";
                            // line 286
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", array()), "html", null, true);
                            echo "</td>

    <td class=\"td\">";
                            // line 288
                            $context["x"] = (($context["final"] ?? $this->getContext($context, "final")) * $this->getAttribute($context["item"], "quantity", array()));
                            echo " ";
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round(($context["x"] ?? $this->getContext($context, "x")), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["x"] ?? $this->getContext($context, "x")), 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
 </tr>
 ";
                        }
                        // line 291
                        echo "    ";
                        $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + ($context["taxp"] ?? $this->getContext($context, "taxp")));
                        // line 292
                        echo "    ";
                        $context["sum"] = (($context["sum"] ?? $this->getContext($context, "sum")) + ($context["x"] ?? $this->getContext($context, "x")));
                        // line 293
                        echo "     ";
                        $context["quantity"] = (($context["quantity"] ?? $this->getContext($context, "quantity")) + $this->getAttribute($context["item"], "quantity", array()));
                        // line 294
                        echo "
";
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 297
                echo "</table>
<hr>  
";
                // line 299
                if (((($context["count"] ?? $this->getContext($context, "count")) == 0) || (($context["count"] ?? $this->getContext($context, "count")) == ""))) {
                    // line 300
                    echo "<div class=\"totalprice\">

        <p class=\"sub\"> Subtotal <span> ";
                    // line 302
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round(($context["sum"] ?? $this->getContext($context, "sum")), 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["sum"] ?? $this->getContext($context, "sum")), 2, ".", ""), "html", null, true);
                    }
                    echo "</span></p>
        <!-- <p class=\"del\"> Tax <span>   ";
                    // line 303
                    echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                    echo " </span> </p> -->
        <!-- <p class=\"del\"> Discount <span> ";
                    // line 304
                    echo twig_escape_filter($this->env, ($this->getAttribute($context["order"], "totalDiscount", array()) + $this->getAttribute($context["order"], "discountTotal", array())), "html", null, true);
                    echo " </span> </p> -->

        <p class=\"del\"> Delivery <span>  ";
                    // line 306
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["order"], "deliveryCharge", array()), 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["order"], "deliveryCharge", array()), 2, ".", ""), "html", null, true);
                    }
                    echo " </span> </p>

        <hr>

        <p class=\"del\"> Total <span> ";
                    // line 310
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["order"], "orderAmount", array()), 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["order"], "orderAmount", array()), 2, ".", ""), "html", null, true);
                    }
                    echo " </span> </p>

      </div>
      ";
                    // line 313
                    if (($this->getAttribute($context["order"], "discountTotal", array()) == 0)) {
                        // line 314
                        echo "      ";
                    } else {
                        // line 315
                        echo "          ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(($context["restaurant"] ?? $this->getContext($context, "restaurant")));
                        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
                            // line 316
                            echo "       <center><b>You Saved ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "currencyFormat", array()), "html", null, true);
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["order"], "discountTotal", array()), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["order"], "discountTotal", array()), 2, ".", ""), "html", null, true);
                            }
                            echo "<b></center>
        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 318
                        echo "        ";
                    }
                } else {
                    // line 320
                    echo "      <div class=\"totalprice\">

        <p class=\"sub\"> Subtotal <span> ";
                    // line 322
                    $context["x"] = (($this->getAttribute($context["order"], "actualAmount", array()) * ($context["count"] ?? $this->getContext($context, "count"))) / 100);
                    echo " ";
                    $context["fin"] = (($context["sum"] ?? $this->getContext($context, "sum")) - ($context["x"] ?? $this->getContext($context, "x")));
                    echo " ";
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round(($context["sum"] ?? $this->getContext($context, "sum")), 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["sum"] ?? $this->getContext($context, "sum")), 2, ".", ""), "html", null, true);
                    }
                    echo "</span></p>
        <!-- <p class=\"del\"> Tax <span>   ";
                    // line 323
                    echo twig_escape_filter($this->env, twig_round(($context["count"] ?? $this->getContext($context, "count"))), "html", null, true);
                    echo " </span> </p> -->
        <!-- <p class=\"del\"> Discount <span> ";
                    // line 324
                    echo twig_escape_filter($this->env, ($this->getAttribute($context["order"], "totalDiscount", array()) + $this->getAttribute($context["order"], "discountTotal", array())), "html", null, true);
                    echo " </span> </p> -->

        <p class=\"del\"> Delivery <span> ";
                    // line 326
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["order"], "deliveryCharge", array()), 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["order"], "deliveryCharge", array()), 2, ".", ""), "html", null, true);
                    }
                    echo " </span> </p>

        <hr>

        <p class=\"del\"> Total <span> ";
                    // line 330
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["order"], "orderAmount", array()), 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["order"], "orderAmount", array()), 2, ".", ""), "html", null, true);
                    }
                    echo " </span> </p>

      </div>
      ";
                    // line 333
                    if (($this->getAttribute($context["order"], "discountTotal", array()) == 0)) {
                        // line 334
                        echo "      ";
                    } else {
                        // line 335
                        echo "          ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(($context["restaurant"] ?? $this->getContext($context, "restaurant")));
                        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
                            // line 336
                            echo "       <center><b>You Saved ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "currencyFormat", array()), "html", null, true);
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["order"], "discountTotal", array()), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["order"], "discountTotal", array()), 2, ".", ""), "html", null, true);
                            }
                            echo "<b></center>
        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 338
                        echo "     ";
                    }
                    // line 339
                    echo "
      <hr>
 
<table>
  <tr>
    <td class=\"tdss\">GST Index</td>
    <td class=\"tdss\">Taxable Amount</td>
    <td class=\"tdss\">CGST</td>
    <td class=\"tdss\">SGST</td>
    <td class=\"tdss\">Total</td>
 </tr>
 ";
                    // line 350
                    $context["count"] = 1;
                    // line 351
                    echo "  ";
                    $context["res"] = 0;
                    // line 352
                    echo "  ";
                    $context["data"] = 0;
                    // line 353
                    echo " ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(($context["tax"] ?? $this->getContext($context, "tax")));
                    foreach ($context['_seq'] as $context["_key"] => $context["ta"]) {
                        // line 354
                        echo " ";
                        if (($this->getAttribute($context["ta"], "order_d", array()) == $this->getAttribute($context["order"], "id", array()))) {
                            // line 355
                            echo "  <tr> 
    <td class=\"td\">";
                            // line 356
                            echo twig_escape_filter($this->env, $this->getAttribute($context["ta"], "tax", array()), "html", null, true);
                            echo "</td>
    <td class=\"td\">";
                            // line 357
                            $context["x"] = (100 + $this->getAttribute($context["ta"], "tax", array()));
                            // line 358
                            echo "                                     ";
                            $context["pr"] = (($this->getAttribute($context["ta"], "subTotal", array()) * 100) / ($context["x"] ?? $this->getContext($context, "x")));
                            echo " ";
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round(($context["pr"] ?? $this->getContext($context, "pr")), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["pr"] ?? $this->getContext($context, "pr")), 2, ".", ""), "html", null, true);
                            }
                            // line 359
                            echo "</td>
";
                            // line 360
                            $context["cgst"] = ($this->getAttribute($context["ta"], "subTotal", array()) - ($context["pr"] ?? $this->getContext($context, "pr")));
                            echo " 
    <td class=\"td\">";
                            // line 361
                            $context["cg"] = (($context["cgst"] ?? $this->getContext($context, "cgst")) / 2);
                            echo " ";
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round(($context["cg"] ?? $this->getContext($context, "cg")), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["cg"] ?? $this->getContext($context, "cg")), 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
    <td class=\"td\"> ";
                            // line 362
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round(($context["cg"] ?? $this->getContext($context, "cg")), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["cg"] ?? $this->getContext($context, "cg")), 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
    <td class=\"td\">";
                            // line 363
                            echo twig_escape_filter($this->env, $this->getAttribute($context["ta"], "subTotal", array()), "html", null, true);
                            echo "</td>
 </tr>
 ";
                            // line 365
                            $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
                            // line 366
                            echo " ";
                            $context["res"] = ($context["res"] + ($context["cg"] ?? $this->getContext($context, "cg")));
                            // line 367
                            echo "  ";
                            $context["data"] = (($context["data"] ?? $this->getContext($context, "data")) + ($context["pr"] ?? $this->getContext($context, "pr")));
                        }
                        // line 369
                        echo "
";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ta'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 371
                    echo "<tr>
<th colspan=\"5\"><hr></th></tr>
  <tr>

    <td class=\"tdss\">Total</td>
    <td class=\"tdss\"> ";
                    // line 376
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round(($context["data"] ?? $this->getContext($context, "data")), 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["data"] ?? $this->getContext($context, "data")), 2, ".", ""), "html", null, true);
                    }
                    echo "</td>
    <td class=\"tdss\">";
                    // line 377
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round($context["res"], 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $context["res"], 2, ".", ""), "html", null, true);
                    }
                    echo "</td>
    <td class=\"tdss\">";
                    // line 378
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round($context["res"], 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $context["res"], 2, ".", ""), "html", null, true);
                    }
                    echo "</td>
    <td class=\"tdss\">";
                    // line 379
                    echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "actualAmount", array()), "html", null, true);
                    echo " </td>
 </tr>
 ";
                }
                // line 382
                echo "</table>
<hr>
    <center><h4>Total Items : ";
                // line 384
                echo twig_escape_filter($this->env, ($context["quantity"] ?? $this->getContext($context, "quantity")), "html", null, true);
                echo "</h4></center>
 ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 386
            echo "
      <!-- Footer -->
      <footer><b> Thank you for ordering with      ";
            // line 388
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["restaurant"] ?? $this->getContext($context, "restaurant")));
            foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
                // line 389
                echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantName", array()), "html", null, true);
                echo "</b> ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "</footer>

    </div>
  </div>
   ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['order'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 393
        echo "   
";
        
        $__internal_401f7e8ec8e3806bbe91789274608f47ee87b809e5cf5dff49440347714e1739->leave($__internal_401f7e8ec8e3806bbe91789274608f47ee87b809e5cf5dff49440347714e1739_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Orders/multithermal.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  821 => 393,  805 => 389,  801 => 388,  797 => 386,  789 => 384,  785 => 382,  779 => 379,  771 => 378,  763 => 377,  755 => 376,  748 => 371,  741 => 369,  737 => 367,  734 => 366,  732 => 365,  727 => 363,  719 => 362,  709 => 361,  705 => 360,  702 => 359,  693 => 358,  691 => 357,  687 => 356,  684 => 355,  681 => 354,  676 => 353,  673 => 352,  670 => 351,  668 => 350,  655 => 339,  652 => 338,  638 => 336,  633 => 335,  630 => 334,  628 => 333,  618 => 330,  607 => 326,  602 => 324,  598 => 323,  586 => 322,  582 => 320,  578 => 318,  564 => 316,  559 => 315,  556 => 314,  554 => 313,  544 => 310,  533 => 306,  528 => 304,  524 => 303,  516 => 302,  512 => 300,  510 => 299,  506 => 297,  498 => 294,  495 => 293,  492 => 292,  489 => 291,  477 => 288,  472 => 286,  462 => 284,  455 => 283,  451 => 282,  448 => 281,  446 => 280,  438 => 279,  435 => 278,  423 => 275,  419 => 274,  409 => 273,  407 => 272,  401 => 271,  396 => 269,  394 => 268,  392 => 267,  388 => 266,  385 => 265,  382 => 264,  379 => 263,  377 => 262,  352 => 248,  346 => 247,  342 => 246,  338 => 245,  334 => 244,  330 => 243,  326 => 242,  322 => 241,  318 => 240,  314 => 239,  310 => 238,  306 => 237,  292 => 226,  288 => 225,  283 => 223,  279 => 222,  275 => 221,  264 => 219,  260 => 218,  254 => 215,  249 => 212,  246 => 211,  242 => 210,  239 => 209,  235 => 208,  29 => 4,  25 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("        {% if yes == 1 %}
    <center>No Data Found!</center>
{% endif %}

      <style type=\"text/css\">
    /* Our Font */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;700&display=swap');

/* Global */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins';
  color: #000 !important;
}
 
body {
  margin-top: 10px;
  height: 100vh;
}

/* The Receipt */
.receipt {
    width: 400px;
    background-color: white;
    border-radius: 30px;
    position: relative;
    /* top: 30%; */
    /* left: 50%; */
    /* margin-top: -360px; */
    /* margin-left: -180px; */
    padding: 20px;
    margin: 0px auto;
}
.body {
    width: 100%;
    display: inline-block;
    margin: 0 auto;
}
/* Heading */
.name {
  text-transform: uppercase;
  text-align: center;
  color: #6c8b8e;
  letter-spacing: 1px;
  font-size: 1.8em;
  margin-top: 10px
}

/* Big thank */
.greeting {
  font-size: 21px;
  text-transform: capitalize;
  text-align: center;
  color: #6f8d90;
  margin: 35px 0;
  letter-spacing: 1.2px
}

/* Order info */
.order p {
  font-size: 13px;
  color: #aaa;
  padding-left: 10px;
  letter-spacing: .7px
}

/* Our line */
hr {
  border: .7px solid #ddd;
  margin: 15px 0;
}

/* Order details */
.details {
  padding-left: 10px;
  margin-bottom: 3px;
  overflow: hidden
}

.details h3 {
  font-weight: 400;
  color: #6c8b8e;
  font-size: 1.5em;
  margin-bottom: 8px
}

/* Image and the info of the order */
.product {
  float: left;
  width: 83%
}

.product img {
  width: 65px;
  float: left
}

.product .info {
  float: left;
  margin-left: 15px
}

.product .info h4 {
  color: #6f8d90;
  font-weight: 400;
  text-transform: uppercase;
  margin-top: 5px
}

.product .info p {
  font-size: 12px;
  color: #aaa;
}

/* Net price */
.details > p {
  color: #6f8d90;
  margin-top: 25px;
  font-size: 15px
}

/* Total price */
.totalprice p {
  padding-left: 10px
}

.totalprice .sub,
.totalprice .del {
  font-size: 13px;
  color: #aaa
}

.totalprice span {
  float: right;
  margin-right: 17px
}

.totalprice .tot {
  color: #6f8d90;
  font-size: 15px
}

/* Footer */
footer {
  font-size: 10px;
  text-align: center;
  margin-top: 15px; /* You can make it with position try it */
  color: #aaa
}
.td
{
      padding-left: 24px !important;
    background: white;
    padding: 3px;
    font-size: 12px;
}
.tdd
{
    background: white;
    padding: 3px;
    font-size: 12px;
}
.tds {
    padding-left: 20px !important;
    background: white;
    padding: 3px;
    font-size: 12px;
    font-weight: bold;  
}
.tdds {
    background: white;
    padding: 3px;
    font-size: 12px;
    font-weight: bold;  
}
.tdss {
    padding-left: 18px !important;
    background: white;
    padding: 3px;
    font-size: 10px;
    font-weight: bold;  
}
.tdsss {
    padding-left: 50px !important;
    background: white;
    padding: 3px;
    font-size: 10px;
    font-weight: bold;  
}
hr {
    border: .7px solid #ddd;
    margin: 3px 0;
}
 @media print
      {
         @page {
           margin-top: 0;
           margin-bottom: 0;
         }
         body  {
           padding-top: 72px;
           padding-bottom: 72px ;
         }
      } 
    </style>
    {% for order in orders %}

    {% for res in restaurant%}
    {% set numberFormat = res.number_format %}
       <div class=\"body\">

    <div class=\"receipt\">
      <h2 class=\"name\"> {{ res.restaurantName }} </h2>
      
    <center>  
    <b>#{{ order.id }}</b>
    <h4>{% if order.orderType == 'Delivery' %} Home Delivery {% elseif order.orderType == 'pickup' %} Pickup From Store {% else %} Express Delivery {% endif %}</h4>
 <div class=\"order\"><small>
                           {{ res.restaurantAddress }}<br>
                           {{ res.restaurantLocation }}<br>
                            Gst No:{{ res.gst }}<br>

                           Mobile : {{ res.primaryMobile }}<br>
                           Email : {{ res.primaryEmail }} 
                         </small>
                         </div></center>
<hr>

      <!-- Order info -->
      <div class=\"order\">


      <p>Bill to/Ship to:<br>
                           <small>
                           {{ order.customerName }}<br>
                           {{ order.address }}<br>
                           {{ order.landmark }}<br>
                           Mobile : {{ order.mobileNo }}<br>
                           Email : {{ order.email }}<br>
                           Gst No: {{ order.gst }}<br>
                           Delivery Date :  {{ order.fixDate }}<br>
Delivery Time : {{ order.fixtime }}<br>
Promocode : {{ order.promocode }}<br>
Note : {{ order.note }}<br>
Order Date :{{  order.orderDate|date(\"d-m-Y\") }} at {{  order.orderDate|date(\"h-i A\") }}<br>
Payment Type : {% if order.paymentType == 'cod' %}Cash On Delivery {% elseif order.paymentType == 'sod'%} Swipe On Delivery {% else %} {{ order.paymentType }} {% endif %}<br>
                           </small>
      </div>

      <hr>

      <!-- Details -->
<table>
  <tr>
    <td class=\"tdds\">Item/Hsn</td>
      <td class=\"tds\">Net. Price</td>
    <td class=\"tds\">Qty</td>
    <td class=\"tds\">Total </td>
 </tr>
 {% set count = 0 %}
 {% set sum = 0 %}
         {% set quantity = 0 %}

{% for item in items %}
{% if item.order_d == order.id %}
{% if item.tax == 0 or item.tax == ''%}
{% set taxp = item.tax %} 
<tr>
    <td class=\"tdd\">{{ item.itemName }} - {{ item.priceVariavtion }}</td>
  {% set dis = item.discount+item.discountPrice %}
    <td class=\"td\">{% set final = item.price  %}{% if numberFormat == 0 %}{{ final|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ final|number_format(2, '.', '') }}{% endif %}</td>
    <td class=\"td\">{{ item.quantity }}</td>
    <td class=\"td\">{% set x =  item.price * item.quantity  %} {% if numberFormat == 0 %}{{ item.subTotal|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ item.subTotal|number_format(2, '.', '') }}{% endif %}</td>
 </tr>
{% else %}
<tr>
    <td class=\"tdd\">{{ item.itemName }} - {{ item.priceVariavtion }} / {{ item.hsn }}</td>
  {% set dis = item.discount+item.discountPrice %}
    {% if orders == '' %}
    <center>No Data Found!</center>
{% endif %}   {% set taxp = item.price / item.tax %} {% set finals = item.price  %} {% set final =  finals %}
    <td class=\"td\">{% if numberFormat == 0 %}{{ final|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ final|number_format(2, '.', '') }}{% endif %}</td>
  
    <td class=\"td\">{{ item.quantity }}</td>

    <td class=\"td\">{% set x =  final * item.quantity  %} {% if numberFormat == 0 %}{{ x|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ x|number_format(2, '.', '') }}{% endif %}</td>
 </tr>
 {% endif %}
    {% set count = count + taxp %}
    {% set sum = sum + x %}
     {% set quantity = quantity + item.quantity %}

{% endif %}
{% endfor %}
</table>
<hr>  
{% if count == 0 or count == ''%}
<div class=\"totalprice\">

        <p class=\"sub\"> Subtotal <span> {% if numberFormat == 0 %}{{ sum|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ sum|number_format(2, '.', '') }}{% endif %}</span></p>
        <!-- <p class=\"del\"> Tax <span>   {{ count }} </span> </p> -->
        <!-- <p class=\"del\"> Discount <span> {{ order.totalDiscount + order.discountTotal }} </span> </p> -->

        <p class=\"del\"> Delivery <span>  {% if numberFormat == 0 %}{{ order.deliveryCharge|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.deliveryCharge|number_format(2, '.', '') }}{% endif %} </span> </p>

        <hr>

        <p class=\"del\"> Total <span> {% if numberFormat == 0 %}{{ order.orderAmount|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.orderAmount|number_format(2, '.', '') }}{% endif %} </span> </p>

      </div>
      {% if order.discountTotal == 0  %}
      {% else %}
          {% for res in restaurant%}
       <center><b>You Saved {{ res.currencyFormat }}{% if numberFormat == 0 %}{{ order.discountTotal|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.discountTotal|number_format(2, '.', '') }}{% endif %}<b></center>
        {% endfor %}
        {% endif %}
{% else %}
      <div class=\"totalprice\">

        <p class=\"sub\"> Subtotal <span> {% set x = order.actualAmount * count / 100 %} {%  set fin = sum - x %} {% if numberFormat == 0 %}{{ sum|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ sum|number_format(2, '.', '') }}{% endif %}</span></p>
        <!-- <p class=\"del\"> Tax <span>   {{ count|round }} </span> </p> -->
        <!-- <p class=\"del\"> Discount <span> {{ order.totalDiscount + order.discountTotal }} </span> </p> -->

        <p class=\"del\"> Delivery <span> {% if numberFormat == 0 %}{{ order.deliveryCharge|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.deliveryCharge|number_format(2, '.', '') }}{% endif %} </span> </p>

        <hr>

        <p class=\"del\"> Total <span> {% if numberFormat == 0 %}{{ order.orderAmount|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.orderAmount|number_format(2, '.', '') }}{% endif %} </span> </p>

      </div>
      {% if order.discountTotal == 0  %}
      {% else %}
          {% for res in restaurant%}
       <center><b>You Saved {{ res.currencyFormat }}{% if numberFormat == 0 %}{{ order.discountTotal|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.discountTotal|number_format(2, '.', '') }}{% endif %}<b></center>
        {% endfor %}
     {% endif %}

      <hr>
 
<table>
  <tr>
    <td class=\"tdss\">GST Index</td>
    <td class=\"tdss\">Taxable Amount</td>
    <td class=\"tdss\">CGST</td>
    <td class=\"tdss\">SGST</td>
    <td class=\"tdss\">Total</td>
 </tr>
 {% set count = 1 %}
  {% set res = 0 %}
  {% set data = 0 %}
 {% for ta in tax %}
 {% if ta.order_d == order.id %}
  <tr> 
    <td class=\"td\">{{ ta.tax }}</td>
    <td class=\"td\">{% set x= 100+ta.tax %}
                                     {% set pr=ta.subTotal*100/x %} {% if numberFormat == 0 %}{{ pr|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ pr|number_format(2, '.', '') }}{% endif %}
</td>
{% set cgst = ta.subTotal-pr %} 
    <td class=\"td\">{% set cg = cgst/2 %} {% if numberFormat == 0 %}{{ cg|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ cg|number_format(2, '.', '') }}{% endif %}</td>
    <td class=\"td\"> {% if numberFormat == 0 %}{{ cg|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ cg|number_format(2, '.', '') }}{% endif %}</td>
    <td class=\"td\">{{ ta.subTotal }}</td>
 </tr>
 {% set count = count + 1 %}
 {% set res = res + cg %}
  {% set data = data + pr %}
{% endif %}

{% endfor %}
<tr>
<th colspan=\"5\"><hr></th></tr>
  <tr>

    <td class=\"tdss\">Total</td>
    <td class=\"tdss\"> {% if numberFormat == 0 %}{{ data|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ data|number_format(2, '.', '') }}{% endif %}</td>
    <td class=\"tdss\">{% if numberFormat == 0 %}{{ res|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ res|number_format(2, '.', '') }}{% endif %}</td>
    <td class=\"tdss\">{% if numberFormat == 0 %}{{ res|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ res|number_format(2, '.', '') }}{% endif %}</td>
    <td class=\"tdss\">{{ order.actualAmount }} </td>
 </tr>
 {% endif %}
</table>
<hr>
    <center><h4>Total Items : {{ quantity }}</h4></center>
 {% endfor %}

      <!-- Footer -->
      <footer><b> Thank you for ordering with      {% for res in restaurant%}
{{ res.restaurantName }}</b> {% endfor %}</footer>

    </div>
  </div>
   {% endfor %}   
", "AppBundle:Admin:Orders/multithermal.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Orders/multithermal.html.twig");
    }
}

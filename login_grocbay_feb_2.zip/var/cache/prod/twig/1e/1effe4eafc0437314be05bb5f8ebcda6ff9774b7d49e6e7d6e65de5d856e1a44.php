<?php

/* AppBundle:Admin:Pickup/sub-location.html.twig */
class __TwigTemplate_64ce63e18dfb47ff7326d114b0076335ab378ea5471f313814382637212316cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pickup/sub-location.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_02afec89bc65609bf12a2621185636f08b40fec6e6f8059dea10bcf8b14a0cb0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02afec89bc65609bf12a2621185636f08b40fec6e6f8059dea10bcf8b14a0cb0->enter($__internal_02afec89bc65609bf12a2621185636f08b40fec6e6f8059dea10bcf8b14a0cb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pickup/sub-location.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_02afec89bc65609bf12a2621185636f08b40fec6e6f8059dea10bcf8b14a0cb0->leave($__internal_02afec89bc65609bf12a2621185636f08b40fec6e6f8059dea10bcf8b14a0cb0_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_d6a00eb2feb88cd945733c2c595bb515c587f561ee5861fd69aafe53599e962a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6a00eb2feb88cd945733c2c595bb515c587f561ee5861fd69aafe53599e962a->enter($__internal_d6a00eb2feb88cd945733c2c595bb515c587f561ee5861fd69aafe53599e962a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "<!--nestable CSS -->
<link href=\"/assets/plugins/nestable/nestable.css\" rel=\"stylesheet\" type=\"text/css\" />
 <script src=\"https://apis.google.com/js/platform.js\" async defer></script>
       <script type=\"text/javascript\"
            src=\"https://maps.google.com/maps/api/js?sensor=false&key=AIzaSyBSR3pigsWMH7goi_CthGQFckfb5QPOH8E&v=3.21.5a&libraries=drawing&signed_in=true&libraries=places,drawing,geometry\"></script>
<style>
</style>

";
        
        $__internal_d6a00eb2feb88cd945733c2c595bb515c587f561ee5861fd69aafe53599e962a->leave($__internal_d6a00eb2feb88cd945733c2c595bb515c587f561ee5861fd69aafe53599e962a_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_e9d14125a1a6574e7622c77314d8b413c63da7ffdbff3496830cf55c7d6efd97 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9d14125a1a6574e7622c77314d8b413c63da7ffdbff3496830cf55c7d6efd97->enter($__internal_e9d14125a1a6574e7622c77314d8b413c63da7ffdbff3496830cf55c7d6efd97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo " <!-- Modal -->
  <div class=\"modal fade\" id=\"myModal\" role=\"dialog\">
    <div class=\"modal-dialog\">
    
      <!-- Modal content-->
      <div class=\"modal-content\">
        <div class=\"modal-header\">
          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
          <h4 class=\"modal-title\">Create Pickup Location</h4>
        </div>
        <div class=\"modal-body\">
          <form method=\"post\" action=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create_pickup_location");
        echo "\">

<div class=\"form-group\">
  <label>Pickup Location Name</label>
  <input type=\"text\" class=\"form-control\" placeholder=\"Pickup Location Name\" name=\"name\">
</div>
<div class=\"form-group\">
  <label>Address</label>
  <textarea class=\"form-control\" rows=\"3\" placeholder=\"Address\" name=\"address\"></textarea>
</div>
<div class=\"form-group\">
  <label>Contact Number</label>
  <input type=\"text\" class=\"form-control\" placeholder=\"Contact Number\" name=\"contact\">
</div>
<div class=\"form-group\">
  <label>Delivery Block</label>
  <select class=\"form-control\" name=\"area\">
 ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["areas"] ?? $this->getContext($context, "areas")));
        foreach ($context['_seq'] as $context["_key"] => $context["area"]) {
            // line 42
            echo " <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["area"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["area"], "title", array()), "html", null, true);
            echo "</option>
 ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['area'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "  </select>
</div>
                         <a href=\"#openmap\" data-toggle=\"modal\" data-target=\"#location\">Map</a>
<div class=\"row\">
                            
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        <label for=\"appbundle_restaurants_restaurantLat\">Latitude</label>
                                        <div id=\"appbundle_restaurants_restaurantLat_form_group\" class=\"form-group \"><input type=\"text\" id=\"appbundle_restaurants_restaurantLat\" name=\"latitude\" maxlength=\"255\" class=\"form-control\"></div>
                                    </div>
                                </div>   
                                     <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        <label for=\"appbundle_restaurants_restaurantLong\">Longitude</label>
                                        <div id=\"appbundle_restaurants_restaurantLong_form_group\" class=\"form-group \"><input type=\"text\" id=\"appbundle_restaurants_restaurantLong\" name=\"longitude\" maxlength=\"255\" class=\"form-control form-control\"></div>
                                    </div>
                                </div>
                            </div>
          
        </div>
        <div class=\"modal-footer\">
          <button type=\"submit\" class=\"btn btn-primary\">Save</button>
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
  




<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"card\">
            ";
        // line 82
        echo "            <div class=\"card-body\">
                   <h4 class=\"card-title\">Manage Pickup Location<button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#myModal\" style=\"float:right;\">
                Create New</button></h4>
  

                <table class=\"table table-hovered\" id=\"myTable\">
                    <thead>
                    <tr>
                      <th>#</th>
                        <th>Location</th>
                        <th>Address</th>
                        <th>Contact Details</th>
                        <th>Delivery Block</th>
                        <th>Action</th>
                    </tr>
                    
                </thead>
                ";
        // line 99
        $context["count"] = 1;
        // line 100
        echo "                    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["location"] ?? $this->getContext($context, "location")));
        foreach ($context['_seq'] as $context["_key"] => $context["loc"]) {
            // line 101
            echo "<tr>
<td>";
            // line 102
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo " </td>
<td>";
            // line 103
            echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "name", array()), "html", null, true);
            echo " </td>
<td>";
            // line 104
            echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "address", array()), "html", null, true);
            echo " </td>
<td>";
            // line 105
            echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "contact", array()), "html", null, true);
            echo " </td>
<td> 
  ";
            // line 107
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["areas"] ?? $this->getContext($context, "areas")));
            foreach ($context['_seq'] as $context["_key"] => $context["area"]) {
                // line 108
                if (($this->getAttribute($context["area"], "id", array()) == $this->getAttribute($context["loc"], "parent", array()))) {
                    // line 109
                    echo twig_escape_filter($this->env, $this->getAttribute($context["area"], "title", array()), "html", null, true);
                    echo "
";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['area'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 111
            echo " </td>
<td style=\"text-align:center;\"><a href=\"";
            // line 112
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_pickup", array("id" => $this->getAttribute($context["loc"], "id", array()))), "html", null, true);
            echo "\"   class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i></a >

<a href=\"#edit\"   class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#edit";
            // line 114
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\"><i class=\"fa fa-edit\"></i></a >  <br>
<a href=\"";
            // line 115
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pickup_slots", array("id" => $this->getAttribute($context["loc"], "id", array()))), "html", null, true);
            echo "\"   class=\"btn btn-primary btn-sm\" style=\"margin-top:10px;\"><i class=\"fa fa-edit\"></i> Create Slots</a >  </td>

</tr>
<div class=\"modal fade\" id=\"edit";
            // line 118
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" role=\"dialog\">
    <div class=\"modal-dialog\">
    
      <!-- Modal content-->
      <div class=\"modal-content\">
        <div class=\"modal-header\">
          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
          <h4 class=\"modal-title\">Edit Pickup Location</h4>
        </div>
        <div class=\"modal-body\">
          <form method=\"post\" action=\"";
            // line 128
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("edit_pickup_location");
            echo "\">

<div class=\"form-group\">
  <label>Pickup Location Name</label>
  <input type=\"text\" class=\"form-control\" placeholder=\"Pickup Location Name\" name=\"name\" value=\"";
            // line 132
            echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "name", array()), "html", null, true);
            echo "\">
  <input type=\"hidden\" class=\"form-control\" placeholder=\"Pickup Location Name\" name=\"id\" value=\"";
            // line 133
            echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "id", array()), "html", null, true);
            echo "\">
</div>
<div class=\"form-group\">
  <label>Address</label>
  <textarea class=\"form-control\" rows=\"3\" placeholder=\"Address\" name=\"address\">";
            // line 137
            echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "address", array()), "html", null, true);
            echo "</textarea>
</div>
<div class=\"form-group\">
  <label>Contact Number</label>
  <input type=\"text\" class=\"form-control\" placeholder=\"Contact Number\" name=\"contact\" value=\"";
            // line 141
            echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "contact", array()), "html", null, true);
            echo "\">
</div>
<div class=\"form-group\">
  <label>Delivery Block</label>
  <select class=\"form-control\" name=\"area\">
 ";
            // line 146
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["areas"] ?? $this->getContext($context, "areas")));
            foreach ($context['_seq'] as $context["_key"] => $context["area"]) {
                // line 147
                echo " <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["area"], "id", array()), "html", null, true);
                echo "\" ";
                if (($this->getAttribute($context["area"], "id", array()) == $this->getAttribute($context["loc"], "parent", array()))) {
                    echo " selected ";
                }
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["area"], "title", array()), "html", null, true);
                echo "</option>
 ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['area'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 149
            echo "  </select>
</div>
<div class=\"row\">
                            
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        <label for=\"appbundle_restaurants_restaurantLat\">Latitude</label>
                                        <div id=\"appbundle_restaurants_restaurantLat_form_group\" class=\"form-group \"><input type=\"text\" id=\"\" name=\"latitude\" maxlength=\"255\" class=\"form-control appbundle_restaurants_restaurantLat\" value=\"";
            // line 156
            echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "latitude", array()), "html", null, true);
            echo "\"></div>
                                    </div>
                                </div>   
                                     <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        <label for=\"appbundle_restaurants_restaurantLong\">Longitude</label>
                                        <div id=\"appbundle_restaurants_restaurantLong_form_group\" class=\"form-group \"><input type=\"text\" id=\"\" name=\"longitude\" maxlength=\"255\" class=\"form-control form-control appbundle_restaurants_restaurantLong\" value=\"";
            // line 162
            echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "longitude", array()), "html", null, true);
            echo "\"></div>
                                    </div>
                                </div>
                            </div>
          
        </div>
        <div class=\"modal-footer\">
          <button type=\"submit\" class=\"btn btn-primary\">Save</button>
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
  

";
            // line 179
            $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
            // line 180
            echo "                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['loc'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "  
                                    <tbody>

                      </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
";
        
        $__internal_e9d14125a1a6574e7622c77314d8b413c63da7ffdbff3496830cf55c7d6efd97->leave($__internal_e9d14125a1a6574e7622c77314d8b413c63da7ffdbff3496830cf55c7d6efd97_prof);

    }

    // line 191
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_c2c2a8902796d02c1a1bb9b06b000dbdb685462e4511359032c04b4030700993 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2c2a8902796d02c1a1bb9b06b000dbdb685462e4511359032c04b4030700993->enter($__internal_c2c2a8902796d02c1a1bb9b06b000dbdb685462e4511359032c04b4030700993_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 192
        echo "<!--Nestable js -->
<script src=\"/assets/plugins/nestable/jquery.nestable.js\"></script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
   \$(document).ready(function() {
      \$('#myTable').DataTable();
    });
</script>
<script type=\"text/javascript\">
    \$(document).ready(function() {
        // Nestable

        //updateOutput(\$('#nestable').data('output', \$('#nestable-output')));
/*
        \$('#nestable-menu').on('click', function(e) {
            var target = \$(e.target),
                action = target.data('action');
            if (action === 'expand-all') {
                \$('.dd').nestable('expandAll');
            }
            if (action === 'collapse-all') {
                \$('.dd').nestable('collapseAll');
            }
        });*/

        \$('#nestable-menu').nestable();/*
        \$('.dd').nestable('collapseAll');*/
    });
    </script>
<!-- Modal -->
<div id=\"location\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Select Branch Location</h4>
      </div>
      <div class=\"modal-body\">
                         <div  class=\"map-area\">
<script>
var map;
var marker;

function initialize() {
  var mapOptions = {
    zoom: 12
  };
  map = new google.maps.Map(document.getElementById('map-canvas'),
    mapOptions);

  // Get GEOLOCATION
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var pos = new google.maps.LatLng(position.coords.latitude,
        position.coords.longitude);
\$('#appbundle_restaurants_restaurantLat').val(position.coords.latitude);
\$('#appbundle_restaurants_restaurantLong').val(position.coords.longitude);



      map.setCenter(pos);
      marker = new google.maps.Marker({
        position: pos,
        map: map,
        draggable: true
      });
      google.maps.event.addListener(marker, 'dragstart', function(evt) {
 \$('#appbundle_restaurants_restaurantLat').val(marker.position.lat());
\$('#appbundle_restaurants_restaurantLong').val(marker.position.lng());

});

    }, function() {
      handleNoGeolocation(true);
    });

  } else {
    // Browser doesn't support Geolocation
    handleNoGeolocation(false);
  }

  function handleNoGeolocation(errorFlag) {
    if (errorFlag) {
      var content = 'Error: The Geolocation service failed.';
    } else {
      var content = 'Error: Your browser doesn\\'t support geolocation.';
    }

    var options = {
      map: map,
      position: new google.maps.LatLng(60, 105),
      content: content
    };

    map.setCenter(options.position);
    marker = new google.maps.Marker({
      position: options.position,
      map: map,
      draggable: true
    });

  }

  // get places auto-complete when user type in location-text-box
  var input = /** @type {HTMLInputElement} */
    (
      document.getElementById('location-text-box'));


  var autocomplete = new google.maps.places.Autocomplete(input);
  autocomplete.bindTo('bounds', map);

  var infowindow = new google.maps.InfoWindow();
  marker = new google.maps.Marker({
    map: map,
    anchorPoint: new google.maps.Point(0, -29),
    draggable: true
  });

  google.maps.event.addListener(autocomplete, 'place_changed', function() {
    infowindow.close();
    marker.setVisible(false);
    var place = autocomplete.getPlace();
    if (!place.geometry) {
      return;
    }

    // If the place has a geometry, then present it on a map.
    if (place.geometry.viewport) {
      map.fitBounds(place.geometry.viewport);
    } else {
      map.setCenter(place.geometry.location);
      map.setZoom(17); // Why 17? Because it looks good.
    }
    marker.setIcon( /** @type {google.maps.Icon} */ ({
      url: place.icon,
      size: new google.maps.Size(71, 71),
      origin: new google.maps.Point(0, 0),
      anchor: new google.maps.Point(17, 34),
      scaledSize: new google.maps.Size(35, 35)
    }));
    \$('#appbundle_restaurants_restaurantLat').val(marker.position.lat());
\$('#appbundle_restaurants_restaurantLong').val(marker.position.lng());
    marker.setPosition(place.geometry.location);
    marker.setVisible(true);

    var address = '';
    if (place.address_components) {
      address = [
        (place.address_components[0] && place.address_components[0].short_name || ''), (place.address_components[1] && place.address_components[1].short_name || ''), (place.address_components[2] && place.address_components[2].short_name || '')
      ].join(' ');
    }

  });



}

google.maps.event.addDomListener(window, 'load', initialize);

</script>
<style type=\"text/css\">
  #map-canvas {
  height: 350px;
  width: 100%;
  margin: 0px;
  padding: 0px
}
.pac-container {
    z-index: 1051 !important;
}
</style>
<div style=\"height:100%; width:100%;\">
  <div id=\"map-canvas\"></div>
    <input type=\"text\" id=\"location-text-box\"  class=\"form-control\" placeholder=\"please enter location\" /><br>
</div>
</div>
      </div>

      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Save & Close</button>
      </div>
    </div>

  </div>
</div>
";
        
        $__internal_c2c2a8902796d02c1a1bb9b06b000dbdb685462e4511359032c04b4030700993->leave($__internal_c2c2a8902796d02c1a1bb9b06b000dbdb685462e4511359032c04b4030700993_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pickup/sub-location.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  361 => 192,  355 => 191,  334 => 180,  332 => 179,  312 => 162,  303 => 156,  294 => 149,  279 => 147,  275 => 146,  267 => 141,  260 => 137,  253 => 133,  249 => 132,  242 => 128,  229 => 118,  223 => 115,  219 => 114,  214 => 112,  211 => 111,  202 => 109,  200 => 108,  196 => 107,  191 => 105,  187 => 104,  183 => 103,  179 => 102,  176 => 101,  171 => 100,  169 => 99,  150 => 82,  111 => 44,  100 => 42,  96 => 41,  76 => 24,  63 => 13,  57 => 12,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}
{% block styles %}
<!--nestable CSS -->
<link href=\"/assets/plugins/nestable/nestable.css\" rel=\"stylesheet\" type=\"text/css\" />
 <script src=\"https://apis.google.com/js/platform.js\" async defer></script>
       <script type=\"text/javascript\"
            src=\"https://maps.google.com/maps/api/js?sensor=false&key=AIzaSyBSR3pigsWMH7goi_CthGQFckfb5QPOH8E&v=3.21.5a&libraries=drawing&signed_in=true&libraries=places,drawing,geometry\"></script>
<style>
</style>

{% endblock %}
{% block body %}
 <!-- Modal -->
  <div class=\"modal fade\" id=\"myModal\" role=\"dialog\">
    <div class=\"modal-dialog\">
    
      <!-- Modal content-->
      <div class=\"modal-content\">
        <div class=\"modal-header\">
          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
          <h4 class=\"modal-title\">Create Pickup Location</h4>
        </div>
        <div class=\"modal-body\">
          <form method=\"post\" action=\"{{ path('create_pickup_location') }}\">

<div class=\"form-group\">
  <label>Pickup Location Name</label>
  <input type=\"text\" class=\"form-control\" placeholder=\"Pickup Location Name\" name=\"name\">
</div>
<div class=\"form-group\">
  <label>Address</label>
  <textarea class=\"form-control\" rows=\"3\" placeholder=\"Address\" name=\"address\"></textarea>
</div>
<div class=\"form-group\">
  <label>Contact Number</label>
  <input type=\"text\" class=\"form-control\" placeholder=\"Contact Number\" name=\"contact\">
</div>
<div class=\"form-group\">
  <label>Delivery Block</label>
  <select class=\"form-control\" name=\"area\">
 {% for area in areas %}
 <option value=\"{{ area.id }}\">{{ area.title }}</option>
 {% endfor %}
  </select>
</div>
                         <a href=\"#openmap\" data-toggle=\"modal\" data-target=\"#location\">Map</a>
<div class=\"row\">
                            
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        <label for=\"appbundle_restaurants_restaurantLat\">Latitude</label>
                                        <div id=\"appbundle_restaurants_restaurantLat_form_group\" class=\"form-group \"><input type=\"text\" id=\"appbundle_restaurants_restaurantLat\" name=\"latitude\" maxlength=\"255\" class=\"form-control\"></div>
                                    </div>
                                </div>   
                                     <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        <label for=\"appbundle_restaurants_restaurantLong\">Longitude</label>
                                        <div id=\"appbundle_restaurants_restaurantLong_form_group\" class=\"form-group \"><input type=\"text\" id=\"appbundle_restaurants_restaurantLong\" name=\"longitude\" maxlength=\"255\" class=\"form-control form-control\"></div>
                                    </div>
                                </div>
                            </div>
          
        </div>
        <div class=\"modal-footer\">
          <button type=\"submit\" class=\"btn btn-primary\">Save</button>
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
  




<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"card\">
            {# {{ path('category_create') }} #}
            <div class=\"card-body\">
                   <h4 class=\"card-title\">Manage Pickup Location<button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#myModal\" style=\"float:right;\">
                Create New</button></h4>
  

                <table class=\"table table-hovered\" id=\"myTable\">
                    <thead>
                    <tr>
                      <th>#</th>
                        <th>Location</th>
                        <th>Address</th>
                        <th>Contact Details</th>
                        <th>Delivery Block</th>
                        <th>Action</th>
                    </tr>
                    
                </thead>
                {% set count = 1 %}
                    {% for loc in location %}
<tr>
<td>{{ count }} </td>
<td>{{ loc.name }} </td>
<td>{{ loc.address }} </td>
<td>{{ loc.contact }} </td>
<td> 
  {% for area in areas %}
{% if area.id == loc.parent %}
{{ area.title }}
{% endif %}
{% endfor %} </td>
<td style=\"text-align:center;\"><a href=\"{{ path('delete_pickup',{'id':loc.id}) }}\"   class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i></a >

<a href=\"#edit\"   class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#edit{{ count }}\"><i class=\"fa fa-edit\"></i></a >  <br>
<a href=\"{{ path('pickup_slots',{'id':loc.id}) }}\"   class=\"btn btn-primary btn-sm\" style=\"margin-top:10px;\"><i class=\"fa fa-edit\"></i> Create Slots</a >  </td>

</tr>
<div class=\"modal fade\" id=\"edit{{ count }}\" role=\"dialog\">
    <div class=\"modal-dialog\">
    
      <!-- Modal content-->
      <div class=\"modal-content\">
        <div class=\"modal-header\">
          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
          <h4 class=\"modal-title\">Edit Pickup Location</h4>
        </div>
        <div class=\"modal-body\">
          <form method=\"post\" action=\"{{ path('edit_pickup_location') }}\">

<div class=\"form-group\">
  <label>Pickup Location Name</label>
  <input type=\"text\" class=\"form-control\" placeholder=\"Pickup Location Name\" name=\"name\" value=\"{{ loc.name }}\">
  <input type=\"hidden\" class=\"form-control\" placeholder=\"Pickup Location Name\" name=\"id\" value=\"{{ loc.id }}\">
</div>
<div class=\"form-group\">
  <label>Address</label>
  <textarea class=\"form-control\" rows=\"3\" placeholder=\"Address\" name=\"address\">{{ loc.address }}</textarea>
</div>
<div class=\"form-group\">
  <label>Contact Number</label>
  <input type=\"text\" class=\"form-control\" placeholder=\"Contact Number\" name=\"contact\" value=\"{{ loc.contact }}\">
</div>
<div class=\"form-group\">
  <label>Delivery Block</label>
  <select class=\"form-control\" name=\"area\">
 {% for area in areas %}
 <option value=\"{{ area.id }}\" {% if area.id == loc.parent%} selected {% endif %}>{{ area.title }}</option>
 {% endfor %}
  </select>
</div>
<div class=\"row\">
                            
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        <label for=\"appbundle_restaurants_restaurantLat\">Latitude</label>
                                        <div id=\"appbundle_restaurants_restaurantLat_form_group\" class=\"form-group \"><input type=\"text\" id=\"\" name=\"latitude\" maxlength=\"255\" class=\"form-control appbundle_restaurants_restaurantLat\" value=\"{{ loc.latitude }}\"></div>
                                    </div>
                                </div>   
                                     <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        <label for=\"appbundle_restaurants_restaurantLong\">Longitude</label>
                                        <div id=\"appbundle_restaurants_restaurantLong_form_group\" class=\"form-group \"><input type=\"text\" id=\"\" name=\"longitude\" maxlength=\"255\" class=\"form-control form-control appbundle_restaurants_restaurantLong\" value=\"{{ loc.longitude }}\"></div>
                                    </div>
                                </div>
                            </div>
          
        </div>
        <div class=\"modal-footer\">
          <button type=\"submit\" class=\"btn btn-primary\">Save</button>
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
  

{% set count = count +1 %}
                    {% endfor %}  
                                    <tbody>

                      </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block scripts %}
<!--Nestable js -->
<script src=\"/assets/plugins/nestable/jquery.nestable.js\"></script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
   \$(document).ready(function() {
      \$('#myTable').DataTable();
    });
</script>
<script type=\"text/javascript\">
    \$(document).ready(function() {
        // Nestable

        //updateOutput(\$('#nestable').data('output', \$('#nestable-output')));
/*
        \$('#nestable-menu').on('click', function(e) {
            var target = \$(e.target),
                action = target.data('action');
            if (action === 'expand-all') {
                \$('.dd').nestable('expandAll');
            }
            if (action === 'collapse-all') {
                \$('.dd').nestable('collapseAll');
            }
        });*/

        \$('#nestable-menu').nestable();/*
        \$('.dd').nestable('collapseAll');*/
    });
    </script>
<!-- Modal -->
<div id=\"location\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Select Branch Location</h4>
      </div>
      <div class=\"modal-body\">
                         <div  class=\"map-area\">
<script>
var map;
var marker;

function initialize() {
  var mapOptions = {
    zoom: 12
  };
  map = new google.maps.Map(document.getElementById('map-canvas'),
    mapOptions);

  // Get GEOLOCATION
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var pos = new google.maps.LatLng(position.coords.latitude,
        position.coords.longitude);
\$('#appbundle_restaurants_restaurantLat').val(position.coords.latitude);
\$('#appbundle_restaurants_restaurantLong').val(position.coords.longitude);



      map.setCenter(pos);
      marker = new google.maps.Marker({
        position: pos,
        map: map,
        draggable: true
      });
      google.maps.event.addListener(marker, 'dragstart', function(evt) {
 \$('#appbundle_restaurants_restaurantLat').val(marker.position.lat());
\$('#appbundle_restaurants_restaurantLong').val(marker.position.lng());

});

    }, function() {
      handleNoGeolocation(true);
    });

  } else {
    // Browser doesn't support Geolocation
    handleNoGeolocation(false);
  }

  function handleNoGeolocation(errorFlag) {
    if (errorFlag) {
      var content = 'Error: The Geolocation service failed.';
    } else {
      var content = 'Error: Your browser doesn\\'t support geolocation.';
    }

    var options = {
      map: map,
      position: new google.maps.LatLng(60, 105),
      content: content
    };

    map.setCenter(options.position);
    marker = new google.maps.Marker({
      position: options.position,
      map: map,
      draggable: true
    });

  }

  // get places auto-complete when user type in location-text-box
  var input = /** @type {HTMLInputElement} */
    (
      document.getElementById('location-text-box'));


  var autocomplete = new google.maps.places.Autocomplete(input);
  autocomplete.bindTo('bounds', map);

  var infowindow = new google.maps.InfoWindow();
  marker = new google.maps.Marker({
    map: map,
    anchorPoint: new google.maps.Point(0, -29),
    draggable: true
  });

  google.maps.event.addListener(autocomplete, 'place_changed', function() {
    infowindow.close();
    marker.setVisible(false);
    var place = autocomplete.getPlace();
    if (!place.geometry) {
      return;
    }

    // If the place has a geometry, then present it on a map.
    if (place.geometry.viewport) {
      map.fitBounds(place.geometry.viewport);
    } else {
      map.setCenter(place.geometry.location);
      map.setZoom(17); // Why 17? Because it looks good.
    }
    marker.setIcon( /** @type {google.maps.Icon} */ ({
      url: place.icon,
      size: new google.maps.Size(71, 71),
      origin: new google.maps.Point(0, 0),
      anchor: new google.maps.Point(17, 34),
      scaledSize: new google.maps.Size(35, 35)
    }));
    \$('#appbundle_restaurants_restaurantLat').val(marker.position.lat());
\$('#appbundle_restaurants_restaurantLong').val(marker.position.lng());
    marker.setPosition(place.geometry.location);
    marker.setVisible(true);

    var address = '';
    if (place.address_components) {
      address = [
        (place.address_components[0] && place.address_components[0].short_name || ''), (place.address_components[1] && place.address_components[1].short_name || ''), (place.address_components[2] && place.address_components[2].short_name || '')
      ].join(' ');
    }

  });



}

google.maps.event.addDomListener(window, 'load', initialize);

</script>
<style type=\"text/css\">
  #map-canvas {
  height: 350px;
  width: 100%;
  margin: 0px;
  padding: 0px
}
.pac-container {
    z-index: 1051 !important;
}
</style>
<div style=\"height:100%; width:100%;\">
  <div id=\"map-canvas\"></div>
    <input type=\"text\" id=\"location-text-box\"  class=\"form-control\" placeholder=\"please enter location\" /><br>
</div>
</div>
      </div>

      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Save & Close</button>
      </div>
    </div>

  </div>
</div>
{% endblock %}", "AppBundle:Admin:Pickup/sub-location.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pickup/sub-location.html.twig");
    }
}

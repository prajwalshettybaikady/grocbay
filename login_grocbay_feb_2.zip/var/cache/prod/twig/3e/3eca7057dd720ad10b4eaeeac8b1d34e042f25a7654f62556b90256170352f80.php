<?php

/* AppBundle:Admin:Sms/template.html.twig */
class __TwigTemplate_5334291ab8fa3dff780e24dd18b3c938232c51bf19b5042ebef4b51a86d15676 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Sms/template.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_87986d21fbab9f66e0766448ad4efe947c4347c540c518312b2c45812afb8711 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87986d21fbab9f66e0766448ad4efe947c4347c540c518312b2c45812afb8711->enter($__internal_87986d21fbab9f66e0766448ad4efe947c4347c540c518312b2c45812afb8711_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Sms/template.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_87986d21fbab9f66e0766448ad4efe947c4347c540c518312b2c45812afb8711->leave($__internal_87986d21fbab9f66e0766448ad4efe947c4347c540c518312b2c45812afb8711_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_d7d2c9b0af31afdf2aaf66c63598289fc38ad805bcd2cdd7805b85d5d2c0ed87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d7d2c9b0af31afdf2aaf66c63598289fc38ad805bcd2cdd7805b85d5d2c0ed87->enter($__internal_d7d2c9b0af31afdf2aaf66c63598289fc38ad805bcd2cdd7805b85d5d2c0ed87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">SMS Template 
                       
                    </h4>
                </div>
                               <form method=\"post\" action=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_template");
        echo "\">
     ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
            // line 13
            echo "                    
                <div class=\"card-body\">
<center><span  style=\"color: red;font-size: smaller;font-weight: 400;\">Paste template Id  accordingly.
</span></center>
                    <div class=\"col-md-12\">
                        <div class=\"form-group\">
                         <label for=\"reg1\">Registration (Customer)*</label>
                         <input type=\"text\"  class=\"form-control\" rows=\"1\"  id=\"reg1\" required name=\"a1\" value=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "registration_user", array()), "html", null, true);
            echo "\">
                        </div>
                        <div class=\"form-group\">
                         <label for=\"reg2\">Registration (Delivery)</label>
                         <input type=\"text\" class=\"form-control\" rows=\"1\" id=\"reg2\"  name=\"a2\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "registration_delivery", array()), "html", null, true);
            echo "\">
                        </div>   
                      <div class=\"form-group\">
                         <label for=\"reg3\">OTP *</label>
                        <input type=\"text\" class=\"form-control\" rows=\"1\"  id=\"reg3\" required  name=\"a3\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "otp", array()), "html", null, true);
            echo "\">
                        </div>
                         
                        <div class=\"form-group\">
                         <label for=\"reg4\">SMS after Creating Order (Customer)</label>
                          <input type=\"text\" class=\"form-control\" rows=\"1\"  id=\"reg4\"  name=\"a4\" value=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "order_u", array()), "html", null, true);
            echo "\">
                        </div>
                        <div class=\"form-group\">
                         <label for=\"reg5\">SMS after Creating Order (Admin)</label>
                        <input type=\"text\" class=\"form-control\" rows=\"1\"  id=\"reg5\"  name=\"a5\" value=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "order_a", array()), "html", null, true);
            echo "\">
                        </div>
                         <div class=\"form-group\">
                         <label for=\"reg6\">SMS after Receiving Order (Customer)</label>
                         <input type=\"text\" class=\"form-control\" rows=\"1\"  id=\"reg6\"  name=\"a6\" value=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "recciving", array()), "html", null, true);
            echo "\">
                        </div>
                        
                          <div class=\"form-group\">
                         <label for=\"reg7\">SMS after Out For Delivery (Customer)</label>
                        <input type=\"text\" class=\"form-control\" rows=\"1\"  id=\"reg7\"  name=\"a7\" value=\"";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "delivery_u", array()), "html", null, true);
            echo "\">
                        </div>
                         <div class=\"form-group\">
                         <label for=\"reg8\">SMS after Out For Delivery (Delivery Boy)</label>
                      <input type=\"text\" class=\"form-control\" rows=\"1\" id=\"reg8\"  name=\"a8\" value=\"";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "delivery_d", array()), "html", null, true);
            echo "\">
                        </div>
                         <div class=\"form-group\">
                         <label for=\"reg9\">SMS after Item Delivered (Customer)</label>
                        <input type=\"text\" class=\"form-control\" rows=\"1\" id=\"reg9\"  name=\"a9\" value=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "delivered", array()), "html", null, true);
            echo "\">
                        </div>   
                         <div class=\"form-group\">
                         <label for=\"reg10\">SMS after Order Completed (Customer)</label>
                        <input type=\"text\" class=\"form-control\" rows=\"1\" id=\"reg10\" name=\"a10\" value=\"";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "completed", array()), "html", null, true);
            echo "\"> 
                        </div>  
                        <div class=\"form-group\">
                         <label for=\"reg11\">SMS after Order Cancelled (Customer)</label>
                         <input type=\"text\" class=\"form-control\" rows=\"1\" id=\"reg11\"  name=\"a11\" value=\"";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "cancelled", array()), "html", null, true);
            echo "\"> 
                        </div>       

                      </div>
                      
                        <div class=\"clearfix\"></div>
                        <button type=\"submit\" class=\"btn btn-primary pull-right\">Save</button>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "                </div>
            </form>
            </div>
        </div>
    </div>
";
        
        $__internal_d7d2c9b0af31afdf2aaf66c63598289fc38ad805bcd2cdd7805b85d5d2c0ed87->leave($__internal_d7d2c9b0af31afdf2aaf66c63598289fc38ad805bcd2cdd7805b85d5d2c0ed87_prof);

    }

    // line 77
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_930b6bc95c39b82c7791962d878dd6a0c7fed3a38351c5a9c40c384e90daf0ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_930b6bc95c39b82c7791962d878dd6a0c7fed3a38351c5a9c40c384e90daf0ae->enter($__internal_930b6bc95c39b82c7791962d878dd6a0c7fed3a38351c5a9c40c384e90daf0ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 78
        echo "


";
        
        $__internal_930b6bc95c39b82c7791962d878dd6a0c7fed3a38351c5a9c40c384e90daf0ae->leave($__internal_930b6bc95c39b82c7791962d878dd6a0c7fed3a38351c5a9c40c384e90daf0ae_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Sms/template.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  172 => 78,  166 => 77,  154 => 70,  140 => 62,  133 => 58,  126 => 54,  119 => 50,  112 => 46,  104 => 41,  97 => 37,  90 => 33,  82 => 28,  75 => 24,  68 => 20,  59 => 13,  55 => 12,  51 => 11,  41 => 3,  35 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}
{% block body %}
    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">SMS Template 
                       
                    </h4>
                </div>
                               <form method=\"post\" action=\"{{ path('update_template') }}\">
     {% for res in data %}
                    
                <div class=\"card-body\">
<center><span  style=\"color: red;font-size: smaller;font-weight: 400;\">Paste template Id  accordingly.
</span></center>
                    <div class=\"col-md-12\">
                        <div class=\"form-group\">
                         <label for=\"reg1\">Registration (Customer)*</label>
                         <input type=\"text\"  class=\"form-control\" rows=\"1\"  id=\"reg1\" required name=\"a1\" value=\"{{ res.registration_user}}\">
                        </div>
                        <div class=\"form-group\">
                         <label for=\"reg2\">Registration (Delivery)</label>
                         <input type=\"text\" class=\"form-control\" rows=\"1\" id=\"reg2\"  name=\"a2\" value=\"{{ res.registration_delivery}}\">
                        </div>   
                      <div class=\"form-group\">
                         <label for=\"reg3\">OTP *</label>
                        <input type=\"text\" class=\"form-control\" rows=\"1\"  id=\"reg3\" required  name=\"a3\" value=\"{{ res.otp}}\">
                        </div>
                         
                        <div class=\"form-group\">
                         <label for=\"reg4\">SMS after Creating Order (Customer)</label>
                          <input type=\"text\" class=\"form-control\" rows=\"1\"  id=\"reg4\"  name=\"a4\" value=\"{{ res.order_u}}\">
                        </div>
                        <div class=\"form-group\">
                         <label for=\"reg5\">SMS after Creating Order (Admin)</label>
                        <input type=\"text\" class=\"form-control\" rows=\"1\"  id=\"reg5\"  name=\"a5\" value=\"{{ res.order_a}}\">
                        </div>
                         <div class=\"form-group\">
                         <label for=\"reg6\">SMS after Receiving Order (Customer)</label>
                         <input type=\"text\" class=\"form-control\" rows=\"1\"  id=\"reg6\"  name=\"a6\" value=\"{{ res.recciving}}\">
                        </div>
                        
                          <div class=\"form-group\">
                         <label for=\"reg7\">SMS after Out For Delivery (Customer)</label>
                        <input type=\"text\" class=\"form-control\" rows=\"1\"  id=\"reg7\"  name=\"a7\" value=\"{{ res.delivery_u}}\">
                        </div>
                         <div class=\"form-group\">
                         <label for=\"reg8\">SMS after Out For Delivery (Delivery Boy)</label>
                      <input type=\"text\" class=\"form-control\" rows=\"1\" id=\"reg8\"  name=\"a8\" value=\"{{ res.delivery_d}}\">
                        </div>
                         <div class=\"form-group\">
                         <label for=\"reg9\">SMS after Item Delivered (Customer)</label>
                        <input type=\"text\" class=\"form-control\" rows=\"1\" id=\"reg9\"  name=\"a9\" value=\"{{ res.delivered}}\">
                        </div>   
                         <div class=\"form-group\">
                         <label for=\"reg10\">SMS after Order Completed (Customer)</label>
                        <input type=\"text\" class=\"form-control\" rows=\"1\" id=\"reg10\" name=\"a10\" value=\"{{ res.completed}}\"> 
                        </div>  
                        <div class=\"form-group\">
                         <label for=\"reg11\">SMS after Order Cancelled (Customer)</label>
                         <input type=\"text\" class=\"form-control\" rows=\"1\" id=\"reg11\"  name=\"a11\" value=\"{{ res.cancelled}}\"> 
                        </div>       

                      </div>
                      
                        <div class=\"clearfix\"></div>
                        <button type=\"submit\" class=\"btn btn-primary pull-right\">Save</button>
{% endfor %}
                </div>
            </form>
            </div>
        </div>
    </div>
{% endblock %}

{% block scripts %}



{% endblock %}
", "AppBundle:Admin:Sms/template.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Sms/template.html.twig");
    }
}

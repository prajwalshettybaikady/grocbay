<?php

/* AppBundle:Admin:Stock/returnStock.html.twig */
class __TwigTemplate_08d7c17a51e9342d4a5abd04c26446b90d4289083fac05dfaafc83344f0cd73a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Stock/returnStock.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13803aea330f538f007849ea81134e7e6b5596fed6a5da8518ed1314862d5cbf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13803aea330f538f007849ea81134e7e6b5596fed6a5da8518ed1314862d5cbf->enter($__internal_13803aea330f538f007849ea81134e7e6b5596fed6a5da8518ed1314862d5cbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Stock/returnStock.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_13803aea330f538f007849ea81134e7e6b5596fed6a5da8518ed1314862d5cbf->leave($__internal_13803aea330f538f007849ea81134e7e6b5596fed6a5da8518ed1314862d5cbf_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_84c2cc9832a85a7e3511ced275d038c39e7202b630e2e71ccd7a3547c9a5c8b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84c2cc9832a85a7e3511ced275d038c39e7202b630e2e71ccd7a3547c9a5c8b5->enter($__internal_84c2cc9832a85a7e3511ced275d038c39e7202b630e2e71ccd7a3547c9a5c8b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "     
      
      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>

";
        // line 17
        echo "<!-- Modal -->

<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                        <span class=\"pull-right\">
                    ";
        // line 26
        echo "                          
                        </span>
                    </div>
                    <h2>Purchase Return</h2>

                    <div>
                    <form action=\"";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_return_stock_item");
        echo "\" method=\"post\">
                        <div class=\"row\">
                            
                        <div class=\"form-group col-md-4\">
                            <label>Date *</label>
                            <input type=\"text\" name=\"date\" class=\"form-control\" required=\"\" id = \"datepicker-13\" autocomplete=\"off\">

                        </div>
                        <div class=\"form-group col-md-8\">
                            <label>Description *</label>
                            <textarea class=\"form-control\" name=\"description\" required></textarea> 
                        </div>
                    </div>
                        <hr>
                          <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\" style=\"float:right;\">Add Items</a> 
 <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>Item Name</th>
                                     <th>Variation</th>
                                    <th>Quantity</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                               
                            </tbody>
                        </table>
                    </div>
                    <button class=\"btn btn-success\" type=\"submit\" style=\"float:right;\">Save</button>
                    </form> 
                    </div>
     
                </div>
            </div>
    </div>
</div>

";
        // line 72
        echo "<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Add Stock</h4>
      </div>
      <div class=\"modal-body\">
        <p><form>
            <div class=\"form-group\">
            <label>Search Item *</label>
  <select id=\"select-state\" placeholder=\"Pick a Menu Item...\" class=\"form-control select\">
    ";
        // line 86
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["menuItems"] ?? $this->getContext($context, "menuItems")));
        foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
            // line 87
            echo "    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "id", array()), "html", null, true);
            echo "\" data-name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "itemName", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "itemName", array()), "html", null, true);
            echo "</option>
   ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 89
        echo "  </select>
            </div>

            <div class=\"form-group\">
            <label>Select Variation *</label>
  <select class=\"form-control var\"  id=\"vars\" style=\"display:block !important;\">
   
  </select>
</div>
<div id=\"stocks\"></div><br>
<div class=\"form-group\">
<label>Quantity *</label>
<input type=\"number\" class=\"form-control\" id=\"quantity\">
</div>
         
        <span style=\"margin-top:10px;\">
            <button class=\"btn btn-success\" id=\"sel\" type=\"button\">add</button>
        </span>
        
        </form></p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
";
        
        $__internal_84c2cc9832a85a7e3511ced275d038c39e7202b630e2e71ccd7a3547c9a5c8b5->leave($__internal_84c2cc9832a85a7e3511ced275d038c39e7202b630e2e71ccd7a3547c9a5c8b5_prof);

    }

    // line 120
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_e7957a48f7301e42b28eef2d9b48cba489be33868b209cac7ebb72e291689d87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7957a48f7301e42b28eef2d9b48cba489be33868b209cac7ebb72e291689d87->enter($__internal_e7957a48f7301e42b28eef2d9b48cba489be33868b209cac7ebb72e291689d87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 121
        echo "
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
function send(myObjects)
{
\$('#quantity').val('');
\$('#stocks').html('');
\$('.var').html('');    
\$.each(myObjects, function () {
    \$('.var').append('<option value=\"'+this.id+'\"  data-stock=\"'+this.stock+'\" data-type=\"'+this.type+'\"  data-name=\"'+this.name+'\">'+this.name+'</option>');
        \$('#stocks').html('<span style=\"color:red;font-weight:bold;\">Curent Stock : '+this.stock+' </span>');
    });       
         
   }
 function removeVariant(obj){
// \$(this).attr(\"data-usr\" , '');

        \$(obj).parent().parent().remove();

    }
    \$(document).ready(function() {
        \$('#myTables').DataTable();
    });
    

 \$(document).ready(function () {
  \$('.var').change(function(){
     var x=\$('.var').val();
var stock = \$('.var').find(':selected').attr('data-stock')


     // alert(stocksck);

 \$('#stocks').html('<span style=\"color:red;font-weight:bold;\">Curent Stock : '+stock+' </span>');
  });
\$('#select-state').change(function(){
var id=\$('#select-state').val();
var out ={'data':id};      
// alert(id);                 // alert(x);
\$.ajax({
    type: \"POST\",
    url: \"";
        // line 162
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_get_var");
        echo "\",
    data: {
      'data' : id
    },
    success: function (res, dataType) {
 // console.log('";
        // line 167
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_get_cat");
        echo "');
send(res);
          
// console.log(datas);

    },
    error: function (XMLHttpRequest, textStatus, errorThrown) {
        alert('Error : ' + errorThrown);
    }
});
                                        

});

 \$('#sel').click(function () {
var selid=\$('#select-state').val();
var selvalue = \$('#select-state').find(':selected').attr('data-name');
var varid=\$('.var').val();
// alert(varid);
var varvalue = \$('.var').find(':selected').attr('data-name');
var quantity=\$('#quantity').val();
var type = \$('.var').find(':selected').attr('data-type')

if(quantity=='' || quantity=='0')
{
    alert('please enter quantity!');
    return false;
}
// \$('#myTable tr').each(function() {
//   // need this to skip the first row
// console.log(\$(this).find(\"td:first\").length);
//     var cutomerId = \$(this).find(\"td:first\").html();

//    if(cutomerId==='<input type=\"hidden\" value=\"'+selid+'\" name=\"selid[]\">'+selvalue+'')
//    {
//     alert('Item already in list please try with different list!');
//    }
//    else
//    {
    
//     alert('no');
//    }

// });

 \$('#myTable').append('<tr><td><input type=\"hidden\" value=\"'+type+'\" name=\"type[]\"><input type=\"hidden\" value=\"'+selid+'\" name=\"selid[]\">'+selvalue+'</td><td><input type=\"hidden\" value=\"'+varid+'\" name=\"varid[]\">'+varvalue+'</td><td><input type=\"hidden\" value=\"'+quantity+'\" name=\"selqty[]\">'+quantity+'</td><td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\">remove</button></td></tr>'); 
 });
\$(\".remove a\").click(function() {
    \$(this).parent().remove();
});
 });
</script>

<script>
";
        
        $__internal_e7957a48f7301e42b28eef2d9b48cba489be33868b209cac7ebb72e291689d87->leave($__internal_e7957a48f7301e42b28eef2d9b48cba489be33868b209cac7ebb72e291689d87_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Stock/returnStock.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  240 => 167,  232 => 162,  189 => 121,  183 => 120,  148 => 89,  135 => 87,  131 => 86,  115 => 72,  73 => 32,  65 => 26,  55 => 17,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}
     
      
      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>

{# {{ dump(res) }} #}
<!-- Modal -->

<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                        <span class=\"pull-right\">
                    {#      <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\">Upload CSV</a> #}
                          
                        </span>
                    </div>
                    <h2>Purchase Return</h2>

                    <div>
                    <form action=\"{{ path('manage_restaurant_return_stock_item') }}\" method=\"post\">
                        <div class=\"row\">
                            
                        <div class=\"form-group col-md-4\">
                            <label>Date *</label>
                            <input type=\"text\" name=\"date\" class=\"form-control\" required=\"\" id = \"datepicker-13\" autocomplete=\"off\">

                        </div>
                        <div class=\"form-group col-md-8\">
                            <label>Description *</label>
                            <textarea class=\"form-control\" name=\"description\" required></textarea> 
                        </div>
                    </div>
                        <hr>
                          <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\" style=\"float:right;\">Add Items</a> 
 <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>Item Name</th>
                                     <th>Variation</th>
                                    <th>Quantity</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                               
                            </tbody>
                        </table>
                    </div>
                    <button class=\"btn btn-success\" type=\"submit\" style=\"float:right;\">Save</button>
                    </form> 
                    </div>
     
                </div>
            </div>
    </div>
</div>

{# modal #}
<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Add Stock</h4>
      </div>
      <div class=\"modal-body\">
        <p><form>
            <div class=\"form-group\">
            <label>Search Item *</label>
  <select id=\"select-state\" placeholder=\"Pick a Menu Item...\" class=\"form-control select\">
    {% for menu in menuItems %}
    <option value=\"{{ menu.id }}\" data-name=\"{{ menu.itemName }}\">{{ menu.itemName }}</option>
   {% endfor %}
  </select>
            </div>

            <div class=\"form-group\">
            <label>Select Variation *</label>
  <select class=\"form-control var\"  id=\"vars\" style=\"display:block !important;\">
   
  </select>
</div>
<div id=\"stocks\"></div><br>
<div class=\"form-group\">
<label>Quantity *</label>
<input type=\"number\" class=\"form-control\" id=\"quantity\">
</div>
         
        <span style=\"margin-top:10px;\">
            <button class=\"btn btn-success\" id=\"sel\" type=\"button\">add</button>
        </span>
        
        </form></p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
{# end modal #}
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
function send(myObjects)
{
\$('#quantity').val('');
\$('#stocks').html('');
\$('.var').html('');    
\$.each(myObjects, function () {
    \$('.var').append('<option value=\"'+this.id+'\"  data-stock=\"'+this.stock+'\" data-type=\"'+this.type+'\"  data-name=\"'+this.name+'\">'+this.name+'</option>');
        \$('#stocks').html('<span style=\"color:red;font-weight:bold;\">Curent Stock : '+this.stock+' </span>');
    });       
         
   }
 function removeVariant(obj){
// \$(this).attr(\"data-usr\" , '');

        \$(obj).parent().parent().remove();

    }
    \$(document).ready(function() {
        \$('#myTables').DataTable();
    });
    

 \$(document).ready(function () {
  \$('.var').change(function(){
     var x=\$('.var').val();
var stock = \$('.var').find(':selected').attr('data-stock')


     // alert(stocksck);

 \$('#stocks').html('<span style=\"color:red;font-weight:bold;\">Curent Stock : '+stock+' </span>');
  });
\$('#select-state').change(function(){
var id=\$('#select-state').val();
var out ={'data':id};      
// alert(id);                 // alert(x);
\$.ajax({
    type: \"POST\",
    url: \"{{ path('manage_restaurant_get_var') }}\",
    data: {
      'data' : id
    },
    success: function (res, dataType) {
 // console.log('{{ path('manage_restaurant_get_cat') }}');
send(res);
          
// console.log(datas);

    },
    error: function (XMLHttpRequest, textStatus, errorThrown) {
        alert('Error : ' + errorThrown);
    }
});
                                        

});

 \$('#sel').click(function () {
var selid=\$('#select-state').val();
var selvalue = \$('#select-state').find(':selected').attr('data-name');
var varid=\$('.var').val();
// alert(varid);
var varvalue = \$('.var').find(':selected').attr('data-name');
var quantity=\$('#quantity').val();
var type = \$('.var').find(':selected').attr('data-type')

if(quantity=='' || quantity=='0')
{
    alert('please enter quantity!');
    return false;
}
// \$('#myTable tr').each(function() {
//   // need this to skip the first row
// console.log(\$(this).find(\"td:first\").length);
//     var cutomerId = \$(this).find(\"td:first\").html();

//    if(cutomerId==='<input type=\"hidden\" value=\"'+selid+'\" name=\"selid[]\">'+selvalue+'')
//    {
//     alert('Item already in list please try with different list!');
//    }
//    else
//    {
    
//     alert('no');
//    }

// });

 \$('#myTable').append('<tr><td><input type=\"hidden\" value=\"'+type+'\" name=\"type[]\"><input type=\"hidden\" value=\"'+selid+'\" name=\"selid[]\">'+selvalue+'</td><td><input type=\"hidden\" value=\"'+varid+'\" name=\"varid[]\">'+varvalue+'</td><td><input type=\"hidden\" value=\"'+quantity+'\" name=\"selqty[]\">'+quantity+'</td><td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\">remove</button></td></tr>'); 
 });
\$(\".remove a\").click(function() {
    \$(this).parent().remove();
});
 });
</script>

<script>
{% endblock %}
", "AppBundle:Admin:Stock/returnStock.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Stock/returnStock.html.twig");
    }
}

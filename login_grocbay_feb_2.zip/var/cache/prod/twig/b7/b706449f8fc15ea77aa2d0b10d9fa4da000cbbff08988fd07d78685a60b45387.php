<?php

/* AppBundle:Admin:Reports/order.html.twig */
class __TwigTemplate_11de24277808ceb13a2946254d9e6937f7eeacc18cfc5dc140973e5b2af99ba8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((("@AppBundle/" . ($context["myExtend"] ?? $this->getContext($context, "myExtend"))) . "/base.html.twig"), "AppBundle:Admin:Reports/order.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_31591655654fd9773e1dd5067c0148e3f47b630ecdac615b68deb032444a724c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31591655654fd9773e1dd5067c0148e3f47b630ecdac615b68deb032444a724c->enter($__internal_31591655654fd9773e1dd5067c0148e3f47b630ecdac615b68deb032444a724c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Reports/order.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_31591655654fd9773e1dd5067c0148e3f47b630ecdac615b68deb032444a724c->leave($__internal_31591655654fd9773e1dd5067c0148e3f47b630ecdac615b68deb032444a724c_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_2c87d62c28d37428172240bb6fae3dbfe4016eddef2f64d473fd071b7cef50ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c87d62c28d37428172240bb6fae3dbfe4016eddef2f64d473fd071b7cef50ba->enter($__internal_2c87d62c28d37428172240bb6fae3dbfe4016eddef2f64d473fd071b7cef50ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "
";
        
        $__internal_2c87d62c28d37428172240bb6fae3dbfe4016eddef2f64d473fd071b7cef50ba->leave($__internal_2c87d62c28d37428172240bb6fae3dbfe4016eddef2f64d473fd071b7cef50ba_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_7458150b1a3473683bf4b48f08908f9e391c163ef0efed5b38671df36553c16e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7458150b1a3473683bf4b48f08908f9e391c163ef0efed5b38671df36553c16e->enter($__internal_7458150b1a3473683bf4b48f08908f9e391c163ef0efed5b38671df36553c16e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div id=\"order-report-app\">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->

    <div class=\"row container-fluid\">

        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-body collapse show\">
                    <h6>Order report filter</h6>
                    <hr>
                    <form method=\"post\" action=\"";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("filter_order");
        echo "\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                                <label for=\"\">From</label>
                            <input type=\"text\" name=\"fromDate\" id=\"fromDate\"  class=\"form-control\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, ($context["fromDate"] ?? $this->getContext($context, "fromDate")), "html", null, true);
        echo "\" autocomplete=\"off\">
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"\">To</label>
                            <input type=\"text\" name=\"toDate\" id=\"toDate\" class=\"form-control\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, ($context["toDate"] ?? $this->getContext($context, "toDate")), "html", null, true);
        echo "\"  autocomplete=\"off\">
                        </div>
                    </div>
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <label for=\"\">Order Status</label>
                            <select name=\"status\" class=\"form-control\">
                                <option value=\"all\" ";
        // line 33
        if ((($context["status"] ?? $this->getContext($context, "status")) == "all")) {
            echo "selected ";
        }
        echo ">All</option>
                                <option value=\"completed\"  ";
        // line 34
        if ((($context["status"] ?? $this->getContext($context, "status")) == "completed")) {
            echo "selected ";
        }
        echo ">Completed</option>
                                <option value=\"cancelled\"  ";
        // line 35
        if ((($context["status"] ?? $this->getContext($context, "status")) == "cancelled")) {
            echo "selected ";
        }
        echo ">Cancelled</option>
                            </select>
                        </div>
                    </div>
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <label for=\"\">Customer</label>
                            <select name=\"customer\" id=\"\" class=\"form-control\">
                                <option value=\"\" ";
        // line 43
        if ((($context["customerdata"] ?? $this->getContext($context, "customerdata")) == "all")) {
            echo "selected ";
        }
        echo ">All</option>
                                ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["customer"] ?? $this->getContext($context, "customer")));
        foreach ($context['_seq'] as $context["_key"] => $context["cus"]) {
            // line 45
            echo "                                <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["cus"], "id", array()), "html", null, true);
            echo "\" ";
            if ((($context["customerdata"] ?? $this->getContext($context, "customerdata")) == $this->getAttribute($context["cus"], "id", array()))) {
                echo "selected ";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["cus"], "username", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cus'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "                            </select>
                        </div>
                    </div>
                    <br>
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <button class=\"btn btn-primary\" type=\"submit\" name=\"filter\">Filter</button>
                       
                            <button class=\"btn btn-primary\" type=\"submit\" name=\"print\">Print</button>
                        
                            <button class=\"btn btn-primary\" type=\"submit\"  name=\"packing\">Export Packing List</button>
                       
                            <button class=\"btn btn-primary\"  type=\"submit\"  name=\"order\">Export Order List</button>
                        </div>
                    </div>
                </div>
            </form>
            </div>
        </div>
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">Order Reports
                        <p class=\"text-muted pull-right\"></p>
                    </h4>
                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                            <tr>
                                <td>Order ID</td>
                                <td>Order Date</td>
                                <td>Order amount</td>
                                <td>Payment Type</td>
                                <td>Order Status</td>
                            </tr>
                        </thead>
                        <tbody>
                            ";
        // line 85
        $context["sum"] = 0;
        // line 86
        echo "                            ";
        $context["profit"] = 0;
        // line 87
        echo "                        
                            ";
        // line 88
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 89
            echo "                            <tr >
                                <td><a href=\"";
            // line 90
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_orders_panel_update", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" title=\"Edit\" style=\"font-weight:600;\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "</a></td>
                                <td>";
            // line 91
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "orderDate", array()), "date", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                                <td>";
            // line 92
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "orderAmount", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "paymentType", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 94
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "orderStatus", array()), "html", null, true);
            echo "</td>
                        
                            </tr>
                               ";
            // line 97
            $context["sum"] = (($context["sum"] ?? $this->getContext($context, "sum")) + $this->getAttribute($context["item"], "orderAmount", array()));
            // line 98
            echo "                               ";
            $context["profit"] = (($context["profit"] ?? $this->getContext($context, "profit")) + $this->getAttribute($context["item"], "cost", array()));
            // line 99
            echo "
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 101
        echo "                        </tbody>
                    </table>
                    <hr>
                    <b style=\"color:red;font-size:17px;font-weight:bold;\"> Total Sale : ";
        // line 104
        echo twig_escape_filter($this->env, twig_round(($context["sum"] ?? $this->getContext($context, "sum"))), "html", null, true);
        echo " </b> |    <b style=\"color:red;font-size:17px;font-weight:bold;\"> Profit : ";
        echo twig_escape_filter($this->env, twig_round(($context["profit"] ?? $this->getContext($context, "profit"))), "html", null, true);
        echo " </b>
                </div>
                <div class=\"card-body collapse show\">
                    
                </div>
            </div>
        </div>
    </div>
</div>
";
        
        $__internal_7458150b1a3473683bf4b48f08908f9e391c163ef0efed5b38671df36553c16e->leave($__internal_7458150b1a3473683bf4b48f08908f9e391c163ef0efed5b38671df36553c16e_prof);

    }

    // line 115
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_25ba5419faae74653b6f7a4f81561511a58b35012dcabfb3075e6eebca681101 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_25ba5419faae74653b6f7a4f81561511a58b35012dcabfb3075e6eebca681101->enter($__internal_25ba5419faae74653b6f7a4f81561511a58b35012dcabfb3075e6eebca681101_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 116
        echo "
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
    \$(function() {
            \$( \"#fromDate\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });
        });
    \$(function() {
            \$( \"#toDate\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });
        });
</script>
";
        
        $__internal_25ba5419faae74653b6f7a4f81561511a58b35012dcabfb3075e6eebca681101->leave($__internal_25ba5419faae74653b6f7a4f81561511a58b35012dcabfb3075e6eebca681101_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Reports/order.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  264 => 116,  258 => 115,  239 => 104,  234 => 101,  227 => 99,  224 => 98,  222 => 97,  216 => 94,  212 => 93,  208 => 92,  204 => 91,  198 => 90,  195 => 89,  191 => 88,  188 => 87,  185 => 86,  183 => 85,  143 => 47,  128 => 45,  124 => 44,  118 => 43,  105 => 35,  99 => 34,  93 => 33,  83 => 26,  76 => 22,  69 => 18,  55 => 6,  49 => 5,  41 => 3,  35 => 2,  20 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/'~ myExtend ~'/base.html.twig' %}
{% block styles %}

{% endblock %}
{% block body %}
<div id=\"order-report-app\">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->

    <div class=\"row container-fluid\">

        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-body collapse show\">
                    <h6>Order report filter</h6>
                    <hr>
                    <form method=\"post\" action=\"{{ path('filter_order')}}\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                                <label for=\"\">From</label>
                            <input type=\"text\" name=\"fromDate\" id=\"fromDate\"  class=\"form-control\" value=\"{{ fromDate }}\" autocomplete=\"off\">
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"\">To</label>
                            <input type=\"text\" name=\"toDate\" id=\"toDate\" class=\"form-control\" value=\"{{ toDate }}\"  autocomplete=\"off\">
                        </div>
                    </div>
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <label for=\"\">Order Status</label>
                            <select name=\"status\" class=\"form-control\">
                                <option value=\"all\" {% if status == 'all' %}selected {% endif %}>All</option>
                                <option value=\"completed\"  {% if status == 'completed' %}selected {% endif %}>Completed</option>
                                <option value=\"cancelled\"  {% if status == 'cancelled' %}selected {% endif %}>Cancelled</option>
                            </select>
                        </div>
                    </div>
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <label for=\"\">Customer</label>
                            <select name=\"customer\" id=\"\" class=\"form-control\">
                                <option value=\"\" {% if customerdata == 'all' %}selected {% endif %}>All</option>
                                {% for cus in customer%}
                                <option value=\"{{ cus.id }}\" {% if customerdata == cus.id %}selected {% endif %}>{{ cus.username }}</option>
                                {% endfor %}
                            </select>
                        </div>
                    </div>
                    <br>
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <button class=\"btn btn-primary\" type=\"submit\" name=\"filter\">Filter</button>
                       
                            <button class=\"btn btn-primary\" type=\"submit\" name=\"print\">Print</button>
                        
                            <button class=\"btn btn-primary\" type=\"submit\"  name=\"packing\">Export Packing List</button>
                       
                            <button class=\"btn btn-primary\"  type=\"submit\"  name=\"order\">Export Order List</button>
                        </div>
                    </div>
                </div>
            </form>
            </div>
        </div>
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">Order Reports
                        <p class=\"text-muted pull-right\"></p>
                    </h4>
                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                            <tr>
                                <td>Order ID</td>
                                <td>Order Date</td>
                                <td>Order amount</td>
                                <td>Payment Type</td>
                                <td>Order Status</td>
                            </tr>
                        </thead>
                        <tbody>
                            {% set sum = 0 %}
                            {% set profit = 0 %}
                        
                            {% for item in data %}
                            <tr >
                                <td><a href=\"{{ path('restaurant_orders_panel_update',{'id':item.id}) }}\" title=\"Edit\" style=\"font-weight:600;\">{{ item.id }}</a></td>
                                <td>{{ item.orderDate.date|date(\"d-m-Y\") }}</td>
                                <td>{{ item.orderAmount }}</td>
                                <td>{{ item.paymentType }}</td>
                                <td>{{ item.orderStatus }}</td>
                        
                            </tr>
                               {% set sum = sum + item.orderAmount %}
                               {% set profit = profit + item.cost %}

                            {% endfor %}
                        </tbody>
                    </table>
                    <hr>
                    <b style=\"color:red;font-size:17px;font-weight:bold;\"> Total Sale : {{ sum|round }} </b> |    <b style=\"color:red;font-size:17px;font-weight:bold;\"> Profit : {{ profit|round }} </b>
                </div>
                <div class=\"card-body collapse show\">
                    
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
    \$(function() {
            \$( \"#fromDate\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });
        });
    \$(function() {
            \$( \"#toDate\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });
        });
</script>
{% endblock %}", "AppBundle:Admin:Reports/order.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Reports/order.html.twig");
    }
}

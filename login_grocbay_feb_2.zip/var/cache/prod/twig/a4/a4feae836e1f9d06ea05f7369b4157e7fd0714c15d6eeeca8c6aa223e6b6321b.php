<?php

/* @AppBundle/Admin/Properties/footer.html.twig */
class __TwigTemplate_eba675bc98e8aaffb6de0581e78b04b5cc6a838a03084d499fffde641425c990 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b16ac53298c2ed1ef7cb6edeb2e0879cf85438b18564c2a559961523ea97d3c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b16ac53298c2ed1ef7cb6edeb2e0879cf85438b18564c2a559961523ea97d3c9->enter($__internal_b16ac53298c2ed1ef7cb6edeb2e0879cf85438b18564c2a559961523ea97d3c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@AppBundle/Admin/Properties/footer.html.twig"));

        // line 1
        echo " <!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<script type=\"text/javascript\">

\$(document).ready(function(){
web_getneworder();

});
function web_getneworder() {
  \$.get(\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("web_getneworder", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "branch", array()))), "html", null, true);
        echo "\", function(data, status){
\t// \$('.page-title').html(data);
  // console.log(data.delivery);
  // \$.each(data, function () {
  \$('.home').html(data.delivery);
  \$('.pickup').html(data.pickup);
  \$('.express').html(data.express);
   \$('.page-title').html(data.branch);
   \$('.onway').html(data.onway);
   \$('.neworder').html(data.new);

// });

});
}
window.setInterval(function(){
web_getneworder();
// notifyMe();
  }, 5000);

  

</script>

<footer class=\"footer noprint\">
  <!--   Designed and developed by <a href=\"https://www.appinsight.tech/\" target=\"blank_\" style=\"color:#f79501;\"> Appinsight Technologies </a> -->
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->";
        
        $__internal_b16ac53298c2ed1ef7cb6edeb2e0879cf85438b18564c2a559961523ea97d3c9->leave($__internal_b16ac53298c2ed1ef7cb6edeb2e0879cf85438b18564c2a559961523ea97d3c9_prof);

    }

    public function getTemplateName()
    {
        return "@AppBundle/Admin/Properties/footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 11,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source(" <!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<script type=\"text/javascript\">

\$(document).ready(function(){
web_getneworder();

});
function web_getneworder() {
  \$.get(\"{{ path('web_getneworder',{'id':app.user.branch }) }}\", function(data, status){
\t// \$('.page-title').html(data);
  // console.log(data.delivery);
  // \$.each(data, function () {
  \$('.home').html(data.delivery);
  \$('.pickup').html(data.pickup);
  \$('.express').html(data.express);
   \$('.page-title').html(data.branch);
   \$('.onway').html(data.onway);
   \$('.neworder').html(data.new);

// });

});
}
window.setInterval(function(){
web_getneworder();
// notifyMe();
  }, 5000);

  

</script>

<footer class=\"footer noprint\">
  <!--   Designed and developed by <a href=\"https://www.appinsight.tech/\" target=\"blank_\" style=\"color:#f79501;\"> Appinsight Technologies </a> -->
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->", "@AppBundle/Admin/Properties/footer.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Properties/footer.html.twig");
    }
}

<?php

/* AppBundle:Admin:Reports/itemSales.html.twig */
class __TwigTemplate_ee0995ab5521d018c29956993ada15219b0e87a1e17a8371ba6f2b67cbffa4b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((("@AppBundle/" . ($context["myExtend"] ?? $this->getContext($context, "myExtend"))) . "/base.html.twig"), "AppBundle:Admin:Reports/itemSales.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4db1e811a5879abcb4e39c805453028d020294948f4077335927858d41234b96 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4db1e811a5879abcb4e39c805453028d020294948f4077335927858d41234b96->enter($__internal_4db1e811a5879abcb4e39c805453028d020294948f4077335927858d41234b96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Reports/itemSales.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4db1e811a5879abcb4e39c805453028d020294948f4077335927858d41234b96->leave($__internal_4db1e811a5879abcb4e39c805453028d020294948f4077335927858d41234b96_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_dd4bd71aa88d6f164956cacc7668f8a39badc1b527b5ce74ef4b6794f8cc0976 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd4bd71aa88d6f164956cacc7668f8a39badc1b527b5ce74ef4b6794f8cc0976->enter($__internal_dd4bd71aa88d6f164956cacc7668f8a39badc1b527b5ce74ef4b6794f8cc0976_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "
";
        
        $__internal_dd4bd71aa88d6f164956cacc7668f8a39badc1b527b5ce74ef4b6794f8cc0976->leave($__internal_dd4bd71aa88d6f164956cacc7668f8a39badc1b527b5ce74ef4b6794f8cc0976_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_96f2a9ae363b39ba8867b4396cc064531f15a88eb89b70cdffa21a59e8e8bd04 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_96f2a9ae363b39ba8867b4396cc064531f15a88eb89b70cdffa21a59e8e8bd04->enter($__internal_96f2a9ae363b39ba8867b4396cc064531f15a88eb89b70cdffa21a59e8e8bd04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div id=\"order-report-app\">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->

      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker1\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });
   \$( \"#datepicker2\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
    <div class=\"row\">
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-body collapse show\">
                    <h6>Item report filter</h6>
                    <hr>
                    <form method=\"post\" action=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("filter_items");
        echo "\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                                <label for=\"\">From</label>
                            <input type=\"text\" name=\"fromDate\" id=\"datepicker1\"  class=\"form-control\" autocomplete=\"off\"  value=\"";
        // line 33
        echo twig_escape_filter($this->env, ($context["from"] ?? $this->getContext($context, "from")), "html", null, true);
        echo "\">
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"\">To</label>
                            <input type=\"text\" name=\"toDate\" id=\"datepicker2\" class=\"form-control\"  autocomplete=\"off\" value=\"";
        // line 37
        echo twig_escape_filter($this->env, ($context["to"] ?? $this->getContext($context, "to")), "html", null, true);
        echo "\">
                        </div>
                    </div>
                    
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <label for=\"\">Items</label>
                            <select name=\"item\" id=\"grocbay\" class=\"form-control\">
                                <option value=\"0\">All</option>
                                ";
        // line 46
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["items"] ?? $this->getContext($context, "items")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 47
            echo "                                <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "\" ";
            if ((($context["itemid"] ?? $this->getContext($context, "itemid")) == $this->getAttribute($context["item"], "id", array()))) {
                echo " selected ";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
            echo " - (";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "variationName", array()), "html", null, true);
            echo ")</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "                            </select>
                        </div>
                    </div>
                    <br>
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <button class=\"btn btn-primary\" type=\"submit\" name=\"filter\">Filter</button>
                       
                        </div>
                    </div>
                </div>
            </form>
            </div>
        </div>
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">Itemwise Sales Report
                    </h4>
                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                            <tr>
                                <td>#</td>
                                <td>Item Name</td>
                                <td>Quantity</td>
                                <td>Total</td>
                                <td>Action</td>
                            </tr>
                        </thead>
                        <tbody>
                            ";
        // line 81
        $context["count"] = 1;
        // line 82
        echo "                            ";
        $context["sales"] = 0;
        // line 83
        echo "                            ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["da"]) {
            // line 84
            echo "                            <tr>
                                <td>";
            // line 85
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "</td>
                                <td>";
            // line 86
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "itemName", array()), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "priceVariavtion", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 87
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "quantity", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 88
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["da"], "price", array()), 2, "floor"), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["da"], "price", array()), 2, ".", ""), "html", null, true);
            }
            echo "</td>
                                <td><a href=\"";
            // line 89
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("view_item_sale", array("id" => $this->getAttribute($context["da"], "itemId", array()))), "html", null, true);
            echo "\">view</a></td>

                                    
                                </tr>
                ";
            // line 93
            $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
            // line 94
            echo "                ";
            $context["sales"] = (($context["sales"] ?? $this->getContext($context, "sales")) + $this->getAttribute($context["da"], "price", array()));
            // line 95
            echo "
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['da'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 97
        echo "                        </tbody>
                    </table>
                    <hr>
                  <b style=\"color:red;\">  Sales : ";
        // line 100
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            echo twig_escape_filter($this->env, twig_round(($context["sales"] ?? $this->getContext($context, "sales")), 2, "floor"), "html", null, true);
        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["sales"] ?? $this->getContext($context, "sales")), 2, ".", ""), "html", null, true);
        }
        echo "</b>
                </div>
                <div class=\"card-body collapse show\">
                    
                </div>
            </div>
        </div>
    </div>
</div>
</div>
";
        
        $__internal_96f2a9ae363b39ba8867b4396cc064531f15a88eb89b70cdffa21a59e8e8bd04->leave($__internal_96f2a9ae363b39ba8867b4396cc064531f15a88eb89b70cdffa21a59e8e8bd04_prof);

    }

    // line 112
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_4bee92a5d793a52a97a841565ef3ff410fa52a1a4460e1abb3c0c4505315b964 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bee92a5d793a52a97a841565ef3ff410fa52a1a4460e1abb3c0c4505315b964->enter($__internal_4bee92a5d793a52a97a841565ef3ff410fa52a1a4460e1abb3c0c4505315b964_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 113
        echo "
<script>

\$('#grocbay').select2({
  selectOnClose: true
});

         \$('#myTable').DataTable();
         </script>

";
        
        $__internal_4bee92a5d793a52a97a841565ef3ff410fa52a1a4460e1abb3c0c4505315b964->leave($__internal_4bee92a5d793a52a97a841565ef3ff410fa52a1a4460e1abb3c0c4505315b964_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Reports/itemSales.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  248 => 113,  242 => 112,  220 => 100,  215 => 97,  208 => 95,  205 => 94,  203 => 93,  196 => 89,  188 => 88,  184 => 87,  178 => 86,  174 => 85,  171 => 84,  166 => 83,  163 => 82,  161 => 81,  127 => 49,  110 => 47,  106 => 46,  94 => 37,  87 => 33,  80 => 29,  55 => 6,  49 => 5,  41 => 3,  35 => 2,  20 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/'~ myExtend ~'/base.html.twig' %}
{% block styles %}

{% endblock %}
{% block body %}
<div id=\"order-report-app\">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->

      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker1\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });
   \$( \"#datepicker2\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
    <div class=\"row\">
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-body collapse show\">
                    <h6>Item report filter</h6>
                    <hr>
                    <form method=\"post\" action=\"{{ path('filter_items')}}\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                                <label for=\"\">From</label>
                            <input type=\"text\" name=\"fromDate\" id=\"datepicker1\"  class=\"form-control\" autocomplete=\"off\"  value=\"{{ from }}\">
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"\">To</label>
                            <input type=\"text\" name=\"toDate\" id=\"datepicker2\" class=\"form-control\"  autocomplete=\"off\" value=\"{{ to }}\">
                        </div>
                    </div>
                    
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <label for=\"\">Items</label>
                            <select name=\"item\" id=\"grocbay\" class=\"form-control\">
                                <option value=\"0\">All</option>
                                {% for item in items%}
                                <option value=\"{{ item.id }}\" {% if itemid == item.id %} selected {% endif %}>{{ item.itemName }} - ({{ item.variationName }})</option>
                                {% endfor %}
                            </select>
                        </div>
                    </div>
                    <br>
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <button class=\"btn btn-primary\" type=\"submit\" name=\"filter\">Filter</button>
                       
                        </div>
                    </div>
                </div>
            </form>
            </div>
        </div>
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">Itemwise Sales Report
                    </h4>
                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                            <tr>
                                <td>#</td>
                                <td>Item Name</td>
                                <td>Quantity</td>
                                <td>Total</td>
                                <td>Action</td>
                            </tr>
                        </thead>
                        <tbody>
                            {% set count = 1 %}
                            {% set sales = 0 %}
                            {% for da in data %}
                            <tr>
                                <td>{{ count }}</td>
                                <td>{{ da.itemName }} - {{ da.priceVariavtion }}</td>
                                <td>{{ da.quantity }}</td>
                                <td>{% if numberFormat == 0 %}{{ da.price|round(2, 'floor')}}{% elseif numberFormat == 1 %}{{ da.price|number_format(2, '.', '') }}{% endif %}</td>
                                <td><a href=\"{{ path('view_item_sale',{'id':da.itemId}) }}\">view</a></td>

                                    
                                </tr>
                {% set count = count + 1 %}
                {% set sales = sales + da.price %}

                            {% endfor %}
                        </tbody>
                    </table>
                    <hr>
                  <b style=\"color:red;\">  Sales : {% if numberFormat == 0 %}{{ sales|round(2, 'floor')}}{% elseif numberFormat == 1 %}{{ sales|number_format(2, '.', '') }}{% endif %}</b>
                </div>
                <div class=\"card-body collapse show\">
                    
                </div>
            </div>
        </div>
    </div>
</div>
</div>
{% endblock %}

{% block scripts %}

<script>

\$('#grocbay').select2({
  selectOnClose: true
});

         \$('#myTable').DataTable();
         </script>

{% endblock %}", "AppBundle:Admin:Reports/itemSales.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Reports/itemSales.html.twig");
    }
}

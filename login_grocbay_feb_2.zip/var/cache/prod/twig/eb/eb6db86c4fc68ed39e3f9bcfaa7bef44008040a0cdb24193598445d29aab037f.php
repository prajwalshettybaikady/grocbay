<?php

/* AppBundle:Admin:Pages/restaurantForm.html.twig */
class __TwigTemplate_fe804b86db4131d31c1d4d4b27ad2f7e59bbb30f61efb5e898904d471611ba48 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/restaurantForm.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_709ae133e7477d1758683da61c106387a23c4e63649aad28543ffc25fb171995 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_709ae133e7477d1758683da61c106387a23c4e63649aad28543ffc25fb171995->enter($__internal_709ae133e7477d1758683da61c106387a23c4e63649aad28543ffc25fb171995_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/restaurantForm.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_709ae133e7477d1758683da61c106387a23c4e63649aad28543ffc25fb171995->leave($__internal_709ae133e7477d1758683da61c106387a23c4e63649aad28543ffc25fb171995_prof);

    }

    // line 3
    public function block_styles($context, array $blocks = array())
    {
        $__internal_5d5c6738997a120e3ae4d23f28bc879598a5ed715525012a183643b82ad0ba45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5d5c6738997a120e3ae4d23f28bc879598a5ed715525012a183643b82ad0ba45->enter($__internal_5d5c6738997a120e3ae4d23f28bc879598a5ed715525012a183643b82ad0ba45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 4
        echo "
 <script src=\"https://apis.google.com/js/platform.js\" async defer></script>
       <script type=\"text/javascript\"
            src=\"https://maps.google.com/maps/api/js?sensor=false&key=AIzaSyBSR3pigsWMH7goi_CthGQFckfb5QPOH8E&v=3.21.5a&libraries=drawing&signed_in=true&libraries=places,drawing,geometry\"></script>
<link href=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.css\" rel=\"stylesheet\">
<link href=\"/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css\" rel=\"stylesheet\">
<link href=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.css\" rel=\"stylesheet\">

<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked){
        position: relative;
        left: auto;
        opacity: 1;
    }
</style>
";
        
        $__internal_5d5c6738997a120e3ae4d23f28bc879598a5ed715525012a183643b82ad0ba45->leave($__internal_5d5c6738997a120e3ae4d23f28bc879598a5ed715525012a183643b82ad0ba45_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_95310a0345035199e1b08caf3c70b76e7fd1027d16682621dd4eaf69f97bd983 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_95310a0345035199e1b08caf3c70b76e7fd1027d16682621dd4eaf69f97bd983->enter($__internal_95310a0345035199e1b08caf3c70b76e7fd1027d16682621dd4eaf69f97bd983_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 21
        echo " <!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<!-- Row -->
<div class=\"row\">
        <div class=\"col-lg-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">Branch Update Panel</h4>
                </div>
                <div class=\"card-body\">
                    ";
        // line 32
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
                    ";
        // line 33
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/widget.html.twig"));
        // line 34
        echo "                        <div class=\"form-body\">
                            <h3 class=\"card-title\">Branch Info</h3>
                            <hr>
                            <div class=\"row p-t-10\">
                                <div class=\"col-md-12\">
                                    <div class=\"form-group\">
                                        ";
        // line 40
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "restaurantName", array()), 'label', array("label" => "Branch Name"));
        echo "
                                        ";
        // line 41
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "restaurantName", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Branch Name")));
        echo "
                                    </div>
                                </div>
                            </div>
                            <!--/row-->
                           
                             <!--/row-->
                            <div class=\"row p-t-10\">
                                <div class=\"col-md-12\">
                                    <div class=\"form-group\">
                                        ";
        // line 51
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "gst", array()), 'label', array("label" => "GST Number"));
        echo "
                                        ";
        // line 52
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "gst", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Shop gst Number")));
        echo "
                                    </div>
                                </div>
                            </div>
                            <!--/row-->
                            <!--/row-->
                            <div class=\"row\">
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        ";
        // line 61
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "primaryMobile", array()), 'label', array("label" => "Primary Mobile Number"));
        echo "
                                        ";
        // line 62
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "primaryMobile", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "9918625689")));
        echo " 
                                    </div>
                                </div>
                                <!--/span-->
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        ";
        // line 68
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "secondaryMobile", array()), 'label', array("label" => "Secondary Mobile Number"));
        echo "
                                        ";
        // line 69
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "secondaryMobile", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "(optional)")));
        echo "
                                    </div>
                                </div>
                                <!--/span-->
                            </div>
                            <!--/row-->
                            <div class=\"row\">
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        ";
        // line 78
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "primaryEmail", array()), 'label', array("label" => "Primary email"));
        echo "
                                        ";
        // line 79
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "primaryEmail", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "test@domain.com")));
        echo "
                                    </div>
                                </div>
                                <!--/span-->
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        ";
        // line 85
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "secondaryEmail", array()), 'label', array("label" => "Secondary email"));
        echo "
                                        ";
        // line 86
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "secondaryEmail", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "(optional)")));
        echo "
                                    </div>
                                </div>
                                <!--/span-->
                            </div>
                            <!--/row-->

                          <!--/row-->
                              
                              <div class=\"row\">
                                  <div class=\"col-md-3\">
                                      <div class=\"form-group\">
                                          ";
        // line 98
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "countryCode", array()), 'label', array("label" => "Country Code"));
        echo "
                                          ";
        // line 99
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "countryCode", array()), 'row', array("attr" => array("class" => "form-control")));
        echo "
                                      </div>
                                  </div>
                                  <div class=\"col-md-3\">
                                      <div class=\"form-group\">
                                          ";
        // line 104
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "currencyFormat", array()), 'label', array("label" => "Currency Format"));
        echo "
                                          ";
        // line 105
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "currencyFormat", array()), 'row', array("attr" => array("class" => "form-control")));
        echo "
                                      </div>
                                  </div>   
                                    <div class=\"col-md-3\">
                                      <div class=\"form-group\">
                                          ";
        // line 110
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "allowOutOfStock", array()), 'label', array("label" => "Allow Out Of Stock Products (enable/disable)"));
        echo "
                                          ";
        // line 111
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "allowOutOfStock", array()), 'row', array("attr" => array("class" => "form-control c", "data-on-text" => "Active", "data-off-text" => "Inactive")));
        echo "
                                      </div>
                                  </div>   
                               <div class=\"col-md-3\">
                                      <div class=\"form-group\">
                                          ";
        // line 116
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "currencyFormat", array()), 'label', array("label" => "Commission Fee in %"));
        echo "
                                          ";
        // line 117
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "serviceFee", array()), 'row', array("attr" => array("class" => "form-control")));
        echo "
                                      </div>
                                  </div>                   
                              </div>

                            <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <div class=\"form-group\">
                                        ";
        // line 125
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "restaurantAddress", array()), 'label', array("label" => "Shop Address"));
        echo "
                                        ";
        // line 126
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "restaurantAddress", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "(optional)")));
        echo "
                                    </div>
                                </div>
                            </div>
                              <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <div class=\"form-group\">
                                        ";
        // line 133
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "restaurantLocation", array()), 'label', array("label" => "Shop Location"));
        echo "
                                        ";
        // line 134
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "restaurantLocation", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "(location)")));
        echo "
                                    </div>
                                </div>
                            </div>
                           
                         
                            <div class=\"row\">
                              
                                     <div class=\"col-md-4\">
                                    <div class=\"form-group\">
                                        ";
        // line 144
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "slot", array()), 'label', array("label" => "Next Available Slot"));
        echo "
                                        ";
        // line 145
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "slot", array()), 'row', array("attr" => array("class" => "form-control form-control", "placeholder" => "1 hour")));
        echo "
                                    </div>
                                </div>
                                    <div class=\"col-md-4\">
                                    <div class=\"form-group\">
                                          ";
        // line 150
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minimumOrderAmount", array()), 'label', array("label" => "Minimum Order Amount (Default 0)"));
        echo "
                                    ";
        // line 151
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minimumOrderAmount", array()), 'row', array("attr" => array("class" => "form-control")));
        echo "
                                    </div>
                                </div>
              
                                        
                            </div>
                         
                         <a href=\"#openmap\" data-toggle=\"modal\" data-target=\"#myModal\">Map</a>
                           <div class=\"row\">
                            
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        ";
        // line 163
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "restaurantLat", array()), 'label', array("label" => "Latitude"));
        echo "
                                        ";
        // line 164
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "restaurantLat", array()), 'row', array("attr" => array("class" => "form-control")));
        echo "
                                    </div>
                                </div>   
                                     <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        ";
        // line 169
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "restaurantLong", array()), 'label', array("label" => "Longitude"));
        echo "
                                        ";
        // line 170
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "restaurantLong", array()), 'row', array("attr" => array("class" => "form-control form-control")));
        echo "
                                    </div>
                                </div>
                            </div>

                            <h3 class=\"box-title m-t-40\">Shop Identity</h3>
                            
                            ";
        // line 177
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/file.html.twig"));
        // line 178
        echo "                            <hr>
                            <div class=\"row\">
                                <div class=\"col-md-3 \">
                                    <div class=\"form-group\">
                                        ";
        // line 182
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "iconFile", array()), 'label', array("label" => "Shop Photo"));
        echo "
                                        ";
        // line 183
        $context["iconImage"] = "";
        // line 184
        echo "                                        ";
        if (($this->getAttribute(($context["restaurant"] ?? $this->getContext($context, "restaurant")), "iconImage", array()) != null)) {
            // line 185
            echo "                                            ";
            $context["iconImage"] = ("/uploads/restaurant/icons/" . $this->getAttribute(($context["restaurant"] ?? $this->getContext($context, "restaurant")), "iconImage", array()));
            // line 186
            echo "                                        ";
        }
        // line 187
        echo "                                        ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "iconFile", array()), 'row', array("attr" => array("data-default-file" => ($context["iconImage"] ?? $this->getContext($context, "iconImage")))));
        echo "
                                    </div>
                                </div>
                              
                              
                            </div>
                            <!--/row-->

                            
                            ";
        // line 196
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/widget.html.twig"));
        // line 197
        echo "                      
                         
                           
                            <!--/row-->
                            
                    
                           
                        </div>
                        <div class=\"form-actions\">
                            <button type=\"submit\" class=\"btn btn-success\"> <i class=\"fa fa-check\"></i> Save</button>
                            <button type=\"reset\" class=\"btn btn-inverse\">Cancel</button>
                        </div>
                    ";
        // line 209
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
                    ";
        // line 210
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'rest');
        echo "
                </div>
            </div>
        </div>
    </div>
    <!-- Row -->



    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->

<!-- Modal -->
<div id=\"myModal\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Select Branch Location</h4>
      </div>
      <div class=\"modal-body\">
                         <div  class=\"map-area\">
<script>
var map;
var marker;

function initialize() {
  var mapOptions = {
    zoom: 12
  };
  map = new google.maps.Map(document.getElementById('map-canvas'),
    mapOptions);

  // Get GEOLOCATION
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var pos = new google.maps.LatLng(position.coords.latitude,
        position.coords.longitude);
      if(\$('#appbundle_restaurants_restaurantLat').val()=='')
      {
  \$('#appbundle_restaurants_restaurantLat').val(position.coords.latitude);
\$('#appbundle_restaurants_restaurantLong').val(position.coords.longitude);      
      }




      map.setCenter(pos);
      marker = new google.maps.Marker({
        position: pos,
        map: map,
        draggable: true
      });
      google.maps.event.addListener(marker, 'dragstart', function(evt) {
//  \$('#appbundle_restaurants_restaurantLat').val(marker.position.lat());
// \$('#appbundle_restaurants_restaurantLong').val(marker.position.lng());

});

    }, function() {
      handleNoGeolocation(true);
    });

  } else {
    // Browser doesn't support Geolocation
    handleNoGeolocation(false);
  }

  function handleNoGeolocation(errorFlag) {
    if (errorFlag) {
      var content = 'Error: The Geolocation service failed.';
    } else {
      var content = 'Error: Your browser doesn\\'t support geolocation.';
    }

    var options = {
      map: map,
      position: new google.maps.LatLng(60, 105),
      content: content
    };

    map.setCenter(options.position);
    marker = new google.maps.Marker({
      position: options.position,
      map: map,
      draggable: true
    });

  }

  // get places auto-complete when user type in location-text-box
  var input = /** @type {HTMLInputElement} */
    (
      document.getElementById('location-text-box'));


  var autocomplete = new google.maps.places.Autocomplete(input);
  autocomplete.bindTo('bounds', map);

  var infowindow = new google.maps.InfoWindow();
  marker = new google.maps.Marker({
    map: map,
    anchorPoint: new google.maps.Point(0, -29),
    draggable: true
  });

  google.maps.event.addListener(autocomplete, 'place_changed', function() {
    infowindow.close();
    marker.setVisible(false);
    var place = autocomplete.getPlace();
    if (!place.geometry) {
      return;
    }

    // If the place has a geometry, then present it on a map.
    if (place.geometry.viewport) {
      map.fitBounds(place.geometry.viewport);
    } else {
      map.setCenter(place.geometry.location);
      map.setZoom(17); // Why 17? Because it looks good.
    }
    marker.setIcon( /** @type {google.maps.Icon} */ ({
      url: place.icon,
      size: new google.maps.Size(71, 71),
      origin: new google.maps.Point(0, 0),
      anchor: new google.maps.Point(17, 34),
      scaledSize: new google.maps.Size(35, 35)
    }));
    \$('#appbundle_restaurants_restaurantLat').val(marker.position.lat());
\$('#appbundle_restaurants_restaurantLong').val(marker.position.lng());
    marker.setPosition(place.geometry.location);
    marker.setVisible(true);

    var address = '';
    if (place.address_components) {
      address = [
        (place.address_components[0] && place.address_components[0].short_name || ''), (place.address_components[1] && place.address_components[1].short_name || ''), (place.address_components[2] && place.address_components[2].short_name || '')
      ].join(' ');
    }

  });



}

google.maps.event.addDomListener(window, 'load', initialize);

</script>
<style type=\"text/css\">
  #map-canvas {
  height: 350px;
  width: 100%;
  margin: 0px;
  padding: 0px
}
.pac-container {
    z-index: 1051 !important;
}
</style>
<div style=\"height:100%; width:100%;\">
  <div id=\"map-canvas\"></div>
    <input type=\"text\" id=\"location-text-box\"  class=\"form-control\" placeholder=\"please enter location\" /><br>
</div>
</div>
      </div>

      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Save & Close</button>
      </div>
    </div>

  </div>
</div>
";
        
        $__internal_95310a0345035199e1b08caf3c70b76e7fd1027d16682621dd4eaf69f97bd983->leave($__internal_95310a0345035199e1b08caf3c70b76e7fd1027d16682621dd4eaf69f97bd983_prof);

    }

    // line 389
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_05c740c2f99c657c55bc01675add78f30e7797efa57f9df00ccfb711ca55b746 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05c740c2f99c657c55bc01675add78f30e7797efa57f9df00ccfb711ca55b746->enter($__internal_05c740c2f99c657c55bc01675add78f30e7797efa57f9df00ccfb711ca55b746_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 390
        echo "<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>
<script src=\"/assets/plugins/moment/moment.js\"></script>
<script src=\"/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js\"></script>
<script src=\"/assets/js/colorpicker.js\"></script>

<script>
 
        \$(document).ready(function() {



            \$('#appbundle_restaurants_orderType').multiselect({
                    nonSelectedText: 'Click Here',
                    enableFiltering: true,
                    enableCaseInsensitiveFiltering: true,
                    buttonWidth:'100%',
                    includeSelectAllOption: true,
                    selectAllValue: 'select-all-value'
                });

            \$('#appbundle_restaurants_restaurantType').multiselect({
                    nonSelectedText: 'Click Here',
                    enableFiltering: true,
                    enableCaseInsensitiveFiltering: true,
                    buttonWidth:'100%',
                    includeSelectAllOption: true,
                    selectAllValue: 'select-all-value'
                });

            \$('#appbundle_restaurants_openTime').bootstrapMaterialDatePicker({ format : 'HH:mm', time: true, date: false });
            \$('#appbundle_restaurants_closeTime').bootstrapMaterialDatePicker({ format : 'HH:mm', time: true, date: false });


            \$(\"#appbundle_restaurants_isOpen\").bootstrapSwitch();
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });

</script>

";
        
        $__internal_05c740c2f99c657c55bc01675add78f30e7797efa57f9df00ccfb711ca55b746->leave($__internal_05c740c2f99c657c55bc01675add78f30e7797efa57f9df00ccfb711ca55b746_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/restaurantForm.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  577 => 390,  571 => 389,  386 => 210,  382 => 209,  368 => 197,  366 => 196,  353 => 187,  350 => 186,  347 => 185,  344 => 184,  342 => 183,  338 => 182,  332 => 178,  330 => 177,  320 => 170,  316 => 169,  308 => 164,  304 => 163,  289 => 151,  285 => 150,  277 => 145,  273 => 144,  260 => 134,  256 => 133,  246 => 126,  242 => 125,  231 => 117,  227 => 116,  219 => 111,  215 => 110,  207 => 105,  203 => 104,  195 => 99,  191 => 98,  176 => 86,  172 => 85,  163 => 79,  159 => 78,  147 => 69,  143 => 68,  134 => 62,  130 => 61,  118 => 52,  114 => 51,  101 => 41,  97 => 40,  89 => 34,  87 => 33,  83 => 32,  70 => 21,  64 => 20,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}

{% block styles %}

 <script src=\"https://apis.google.com/js/platform.js\" async defer></script>
       <script type=\"text/javascript\"
            src=\"https://maps.google.com/maps/api/js?sensor=false&key=AIzaSyBSR3pigsWMH7goi_CthGQFckfb5QPOH8E&v=3.21.5a&libraries=drawing&signed_in=true&libraries=places,drawing,geometry\"></script>
<link href=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.css\" rel=\"stylesheet\">
<link href=\"/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css\" rel=\"stylesheet\">
<link href=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.css\" rel=\"stylesheet\">

<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked){
        position: relative;
        left: auto;
        opacity: 1;
    }
</style>
{% endblock %}
{% block body %}
 <!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<!-- Row -->
<div class=\"row\">
        <div class=\"col-lg-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">Branch Update Panel</h4>
                </div>
                <div class=\"card-body\">
                    {{ form_start(form) }}
                    {% form_theme form '@AppBundle/Themes/widget.html.twig' %}
                        <div class=\"form-body\">
                            <h3 class=\"card-title\">Branch Info</h3>
                            <hr>
                            <div class=\"row p-t-10\">
                                <div class=\"col-md-12\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.restaurantName, \"Branch Name\") }}
                                        {{ form_row(form.restaurantName,{'attr':{'class':'form-control','placeholder':'Branch Name'}}) }}
                                    </div>
                                </div>
                            </div>
                            <!--/row-->
                           
                             <!--/row-->
                            <div class=\"row p-t-10\">
                                <div class=\"col-md-12\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.gst, \"GST Number\") }}
                                        {{ form_row(form.gst,{'attr':{'class':'form-control','placeholder':'Shop gst Number'}}) }}
                                    </div>
                                </div>
                            </div>
                            <!--/row-->
                            <!--/row-->
                            <div class=\"row\">
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.primaryMobile, \"Primary Mobile Number\") }}
                                        {{ form_row(form.primaryMobile,{'attr':{'class':'form-control','placeholder':'9918625689'}}) }} 
                                    </div>
                                </div>
                                <!--/span-->
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.secondaryMobile, \"Secondary Mobile Number\") }}
                                        {{ form_row(form.secondaryMobile,{'attr':{'class':'form-control','placeholder':'(optional)'}}) }}
                                    </div>
                                </div>
                                <!--/span-->
                            </div>
                            <!--/row-->
                            <div class=\"row\">
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.primaryEmail, \"Primary email\") }}
                                        {{ form_row(form.primaryEmail,{'attr':{'class':'form-control','placeholder':'test@domain.com'}}) }}
                                    </div>
                                </div>
                                <!--/span-->
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.secondaryEmail, \"Secondary email\") }}
                                        {{ form_row(form.secondaryEmail,{'attr':{'class':'form-control','placeholder':'(optional)'}}) }}
                                    </div>
                                </div>
                                <!--/span-->
                            </div>
                            <!--/row-->

                          <!--/row-->
                              
                              <div class=\"row\">
                                  <div class=\"col-md-3\">
                                      <div class=\"form-group\">
                                          {{ form_label(form.countryCode, \"Country Code\") }}
                                          {{ form_row(form.countryCode,{'attr':{'class':'form-control'}}) }}
                                      </div>
                                  </div>
                                  <div class=\"col-md-3\">
                                      <div class=\"form-group\">
                                          {{ form_label(form.currencyFormat, \"Currency Format\") }}
                                          {{ form_row(form.currencyFormat,{'attr':{'class':'form-control'}}) }}
                                      </div>
                                  </div>   
                                    <div class=\"col-md-3\">
                                      <div class=\"form-group\">
                                          {{ form_label(form.allowOutOfStock, \"Allow Out Of Stock Products (enable/disable)\") }}
                                          {{ form_row(form.allowOutOfStock,{'attr':{'class':'form-control c',\"data-on-text\":\"Active\",\"data-off-text\":\"Inactive\"}}) }}
                                      </div>
                                  </div>   
                               <div class=\"col-md-3\">
                                      <div class=\"form-group\">
                                          {{ form_label(form.currencyFormat, \"Commission Fee in %\") }}
                                          {{ form_row(form.serviceFee,{'attr':{'class':'form-control'}}) }}
                                      </div>
                                  </div>                   
                              </div>

                            <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.restaurantAddress, \"Shop Address\") }}
                                        {{ form_row(form.restaurantAddress,{'attr':{'class':'form-control','placeholder':'(optional)'}}) }}
                                    </div>
                                </div>
                            </div>
                              <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.restaurantLocation, \"Shop Location\") }}
                                        {{ form_row(form.restaurantLocation,{'attr':{'class':'form-control','placeholder':'(location)'}}) }}
                                    </div>
                                </div>
                            </div>
                           
                         
                            <div class=\"row\">
                              
                                     <div class=\"col-md-4\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.slot, \"Next Available Slot\") }}
                                        {{ form_row(form.slot,{'attr':{'class':'form-control form-control','placeholder':'1 hour'}}) }}
                                    </div>
                                </div>
                                    <div class=\"col-md-4\">
                                    <div class=\"form-group\">
                                          {{ form_label(form.minimumOrderAmount, \"Minimum Order Amount (Default 0)\") }}
                                    {{ form_row(form.minimumOrderAmount,{'attr':{'class':'form-control'}}) }}
                                    </div>
                                </div>
              
                                        
                            </div>
                         
                         <a href=\"#openmap\" data-toggle=\"modal\" data-target=\"#myModal\">Map</a>
                           <div class=\"row\">
                            
                                <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.restaurantLat, \"Latitude\") }}
                                        {{ form_row(form.restaurantLat,{'attr':{'class':'form-control'}}) }}
                                    </div>
                                </div>   
                                     <div class=\"col-md-6\">
                                    <div class=\"form-group\">
                                        {{ form_label(form.restaurantLong, \"Longitude\") }}
                                        {{ form_row(form.restaurantLong,{'attr':{'class':'form-control form-control'}}) }}
                                    </div>
                                </div>
                            </div>

                            <h3 class=\"box-title m-t-40\">Shop Identity</h3>
                            
                            {% form_theme form '@AppBundle/Themes/file.html.twig' %}
                            <hr>
                            <div class=\"row\">
                                <div class=\"col-md-3 \">
                                    <div class=\"form-group\">
                                        {{ form_label(form.iconFile, \"Shop Photo\") }}
                                        {% set iconImage = \"\" %}
                                        {% if restaurant.iconImage != null %}
                                            {% set iconImage = '/uploads/restaurant/icons/'~restaurant.iconImage %}
                                        {% endif %}
                                        {{ form_row(form.iconFile,{'attr':{'data-default-file':iconImage}}) }}
                                    </div>
                                </div>
                              
                              
                            </div>
                            <!--/row-->

                            
                            {% form_theme form '@AppBundle/Themes/widget.html.twig' %}
                      
                         
                           
                            <!--/row-->
                            
                    
                           
                        </div>
                        <div class=\"form-actions\">
                            <button type=\"submit\" class=\"btn btn-success\"> <i class=\"fa fa-check\"></i> Save</button>
                            <button type=\"reset\" class=\"btn btn-inverse\">Cancel</button>
                        </div>
                    {{ form_end(form) }}
                    {{ form_rest(form) }}
                </div>
            </div>
        </div>
    </div>
    <!-- Row -->



    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->

<!-- Modal -->
<div id=\"myModal\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Select Branch Location</h4>
      </div>
      <div class=\"modal-body\">
                         <div  class=\"map-area\">
<script>
var map;
var marker;

function initialize() {
  var mapOptions = {
    zoom: 12
  };
  map = new google.maps.Map(document.getElementById('map-canvas'),
    mapOptions);

  // Get GEOLOCATION
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var pos = new google.maps.LatLng(position.coords.latitude,
        position.coords.longitude);
      if(\$('#appbundle_restaurants_restaurantLat').val()=='')
      {
  \$('#appbundle_restaurants_restaurantLat').val(position.coords.latitude);
\$('#appbundle_restaurants_restaurantLong').val(position.coords.longitude);      
      }




      map.setCenter(pos);
      marker = new google.maps.Marker({
        position: pos,
        map: map,
        draggable: true
      });
      google.maps.event.addListener(marker, 'dragstart', function(evt) {
//  \$('#appbundle_restaurants_restaurantLat').val(marker.position.lat());
// \$('#appbundle_restaurants_restaurantLong').val(marker.position.lng());

});

    }, function() {
      handleNoGeolocation(true);
    });

  } else {
    // Browser doesn't support Geolocation
    handleNoGeolocation(false);
  }

  function handleNoGeolocation(errorFlag) {
    if (errorFlag) {
      var content = 'Error: The Geolocation service failed.';
    } else {
      var content = 'Error: Your browser doesn\\'t support geolocation.';
    }

    var options = {
      map: map,
      position: new google.maps.LatLng(60, 105),
      content: content
    };

    map.setCenter(options.position);
    marker = new google.maps.Marker({
      position: options.position,
      map: map,
      draggable: true
    });

  }

  // get places auto-complete when user type in location-text-box
  var input = /** @type {HTMLInputElement} */
    (
      document.getElementById('location-text-box'));


  var autocomplete = new google.maps.places.Autocomplete(input);
  autocomplete.bindTo('bounds', map);

  var infowindow = new google.maps.InfoWindow();
  marker = new google.maps.Marker({
    map: map,
    anchorPoint: new google.maps.Point(0, -29),
    draggable: true
  });

  google.maps.event.addListener(autocomplete, 'place_changed', function() {
    infowindow.close();
    marker.setVisible(false);
    var place = autocomplete.getPlace();
    if (!place.geometry) {
      return;
    }

    // If the place has a geometry, then present it on a map.
    if (place.geometry.viewport) {
      map.fitBounds(place.geometry.viewport);
    } else {
      map.setCenter(place.geometry.location);
      map.setZoom(17); // Why 17? Because it looks good.
    }
    marker.setIcon( /** @type {google.maps.Icon} */ ({
      url: place.icon,
      size: new google.maps.Size(71, 71),
      origin: new google.maps.Point(0, 0),
      anchor: new google.maps.Point(17, 34),
      scaledSize: new google.maps.Size(35, 35)
    }));
    \$('#appbundle_restaurants_restaurantLat').val(marker.position.lat());
\$('#appbundle_restaurants_restaurantLong').val(marker.position.lng());
    marker.setPosition(place.geometry.location);
    marker.setVisible(true);

    var address = '';
    if (place.address_components) {
      address = [
        (place.address_components[0] && place.address_components[0].short_name || ''), (place.address_components[1] && place.address_components[1].short_name || ''), (place.address_components[2] && place.address_components[2].short_name || '')
      ].join(' ');
    }

  });



}

google.maps.event.addDomListener(window, 'load', initialize);

</script>
<style type=\"text/css\">
  #map-canvas {
  height: 350px;
  width: 100%;
  margin: 0px;
  padding: 0px
}
.pac-container {
    z-index: 1051 !important;
}
</style>
<div style=\"height:100%; width:100%;\">
  <div id=\"map-canvas\"></div>
    <input type=\"text\" id=\"location-text-box\"  class=\"form-control\" placeholder=\"please enter location\" /><br>
</div>
</div>
      </div>

      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Save & Close</button>
      </div>
    </div>

  </div>
</div>
{% endblock %}

{% block scripts %}
<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>
<script src=\"/assets/plugins/moment/moment.js\"></script>
<script src=\"/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js\"></script>
<script src=\"/assets/js/colorpicker.js\"></script>

<script>
 
        \$(document).ready(function() {



            \$('#appbundle_restaurants_orderType').multiselect({
                    nonSelectedText: 'Click Here',
                    enableFiltering: true,
                    enableCaseInsensitiveFiltering: true,
                    buttonWidth:'100%',
                    includeSelectAllOption: true,
                    selectAllValue: 'select-all-value'
                });

            \$('#appbundle_restaurants_restaurantType').multiselect({
                    nonSelectedText: 'Click Here',
                    enableFiltering: true,
                    enableCaseInsensitiveFiltering: true,
                    buttonWidth:'100%',
                    includeSelectAllOption: true,
                    selectAllValue: 'select-all-value'
                });

            \$('#appbundle_restaurants_openTime').bootstrapMaterialDatePicker({ format : 'HH:mm', time: true, date: false });
            \$('#appbundle_restaurants_closeTime').bootstrapMaterialDatePicker({ format : 'HH:mm', time: true, date: false });


            \$(\"#appbundle_restaurants_isOpen\").bootstrapSwitch();
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });

</script>

{% endblock %}", "AppBundle:Admin:Pages/restaurantForm.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/restaurantForm.html.twig");
    }
}

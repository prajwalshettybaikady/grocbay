<?php

/* AppBundle:Admin:Reports/deliveryBoy.html.twig */
class __TwigTemplate_c1acf1566b34f49f1aca0235bc12cd6e7db6b2e9a8d4a876269120e934fd882c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Reports/deliveryBoy.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d23d1436051ba262d3030833b097f16129cd39b336fecfe4d58c2dfa8dd995c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d23d1436051ba262d3030833b097f16129cd39b336fecfe4d58c2dfa8dd995c->enter($__internal_9d23d1436051ba262d3030833b097f16129cd39b336fecfe4d58c2dfa8dd995c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Reports/deliveryBoy.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9d23d1436051ba262d3030833b097f16129cd39b336fecfe4d58c2dfa8dd995c->leave($__internal_9d23d1436051ba262d3030833b097f16129cd39b336fecfe4d58c2dfa8dd995c_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_de742f946490da3b4d368f6a5e737cbc559cfc20a4091f926da8b3127e276ddf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de742f946490da3b4d368f6a5e737cbc559cfc20a4091f926da8b3127e276ddf->enter($__internal_de742f946490da3b4d368f6a5e737cbc559cfc20a4091f926da8b3127e276ddf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "
";
        
        $__internal_de742f946490da3b4d368f6a5e737cbc559cfc20a4091f926da8b3127e276ddf->leave($__internal_de742f946490da3b4d368f6a5e737cbc559cfc20a4091f926da8b3127e276ddf_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_0b63197c308166535bb68c1544ba2f10f2475e4e94bc99d6abff31e91a59aea3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b63197c308166535bb68c1544ba2f10f2475e4e94bc99d6abff31e91a59aea3->enter($__internal_0b63197c308166535bb68c1544ba2f10f2475e4e94bc99d6abff31e91a59aea3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->


    <div class=\"row container-fluid\">
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">Delivery Report</h4>
                </div>
                <form method=\"post\" action=\"";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("filter_delivery");
        echo "\">
                <div class=\"card-body collapse show\">
                    <div class=\"form-group\">
                        <label for=\"\">Delivery Boy</label>
                        <select name=\"deliveryBoy\" id=\"\" class=\"form-control\" >
                            <option value=\"0\">All</option>
                            ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["delivery"] ?? $this->getContext($context, "delivery")));
        foreach ($context['_seq'] as $context["_key"] => $context["da"]) {
            // line 26
            echo "                            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "id", array()), "html", null, true);
            echo "\" ";
            if (($this->getAttribute($context["da"], "id", array()) == ($context["boy"] ?? $this->getContext($context, "boy")))) {
                echo " selected ";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "firstName", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "lastName", array()), "html", null, true);
            echo " </option>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['da'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "                        </select>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"\">Order Status</label>
                           <select name=\"status\" id=\"\" class=\"form-control\" >
                            <option value=\"0\"  ";
        // line 33
        if ((($context["status"] ?? $this->getContext($context, "status")) == "0")) {
            echo " selected ";
        }
        echo ">All</option>
                            <option value=\"dispatched\" ";
        // line 34
        if ((($context["status"] ?? $this->getContext($context, "status")) == "dispatched")) {
            echo " selected ";
        }
        echo ">Assigned</option>
                            <option value=\"onway\"  ";
        // line 35
        if ((($context["status"] ?? $this->getContext($context, "status")) == "onway")) {
            echo " selected ";
        }
        echo ">On Way</option>
                            <option value=\"completed\"  ";
        // line 36
        if ((($context["status"] ?? $this->getContext($context, "status")) == "completed")) {
            echo " selected ";
        }
        echo ">Completed</option>
                        </select>
                    </div>
                  
                    <button type=\"submit\"  class=\"btn btn-primary\" >Filter</button>
                </div>
            </form>
            </div>
        </div>
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">Delivery Boys</h4>
                </div>
                <div class=\"card-body collapse show\">
                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                        <tr>
                            <th>Order Id</th>
                            <th>Area</th>
                            <th>Delivery Boy</th>
                            <th>Payment Mode</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                       </thead>
                        <tbody>
                            ";
        // line 65
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["resp"]) {
            // line 66
            echo "                        <tr>
                            <td><a href=\"";
            // line 67
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_orders_panel_update", array("id" => $this->getAttribute($context["resp"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["resp"], "id", array()), "html", null, true);
            echo "</a></td>
                            <td>";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute($context["resp"], "area", array()), "html", null, true);
            echo "</td>
                            <td><a href=\"";
            // line 69
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_view", array("id" => $this->getAttribute($context["resp"], "dboy", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["resp"], "deliveryBoy", array()), "html", null, true);
            echo "</a></td>
                            <td>";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute($context["resp"], "paymentType", array()), "html", null, true);
            echo "</td>
                            <td>";
            // line 71
            echo twig_escape_filter($this->env, $this->getAttribute($context["resp"], "orderStatus", array()), "html", null, true);
            echo "</td>
                             <td><a href=\"";
            // line 72
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_orders_panel_update", array("id" => $this->getAttribute($context["resp"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary btn-sm\">
                            <i class=\"fa fa-eye\"></i></a></td>
                        </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['resp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 76
        echo "                       </tbody>
                    </table>
                </div>
            </div>
        </div>
</div>

";
        
        $__internal_0b63197c308166535bb68c1544ba2f10f2475e4e94bc99d6abff31e91a59aea3->leave($__internal_0b63197c308166535bb68c1544ba2f10f2475e4e94bc99d6abff31e91a59aea3_prof);

    }

    // line 85
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_1183476d9a0bd8277be848f1f67623515d046cc36bf763f2730ba98aea4e7dc7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1183476d9a0bd8277be848f1f67623515d046cc36bf763f2730ba98aea4e7dc7->enter($__internal_1183476d9a0bd8277be848f1f67623515d046cc36bf763f2730ba98aea4e7dc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 86
        echo "
<script>
  \$(document).ready(function() {
         \$('#myTable').DataTable( {
         
    });
     });
         </script>
";
        
        $__internal_1183476d9a0bd8277be848f1f67623515d046cc36bf763f2730ba98aea4e7dc7->leave($__internal_1183476d9a0bd8277be848f1f67623515d046cc36bf763f2730ba98aea4e7dc7_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Reports/deliveryBoy.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  221 => 86,  215 => 85,  201 => 76,  191 => 72,  187 => 71,  183 => 70,  177 => 69,  173 => 68,  167 => 67,  164 => 66,  160 => 65,  126 => 36,  120 => 35,  114 => 34,  108 => 33,  101 => 28,  84 => 26,  80 => 25,  71 => 19,  56 => 6,  50 => 5,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}
{% block styles %}

{% endblock %}
{% block body %}
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->


    <div class=\"row container-fluid\">
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">Delivery Report</h4>
                </div>
                <form method=\"post\" action=\"{{ path('filter_delivery')}}\">
                <div class=\"card-body collapse show\">
                    <div class=\"form-group\">
                        <label for=\"\">Delivery Boy</label>
                        <select name=\"deliveryBoy\" id=\"\" class=\"form-control\" >
                            <option value=\"0\">All</option>
                            {% for da in delivery %}
                            <option value=\"{{ da.id }}\" {% if da.id == boy %} selected {% endif %}>{{ da.firstName }} {{ da.lastName }} </option>
                            {% endfor %}
                        </select>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"\">Order Status</label>
                           <select name=\"status\" id=\"\" class=\"form-control\" >
                            <option value=\"0\"  {% if status == '0' %} selected {% endif %}>All</option>
                            <option value=\"dispatched\" {% if status == 'dispatched' %} selected {% endif %}>Assigned</option>
                            <option value=\"onway\"  {% if status == 'onway' %} selected {% endif %}>On Way</option>
                            <option value=\"completed\"  {% if status == 'completed' %} selected {% endif %}>Completed</option>
                        </select>
                    </div>
                  
                    <button type=\"submit\"  class=\"btn btn-primary\" >Filter</button>
                </div>
            </form>
            </div>
        </div>
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">Delivery Boys</h4>
                </div>
                <div class=\"card-body collapse show\">
                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                        <tr>
                            <th>Order Id</th>
                            <th>Area</th>
                            <th>Delivery Boy</th>
                            <th>Payment Mode</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                       </thead>
                        <tbody>
                            {% for resp in data %}
                        <tr>
                            <td><a href=\"{{ path('restaurant_orders_panel_update',{'id':resp.id}) }}\">{{ resp.id }}</a></td>
                            <td>{{ resp.area }}</td>
                            <td><a href=\"{{ path('admin_view',{'id':resp.dboy})}}\">{{ resp.deliveryBoy }}</a></td>
                            <td>{{ resp.paymentType }}</td>
                            <td>{{ resp.orderStatus }}</td>
                             <td><a href=\"{{ path('restaurant_orders_panel_update',{'id':resp.id}) }}\" class=\"btn btn-primary btn-sm\">
                            <i class=\"fa fa-eye\"></i></a></td>
                        </tr>
                        {% endfor %}
                       </tbody>
                    </table>
                </div>
            </div>
        </div>
</div>

{% endblock %}

{% block scripts %}

<script>
  \$(document).ready(function() {
         \$('#myTable').DataTable( {
         
    });
     });
         </script>
{% endblock %}", "AppBundle:Admin:Reports/deliveryBoy.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Reports/deliveryBoy.html.twig");
    }
}

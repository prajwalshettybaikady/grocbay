<?php

/* AppBundle:Admin:Pages/siteSetting.html.twig */
class __TwigTemplate_f237ffde7171583589588cf615206c061ea4a2f2b149467896921e437fdef1c2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/siteSetting.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3753f03a7fc618bde9a4c786b75c90565eae7d81c7e863c14d97364a96e7c686 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3753f03a7fc618bde9a4c786b75c90565eae7d81c7e863c14d97364a96e7c686->enter($__internal_3753f03a7fc618bde9a4c786b75c90565eae7d81c7e863c14d97364a96e7c686_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/siteSetting.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3753f03a7fc618bde9a4c786b75c90565eae7d81c7e863c14d97364a96e7c686->leave($__internal_3753f03a7fc618bde9a4c786b75c90565eae7d81c7e863c14d97364a96e7c686_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_f520849a2f10be42cebfbc6a64b1dc5211bf9b3f3e887b65cfdddbb87b79e79c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f520849a2f10be42cebfbc6a64b1dc5211bf9b3f3e887b65cfdddbb87b79e79c->enter($__internal_f520849a2f10be42cebfbc6a64b1dc5211bf9b3f3e887b65cfdddbb87b79e79c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "
<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked){
        position: relative;
        left: auto;
        opacity: 1;
    }
     .fstElement { font-size: 9px; }
            .fstToggleBtn { min-width: 16.5em; }

            .submitBtn { display: none; }

            .fstMultipleMode { display: block; }
            .fstMultipleMode .fstControls { width: 100%; }

</style>
";
        
        $__internal_f520849a2f10be42cebfbc6a64b1dc5211bf9b3f3e887b65cfdddbb87b79e79c->leave($__internal_f520849a2f10be42cebfbc6a64b1dc5211bf9b3f3e887b65cfdddbb87b79e79c_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_654bb88f39e2196094747ec299665482185a02a37e361f37bc5780e1ec04e7a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_654bb88f39e2196094747ec299665482185a02a37e361f37bc5780e1ec04e7a6->enter($__internal_654bb88f39e2196094747ec299665482185a02a37e361f37bc5780e1ec04e7a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 21
        echo "    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">Site Setting

                    </h4>
                </div>
                <div class=\"card-body\">
                 
<form method=\"post\" action=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_site_details");
        echo "\" enctype=\"multipart/form-data\">
  ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
            // line 33
            echo "    <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"background\">Website Background Color</label>
     <input type=\"color\" class=\"form-control \" id=\"background\" placeholder=\"Website Background Color\"  name=\"background\" value=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "background", array()), "html", null, true);
            echo "\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"backgroundColor\">Website Text Color</label>
 <input type=\"color\" class=\"form-control\" id=\"backgroundColor\" placeholder=\"Website Text Color\"  name=\"backgroundColor\" value=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "backgroundColor", array()), "html", null, true);
            echo "\">
    </div>
</div>


    <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"headerBackground\">Header Background Color</label>
     <input type=\"color\" class=\"form-control\" id=\"headerBackground\" placeholder=\"Header Background Color\"  name=\"headerBackground\" value=\"";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "headerBackground", array()), "html", null, true);
            echo "\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"topbarColor\">Header Text Color</label>
 <input type=\"color\" class=\"form-control\" id=\"topbarColor\" placeholder=\"Header Text Color\"  name=\"headerColor\" value=\"";
            // line 52
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "headerColor", array()), "html", null, true);
            echo "\">
    </div>
</div>
   <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"footerBackground\">Footer Background Color</label>
     <input type=\"color\" class=\"form-control\" id=\"footerBackground\" placeholder=\"Footer Background Color\"  name=\"footerBackground\" value=\"";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "footerBackground", array()), "html", null, true);
            echo "\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"footerColor\">Footer Text Color</label>
 <input type=\"color\" class=\"form-control\" id=\"footerColor\" placeholder=\"Footer Text Color\"  name=\"footerColor\" value=\"";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "footerColor", array()), "html", null, true);
            echo "\">
    </div>
</div>
   <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"primaryBackground\">Primary Background Color</label>
     <input type=\"color\" class=\"form-control\" id=\"primaryBackground\" placeholder=\"Primary Background Color\"  name=\"primaryBackground\" value=\"";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "primaryBackground", array()), "html", null, true);
            echo "\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"primaryColor\">Primary Text Color</label>
 <input type=\"color\" class=\"form-control\" id=\"primaryColor\" placeholder=\"primary Text Color\"  name=\"primaryColor\" value=\"";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "primaryColor", array()), "html", null, true);
            echo "\">
    </div>
</div>
    <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"topbarBackground\">Secondary Background Color</label>
     <input type=\"color\" class=\"form-control \" id=\"topbarBackground\" placeholder=\"Secondary Background Color\"  name=\"topbarBackground\" value=\"";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "topbarBackground", array()), "html", null, true);
            echo "\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"topbarColor\">Secondary Text Color</label>
 <input type=\"color\" class=\"form-control\" id=\"topbarColor\" placeholder=\"Secondary Text Color\"  name=\"topbarColor\" value=\"";
            // line 82
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "topbarColor", array()), "html", null, true);
            echo "\">
    </div>
</div>
<hr>
<center><h4>Social Logins</h4></center>
 <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"googleKey\">Google *</label>
     <input type=\"text\" class=\"form-control\" id=\"googleKey\" placeholder=\"google api key \"  name=\"googleKey\" value=\"";
            // line 90
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "googleKey", array()), "html", null, true);
            echo "\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"facebookKey\">Facebook *</label>
 <input type=\"text\" class=\"form-control\" id=\"facebookKey\" placeholder=\"facebook app id\"  name=\"facebookKey\" value=\"";
            // line 94
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "facebookKey", array()), "html", null, true);
            echo "\">
    </div>
</div>
<hr>
<center><h4>Header | Footer | SEO</h4></center>
 <div class=\"form-row\">
   <div class=\"form-group col-md-12\">
      <label for=\"header\">Header </label>
     <textarea class=\"form-control\" id=\"header\" cols=\"3\" placeholder=\"put custom scripts\" name=\"header\">";
            // line 102
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "header", array()), "html", null, true);
            echo "</textarea>
    </div>
  </div>
   <div class=\"form-row\">
   <div class=\"form-group col-md-12\">
      <label for=\"footer\">Footer </label>
     <textarea class=\"form-control\" id=\"footer\" cols=\"3\"  placeholder=\"put custom scripts\" name=\"footer\">";
            // line 108
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "footer", array()), "html", null, true);
            echo "</textarea>
    </div>
  </div>
   <div class=\"form-row\">
<div class=\"form-group col-md-12\">
      <label for=\"facebookKey\">Site Title *</label>
 <input type=\"text\" class=\"form-control\" id=\"facebookKey\" placeholder=\"Online Store | Best store in city\" value=\"";
            // line 114
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "title", array()), "html", null, true);
            echo "\" name=\"title\">
    </div>
</div>
   <div class=\"form-row\">
   <div class=\"form-group col-md-12\">
      <label for=\"ss\">Site Description   </label>
     <textarea class=\"form-control\" id=\"ss\" cols=\"3\"  placeholder=\"Best online store in city\"  name=\"description\">";
            // line 120
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "description", array()), "html", null, true);
            echo "</textarea>
    </div>
  </div>
     <div class=\"form-row\">
   <div class=\"form-group col-md-12\">
      <label for=\"key\">Site Keywords   </label>
     <textarea class=\"form-control\" id=\"key\" cols=\"3\" placeholder=\"online store , grocery\" name=\"keywords\">";
            // line 126
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "keywords", array()), "html", null, true);
            echo "</textarea>
    </div>
  </div>
   <div class=\"form-row\">

    <div class=\"col-6\" style=\"margin-top:20px;\">
     Start Time (Express Delivery)<br>
   
     <select class=\"form-control\" value=\"\" name=\"start\" required>";
            // line 134
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["time"] ?? $this->getContext($context, "time")));
            foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
                echo "<option ";
                if (($context["t"] == $this->getAttribute($context["res"], "start", array()))) {
                    echo " selected ";
                }
                echo ">";
                echo twig_escape_filter($this->env, $context["t"], "html", null, true);
                echo "</option>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "</select>
  </div>
   <div class=\"col-6\" style=\"margin-top:20px;\">
     End Time (Express Delivery)<br>
     <select class=\"form-control\" value=\"\" name=\"end\" required>";
            // line 138
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["time"] ?? $this->getContext($context, "time")));
            foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
                echo "<option ";
                if (($context["t"] == $this->getAttribute($context["res"], "end", array()))) {
                    echo " selected ";
                }
                echo ">";
                echo twig_escape_filter($this->env, $context["t"], "html", null, true);
                echo "</option>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "</select>

</div>
</div>
<hr>
<center><h4>Payment Setting</h4></center>
 <div class=\"form-row\">
   <div class=\"form-group col-md-8\">
      <label for=\"Payment\">Payment Modes *</label>
                         <select class=\"multipleSelect\" multiple name=\"mode[]\">
                          <option value=\"cod\" ";
            // line 148
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["featured"] ?? $this->getContext($context, "featured")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == "cod")) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">Cash On Delivery</option>
                          <option value=\"sod\" ";
            // line 149
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["featured"] ?? $this->getContext($context, "featured")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == "sod")) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">Swipe On Delivery</option>
                          <option value=\"online\"  ";
            // line 150
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["featured"] ?? $this->getContext($context, "featured")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == "online")) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">Online Payment</option>
                          <option value=\"wallet\"  ";
            // line 151
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["featured"] ?? $this->getContext($context, "featured")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == "wallet")) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">Wallet</option>
                          <option value=\"loyalty\"  ";
            // line 152
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["featured"] ?? $this->getContext($context, "featured")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == "wallet")) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">Loyalty</option>
           <option value=\"express\"  ";
            // line 153
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["featured"] ?? $this->getContext($context, "featured")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == "express")) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">Express</option>

                           <option value=\"pickupfromstore\"  ";
            // line 155
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["featured"] ?? $this->getContext($context, "featured")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == "pickupfromstore")) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">Pickup From Store</option>
                           <option value=\"upi\"  ";
            // line 156
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["featured"] ?? $this->getContext($context, "featured")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == "upi")) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">UPI</option>
                            <option value=\"sodedxo\"  ";
            // line 157
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["featured"] ?? $this->getContext($context, "featured")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == "sodedxo")) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">Sodedxo</option>
                           
                         </select>
    </div>


      <div class=\"form-group col-md-2\">
      <label for=\"agte\">Payment Gateway </label>
                         <select class=\"form-control\" id=\"gate\" name=\"gateway\">
                          <option value=\"Paytm\" ";
            // line 166
            if (($this->getAttribute($context["res"], "payment_gateway", array()) == "Paytm")) {
                echo "  selected ";
            }
            echo ">Paytm</option>
                          <option value=\"RazorPay\" ";
            // line 167
            if (($this->getAttribute($context["res"], "payment_gateway", array()) == "RazorPay")) {
                echo "  selected ";
            }
            echo ">RazorPay</option>
                          
                         </select>
    </div>
      <div class=\"form-group col-md-2\">
      <label for=\"mode\">Mode </label>
                         <select class=\"form-control\" id=\"mode\" name=\"pmode\">
                          <option value=\"TEST\" ";
            // line 174
            if (($this->getAttribute($context["res"], "mode", array()) == "TEST")) {
                echo "  selected ";
            }
            echo ">Test</option>
                          <option value=\"PRODUCTION\" ";
            // line 175
            if (($this->getAttribute($context["res"], "mode", array()) == "PRODUCTION")) {
                echo "  selected ";
            }
            echo ">Production</option>
                          
                         </select>
    </div>
  </div>
   ";
            // line 180
            if (($this->getAttribute($context["res"], "payment_gateway", array()) == "Paytm")) {
                echo "  <div class=\"paytm row\"> ";
            }
            // line 181
            echo "       ";
            if (($this->getAttribute($context["res"], "payment_gateway", array()) == "RazorPay")) {
                echo "    <div class=\"paytm row\" style=\"display:none;\">";
            }
            // line 182
            echo "
<div class=\"form-group col-md-6\">
      <label for=\"mid\">Paytm Merchant Id </label>
 <input type=\"text\" class=\"form-control\" id=\"mid\" placeholder=\"Paytm Merchant Id\"  name=\"key\" value=\"";
            // line 185
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "gateway_id", array()), "html", null, true);
            echo "\">
    </div>
    <div class=\"form-group col-md-6\">
      <label for=\"mkey\">Paytm Merchant Key </label>
 <input type=\"text\" class=\"form-control\" id=\"mkey\" placeholder=\"Paytm Merchant Key\"  name=\"secret\" value=\"";
            // line 189
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "gateway_secret", array()), "html", null, true);
            echo "\" >
    </div>
  </div>
   ";
            // line 192
            if (($this->getAttribute($context["res"], "payment_gateway", array()) == "Paytm")) {
                echo "    <div class=\"razor row\" style=\"display:none;\">
 ";
            }
            // line 194
            echo "   ";
            if (($this->getAttribute($context["res"], "payment_gateway", array()) == "RazorPay")) {
                echo "    <div class=\"razor row\" >
 ";
            }
            // line 196
            echo "<div class=\"form-group col-md-6\">
      <label for=\"mid\"> Key Id *</label>
 <input type=\"text\" class=\"form-control\" id=\"mid\" placeholder=\"RazorPay Key Id\"  name=\"rkey\" value=\"";
            // line 198
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "gateway_id", array()), "html", null, true);
            echo "\">
    </div>
    <div class=\"form-group col-md-6\">
      <label for=\"mkey\">Key Secret</label>
 <input type=\"text\" class=\"form-control\" id=\"mkey\" placeholder=\"RazorPay key secret\"  name=\"rsecret\" value=\"";
            // line 202
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "gateway_secret", array()), "html", null, true);
            echo "\">
    </div>
  </div>
   <div class=\"form-row\">

    <div class=\"col-4\" style=\"margin-top:20px;\">
   Logo <br> 
   <input type=\"file\" name=\"logo\" class=\"dropify\" data-default-file=\"/uploads/restaurant/icons/";
            // line 209
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "logo", array()), "html", null, true);
            echo "\"> 
   </div>
   <div class=\"col-4\" style=\"margin-top:20px;\">
     Favicon <br>
   <input type=\"file\" name=\"favicon\" class=\"dropify\" data-default-file=\"/uploads/restaurant/banners/";
            // line 213
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "favicon", array()), "html", null, true);
            echo "\"> 

</div>

   <div class=\"col-4\" style=\"margin-top:20px;\">
     Default Image <br>
   <input type=\"file\" name=\"default\"  class=\"dropify\" data-default-file=\"/uploads/restaurant/banners/";
            // line 219
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "default_image", array()), "html", null, true);
            echo "\"> 

</div>
</div>

";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 224
        echo " <br>
  <button type=\"submit\" class=\"btn btn-primary\">Save</button>

</form>






                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_654bb88f39e2196094747ec299665482185a02a37e361f37bc5780e1ec04e7a6->leave($__internal_654bb88f39e2196094747ec299665482185a02a37e361f37bc5780e1ec04e7a6_prof);

    }

    // line 240
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_41f1c2d7c97ebf71e746467d157a62fe098adb6c9dd396f4acac994e0983acb0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_41f1c2d7c97ebf71e746467d157a62fe098adb6c9dd396f4acac994e0983acb0->enter($__internal_41f1c2d7c97ebf71e746467d157a62fe098adb6c9dd396f4acac994e0983acb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 241
        echo "

<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>
<script src=\"/assets/plugins/moment/moment.js\"></script>
<script src=\"/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js\"></script>
<script>
    
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>
<script>
    
        \$(document).ready(function() {
\$('.multipleSelect').fastselect();
});
     
           \$(document).ready(function() {
            \$('.refund').richText();
        });
               \$('#gate').change(function() {
            var x=\$('#gate').val();
            if(x=='Paytm')
            {
              \$('.paytm').show();
              \$('.razor').hide();
            }
            else
            {
               \$('.paytm').hide();
             \$('.razor').show();              
            }
        });
             \$(document).ready(function() {
            \$('.wallet').richText();
        });
        </script>
";
        
        $__internal_41f1c2d7c97ebf71e746467d157a62fe098adb6c9dd396f4acac994e0983acb0->leave($__internal_41f1c2d7c97ebf71e746467d157a62fe098adb6c9dd396f4acac994e0983acb0_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/siteSetting.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  583 => 241,  577 => 240,  556 => 224,  544 => 219,  535 => 213,  528 => 209,  518 => 202,  511 => 198,  507 => 196,  501 => 194,  496 => 192,  490 => 189,  483 => 185,  478 => 182,  473 => 181,  469 => 180,  459 => 175,  453 => 174,  441 => 167,  435 => 166,  412 => 157,  397 => 156,  382 => 155,  366 => 153,  351 => 152,  336 => 151,  321 => 150,  306 => 149,  291 => 148,  265 => 138,  245 => 134,  234 => 126,  225 => 120,  216 => 114,  207 => 108,  198 => 102,  187 => 94,  180 => 90,  169 => 82,  162 => 78,  153 => 72,  146 => 68,  137 => 62,  130 => 58,  121 => 52,  114 => 48,  103 => 40,  96 => 36,  91 => 33,  87 => 32,  83 => 31,  71 => 21,  65 => 20,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}
{% block styles %}

<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked){
        position: relative;
        left: auto;
        opacity: 1;
    }
     .fstElement { font-size: 9px; }
            .fstToggleBtn { min-width: 16.5em; }

            .submitBtn { display: none; }

            .fstMultipleMode { display: block; }
            .fstMultipleMode .fstControls { width: 100%; }

</style>
{% endblock %}
{% block body %}
    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">Site Setting

                    </h4>
                </div>
                <div class=\"card-body\">
                 
<form method=\"post\" action=\"{{ path('update_site_details') }}\" enctype=\"multipart/form-data\">
  {% for res in data %}
    <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"background\">Website Background Color</label>
     <input type=\"color\" class=\"form-control \" id=\"background\" placeholder=\"Website Background Color\"  name=\"background\" value=\"{{ res.background }}\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"backgroundColor\">Website Text Color</label>
 <input type=\"color\" class=\"form-control\" id=\"backgroundColor\" placeholder=\"Website Text Color\"  name=\"backgroundColor\" value=\"{{ res.backgroundColor }}\">
    </div>
</div>


    <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"headerBackground\">Header Background Color</label>
     <input type=\"color\" class=\"form-control\" id=\"headerBackground\" placeholder=\"Header Background Color\"  name=\"headerBackground\" value=\"{{ res.headerBackground }}\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"topbarColor\">Header Text Color</label>
 <input type=\"color\" class=\"form-control\" id=\"topbarColor\" placeholder=\"Header Text Color\"  name=\"headerColor\" value=\"{{ res.headerColor }}\">
    </div>
</div>
   <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"footerBackground\">Footer Background Color</label>
     <input type=\"color\" class=\"form-control\" id=\"footerBackground\" placeholder=\"Footer Background Color\"  name=\"footerBackground\" value=\"{{ res.footerBackground }}\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"footerColor\">Footer Text Color</label>
 <input type=\"color\" class=\"form-control\" id=\"footerColor\" placeholder=\"Footer Text Color\"  name=\"footerColor\" value=\"{{ res.footerColor }}\">
    </div>
</div>
   <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"primaryBackground\">Primary Background Color</label>
     <input type=\"color\" class=\"form-control\" id=\"primaryBackground\" placeholder=\"Primary Background Color\"  name=\"primaryBackground\" value=\"{{ res.primaryBackground }}\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"primaryColor\">Primary Text Color</label>
 <input type=\"color\" class=\"form-control\" id=\"primaryColor\" placeholder=\"primary Text Color\"  name=\"primaryColor\" value=\"{{ res.primaryColor }}\">
    </div>
</div>
    <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"topbarBackground\">Secondary Background Color</label>
     <input type=\"color\" class=\"form-control \" id=\"topbarBackground\" placeholder=\"Secondary Background Color\"  name=\"topbarBackground\" value=\"{{ res.topbarBackground }}\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"topbarColor\">Secondary Text Color</label>
 <input type=\"color\" class=\"form-control\" id=\"topbarColor\" placeholder=\"Secondary Text Color\"  name=\"topbarColor\" value=\"{{ res.topbarColor }}\">
    </div>
</div>
<hr>
<center><h4>Social Logins</h4></center>
 <div class=\"form-row\">
   <div class=\"form-group col-md-6\">
      <label for=\"googleKey\">Google *</label>
     <input type=\"text\" class=\"form-control\" id=\"googleKey\" placeholder=\"google api key \"  name=\"googleKey\" value=\"{{ res.googleKey }}\">
    </div>
<div class=\"form-group col-md-6\">
      <label for=\"facebookKey\">Facebook *</label>
 <input type=\"text\" class=\"form-control\" id=\"facebookKey\" placeholder=\"facebook app id\"  name=\"facebookKey\" value=\"{{ res.facebookKey }}\">
    </div>
</div>
<hr>
<center><h4>Header | Footer | SEO</h4></center>
 <div class=\"form-row\">
   <div class=\"form-group col-md-12\">
      <label for=\"header\">Header </label>
     <textarea class=\"form-control\" id=\"header\" cols=\"3\" placeholder=\"put custom scripts\" name=\"header\">{{ res.header }}</textarea>
    </div>
  </div>
   <div class=\"form-row\">
   <div class=\"form-group col-md-12\">
      <label for=\"footer\">Footer </label>
     <textarea class=\"form-control\" id=\"footer\" cols=\"3\"  placeholder=\"put custom scripts\" name=\"footer\">{{ res.footer }}</textarea>
    </div>
  </div>
   <div class=\"form-row\">
<div class=\"form-group col-md-12\">
      <label for=\"facebookKey\">Site Title *</label>
 <input type=\"text\" class=\"form-control\" id=\"facebookKey\" placeholder=\"Online Store | Best store in city\" value=\"{{ res.title }}\" name=\"title\">
    </div>
</div>
   <div class=\"form-row\">
   <div class=\"form-group col-md-12\">
      <label for=\"ss\">Site Description   </label>
     <textarea class=\"form-control\" id=\"ss\" cols=\"3\"  placeholder=\"Best online store in city\"  name=\"description\">{{ res.description }}</textarea>
    </div>
  </div>
     <div class=\"form-row\">
   <div class=\"form-group col-md-12\">
      <label for=\"key\">Site Keywords   </label>
     <textarea class=\"form-control\" id=\"key\" cols=\"3\" placeholder=\"online store , grocery\" name=\"keywords\">{{ res.keywords }}</textarea>
    </div>
  </div>
   <div class=\"form-row\">

    <div class=\"col-6\" style=\"margin-top:20px;\">
     Start Time (Express Delivery)<br>
   
     <select class=\"form-control\" value=\"\" name=\"start\" required>{% for t in time %}<option {% if t == res.start %} selected {% endif %}>{{ t }}</option>{% endfor %}</select>
  </div>
   <div class=\"col-6\" style=\"margin-top:20px;\">
     End Time (Express Delivery)<br>
     <select class=\"form-control\" value=\"\" name=\"end\" required>{% for t in time %}<option {% if t == res.end %} selected {% endif %}>{{ t }}</option>{% endfor %}</select>

</div>
</div>
<hr>
<center><h4>Payment Setting</h4></center>
 <div class=\"form-row\">
   <div class=\"form-group col-md-8\">
      <label for=\"Payment\">Payment Modes *</label>
                         <select class=\"multipleSelect\" multiple name=\"mode[]\">
                          <option value=\"cod\" {% for fe in featured %} {% if fe == 'cod' %} selected {% endif %} {% endfor %}>Cash On Delivery</option>
                          <option value=\"sod\" {% for fe in featured %} {% if fe == 'sod' %} selected {% endif %} {% endfor %}>Swipe On Delivery</option>
                          <option value=\"online\"  {% for fe in featured %} {% if fe == 'online' %} selected {% endif %} {% endfor %}>Online Payment</option>
                          <option value=\"wallet\"  {% for fe in featured %} {% if fe == 'wallet' %} selected {% endif %} {% endfor %}>Wallet</option>
                          <option value=\"loyalty\"  {% for fe in featured %} {% if fe == 'wallet' %} selected {% endif %} {% endfor %}>Loyalty</option>
           <option value=\"express\"  {% for fe in featured %} {% if fe == 'express' %} selected {% endif %} {% endfor %}>Express</option>

                           <option value=\"pickupfromstore\"  {% for fe in featured %} {% if fe == 'pickupfromstore' %} selected {% endif %} {% endfor %}>Pickup From Store</option>
                           <option value=\"upi\"  {% for fe in featured %} {% if fe == 'upi' %} selected {% endif %} {% endfor %}>UPI</option>
                            <option value=\"sodedxo\"  {% for fe in featured %} {% if fe == 'sodedxo' %} selected {% endif %} {% endfor %}>Sodedxo</option>
                           
                         </select>
    </div>


      <div class=\"form-group col-md-2\">
      <label for=\"agte\">Payment Gateway </label>
                         <select class=\"form-control\" id=\"gate\" name=\"gateway\">
                          <option value=\"Paytm\" {% if res.payment_gateway == 'Paytm' %}  selected {% endif %}>Paytm</option>
                          <option value=\"RazorPay\" {% if res.payment_gateway == 'RazorPay' %}  selected {% endif %}>RazorPay</option>
                          
                         </select>
    </div>
      <div class=\"form-group col-md-2\">
      <label for=\"mode\">Mode </label>
                         <select class=\"form-control\" id=\"mode\" name=\"pmode\">
                          <option value=\"TEST\" {% if res.mode == 'TEST' %}  selected {% endif %}>Test</option>
                          <option value=\"PRODUCTION\" {% if res.mode == 'PRODUCTION' %}  selected {% endif %}>Production</option>
                          
                         </select>
    </div>
  </div>
   {% if res.payment_gateway == 'Paytm' %}  <div class=\"paytm row\"> {% endif %}
       {% if res.payment_gateway == 'RazorPay' %}    <div class=\"paytm row\" style=\"display:none;\">{% endif %}

<div class=\"form-group col-md-6\">
      <label for=\"mid\">Paytm Merchant Id </label>
 <input type=\"text\" class=\"form-control\" id=\"mid\" placeholder=\"Paytm Merchant Id\"  name=\"key\" value=\"{{ res.gateway_id }}\">
    </div>
    <div class=\"form-group col-md-6\">
      <label for=\"mkey\">Paytm Merchant Key </label>
 <input type=\"text\" class=\"form-control\" id=\"mkey\" placeholder=\"Paytm Merchant Key\"  name=\"secret\" value=\"{{ res.gateway_secret }}\" >
    </div>
  </div>
   {% if res.payment_gateway == 'Paytm' %}    <div class=\"razor row\" style=\"display:none;\">
 {% endif %}
   {% if res.payment_gateway == 'RazorPay' %}    <div class=\"razor row\" >
 {% endif %}
<div class=\"form-group col-md-6\">
      <label for=\"mid\"> Key Id *</label>
 <input type=\"text\" class=\"form-control\" id=\"mid\" placeholder=\"RazorPay Key Id\"  name=\"rkey\" value=\"{{ res.gateway_id }}\">
    </div>
    <div class=\"form-group col-md-6\">
      <label for=\"mkey\">Key Secret</label>
 <input type=\"text\" class=\"form-control\" id=\"mkey\" placeholder=\"RazorPay key secret\"  name=\"rsecret\" value=\"{{ res.gateway_secret }}\">
    </div>
  </div>
   <div class=\"form-row\">

    <div class=\"col-4\" style=\"margin-top:20px;\">
   Logo <br> 
   <input type=\"file\" name=\"logo\" class=\"dropify\" data-default-file=\"/uploads/restaurant/icons/{{ res.logo }}\"> 
   </div>
   <div class=\"col-4\" style=\"margin-top:20px;\">
     Favicon <br>
   <input type=\"file\" name=\"favicon\" class=\"dropify\" data-default-file=\"/uploads/restaurant/banners/{{ res.favicon }}\"> 

</div>

   <div class=\"col-4\" style=\"margin-top:20px;\">
     Default Image <br>
   <input type=\"file\" name=\"default\"  class=\"dropify\" data-default-file=\"/uploads/restaurant/banners/{{ res.default_image }}\"> 

</div>
</div>

{% endfor %} <br>
  <button type=\"submit\" class=\"btn btn-primary\">Save</button>

</form>






                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block scripts %}


<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>
<script src=\"/assets/plugins/moment/moment.js\"></script>
<script src=\"/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js\"></script>
<script>
    
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>
<script>
    
        \$(document).ready(function() {
\$('.multipleSelect').fastselect();
});
     
           \$(document).ready(function() {
            \$('.refund').richText();
        });
               \$('#gate').change(function() {
            var x=\$('#gate').val();
            if(x=='Paytm')
            {
              \$('.paytm').show();
              \$('.razor').hide();
            }
            else
            {
               \$('.paytm').hide();
             \$('.razor').show();              
            }
        });
             \$(document).ready(function() {
            \$('.wallet').richText();
        });
        </script>
{% endblock %}
", "AppBundle:Admin:Pages/siteSetting.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/siteSetting.html.twig");
    }
}

<?php

/* AppBundle:Admin:Reports/gstReport.html.twig */
class __TwigTemplate_ef0a0065239d67eb3e353a8aacdbc11a0350c3e183f065300abb5f4329ccce1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((("@AppBundle/" . ($context["myExtend"] ?? $this->getContext($context, "myExtend"))) . "/base.html.twig"), "AppBundle:Admin:Reports/gstReport.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_42d80a7e37cab0c940f7565e1b0af64e34de9947faf4a988017410b7de8de136 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42d80a7e37cab0c940f7565e1b0af64e34de9947faf4a988017410b7de8de136->enter($__internal_42d80a7e37cab0c940f7565e1b0af64e34de9947faf4a988017410b7de8de136_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Reports/gstReport.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_42d80a7e37cab0c940f7565e1b0af64e34de9947faf4a988017410b7de8de136->leave($__internal_42d80a7e37cab0c940f7565e1b0af64e34de9947faf4a988017410b7de8de136_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_d36e1fdff504b40c5f5ae52d4504fc5918c9ab2284585770432548f73a68e781 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d36e1fdff504b40c5f5ae52d4504fc5918c9ab2284585770432548f73a68e781->enter($__internal_d36e1fdff504b40c5f5ae52d4504fc5918c9ab2284585770432548f73a68e781_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "
";
        
        $__internal_d36e1fdff504b40c5f5ae52d4504fc5918c9ab2284585770432548f73a68e781->leave($__internal_d36e1fdff504b40c5f5ae52d4504fc5918c9ab2284585770432548f73a68e781_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_9728891481a4096ae711714fd7cd6d1eb984e32db2d6e57427bc9dbd71369076 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9728891481a4096ae711714fd7cd6d1eb984e32db2d6e57427bc9dbd71369076->enter($__internal_9728891481a4096ae711714fd7cd6d1eb984e32db2d6e57427bc9dbd71369076_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div id=\"order-report-app\">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->

    <div class=\"row container-fluid\">

        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-body collapse show\">
                    <h6>GST Report</h6>
                    <hr>
                    <form method=\"post\" action=\"";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("filter_gst_report");
        echo "\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                                <label for=\"\">From</label>
                            <input type=\"text\" name=\"fromDate\" id=\"fromDate\"  class=\"form-control\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, ($context["fromDate"] ?? $this->getContext($context, "fromDate")), "html", null, true);
        echo "\" autocomplete=\"off\">
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"\">To</label>
                            <input type=\"text\" name=\"toDate\" id=\"toDate\" class=\"form-control\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, ($context["toDate"] ?? $this->getContext($context, "toDate")), "html", null, true);
        echo "\"  autocomplete=\"off\">
                        </div>
                    </div>
                    <br><br>
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <button class=\"btn btn-primary\" type=\"submit\" name=\"filter\">Filter</button>
                        
                            <button class=\"btn btn-primary\" type=\"submit\"  name=\"export\">Export</button>
                       
                        </div>
                    </div>
                </div>
            </form>
            </div>
        </div>
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">GST Reports
                        <p class=\"text-muted pull-right\"></p>
                    </h4>
                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                            <tr>
                                <td>Sl.No</td>
                                <td>Invoice No</td>
                                <td>Date</td>
                                <td>Customer</td>
                                <td>GST No</td>
                                ";
        // line 59
        echo "                                <td>GST 5%</td>
                                <td>GST 12%</td>
                                <td>GST 18%</td>
                                <td>Invoice Amount</td>
                            </tr>
                        </thead>
                        <tbody>
                            ";
        // line 66
        $context["sl"] = 1;
        // line 67
        echo "                            ";
        $context["sum"] = 0;
        // line 68
        echo "                            ";
        $context["profit"] = 0;
        // line 69
        echo "                        
                            ";
        // line 70
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            echo " 
                            <tr >
                                <td>";
            // line 72
            echo twig_escape_filter($this->env, ($context["sl"] ?? $this->getContext($context, "sl")), "html", null, true);
            echo "</td>
                                <td>";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 74
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "orderDate", array()), "date", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                                <td>";
            // line 75
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "customerName", array()), "html", null, true);
            echo "</td> 
                                <td>";
            // line 76
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "customer", array()), "gst", array()), "html", null, true);
            echo "</td>
                                ";
            // line 87
            echo "                                 <td>
                                    <div class=\"tax\" style=\"display:flex;\">
                                        ";
            // line 89
            $context["v1"] = ($this->getAttribute($context["item"], "orderAmount", array()) * 0.05);
            // line 90
            echo "                                        <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">Amount <br>  
                                        (";
            // line 91
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round(($context["v1"] ?? $this->getContext($context, "v1")), 2, "floor"), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["v1"] ?? $this->getContext($context, "v1")), 2, ".", ""), "html", null, true);
            }
            echo ")

                                        </div>
                                        <div style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">CGST <br> (";
            // line 94
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_round(2, 2, "floor")), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_number_format_filter($this->env, 2, 2, ".", "")), "html", null, true);
            }
            echo ")</div>
                                        <div style=\"padding: 3px;font-size: 10px;\">SGST <br> (";
            // line 95
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_round(2, 2, "floor")), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_number_format_filter($this->env, 2, 2, ".", "")), "html", null, true);
            }
            echo ")</div>
                                    </div>
                                </td>
                                <td>
                                    <div class=\"tax\" style=\"display:flex;\">
                                        ";
            // line 100
            $context["v1"] = ($this->getAttribute($context["item"], "orderAmount", array()) * 0.12);
            // line 101
            echo "                                        <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">Amount <br>  
                                        (";
            // line 102
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round(($context["v1"] ?? $this->getContext($context, "v1")), 2, "floor"), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["v1"] ?? $this->getContext($context, "v1")), 2, ".", ""), "html", null, true);
            }
            echo ")

                                        </div>
                                        <div style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">CGST <br> (";
            // line 105
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_round(2, 2, "floor")), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_number_format_filter($this->env, 2, 2, ".", "")), "html", null, true);
            }
            echo ")</div>
                                        <div style=\"padding: 3px;font-size: 10px;\">SGST <br> (";
            // line 106
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_round(2, 2, "floor")), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_number_format_filter($this->env, 2, 2, ".", "")), "html", null, true);
            }
            echo ")</div>
                                    </div>
                                </td>
                                <td>
                                    <div class=\"tax\" style=\"display:flex;\">
                                        ";
            // line 111
            $context["v1"] = ($this->getAttribute($context["item"], "orderAmount", array()) * 0.18);
            // line 112
            echo "                                        <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">Amount <br>  
                                        (";
            // line 113
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round(($context["v1"] ?? $this->getContext($context, "v1")), 2, "floor"), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["v1"] ?? $this->getContext($context, "v1")), 2, ".", ""), "html", null, true);
            }
            echo ")

                                        </div>
                                        <div style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">CGST <br> (";
            // line 116
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_round(2, 2, "floor")), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_number_format_filter($this->env, 2, 2, ".", "")), "html", null, true);
            }
            echo ")</div>
                                        <div style=\"padding: 3px;font-size: 10px;\">SGST <br> (";
            // line 117
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_round(2, 2, "floor")), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, (($context["v1"] ?? $this->getContext($context, "v1")) / twig_number_format_filter($this->env, 2, 2, ".", "")), "html", null, true);
            }
            echo ")</div>
                                    </div>
                                </td>
                                <td>";
            // line 120
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "orderAmount", array()), "html", null, true);
            echo "</td>
                        
                            </tr>
                               ";
            // line 123
            $context["sl"] = (($context["sl"] ?? $this->getContext($context, "sl")) + 1);
            // line 124
            echo "                               ";
            $context["sum"] = (($context["sum"] ?? $this->getContext($context, "sum")) + $this->getAttribute($context["item"], "orderAmount", array()));
            // line 125
            echo "                               ";
            $context["profit"] = (($context["profit"] ?? $this->getContext($context, "profit")) + $this->getAttribute($context["item"], "cost", array()));
            // line 126
            echo "
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 128
        echo "                        </tbody>
                    </table>
                    <hr>
                    <b style=\"color:red;font-size:17px;font-weight:bold;\"> Total Sale : ";
        // line 131
        echo twig_escape_filter($this->env, twig_round(($context["sum"] ?? $this->getContext($context, "sum"))), "html", null, true);
        echo " </b> |    <b style=\"color:red;font-size:17px;font-weight:bold;\"> Profit : ";
        echo twig_escape_filter($this->env, twig_round(($context["profit"] ?? $this->getContext($context, "profit"))), "html", null, true);
        echo " </b>
                </div>
                <div class=\"card-body collapse show\">
                    
                </div>
            </div>
        </div>
    </div>
</div>
";
        
        $__internal_9728891481a4096ae711714fd7cd6d1eb984e32db2d6e57427bc9dbd71369076->leave($__internal_9728891481a4096ae711714fd7cd6d1eb984e32db2d6e57427bc9dbd71369076_prof);

    }

    // line 142
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_d9c22acc7238cfd7e604a7f510b2d9920e8f4c437f21f9888918b134632759d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9c22acc7238cfd7e604a7f510b2d9920e8f4c437f21f9888918b134632759d2->enter($__internal_d9c22acc7238cfd7e604a7f510b2d9920e8f4c437f21f9888918b134632759d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 143
        echo "
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
    \$(function() {
            \$( \"#fromDate\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });
        });
    \$(function() {
            \$( \"#toDate\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });
        });
</script>
";
        
        $__internal_d9c22acc7238cfd7e604a7f510b2d9920e8f4c437f21f9888918b134632759d2->leave($__internal_d9c22acc7238cfd7e604a7f510b2d9920e8f4c437f21f9888918b134632759d2_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Reports/gstReport.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  323 => 143,  317 => 142,  298 => 131,  293 => 128,  286 => 126,  283 => 125,  280 => 124,  278 => 123,  272 => 120,  262 => 117,  254 => 116,  244 => 113,  241 => 112,  239 => 111,  227 => 106,  219 => 105,  209 => 102,  206 => 101,  204 => 100,  192 => 95,  184 => 94,  174 => 91,  171 => 90,  169 => 89,  165 => 87,  161 => 76,  157 => 75,  153 => 74,  149 => 73,  145 => 72,  138 => 70,  135 => 69,  132 => 68,  129 => 67,  127 => 66,  118 => 59,  83 => 26,  76 => 22,  69 => 18,  55 => 6,  49 => 5,  41 => 3,  35 => 2,  20 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/'~ myExtend ~'/base.html.twig' %}
{% block styles %}

{% endblock %}
{% block body %}
<div id=\"order-report-app\">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->

    <div class=\"row container-fluid\">

        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-body collapse show\">
                    <h6>GST Report</h6>
                    <hr>
                    <form method=\"post\" action=\"{{ path('filter_gst_report')}}\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                                <label for=\"\">From</label>
                            <input type=\"text\" name=\"fromDate\" id=\"fromDate\"  class=\"form-control\" value=\"{{ fromDate }}\" autocomplete=\"off\">
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"\">To</label>
                            <input type=\"text\" name=\"toDate\" id=\"toDate\" class=\"form-control\" value=\"{{ toDate }}\"  autocomplete=\"off\">
                        </div>
                    </div>
                    <br><br>
                    <div class=\"row m-t-20\">
                        <div class=\"col-md-12\">
                            <button class=\"btn btn-primary\" type=\"submit\" name=\"filter\">Filter</button>
                        
                            <button class=\"btn btn-primary\" type=\"submit\"  name=\"export\">Export</button>
                       
                        </div>
                    </div>
                </div>
            </form>
            </div>
        </div>
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">GST Reports
                        <p class=\"text-muted pull-right\"></p>
                    </h4>
                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                            <tr>
                                <td>Sl.No</td>
                                <td>Invoice No</td>
                                <td>Date</td>
                                <td>Customer</td>
                                <td>GST No</td>
                                {# <td>GST Details</td> #}
                                <td>GST 5%</td>
                                <td>GST 12%</td>
                                <td>GST 18%</td>
                                <td>Invoice Amount</td>
                            </tr>
                        </thead>
                        <tbody>
                            {% set sl = 1 %}
                            {% set sum = 0 %}
                            {% set profit = 0 %}
                        
                            {% for item in data %} 
                            <tr >
                                <td>{{ sl }}</td>
                                <td>{{ item.id }}</td>
                                <td>{{ item.orderDate.date|date(\"d-m-Y\") }}</td>
                                <td>{{ item.customerName }}</td> 
                                <td>{{ item.customer.gst }}</td>
                                {# <td>
                                    <div class=\"tax\" style=\"display:flex;\">
                                        <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">Amount <br>  
                                        ({% if numberFormat == 0 %}{{ item.orderAmount|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ item.orderAmount|number_format(2, '.', '') }}{% endif %})

                                        </div>
                                        <div style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">CGST <br> ({% if numberFormat == 0 %}{{ item.totalTax/2|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ item.totalTax/2|number_format(2, '.', '') }}{% endif %})</div>
                                        <div style=\"padding: 3px;font-size: 10px;\">SGST <br> ({% if numberFormat == 0 %}{{ item.totalTax/2|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ item.totalTax/2|number_format(2, '.', '') }}{% endif %})</div>
                                    </div>
                                </td> #}
                                 <td>
                                    <div class=\"tax\" style=\"display:flex;\">
                                        {% set v1 = item.orderAmount * 0.05  %}
                                        <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">Amount <br>  
                                        ({% if numberFormat == 0 %}{{ v1|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ v1|number_format(2, '.', '') }}{% endif %})

                                        </div>
                                        <div style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">CGST <br> ({% if numberFormat == 0 %}{{ v1 / 2|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ v1 / 2|number_format(2, '.', '') }}{% endif %})</div>
                                        <div style=\"padding: 3px;font-size: 10px;\">SGST <br> ({% if numberFormat == 0 %}{{ v1 / 2|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ v1 / 2|number_format(2, '.', '') }}{% endif %})</div>
                                    </div>
                                </td>
                                <td>
                                    <div class=\"tax\" style=\"display:flex;\">
                                        {% set v1 = item.orderAmount * 0.12  %}
                                        <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">Amount <br>  
                                        ({% if numberFormat == 0 %}{{ v1|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ v1|number_format(2, '.', '') }}{% endif %})

                                        </div>
                                        <div style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">CGST <br> ({% if numberFormat == 0 %}{{ v1 / 2|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ v1 / 2|number_format(2, '.', '') }}{% endif %})</div>
                                        <div style=\"padding: 3px;font-size: 10px;\">SGST <br> ({% if numberFormat == 0 %}{{ v1 / 2|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ v1 / 2|number_format(2, '.', '') }}{% endif %})</div>
                                    </div>
                                </td>
                                <td>
                                    <div class=\"tax\" style=\"display:flex;\">
                                        {% set v1 = item.orderAmount * 0.18  %}
                                        <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">Amount <br>  
                                        ({% if numberFormat == 0 %}{{ v1|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ v1|number_format(2, '.', '') }}{% endif %})

                                        </div>
                                        <div style=\"border-right: 1px solid;padding: 3px;font-size: 10px;\">CGST <br> ({% if numberFormat == 0 %}{{ v1 / 2|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ v1 / 2|number_format(2, '.', '') }}{% endif %})</div>
                                        <div style=\"padding: 3px;font-size: 10px;\">SGST <br> ({% if numberFormat == 0 %}{{ v1 / 2|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ v1 / 2|number_format(2, '.', '') }}{% endif %})</div>
                                    </div>
                                </td>
                                <td>{{ item.orderAmount }}</td>
                        
                            </tr>
                               {% set sl = sl + 1 %}
                               {% set sum = sum + item.orderAmount %}
                               {% set profit = profit + item.cost %}

                            {% endfor %}
                        </tbody>
                    </table>
                    <hr>
                    <b style=\"color:red;font-size:17px;font-weight:bold;\"> Total Sale : {{ sum|round }} </b> |    <b style=\"color:red;font-size:17px;font-weight:bold;\"> Profit : {{ profit|round }} </b>
                </div>
                <div class=\"card-body collapse show\">
                    
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
    \$(function() {
            \$( \"#fromDate\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });
        });
    \$(function() {
            \$( \"#toDate\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });
        });
</script>
{% endblock %}", "AppBundle:Admin:Reports/gstReport.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Reports/gstReport.html.twig");
    }
}

<?php

/* AppBundle:Admin:Tickets/all.html.twig */
class __TwigTemplate_34bdc7789f8214a0463efac96d542d66fe7514c23e560ca62484d91045514b45 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Tickets/all.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e3d27982cd3079dca60ac3d7a7b797856c7e1b345089c466a0c975e2cfd96393 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e3d27982cd3079dca60ac3d7a7b797856c7e1b345089c466a0c975e2cfd96393->enter($__internal_e3d27982cd3079dca60ac3d7a7b797856c7e1b345089c466a0c975e2cfd96393_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Tickets/all.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e3d27982cd3079dca60ac3d7a7b797856c7e1b345089c466a0c975e2cfd96393->leave($__internal_e3d27982cd3079dca60ac3d7a7b797856c7e1b345089c466a0c975e2cfd96393_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_26508eb32984f3302819ba75c838d77c04834e42cf0e85c26f2f1a3f0a60ea35 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_26508eb32984f3302819ba75c838d77c04834e42cf0e85c26f2f1a3f0a60ea35->enter($__internal_26508eb32984f3302819ba75c838d77c04834e42cf0e85c26f2f1a3f0a60ea35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "<link rel=\"stylesheet\" href=\"/assets/plugins/iCheck/all.css\">
<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked) {
         position: relative; 
         left: 0px; 
         opacity: 1; 
    }
</style>
";
        
        $__internal_26508eb32984f3302819ba75c838d77c04834e42cf0e85c26f2f1a3f0a60ea35->leave($__internal_26508eb32984f3302819ba75c838d77c04834e42cf0e85c26f2f1a3f0a60ea35_prof);

    }

    // line 13
    public function block_body($context, array $blocks = array())
    {
        $__internal_c6685e2735b763f764f4c6d477ffd07d6777705f4ff00cc455ce65196de86f58 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c6685e2735b763f764f4c6d477ffd07d6777705f4ff00cc455ce65196de86f58->enter($__internal_c6685e2735b763f764f4c6d477ffd07d6777705f4ff00cc455ce65196de86f58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 14
        echo "<div class=\"layout-px-spacing\">
<div class=\"row layout-top-spacing\">
    <div class=\"col-12\">
        <div class=\"card card-outline-info\">

                <div class=\"card-header\">
                    <h4 class=\"m-b-0 pl-4 pt-4\">Tickets</h4>
                </div>
                     <!--  <span style=\"margin-left:20px; font-size:15px;\">
                         <a href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("all_tickets", array("status" => "pending", "all" => "all")), "html", null, true);
        echo "\">All</a>  |    <a href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("tickets", array("status" => "list", "type" => "click")), "html", null, true);
        echo "\">Click and send</a>  |  <a href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("tickets", array("status" => "list", "type" => "record")), "html", null, true);
        echo "\">Record and Send</a> |  <a href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("tickets", array("status" => "list", "type" => "callback")), "html", null, true);
        echo "\">Call Back</a>
</span> -->
                ";
        // line 26
        echo "                <div class=\"card-body\">
                    
                    <div class=\"mt-3 pl-3\">
                                    <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("all_tickets", array("status" => "Open"));
        echo "\">
                                    <span class=\"badge outline-badge-primary mb-2\">Open Tickets(";
        // line 30
        echo twig_escape_filter($this->env, ($context["opencount"] ?? $this->getContext($context, "opencount")), "html", null, true);
        echo ")</span></a>
                                    <!--span class=\"badge outline-badge-primary mb-2\">Picker (10)</span-->
                                    <a href=\"";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("all_tickets", array("status" => "Closed"));
        echo "\">
                                    <span class=\"badge outline-badge-primary mb-2\">Closed Tickets(";
        // line 33
        echo twig_escape_filter($this->env, ($context["closedcount"] ?? $this->getContext($context, "closedcount")), "html", null, true);
        echo ")</span></a>
                              </div>
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"zero-config\" class=\"table table-bordered table-striped\">
                            <thead>
                                <tr> 
                                    <th>#</th>
                                    <th>From</th>
                                    <th>Subject</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                ";
        // line 48
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["da"]) {
            // line 49
            echo "                                <tr> 
                                    <th><a href=\"";
            // line 50
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("view_tickets", array("id" => $this->getAttribute($context["da"], "ref", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "ref", array()), "html", null, true);
            echo "</a></th>
                                    <th><a href=\"";
            // line 51
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("customer_view", array("id" => $this->getAttribute($context["da"], "raisedBy", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "username", array()), "html", null, true);
            echo "</th>
                                    <th><a href=\"";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("view_tickets", array("id" => $this->getAttribute($context["da"], "ref", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "subject", array()), "html", null, true);
            echo "</a></th>
                                    <th>";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "type", array()), "html", null, true);
            echo "</th>
                                    <th>
                                        <span class=\"badge badge-danger\">";
            // line 55
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "ticketStatus", array()), "html", null, true);
            echo "</span>
                                    </th>
                                    <th><a href=\"";
            // line 57
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("view_tickets", array("id" => $this->getAttribute($context["da"], "ref", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary btn-sm\" title=\"Edit ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "subject", array()), "html", null, true);
            echo "\"><i class=\"fa fa-edit\"></i></a></th>
                                </tr>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['da'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 60
        echo "                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
</div>
";
        
        $__internal_c6685e2735b763f764f4c6d477ffd07d6777705f4ff00cc455ce65196de86f58->leave($__internal_c6685e2735b763f764f4c6d477ffd07d6777705f4ff00cc455ce65196de86f58_prof);

    }

    // line 70
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_727a310ad8457e93cefc70af623c4b45c25017970a4e811ba8a3b389dafddbef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_727a310ad8457e93cefc70af623c4b45c25017970a4e811ba8a3b389dafddbef->enter($__internal_727a310ad8457e93cefc70af623c4b45c25017970a4e811ba8a3b389dafddbef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 71
        echo "
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script src=\"/assets/plugins/iCheck/icheck.min.js\"></script>
<script src=\"/assets/plugins/table/datatable/datatables.js\"></script>
<script>
    \$(document).ready(function() {
        /*\$('#myTable').DataTable({
                \"order\": [[ 0, 'DESC' ]]

        });*/

        \$('#zero-config').DataTable({
            \"oLanguage\": {
                \"oPaginate\": { \"sPrevious\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-left\"><line x1=\"19\" y1=\"12\" x2=\"5\" y2=\"12\"></line><polyline points=\"12 19 5 12 12 5\"></polyline></svg>', \"sNext\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-right\"><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line><polyline points=\"12 5 19 12 12 19\"></polyline></svg>' },
                \"sInfo\": \"Showing page _PAGE_ of _PAGES_\",
                \"sSearch\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-search\"><circle cx=\"11\" cy=\"11\" r=\"8\"></circle><line x1=\"21\" y1=\"21\" x2=\"16.65\" y2=\"16.65\"></line></svg>',
                \"sSearchPlaceholder\": \"Search...\",
               \"sLengthMenu\": \"Results :  _MENU_\",
            },
            \"stripeClasses\": [],
            \"lengthMenu\": [7, 10, 20, 50],
            \"pageLength\": 7,
            \"bLengthChange\": false,
        });

        //iCheck for checkbox and radio inputs
        if(\$('input[type=\"checkbox\"], input[type=\"radio\"]').length)
            \$('input[type=\"checkbox\"], input[type=\"radio\"]').iCheck({
                checkboxClass: 'icheckbox_minimal-blue',
                radioClass: 'iradio_minimal-blue'
            });
        });
</script>
";
        
        $__internal_727a310ad8457e93cefc70af623c4b45c25017970a4e811ba8a3b389dafddbef->leave($__internal_727a310ad8457e93cefc70af623c4b45c25017970a4e811ba8a3b389dafddbef_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Tickets/all.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  188 => 71,  182 => 70,  167 => 60,  156 => 57,  151 => 55,  146 => 53,  140 => 52,  134 => 51,  128 => 50,  125 => 49,  121 => 48,  103 => 33,  99 => 32,  94 => 30,  90 => 29,  85 => 26,  74 => 23,  63 => 14,  57 => 13,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}
{% block styles %}
<link rel=\"stylesheet\" href=\"/assets/plugins/iCheck/all.css\">
<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked) {
         position: relative; 
         left: 0px; 
         opacity: 1; 
    }
</style>
{% endblock %}

{% block body %}
<div class=\"layout-px-spacing\">
<div class=\"row layout-top-spacing\">
    <div class=\"col-12\">
        <div class=\"card card-outline-info\">

                <div class=\"card-header\">
                    <h4 class=\"m-b-0 pl-4 pt-4\">Tickets</h4>
                </div>
                     <!--  <span style=\"margin-left:20px; font-size:15px;\">
                         <a href=\"{{ path('all_tickets',{'status':'pending','all':'all'})}}\">All</a>  |    <a href=\"{{ path('tickets',{'status':'list','type':'click'})}}\">Click and send</a>  |  <a href=\"{{ path('tickets',{'status':'list','type':'record'})}}\">Record and Send</a> |  <a href=\"{{ path('tickets',{'status':'list','type':'callback'})}}\">Call Back</a>
</span> -->
                {# {{ dump(orders) }} #}
                <div class=\"card-body\">
                    
                    <div class=\"mt-3 pl-3\">
                                    <a href=\"{{ path('all_tickets',{'status':'Open'})}}\">
                                    <span class=\"badge outline-badge-primary mb-2\">Open Tickets({{opencount}})</span></a>
                                    <!--span class=\"badge outline-badge-primary mb-2\">Picker (10)</span-->
                                    <a href=\"{{ path('all_tickets',{'status':'Closed'})}}\">
                                    <span class=\"badge outline-badge-primary mb-2\">Closed Tickets({{closedcount}})</span></a>
                              </div>
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"zero-config\" class=\"table table-bordered table-striped\">
                            <thead>
                                <tr> 
                                    <th>#</th>
                                    <th>From</th>
                                    <th>Subject</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {% for da in data %}
                                <tr> 
                                    <th><a href=\"{{ path('view_tickets',{'id':da.ref})}}\">{{ da.ref }}</a></th>
                                    <th><a href=\"{{ path('customer_view',{'id':da.raisedBy}) }}\">{{ da.username }}</th>
                                    <th><a href=\"{{ path('view_tickets',{'id':da.ref})}}\">{{ da.subject }}</a></th>
                                    <th>{{ da.type }}</th>
                                    <th>
                                        <span class=\"badge badge-danger\">{{ da.ticketStatus }}</span>
                                    </th>
                                    <th><a href=\"{{ path('view_tickets',{'id':da.ref}) }}\" class=\"btn btn-primary btn-sm\" title=\"Edit {{ da.subject }}\"><i class=\"fa fa-edit\"></i></a></th>
                                </tr>
                                {% endfor %}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
</div>
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script src=\"/assets/plugins/iCheck/icheck.min.js\"></script>
<script src=\"/assets/plugins/table/datatable/datatables.js\"></script>
<script>
    \$(document).ready(function() {
        /*\$('#myTable').DataTable({
                \"order\": [[ 0, 'DESC' ]]

        });*/

        \$('#zero-config').DataTable({
            \"oLanguage\": {
                \"oPaginate\": { \"sPrevious\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-left\"><line x1=\"19\" y1=\"12\" x2=\"5\" y2=\"12\"></line><polyline points=\"12 19 5 12 12 5\"></polyline></svg>', \"sNext\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-right\"><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line><polyline points=\"12 5 19 12 12 19\"></polyline></svg>' },
                \"sInfo\": \"Showing page _PAGE_ of _PAGES_\",
                \"sSearch\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-search\"><circle cx=\"11\" cy=\"11\" r=\"8\"></circle><line x1=\"21\" y1=\"21\" x2=\"16.65\" y2=\"16.65\"></line></svg>',
                \"sSearchPlaceholder\": \"Search...\",
               \"sLengthMenu\": \"Results :  _MENU_\",
            },
            \"stripeClasses\": [],
            \"lengthMenu\": [7, 10, 20, 50],
            \"pageLength\": 7,
            \"bLengthChange\": false,
        });

        //iCheck for checkbox and radio inputs
        if(\$('input[type=\"checkbox\"], input[type=\"radio\"]').length)
            \$('input[type=\"checkbox\"], input[type=\"radio\"]').iCheck({
                checkboxClass: 'icheckbox_minimal-blue',
                radioClass: 'iradio_minimal-blue'
            });
        });
</script>
{% endblock %}", "AppBundle:Admin:Tickets/all.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Tickets/all.html.twig");
    }
}

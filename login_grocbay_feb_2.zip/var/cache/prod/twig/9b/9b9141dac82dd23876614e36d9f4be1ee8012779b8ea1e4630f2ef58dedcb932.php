<?php

/* AppBundle:Admin:Orders/orderForm.html.twig */
class __TwigTemplate_52a29dc53d6223c33fec945d23deda4b4540191f45c2b8f3c91a5197474ed6a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((("@AppBundle/" . ($context["myExtend"] ?? $this->getContext($context, "myExtend"))) . "/base.html.twig"), "AppBundle:Admin:Orders/orderForm.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ea00cda3da0cf7530b183431d3817d65480adf0e10ad90d5e7964f5a622e21ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea00cda3da0cf7530b183431d3817d65480adf0e10ad90d5e7964f5a622e21ba->enter($__internal_ea00cda3da0cf7530b183431d3817d65480adf0e10ad90d5e7964f5a622e21ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Orders/orderForm.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ea00cda3da0cf7530b183431d3817d65480adf0e10ad90d5e7964f5a622e21ba->leave($__internal_ea00cda3da0cf7530b183431d3817d65480adf0e10ad90d5e7964f5a622e21ba_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_cf2a5d2e447a9e00b00b1de1dea1762d88deb328cb35bc8d988a8c6fac6d4d57 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf2a5d2e447a9e00b00b1de1dea1762d88deb328cb35bc8d988a8c6fac6d4d57->enter($__internal_cf2a5d2e447a9e00b00b1de1dea1762d88deb328cb35bc8d988a8c6fac6d4d57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<style type=\"text/css\">
thead.ban td {
    padding: 5px !important;
    font-size: 11px;
    font-weight: 600;
    text-transform: capitalize;
}

.pr
   {
    font-size: 10px;
    text-transform: uppercase;
   }
   @media print{
   .noprint{
   display:none;
   }

 
      .print-area
   {
    display: block !important;
    background: #fff !important;
   }
   }
      .print-area
   {
    display: none;
   }
   .edit-order
   {
   float: right;
   font-weight: bolder;
   text-transform: uppercase;
   font-size: 11px;
   }
   .borderless tr {
    border: none;
}
 @media print
      {
         @page {
           margin-top: 0;
           margin-bottom: 0;
         }
         body  {
           padding-top: 72px;
           padding-bottom: 72px ;
         }
         *
         {
          background: #fff !important;
         }
      } 

.x td, .x th {
    border-color: #f3f1f1;
    padding: 0px;
    font-weight: 500;
    font-size: 11px;
}
.xx td, .xx th {
    border-color: #f3f1f1;
    padding: 0px;
    font-weight: 500;
    font-size: 13px;
}

      .ss
      {
        background: #fff0;
    color: #000 !important;
    border: none;
    box-shadow: none;
    }
    .select1{
       padding: 7px 16px;
    }
    .card-header{
        background-color: #fff;
        border-color: #fff;
    }
    .card-header section > div.collapsed {
        color: #000;
       }

     select.info {

  /* styling */
  background-color: white;
  border: thin solid blue;
  border-radius: 4px;
  display: inline-block;
  font: inherit;
  line-height: 1.5em;
  padding: 0.5em 3.5em 0.5em 1em;

  /* reset */

  margin: 0;      
  -webkit-box-sizing: border-box; 
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-appearance: none;
  -moz-appearance: none;
}
 
 .form-control.form-control-sm {
    padding: 6px 16px;
 }
      
select.classic {
  background-image:
    linear-gradient(45deg, transparent 50%, #000 50%),
    linear-gradient(135deg, #000 50%, transparent 50%),
    linear-gradient(to right, #c7c7c7, #c7c7c7);
  background-position:
    calc(100% - 20px) calc(1em + 2px),
    calc(100% - 15px) calc(1em + 2px),
    100% 0;
  background-size:
    5px 5px,
    5px 5px,
    2.5em 2.5em;
  background-repeat: no-repeat;
}

select.classic:focus {
  background-image:
    linear-gradient(45deg, #000 50%, transparent 50%),
    linear-gradient(135deg, transparent 50%, #000 50%),
    linear-gradient(to right, #c7c7c7, #c7c7c7);
  background-position:
    calc(100% - 15px) 1em,
    calc(100% - 20px) 1em,
    100% 0;
  background-size:
    5px 5px,
    5px 5px,
    2.5em 2.5em;
  background-repeat: no-repeat;
  border-color: grey;
  outline: 0;
}
.right-sidebar-option {
      background: #f1f2f3;
}

.card-header section > div:not(.collapsed) {
    color: #000;
}
.right-sidebar-card {
  margin-bottom:0;
  border-radius:0;
}

.select2-container .select2-selection--single{
  height: 100% !important;
}

select.form-control.form-control-sm.fa.fa-angle-down {
    background: #E2A03F;
    color: #fff !important;
}

input.submit-btn.submit-btn.btn-block {
    background: #2F4ACA;
    border: none;
    height: 33px;
    color: #ffff;
    font-size: 15px;
    font-weight: 700;
}

.otype {
   font-weight:700;
}
.importantRule{
   color:#fff !important;
}
</style>
<div class=\"noprint\">
<!-- new invoice start -->


  ";
        // line 188
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
            ";
        // line 189
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/widget.html.twig"));
        echo "  
<div class=\"layout-px-spacing\">
    <div class=\"row layout-top-spacing\">
    <div class=\"col-md-12\">
      <div class=\"card\">
         <div class=\"p-2\">
                <h4 class=\"\"><span class=\"badge badge-primary\">#";
        // line 195
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "id", array()), "html", null, true);
        echo "</span> 
                 ";
        // line 196
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "dispatched")) {
            // line 197
            echo "                    <span class=\"badge\" style=\"background: #ff5722;text-transform: capitalize !important;color: #fff;\">Assigned To Delivey Boy</span>
                      ";
        } elseif (($this->getAttribute(        // line 198
($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "onway")) {
            // line 199
            echo "                    <span class=\"badge\" style=\"background: #ff5722;text-transform: capitalize !important;color: #fff;\">Out For Delivery</span>
                        ";
        } elseif (($this->getAttribute(        // line 200
($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "ready")) {
            echo " 
                    <span class=\"badge\" style=\"background: #4caf50;text-transform: capitalize !important;color: #fff;\">Order Ready</span>
                   ";
        } elseif (($this->getAttribute(        // line 202
($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "received")) {
            echo " 
                    <span class=\"badge\" style=\"background: #3f51b5;text-transform: capitalize !important;color: #fff;\">Received</span>
                     ";
        } elseif (($this->getAttribute(        // line 204
($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "processing")) {
            echo " 
                    <span class=\"badge\" style=\"background: #009688;text-transform: capitalize !important;color: #fff;\">Processing</span>
                     ";
        } elseif (($this->getAttribute(        // line 206
($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "processing")) {
            echo " 
                    <span class=\"badge\" style=\"background: #009688;text-transform: capitalize !important;color: #fff;\">Processing</span>
                     ";
        } elseif (($this->getAttribute(        // line 208
($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "delivered")) {
            echo " 
                    <span class=\"badge\" style=\"background: #4caf50;text-transform: capitalize !important;color: #fff;\">delivered</span>
                     ";
        } elseif (($this->getAttribute(        // line 210
($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "delivered")) {
            echo " 
                    <span class=\"badge\" style=\"background: #4caf50;text-transform: capitalize !important;color: #fff;\">delivered</span>
                   ";
        } else {
            // line 213
            echo "                 <span class=\"badge\" style=\"background: #4caf50;text-transform: capitalize !important;color: #fff;\">";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()), "html", null, true);
            echo " </span>
               ";
        }
        // line 215
        echo "               ";
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderType", array()) == "Delivery")) {
            echo "<span class=\"badge badge-success\">Home Delivery </span>";
        } elseif (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderType", array()) == "pickup")) {
            echo " <span class=\"badge badge-warning\">Pickup From Store</span> ";
        } else {
            echo " <span class=\"badge badge-danger\">Express Delivery</span> ";
        }
        // line 216
        echo "               ";
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "membership", array()) == "0")) {
            echo "<span class=\"badge badge-default\">Normal Order</span>";
        } else {
            echo "<span class=\"badge badge-danger\">Membership Applied</span>
               ";
        }
        // line 218
        echo "               
               <span class=\"badge badge-danger\" style=\"text-transform:capitalize;\">";
        // line 219
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentStatus", array()), "html", null, true);
        echo "</span>
                <span style=\"float:right;\">
                 <a href=\"#kot\" onclick=\"frames['prints'].print()\" value=\"printletter\" style=\"width:100%\"  data-placement=\"bottom\" title=\"KOT Print\">
                  <img src=\"/assets/images/KOT.png\" style=\"width:24px;\"></a>
                  <a href=\"#download\" onclick=\"window.print()\" style=\"width:100%;margin-top:5px;\"   data-placement=\"bottom\" title=\"A4 Print\">
                      <img src=\"/assets/images/A4.png\" style=\"width:24px;\"></a>
                      </a>
                     <a href=\"#thermal\"  onclick=\"frames['frame'].print()\" value=\"printletter\"  style=\"width:100%;margin-top:5px;\"   data-placement=\"bottom\" title=\"Thermal Print\">
                      <img src=\"/assets/images/thermal.png\" style=\"width:24px;\"></a>
                    </span>
                     </h4>
         </div>
      </div>
    </div>
      <!--col-md-9-->
      <div class=\"col-md-9\">
        <div class=\"row\">
          <div class=\"col-md-6 mb-4\">
            <div class=\"card h-100\">
              <div class=\"row form-row\">
                <div class=\"col-md-12 form-group\">
                 <div class=\"card-header\">
                         <!--a href=\"#\" style=\"background: #3F51B5;color:#fff;font-size: 12px;padding: 6px;\">";
        // line 241
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderType", array())), "html", null, true);
        echo "</a-->
          </h4>
        </div>
                  <div id=\"user\">
                     <div class=\"col-md-12 form-group\">
                  <div class=\"card-body\">
                    <!--address-->
                    <h5 class=\"mb-4\">Customer Details</h5>
                    <div class=\"\">
                        <p> ";
        // line 250
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customerName", array()), "html", null, true);
        echo "</p>
                        <p>";
        // line 251
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customer", array()), "email", array()), "html", null, true);
        echo "</p>
                     </div>
                     <hr>
                     <div class=\"\">
                          <p> ";
        // line 255
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "address", array()), "html", null, true);
        echo "</p>
                          <p> ";
        // line 256
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "landmark", array()), "html", null, true);
        echo "</p>
                          <p> Gst No : ";
        // line 257
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customer", array()), "gst", array()), "html", null, true);
        echo "</p>
                          <p> Mobile : ";
        // line 258
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customer", array()), "mobileNumber", array()), "html", null, true);
        echo "</p>
                        
                     </div>
                  </div>

                  <!--end-->
                </div>
                  
                     </div>
                  </div>
                 

               
              </div>
            </div>
          </div>

          <div class=\"col-md-6 mb-4\">
            <div class=\"card h-100\">
                <div class=\"form-group col-md-12\">
 <div class=\"card-body\">
                    <!--address-->
                    <h5 class=\"mb-4\">Payment Details</h5>
                    <div class=\"row form-row\">
                        <div class=\"col-md-12 form-group\">
                           <input  type=\"text\" name=\"txt\" class=\"form-control form-control-sm\" required=\"\" value=\"";
        // line 283
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentType", array()), "html", null, true);
        echo "\" readonly>
                        </div>
                          <div class=\"col-md-12 form-group\">
                           <input  type=\"text\" name=\"txt\" class=\"form-control form-control-sm\" required=\"\" value=\"";
        // line 286
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderType", array()) == "Delivery")) {
            echo " Home Delivery ";
        } elseif (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderType", array()) == "pickup")) {
            echo " Pickup From Store ";
        } else {
            echo " Express Delivery ";
        }
        echo " \" readonly>
                        </div>
                         <div class=\"col-md-12 form-group\">
                           <input  type=\"text\" name=\"txt\" class=\"form-control form-control-sm\" required=\"\" value=\"";
        // line 289
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderDate", array()), "date", array()), "d-m-Y"), "html", null, true);
        echo " at ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderDate", array()), "date", array()), "h-i A"), "html", null, true);
        echo "\" readonly>
                        </div>
                        <div class=\"col-md-12 form-group\">
                           <input  type=\"text\" name=\"txt\" class=\"form-control form-control-sm\" required=\"\" value=\"";
        // line 292
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "fixDate", array()), "html", null, true);
        echo " around ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "fixtime", array()), "html", null, true);
        echo "\" readonly>
                        </div>
                    </div>
                    
             
            </div>
          </div>
          </div>
        </div>
        <div class=\"col-md-12 mb-4\">        
          <div class=\"card\">
           <div class=\"card-body\">
             <h5 class=\"mb-4\">Order Items</h5>

                   <!--div class=\"col-md-12 text-right\">
                      <a href=\"#\" class=\"btn btn-primary btn-sm mb-4\"  data-toggle=\"modal\" data-target=\"#uploadCSV\">Add Items</a> 
                    </div-->
              
                    <div class=\"col-md-12\">
                      <div class=\"table-responsive m-t-10 row table-show\" style=\"display:block;\">
                       <table class=\"table table-hovered\">
                              <thead class=\"bg-primary text-white\" style=\"color:#fff;\">
                                 <tr>
                                    <th style=\"color:#fff;\">Item name</th>
                                    <th style=\"color:#fff;\">price variation</th>
                                    <th style=\"color:#fff;\">Barcode</th>
                                    <th style=\"color:#fff;\">price</th>
                                    <th style=\"color:#fff;\">quantity</th>
                                  <th style=\"color:#fff;\">Discount</th>

                                    ";
        // line 322
        if ((($context["currency"] ?? $this->getContext($context, "currency")) == "AED")) {
            // line 323
            echo "                                   <th style=\"color:#fff;\">VAT</th>
                                    ";
        } else {
            // line 325
            echo "                                    <th style=\"color:#fff;\">Tax</th>
                                    ";
        }
        // line 326
        echo "     

                               <th style=\"color:#fff;\">Sub total</th>
                                 </tr>
                              </thead>
                              <tbody>
                                ";
        // line 332
        $context["tax"] = 0;
        echo " 
                                 ";
        // line 333
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customerOrderItems", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 334
            echo "                                 <tr style=\"font-size:10px;\">
                                    <td>";
            // line 335
            if ((($this->getAttribute($context["item"], "isTray", array()) == "0") || ($this->getAttribute($context["item"], "isTray", array()) == ""))) {
                echo " <span style=\"color:#2196f3;font-weight:400;\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
                echo "</span> ";
            }
            // line 336
            echo "                                   
    ";
            // line 337
            if (($this->getAttribute($context["item"], "isTray", array()) == "3")) {
                echo " <span style=\"color:#e91e63;font-weight:400;\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
                echo "</span> ";
            }
            // line 338
            echo "                                       ";
            if (($this->getAttribute($context["item"], "isTray", array()) == "1")) {
                echo " <span style=\"color:#F44337;font-weight:400;\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
                echo "</span> ";
            }
            // line 339
            echo "                                       ";
            if (($this->getAttribute($context["item"], "isTray", array()) == "2")) {
                echo " <span style=\"color:#014c0a;font-weight:400;\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
                echo "</span> ";
            }
            echo "<br>
                                         ";
            // line 340
            if (($this->getAttribute($context["item"], "edited", array()) == 1)) {
                echo " Edited | Reason : ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "reason", array()), "html", null, true);
            }
            // line 341
            echo "                                    </td>
                                    <td>";
            // line 342
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "priceVariavtion", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 343
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "barcode", array()), "html", null, true);
            echo "</td>
                                    <td>

                                      ";
            // line 346
            if (($this->getAttribute($context["item"], "discount", array()) != 0)) {
                // line 347
                $context["discount"] = $this->getAttribute($context["item"], "discount", array());
                // line 348
                $context["quantity"] = $this->getAttribute($context["item"], "quantity", array());
                // line 349
                $context["priceO"] = (($context["discount"] ?? $this->getContext($context, "discount")) / ($context["quantity"] ?? $this->getContext($context, "quantity")));
                // line 350
                $context["price"] = ($this->getAttribute($context["item"], "price", array()) + ($context["priceO"] ?? $this->getContext($context, "priceO")));
                // line 351
                echo "                                      ";
            } else {
                // line 352
                echo "                                      ";
                $context["price"] = $this->getAttribute($context["item"], "price", array());
                // line 353
                echo "                                      ";
            }
            // line 354
            echo "                                      ";
            $context["x"] = (100 + $this->getAttribute($context["item"], "tax", array()));
            // line 355
            echo "
                                     ";
            // line 356
            $context["pr"] = ((($context["price"] ?? $this->getContext($context, "price")) * 100) / ($context["x"] ?? $this->getContext($context, "x")));
            echo " 
                                     ";
            // line 358
            echo "
                                     ";
            // line 359
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                // line 360
                echo "                                       ";
                echo twig_escape_filter($this->env, twig_round(($context["pr"] ?? $this->getContext($context, "pr")), 2, "floor"), "html", null, true);
                echo "
                                     ";
            } elseif ((            // line 361
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                // line 362
                echo "                                       ";
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["pr"] ?? $this->getContext($context, "pr")), 2, ".", ""), "html", null, true);
                echo "
                                     ";
            }
            // line 364
            echo "
                                   </td>
                                    <td>";
            // line 366
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", array()), "html", null, true);
            echo "  ";
            if (($this->getAttribute($context["item"], "isTray", array()) == "1")) {
                echo " <span style=\"color:#F44337;font-weight:400;\">(";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "trayQty", array()), "html", null, true);
                echo ")</span> ";
            }
            echo " ";
            if (($this->getAttribute($context["item"], "trayQty", array()) > $this->getAttribute($context["item"], "quantity", array()))) {
                echo " <span style=\"color:green;font-weight:400;\">(";
                echo twig_escape_filter($this->env, ($this->getAttribute($context["item"], "trayQty", array()) - $this->getAttribute($context["item"], "quantity", array())), "html", null, true);
                echo ")</span> ";
            }
            echo "</td>
                                    ";
            // line 367
            $context["st"] = ((($this->getAttribute($context["item"], "price", array()) * $this->getAttribute($context["item"], "tax", array())) / 100) * $this->getAttribute($context["item"], "quantity", array()));
            // line 368
            echo "                                      <td class=\"\"> 
";
            // line 369
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "discount", array()), "html", null, true);
            echo "</td>
   
                                       <td class=\"text-right\">
";
            // line 372
            if ((($context["currency"] ?? $this->getContext($context, "currency")) == "AED")) {
                // line 373
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    // line 374
                    echo " ";
                    $context["f"] = (($context["price"] ?? $this->getContext($context, "price")) - twig_round(($context["pr"] ?? $this->getContext($context, "pr")), 2, "floor"));
                    echo " ";
                    $context["ft"] = (($context["f"] ?? $this->getContext($context, "f")) * $this->getAttribute($context["item"], "quantity", array()));
                    echo " 

";
                } elseif ((                // line 376
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    // line 377
                    $context["f"] = (($context["price"] ?? $this->getContext($context, "price")) - twig_number_format_filter($this->env, ($context["pr"] ?? $this->getContext($context, "pr")), 2, ".", ""));
                    echo " 
";
                }
                // line 379
                $context["ft"] = (($context["f"] ?? $this->getContext($context, "f")) * $this->getAttribute($context["item"], "quantity", array()));
                echo " 

 ";
                // line 382
                echo "      ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    // line 383
                    echo "         ";
                    echo twig_escape_filter($this->env, twig_round(($context["ft"] ?? $this->getContext($context, "ft")), 2, "floor"), "html", null, true);
                    echo "
      ";
                } elseif ((                // line 384
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    // line 385
                    echo "         ";
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["ft"] ?? $this->getContext($context, "ft")), 2, ".", ""), "html", null, true);
                    echo "
      ";
                }
                // line 387
                echo " ";
            } else {
                // line 388
                echo "<div class=\"tax\" style=\"display:flex;\">
  <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 7px;\">CGST <br> ";
                // line 389
                echo twig_escape_filter($this->env, ($this->getAttribute($context["item"], "tax", array()) / 2), "html", null, true);
                echo "%  ";
                $context["f"] = (($context["price"] ?? $this->getContext($context, "price")) - ($context["pr"] ?? $this->getContext($context, "pr")));
                echo " <br> (";
                $context["ft"] = (($context["f"] ?? $this->getContext($context, "f")) * $this->getAttribute($context["item"], "quantity", array()));
                echo " 
  ";
                // line 390
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, (twig_round(($context["ft"] ?? $this->getContext($context, "ft")), 2, "floor") / 2), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, (twig_number_format_filter($this->env, ($context["ft"] ?? $this->getContext($context, "ft")), 2, ".", "") / 2), "html", null, true);
                }
                echo ")

  </div>
    <div style=\"padding: 3px;font-size: 7px;\">SGST <br>";
                // line 393
                echo twig_escape_filter($this->env, ($this->getAttribute($context["item"], "tax", array()) / 2), "html", null, true);
                echo "% <br> (";
                $context["ft"] = (($context["f"] ?? $this->getContext($context, "f")) * $this->getAttribute($context["item"], "quantity", array()));
                echo " ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, (twig_round(($context["ft"] ?? $this->getContext($context, "ft")), 2, "floor") / 2), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, (twig_number_format_filter($this->env, ($context["ft"] ?? $this->getContext($context, "ft")), 2, ".", "") / 2), "html", null, true);
                }
                echo ")</div>
</div>

 ";
            }
            // line 397
            echo "
                                       </td>

                                                                      <td class=\"text-right\"> 
                                      ";
            // line 401
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                // line 402
                echo "                                      ";
                $context["subTotals"] = (twig_round(($context["pr"] ?? $this->getContext($context, "pr")), 2, "floor") * $this->getAttribute($context["item"], "quantity", array()));
                echo " 
                                       ";
            } elseif ((            // line 403
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                // line 404
                echo "                                      ";
                $context["subTotals"] = (twig_number_format_filter($this->env, ($context["pr"] ?? $this->getContext($context, "pr")), 2, ".", "") * $this->getAttribute($context["item"], "quantity", array()));
                echo " 
                                    ";
            }
            // line 406
            echo "                                    ";
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                // line 407
                echo "                                       ";
                echo twig_escape_filter($this->env, (($context["subTotals"] ?? $this->getContext($context, "subTotals")) - twig_round($this->getAttribute($context["item"], "discount", array()), 2, "floor")), "html", null, true);
                echo "
                                    ";
            } elseif ((            // line 408
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                // line 409
                echo "                                       ";
                echo twig_escape_filter($this->env, (($context["subTotals"] ?? $this->getContext($context, "subTotals")) - twig_number_format_filter($this->env, $this->getAttribute($context["item"], "discount", array()), 2, ".", "")), "html", null, true);
                echo "
                                    ";
            }
            // line 411
            echo "                                    </td>
                                    ";
            // line 412
            $context["tax"] = (($context["tax"] ?? $this->getContext($context, "tax")) + ($context["ft"] ?? $this->getContext($context, "ft")));
            // line 413
            echo "                                 </tr>
                                 ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 415
        echo "                                
                              </tbody>
                                  <tfoot>
                                    <tr>
                                <th class=\"text-left\">Online/Cash : ";
        // line 419
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            echo twig_escape_filter($this->env, twig_round($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderAmount", array()), 2, "floor"), "html", null, true);
        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderAmount", array()), 2, ".", ""), "html", null, true);
        }
        echo "</span></th>
                              <th colspan=\"6\" class=\"text-right\">Total</th>
                              <th> <span class=\"sums\">
                                 ";
        // line 423
        echo "                                    ";
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            // line 424
            echo "                                       ";
            echo twig_escape_filter($this->env, (twig_round($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "actualAmount", array()), 2, "floor") - twig_round(($context["tax"] ?? $this->getContext($context, "tax")), 2, "floor")), "html", null, true);
            echo "
                                    ";
        } elseif ((        // line 425
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            // line 426
            echo "                                       ";
            echo twig_escape_filter($this->env, (twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "actualAmount", array()), 2, ".", "") - twig_number_format_filter($this->env, ($context["tax"] ?? $this->getContext($context, "tax")), 2, ".", "")), "html", null, true);
            echo "
                                    ";
        }
        // line 428
        echo "                                    </span></th>
                            </tr>

                            <tr>
                               <th class=\"text-left\">Loyalty :  ";
        // line 432
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            echo twig_escape_filter($this->env, twig_round($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "loyalty", array()), 2, "floor"), "html", null, true);
        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "loyalty", array()), 2, ".", ""), "html", null, true);
        }
        echo "</span></th>
                              <th colspan=\"6\" class=\"text-right\">";
        // line 433
        if ((($context["currency"] ?? $this->getContext($context, "currency")) == "AED")) {
            // line 434
            echo "                              Vat
                              ";
        } else {
            // line 436
            echo "                              Tax
                             ";
        }
        // line 437
        echo "  </th>
                              <th>";
        // line 438
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            echo twig_escape_filter($this->env, twig_round(($context["tax"] ?? $this->getContext($context, "tax")), 2, "floor"), "html", null, true);
        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["tax"] ?? $this->getContext($context, "tax")), 2, ".", ""), "html", null, true);
        }
        echo "</th>
                            </tr>
                            <tr>
                               <th class=\"text-left\">Wallet : ";
        // line 441
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            echo twig_escape_filter($this->env, twig_round($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "wallet", array()), 2, "floor"), "html", null, true);
        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "wallet", array()), 2, ".", ""), "html", null, true);
        }
        echo "</span></th>
                              <th colspan=\"6\" class=\"text-right\">Discount</th>
                              <th>";
        // line 443
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "totalDiscount", array()), "html", null, true);
        echo "</th>
                            </tr>
                            <tr>
                               <th class=\"text-left\">Total : ";
        // line 446
        $context["totals"] = (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "wallet", array()) + $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "loyalty", array())) + $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderAmount", array()));
        echo " ";
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            echo twig_escape_filter($this->env, twig_round(($context["totals"] ?? $this->getContext($context, "totals")), 2, "floor"), "html", null, true);
        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["totals"] ?? $this->getContext($context, "totals")), 2, ".", ""), "html", null, true);
        }
        echo "</span></th>
                              <th colspan=\"6\" class=\"text-right\">Delivery Charge</th>
                              <th> <span class=\"delivery\">";
        // line 448
        echo twig_escape_filter($this->env, twig_round($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "deliveryCharge", array()), 2, "floor"), "html", null, true);
        echo "</span></th>
                            </tr>
                           
                            <tr>
                              <th colspan=\"7\" class=\"text-right\">Grand Total</th>
                              <th> <span class=\"sums\"> ";
        // line 453
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentType", array()) == "wallet")) {
            echo " ";
            $context["total"] = (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "actualAmount", array()) + $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "deliveryCharge", array())) - $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "totalDiscount", array()));
            echo " ";
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round(($context["total"] ?? $this->getContext($context, "total"))), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["total"] ?? $this->getContext($context, "total")), 2, ".", ""), "html", null, true);
            }
            echo " ";
        } else {
            $context["total"] = $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderAmount", array());
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round(($context["total"] ?? $this->getContext($context, "total"))), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["total"] ?? $this->getContext($context, "total")), 2, ".", ""), "html", null, true);
            }
        }
        echo "</span></th>
                            </tr>
                          </tfoot>
                           </table>
  ";
        // line 457
        if ((((($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "received") || ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "processing")) || ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "ready")) || ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "pick"))) {
            echo " 
                           <a href=\"#\" class=\"noprint edit-order\" data-toggle=\"modal\" data-target=\"#edit-order\">edit order</a>
";
        }
        // line 460
        echo "
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class=\"col-md-3 mb-4\">
           <div class=\"h-100\">
            <div id=\"toggleAccordion\">
              
              <div class=\"card right-sidebar-card\">
                <div class=\"card-header\" id=\"headingOne1\">
                  <section class=\"mb-0 mt-0\">

                    <div role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#defaultAccordionOne\" aria-expanded=\"true\" aria-controls=\"defaultAccordionOne\">
                      Order Info <div class=\"icons\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-down\"><polyline points=\"6 9 12 15 18 9\"></polyline></svg></div>
                    </div>
                  </section>
                </div>
                <div id=\"defaultAccordionOne\" class=\"collapse show\" aria-labelledby=\"headingOne1\" data-parent=\"#toggleAccordion\">
                  <div class=\"card-body right-sidebar-option\">
                    <div class=\"\">
                      <p style=\"\"><b>Ordered on</b></p>
                      <p>";
        // line 485
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderDate", array()), "date", array()), "d-m-Y"), "html", null, true);
        echo " at ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderDate", array()), "date", array()), "h-i A"), "html", null, true);
        echo "</p>
                    </div>
                    <div>
                     <p style=\"\"><b>Device</b></p>
                     <p>";
        // line 489
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "channel", array()), "html", null, true);
        echo "</p>
                   </div>
                    ";
        // line 491
        if ((($context["dname"] ?? $this->getContext($context, "dname")) == "")) {
            // line 492
            echo "                    ";
        } else {
            // line 493
            echo "                   <div>
                     <p style=\"\"><b>Delivery Boy</b></p>
                     <p>";
            // line 495
            echo twig_escape_filter($this->env, ($context["dname"] ?? $this->getContext($context, "dname")), "html", null, true);
            echo "-(";
            echo twig_escape_filter($this->env, ($context["dmobile"] ?? $this->getContext($context, "dmobile")), "html", null, true);
            echo ")</p>
                   </div>
                   ";
        }
        // line 498
        echo "                   ";
        if ((($context["pname"] ?? $this->getContext($context, "pname")) == "")) {
            // line 499
            echo "                           ";
        } else {
            // line 500
            echo "                      <div>
                     <p style=\"\"><b>Picker Name</b></p>
                     <p>";
            // line 502
            echo twig_escape_filter($this->env, ($context["pname"] ?? $this->getContext($context, "pname")), "html", null, true);
            echo "-(";
            echo twig_escape_filter($this->env, ($context["pmobile"] ?? $this->getContext($context, "pmobile")), "html", null, true);
            echo ")</p>
                   </div>
                                              ";
        }
        // line 504
        echo "          
                   ";
        // line 505
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "note", array()) == "")) {
            // line 506
            echo "                   ";
        } else {
            echo "                    <div>
                     <p style=\"\"><b>Note</b></p>
                     <p>";
            // line 508
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "note", array()), "html", null, true);
            echo "</p>
                   </div>
                   ";
        }
        // line 511
        echo "                   <div>
                     <p style=\"\"><b>Tray Number</b></p>
                     <p>";
        // line 513
        if (((($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "tray", array()) == "") || ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "tray", array()) == "0")) || (null === $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "tray", array())))) {
            echo " <i style=\"color:red;\">not created </i>";
        } else {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "tray", array()), "html", null, true);
        }
        echo "  

                      (<a href=\"#ssss\"  data-toggle=\"modal\" data-target=\"#myModal\">edit</a>)</p>
                   </div>

                      <div>
                     <p style=\"\"><b>Tray Status</b></p>
                     <p> ";
        // line 520
        if (((($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "tray", array()) == "") || ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "tray", array()) == "0")) || (null === $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "tray", array())))) {
            echo " <i style=\"color:red;\">Tray number not assigned</i>";
        } else {
            echo " in Tray ";
        }
        echo "   (<a href=\"#ssss\"  data-toggle=\"modal\" data-target=\"#trayStatus\">edit</a>)</p>
                   </div>
                    ";
        // line 522
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "deliveryTime", array()) == "")) {
            // line 523
            echo "                   ";
        } else {
            echo "                    <div>
                     <p style=\"\"><b>Delivery Time</b></p>
                     <p>";
            // line 525
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "deliveryTime", array()), "date", array()), "d-m-Y"), "html", null, true);
            echo " at ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "deliveryTime", array()), "date", array()), "h-i A"), "html", null, true);
            echo "</p>
                   </div>
                   ";
        }
        // line 528
        echo "                   ";
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "slotReason", array()) == "")) {
            // line 529
            echo "                   ";
        } else {
            // line 530
            echo "                   <div>
                     <p style=\"\"><b>Reason For Reschedule</b></p>
                     <p>";
            // line 532
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "slotReason", array()), "html", null, true);
            echo "</p>
                   </div>
                   ";
        }
        // line 535
        echo "
                    ";
        // line 536
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "promocode", array()) == "")) {
            // line 537
            echo "                   ";
        } else {
            echo "                    <div>
                     <p style=\"\"><b>Promocode</b></p>
                     <p>";
            // line 539
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "promocode", array()), "html", null, true);
            echo "</p>
                   </div>
                   ";
        }
        // line 542
        echo "
                         <div>
                          ";
        // line 544
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentStatus", array()) == "paid")) {
            // line 545
            echo "                  <div class=\"form-group\">
                     <p style=\"cursor:pointer;\"><b>Payment Status</b></p>
                     <div class=\"form-group \" >
                     <span  class=\"badge badge-success\">Paid</span>
                      
                    </div>
                  </div>
                  ";
        }
        // line 553
        echo "                  ";
        if ((((($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentStatus", array()) == "pending") || ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentStatus", array()) == "")) || ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentStatus", array()) == "cancelled")) || ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentStatus", array()) == "failed"))) {
            // line 554
            echo "                  <div class=\"form-group\">
                     <p style=\"cursor:pointer;\"><b>Payment Status</b></p>
                     <div class=\"form-group \" >
                      <span id=\"payment_status\"  data-toggle=\"modal\" data-target=\"#edit-payment-status\" class=\"badge badge-danger\">Mark As Paid </span>
                      
                    </div>
                  </div>
                  ";
        }
        // line 562
        echo "

</div>
<p style=\"\"><b>Version</b></p>
<p>";
        // line 566
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "version", array()), "html", null, true);
        echo "</p>
";
        // line 567
        if ((($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "transactionId", array()) == "") || ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "transactionId", array()) == " "))) {
        } else {
            // line 569
            echo "<p style=\"\"><b>Transction Id</b></p>
<p>";
            // line 570
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "transactionId", array()), "html", null, true);
            echo "</p>
";
        }
        // line 572
        echo "
                              </div>
                            </div>


                          </div>
                          <div class=\"card right-sidebar-card\">
                            <div class=\"card-header\" id=\"headingTwo1\">
                              <section class=\"mb-0 mt-0\">
                                <div role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#defaultAccordionTwo\" aria-expanded=\"true\" aria-controls=\"defaultAccordionTwo\">
                                  Order Status<div class=\"icons\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-down\"><polyline points=\"6 9 12 15 18 9\"></polyline></svg></div>
                                </div>
                              </section>
                            </div>
                            <div id=\"defaultAccordionTwo\" class=\"collapse show\" aria-labelledby=\"headingTwo1\" data-parent=\"#toggleAccordion\">
                              <div class=\"card-body right-sidebar-option\">
                                  ";
        // line 588
        if ((($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) != "completed") && ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) != "cancelled"))) {
            echo " 
               <div class=\"form-group\">
                     ";
            // line 590
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "orderStatus", array()), 'row', array("attr" => array("class" => "form-control otype")));
            echo "
                  </div>
                  <div id=\"dboy\">
                  </div>
<input type=\"hidden\" name=\"fixtime\" id=\"fixtime\">
<input type=\"hidden\" name=\"fixdate\" id=\"fixdate\">

";
            // line 597
            if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderStatus", array()) == "reschedule")) {
                // line 598
                echo "<div class=\"slot-time\">
  ";
            } else {
                // line 600
                echo "<div class=\"slot-time\" style=\"display:none;\">
  ";
            }
            // line 602
            echo "                   <div class=\"row form-row\">
                    <div class=\"col-md-12 form-group\">
                     <select class=\"form-control form-control-sm classic info\" name=\"area\" id=\"locationName\">
                      <option value=\"\">Select Area</option>
                      ";
            // line 606
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["location"] ?? $this->getContext($context, "location")));
            foreach ($context['_seq'] as $context["_key"] => $context["loc"]) {
                // line 607
                echo "                      <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "id", array()), "html", null, true);
                echo "\" data-name=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "title", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["loc"], "title", array()), "html", null, true);
                echo "</option>
                      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['loc'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 609
            echo "                    </select>
                  </div>
                </div>
                  <div class=\"row form-row\">
                  <div class=\"col-md-12 form-group\">
                    <select class=\"form-control form-control-sm classic info\" name=\"slot\" id=\"locationSlot\">
                      <option value=\"\">Slots</option>
                      
                    </select>
                  </div>
                </div>
</div>
                   <div class=\"form-group\">
                     <button type=\"submit\" class=\"btn btn-primary pr\" style=\"width:100% !important;margin-bottom:5px;\">Update order</button>
                            
                          </div>
           
                      </div>
                    </div>
                  </div>

                      
                           ";
        } else {
            // line 631
            echo " 
                      
               ";
        }
        // line 634
        echo "                </div>
                
              </div>




<!-- new invoice end -->





















   <div class=\"col-12\">
     
              
            </div>
            ";
        // line 667
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'widget');
        echo "
            ";
        // line 668
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end', array("render_rest" => false));
        echo "
         </div>

 </div>
 </div>
</div>
</div>
<iframe src=\"";
        // line 675
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("thermal_print", array("id" => $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "id", array()))), "html", null, true);
        echo "\" style=\"display:none;\" name=\"frame\"></iframe>
<iframe src=\"";
        // line 676
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("normal_print", array("id" => $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "id", array()))), "html", null, true);
        echo "\" style=\"display:none;\" name=\"prints\"></iframe>
</div>
<!-- starty of  card -->
<div class=\"print-area\" style=\"display:none\">
  <div class=\"container\">
<div class=\"row\">
  <div class=\"col-12\">
<center><span>O  R  I  G  I  N  A  L     T  A  X     I  N  V  O  I  C  E</span></center>
</div>
</div>
<div class=\"row\">
  <div class=\"col-6\">
      <p>Bill to/Ship to:<br>
                           <small>
                           ";
        // line 690
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customerName", array()), "html", null, true);
        echo "<br>
                           ";
        // line 691
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "address", array()), "html", null, true);
        echo "<br>
                           ";
        // line 692
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "landmark", array()), "html", null, true);
        echo "
                           Mobile : ";
        // line 693
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customer", array()), "mobileNumber", array()), "html", null, true);
        echo "<br>
                           Email : ";
        // line 694
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customer", array()), "email", array()), "html", null, true);
        echo "<br>
                           Gst No: ";
        // line 695
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customer", array()), "gst", array()), "html", null, true);
        echo "

                           </small>
                        </p>
                         <table class=\"table xx table-bordered\">
                                 <tr>
                                  <td>Order Id</td>
                                   <td>";
        // line 702
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "id", array()), "html", null, true);
        echo "</td> 
                                 </tr>
                                 <tr>
                                  <td>Order Date</td>
                                   <td>";
        // line 706
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderDate", array()), "date", array()), "d-m-Y"), "html", null, true);
        echo " at ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderDate", array()), "date", array()), "h-i A"), "html", null, true);
        echo "</td> 
                                 </tr>
                                  <tr>
                                  <td>Slot</td>
                                   <td>";
        // line 710
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "fixtime", array()), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "fixDate", array()), "html", null, true);
        echo "</td> 
                                 </tr>
                                 
                                  <tr>
                                  <td>Order Type</td>
                                   <td>";
        // line 715
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentType", array())), "html", null, true);
        echo "</td> 
                                 </tr>
                                 <tr>
                                  <td>Delivery Area</td>
                                   <td>";
        // line 719
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "area", array())), "html", null, true);
        echo "</td> 
                                 </tr>
                            </table>
</div>
  <div class=\"col-6\">
    ";
        // line 724
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["restaurant"] ?? $this->getContext($context, "restaurant")));
        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
            // line 725
            echo "          <p style=\"float:right\"><img src=\"/uploads/restaurant/icons/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "iconImage", array()), "html", null, true);
            echo "\" style=\"height:50px;\"><br>
                           <small>
                           ";
            // line 727
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantName", array()), "html", null, true);
            echo "<br>
                           ";
            // line 728
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantAddress", array()), "html", null, true);
            echo "<br>
                           ";
            // line 729
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantLocation", array()), "html", null, true);
            echo "<br>
                            Gst No:";
            // line 730
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "gst", array()), "html", null, true);
            echo "<br>

                           Mobile : ";
            // line 732
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "primaryMobile", array()), "html", null, true);
            echo "<br>
                           Email : ";
            // line 733
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "primaryEmail", array()), "html", null, true);
            echo " 
                           </small>

                        </p>
                                   
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 739
        echo "                    
</div>
</div>

<div class=\"table-responsive\">
                           <table class=\"table x table-bordered\">
                              <thead class=\"ban\">
                                 <tr>
                                  <td>#</th>
                                    <td>Item name</td>
                                  ";
        // line 749
        if ((($context["currency"] ?? $this->getContext($context, "currency")) == "AED")) {
            // line 750
            echo "                                  ";
        } else {
            // line 751
            echo "                                      <td>Hsn</td>
                                      ";
        }
        // line 753
        echo "
                                    <td>Price</td>
                                     <td>Quantity</td>
                                         <td>Discount</td>
                                  ";
        // line 757
        if ((($context["currency"] ?? $this->getContext($context, "currency")) == "AED")) {
            // line 758
            echo "                                   <th style=\"color:#fff;\">VAT</th>
                                    ";
        } else {
            // line 760
            echo "                                    <th style=\"color:#fff;\">Tax</th>
                                    ";
        }
        // line 761
        echo "                                     <td> Total Value</td>
                                 </tr>
                              </thead>
                              <tbody>
                                ";
        // line 765
        $context["count"] = 1;
        // line 766
        echo "                                 ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customerOrderItems", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 767
            echo "                                 <tr>
                                  <td>";
            // line 768
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "</td>
                                           

                                    <td>";
            // line 771
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "priceVariavtion", array()), "html", null, true);
            echo "
                                   
                                    </td>
                                    ";
            // line 774
            if ((($context["currency"] ?? $this->getContext($context, "currency")) == "AED")) {
                // line 775
                echo "                                    ";
            } else {
                // line 776
                echo "                                  <td>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "hsn", array()), "html", null, true);
                echo "</td>
                                  ";
            }
            // line 778
            echo "                                    <td>";
            $context["x"] = (100 + $this->getAttribute($context["item"], "tax", array()));
            // line 779
            echo "                                     ";
            $context["pr"] = (($this->getAttribute($context["item"], "price", array()) * 100) / ($context["x"] ?? $this->getContext($context, "x")));
            echo " 
                                       ";
            // line 780
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                // line 781
                echo "                                          ";
                echo twig_escape_filter($this->env, twig_round(($context["pr"] ?? $this->getContext($context, "pr")), 2, "floor"), "html", null, true);
                echo "
                                       ";
            } elseif ((            // line 782
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                // line 783
                echo "                                          ";
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["pr"] ?? $this->getContext($context, "pr")), 2, ".", ""), "html", null, true);
                echo "
                                       ";
            }
            // line 785
            echo "                                    </td>
                                    <td>";
            // line 786
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", array()), "html", null, true);
            echo "</td>
                                     <td>";
            // line 787
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "discount", array()), "html", null, true);
            echo "</td>
                                    <td>

                                      ";
            // line 790
            if ((($context["currency"] ?? $this->getContext($context, "currency")) == "AED")) {
                // line 791
                echo " ";
                $context["f"] = ($this->getAttribute($context["item"], "price", array()) - ($context["pr"] ?? $this->getContext($context, "pr")));
                echo " ";
                $context["ft"] = (($context["f"] ?? $this->getContext($context, "f")) * $this->getAttribute($context["item"], "quantity", array()));
                echo " ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, twig_round(($context["ft"] ?? $this->getContext($context, "ft")), 2, "floor"), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["ft"] ?? $this->getContext($context, "ft")), 2, ".", ""), "html", null, true);
                }
                // line 792
                echo " ";
            } else {
                // line 793
                echo "<div class=\"tax\" style=\"display:flex;\">
  <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 7px;\">CGST <br> ";
                // line 794
                echo twig_escape_filter($this->env, ($this->getAttribute($context["item"], "tax", array()) / 2), "html", null, true);
                echo "%  ";
                $context["f"] = ($this->getAttribute($context["item"], "price", array()) - ($context["pr"] ?? $this->getContext($context, "pr")));
                echo " <br> (";
                $context["ft"] = (($context["f"] ?? $this->getContext($context, "f")) * $this->getAttribute($context["item"], "quantity", array()));
                echo " ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, (twig_round(($context["ft"] ?? $this->getContext($context, "ft")), 2, "floor") / 2), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, (twig_number_format_filter($this->env, ($context["ft"] ?? $this->getContext($context, "ft")), 2, ".", "") / 2), "html", null, true);
                }
                echo " )</div>
    <div style=\"padding: 3px;font-size: 7px;\">SGST <br>";
                // line 795
                echo twig_escape_filter($this->env, ($this->getAttribute($context["item"], "tax", array()) / 2), "html", null, true);
                echo "% <br> (";
                $context["ft"] = (($context["f"] ?? $this->getContext($context, "f")) * $this->getAttribute($context["item"], "quantity", array()));
                echo " ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, (twig_round(($context["ft"] ?? $this->getContext($context, "ft")), 2, "floor") / 2), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, (twig_number_format_filter($this->env, ($context["ft"] ?? $this->getContext($context, "ft")), 2, ".", "") / 2), "html", null, true);
                }
                echo ")</div>
</div>

 ";
            }
            // line 799
            echo "

</td>
                                    <td class=\"text-right\">";
            // line 802
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["item"], "subTotal", array()), 2, "floor"), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["item"], "subTotal", array()), 2, ".", ""), "html", null, true);
            }
            echo "</td>
                                 </tr>
                                                                 ";
            // line 804
            $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
            // line 805
            echo "
                                 ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 807
        echo "

                                   <tr>
                                  <th colspan=\"6\"></th>
                               

                                    <th>Total</th>
                                  <th>";
        // line 814
        $context["m"] = ($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "actualAmount", array()) - ($context["tax"] ?? $this->getContext($context, "tax")));
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            echo twig_escape_filter($this->env, twig_round(($context["m"] ?? $this->getContext($context, "m")), 2, "floor"), "html", null, true);
        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["m"] ?? $this->getContext($context, "m")), 2, ".", ""), "html", null, true);
        }
        echo "</th>
                                 </tr>
                                  <tr>
                                       <th colspan=\"6\"></th>                                         
                                    <th>  ";
        // line 818
        if ((($context["currency"] ?? $this->getContext($context, "currency")) == "AED")) {
            // line 819
            echo "                       Vat
                        ";
        } else {
            // line 821
            echo "                          Tax
                        ";
        }
        // line 822
        echo "    </th>
                                  <th>";
        // line 823
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            echo twig_escape_filter($this->env, twig_round(($context["tax"] ?? $this->getContext($context, "tax")), 2, "floor"), "html", null, true);
        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["tax"] ?? $this->getContext($context, "tax")), 2, ".", ""), "html", null, true);
        }
        echo "</th>
                                 </tr>
                                  <tr>
                                   <tr>
                                       <th colspan=\"6\"></th>                                         
                                    <th>Delivery Charge</th>
                                  <th>";
        // line 829
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            echo twig_escape_filter($this->env, twig_round($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "deliveryCharge", array()), 2, "floor"), "html", null, true);
        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "deliveryCharge", array()), 2, ".", ""), "html", null, true);
        }
        echo "</th>
                                 </tr>
                                  <tr>
                                   <th colspan=\"6\"></th>                               
                                    <th>Discount</th>
                                  <th>";
        // line 834
        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
            echo twig_escape_filter($this->env, twig_round($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "totalDiscount", array()), 2, "floor"), "html", null, true);
        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "totalDiscount", array()), 2, ".", ""), "html", null, true);
        }
        echo "</th>
                                 </tr>
                                 <tr>
                                    <th colspan=\"6\"></th>                              
                                    <th>Grand Total</th>
                                  <th>";
        // line 839
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentType", array()) == "wallet")) {
            echo " ";
            $context["total"] = (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "actualAmount", array()) + $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "deliveryCharge", array())) - $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "totalDiscount", array()));
            echo " ";
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round(($context["total"] ?? $this->getContext($context, "total")), 2, "floor"), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
            }
            echo twig_escape_filter($this->env, twig_round(($context["total"] ?? $this->getContext($context, "total")), 2, "floor"), "html", null, true);
            echo " ";
        } else {
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "orderAmount", array()), "html", null, true);
        }
        echo "</th>
                                 </tr>
                              </tbody>
                           </table>
</div>


</div>
</div>
<!-- end of card -->

<!-- Modal
for payment approval -->
<div id=\"edit-payment-status\" class=\"modal\" role=\"dialog\">
   <div class=\"modal-dialog\">
      <!-- Modal content-->
      <div class=\"modal-content\">
         <div class=\"modal-header\">
            <h4 class=\"modal-title\">Payment Status | ";
        // line 857
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentStatus", array())), "html", null, true);
        echo "</h4>
         </div>
         <div class=\"modal-body\">
            <div class=\"row\">
               <div class=\"col-12\">
                  <form method=\"post\" action=\"";
        // line 862
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_payment");
        echo "\">
                     <div class=\"form-group\" >
                  <label class=\"label\" style=\"color:#000;margin-left: -9px;\">Payment Mode</label>
                  <select class=\"form-control\" name=\"mode\" id=\"payment_statuss\">
                  <option value=\"Online\">Online Payment</option>
                       <option value=\"cash\">Cash</option>
                     </select>
                   </div>
                   <div class=\"ons\">
                 <div class=\"form-group\">
                  <label class=\"label\" style=\"color:#000;margin-left: -9px;\">Transaction Id</label>
                  <input type=\"tex\" name=\"transactionId\" class=\"form-control\" value=\" ";
        // line 873
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "transactionId", array()), "html", null, true);
        echo "\">
                 </div>
                  </div>
  <input type=\"hidden\" name=\"orderid\" class=\"form-control\" required=\"\" value=\"";
        // line 876
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "id", array()), "html", null, true);
        echo "\">
                 <div class=\"form-group\">
                  <label class=\"label\" style=\"color:#000;margin-left: -9px;\">Date / Payment Through / Note</label>
                  <textarea class=\"form-control\" rows=\"3\"  name=\"note\">
                     ";
        // line 880
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "note", array()), "html", null, true);
        echo "
                  </textarea>
               </div>
                     <button class=\"btn btn-success\" type=\"submit\">Mark as Paid</button>
                     <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
               </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<!-- end of modal -->

<!-- Modal 
incase of payment caancelling and all-->
<div id=\"payment_status_remain\" class=\"modal\" role=\"dialog\">
   <div class=\"modal-dialog\">
      <!-- Modal content-->
      <div class=\"modal-content\">
         <div class=\"modal-header\">
            <h4 class=\"modal-title\">Payment Status  | ";
        // line 902
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "paymentStatus", array())), "html", null, true);
        echo "</h4>
         </div>
         <div class=\"modal-body\">
            <div class=\"row\">
               <div class=\"col-12\">
                  <form method=\"post\" action=\"";
        // line 907
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_payment_pending");
        echo "\">
                   
                 
  <input type=\"hidden\" name=\"orderid\" class=\"form-control\" required=\"\" value=\"";
        // line 910
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "id", array()), "html", null, true);
        echo "\">
                 <div class=\"form-group\">
                  <label class=\"label\" style=\"color:#000;\">Reason for changing payment status</label>
                  <textarea class=\"form-control\" rows=\"3\"  name=\"note\">
                    ";
        // line 914
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "note", array()), "html", null, true);
        echo "
                  </textarea>
               </div>
                     <button class=\"btn btn-success\" type=\"submit\">Mark As Pending</button>
                     <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
               </div>
               </form>
            </div>
         </div>
      </div>
   </div> 
</div>
</div>
<!-- end of modal -->
<!-- Modal -->
<div id=\"edit-order\" class=\"modal \" role=\"dialog\">
   <div class=\"modal-dialog\">
      <!-- Modal content-->
      <div class=\"modal-content\">
         <div class=\"modal-header\">
            <h4 class=\"modal-title\">Edit Orders</h4>
         </div>
         <div class=\"modal-body\">
            <div class=\"row\">
               <div class=\"col-12\">
                  <form method=\"post\" action=\"";
        // line 939
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_order");
        echo "\">
                     <div class=\"table-responsive\">
                        <table class=\"table table-hovered\">
                           <thead class=\"bg-primary text-white\">
                              <tr>
                                 <th style=\"color:#fff;\">Item</th>
                                 <th style=\"color:#fff;\">Qty</th>
                              </tr>
                           </thead>
                           <input type=\"hidden\" value=\"";
        // line 948
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "id", array()), "html", null, true);
        echo "\" name=\"order\">
                           ";
        // line 949
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customerOrderItems", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 950
            echo "                           <tr>
                              <td><input type=\"hidden\" value=\"";
            // line 951
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "price", array()), "html", null, true);
            echo "\" name=\"price[]\">
<input type=\"hidden\" value=\"";
            // line 952
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", array()), "html", null, true);
            echo "\" name=\"oqty[]\">
<input type=\"hidden\" value=\"";
            // line 953
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "loyalty", array()), "html", null, true);
            echo "\" name=\"loyalty[]\">
<input type=\"hidden\" value=\"";
            // line 954
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "\" name=\"id[]\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "priceVariavtion", array()), "html", null, true);
            echo "</td>
                              <td>
                                <select class=\"form-control\" name=\"qty[]\">
";
            // line 957
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range($this->getAttribute($context["item"], "quantity", array()), 0));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 958
                echo "    <option>";
                echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                echo "</option>
";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 960
            echo "                                </select>
<textarea name=\"reason[]\" class=\"form-control\" style=\"display:block;width:100%\">";
            // line 961
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "reason", array()), "html", null, true);
            echo "</textarea>
                              </td>
                           </tr>
                           ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 964
        echo " 
                            ";
        // line 965
        if (($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "promocode", array()) != "")) {
            echo " 
                           <tr id=\"promo-a\">
                            <td>
                              <br>
                           <b>Promocode : ";
            // line 969
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "promocode", array()), "html", null, true);
            echo " <br>
                           Discount : ";
            // line 970
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "totalDiscount", array()), "html", null, true);
            echo "</b></td>
                            <td> <label for=\"promos\" id=\"trashs\"> <input type=\"checkbox\" name=\"promocheck\" id=\"promos\" class=\"form-control\" style=\"display:none;\"> <i class=\"fa fa-trash\" style=\"cursor:pointer;\" id=\"trash\"> </i> </label></td>                              
                            </tr> 
                             ";
        }
        // line 973
        echo " 
                        </table>
                       
                     
                      
                       
                     </div>
                     <button class=\"btn btn-success\" type=\"submit\">Save</button>
                     <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
               </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<!-- end of modal -->
<script type=\"text/javascript\">
\$('#trash').click(function(){
\$('#promo-a').hide();
// \$('#promos').prop('checked', true);

});
\$('#trashs').click(function(){
\$('#promo-a').hide();

});
</script>
<!-- Modal -->
<div id=\"myModal\" class=\"modal \" role=\"dialog\">
   <div class=\"modal-dialog\">
      <!-- Modal content-->
      <div class=\"modal-content\">
         <div class=\"modal-header\">
            <h4 class=\"modal-title\">Confirm Tray Items</h4>
         </div>
         <div class=\"modal-body\">
            <div class=\"row m-t-20\">
               <form method=\"post\" action=\"";
        // line 1012
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create_tray_number");
        echo "\">


                  <div class=\"col-md-12\">
                     <div class=\"form-group\">
                        <label>Update Tray Number</label> 
                        <input type=\"text\" name=\"traynumber\" class=\"form-control\" required=\"\" value=\"";
        // line 1018
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "tray", array()), "html", null, true);
        echo "\">
                        <input type=\"hidden\" name=\"orderid\" class=\"form-control\" required=\"\" value=\"";
        // line 1019
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "id", array()), "html", null, true);
        echo "\">
                     </div>
                     <button class=\"btn btn-primary\" type=\"submit\">update Tray Number</button>
                  </div>
               </form>
            </div>
         </div>
         <div class=\"modal-footer\">
            <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
         </div>
      </div>
   </div>
</div>
<!-- end of modal -->
<!-- tray status -->
<div id=\"trayStatus\" class=\"modal \" role=\"dialog\">
   <div class=\"modal-dialog\">
      <!-- Modal content-->
      <div class=\"modal-content\">
         <div class=\"modal-header\">
            <h4 class=\"modal-title\">Confirm Tray Items</h4>
         </div>
         <div class=\"modal-body\">
            <div class=\"row m-t-20\">
               <form method=\"post\" action=\"";
        // line 1043
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_tray_quantity");
        echo "\" class=\"col-12\">
                  <div class=\"col-md-12\">
                     <div class=\"form-group\">
                        <label>Item Id</label> 
                        <input type=\"text\" id=\"barcode\" class=\"form-control\" placeholder=\"scan barcode here\">
                     </div>
                     <div class=\"form-group\">
                        <label>Select Item</label> 
                        <select name=\"traynumber\" class=\"form-control\" id=\"sels\">
                           ";
        // line 1052
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customerOrderItems", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 1053
            echo "                           <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "\" data-name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
            echo "  - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "priceVariavtion", array()), "html", null, true);
            echo "\" data-qty=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
            echo "  - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "priceVariavtion", array()), "html", null, true);
            echo "</option>
                           ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 1055
        echo "                        </select>
                        <input type=\"hidden\" name=\"orderid\" class=\"form-control\" required=\"\" value=\"";
        // line 1056
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "id", array()), "html", null, true);
        echo "\">
                     </div>
                     <div class=\"form-group\">
                        <label>Enter Quantity</label> 
                        <input type=\"number\" id=\"quantity\" class=\"form-control\" >
                     </div>
                     <button class=\"btn btn-primary btn-sm\" type=\"button\" id=\"sel\">Add</button>
                  </div>
                  <br>
                  <div class=\"table-responsive\">
                     <table class=\"table table-hovered\" id=\"myTable\">
                        <thead class=\"bg-primary text-white\">
                           <tr>
                              <th>Item</th>
                              <th>Qty</th>
                              <th>Action</th>
                           </tr>
                        </thead>
                        ";
        // line 1074
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "customerOrderItems", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 1075
            echo "                        ";
            if ((($this->getAttribute($context["item"], "isTray", array()) == "0") || ($this->getAttribute($context["item"], "isTray", array()) == ""))) {
                echo " 
                        ";
            } else {
                // line 1077
                echo "                        <tr>
                           <td><input type=\"hidden\" value=\"";
                // line 1078
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", array()), "html", null, true);
                echo "\" name=\"oqty[]\"><input type=\"hidden\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                echo "\" name=\"id[]\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
                echo " - ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "priceVariavtion", array()), "html", null, true);
                echo "</td>
                           <td><input type=\"hidden\" value=\"";
                // line 1079
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "trayQty", array()), "html", null, true);
                echo "\" name=\"qty[]\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "trayQty", array()), "html", null, true);
                echo "</td>
                           <td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\"><i class=\"fa fa-trash\"></i></button></td>
                        </tr>
                        ";
            }
            // line 1083
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 1084
        echo "                     </table>
                  </div>
                  <div class=\"form-group\">
                     <button class=\"btn btn-success\" type=\"submit\">Save</button>
                     <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>









<!-- end of tray status -->
<script type=\"text/javascript\">
\$( document ).ready(function() {
changeBackgroundColor();
});
   function changeBackgroundColor() {

      var select = \$('.otype');
      var selectedVal = \$('.otype').val();

      if(selectedVal == 'processing') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#009688');
         \$('.otype option').css('color', '#ffffff');

      } else if(selectedVal == 'ready') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#4caf50');
         \$('.otype option').css('color', '#ffffff');

      } else if(selectedVal == 'dispatched') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#ff5722');
         \$('.otype option').css('color', '#ffffff');

      } else if(selectedVal == 'delivered') {
         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#4caf50');
         \$('.otype option').css('color', '#ffffff');
         
      } else if(selectedVal == 'cancelled') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#e2a03f');
         \$('.otype option').css('color', '#ffffff');
         
      } else if(selectedVal == 'completed') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#8dbf42');
         \$('.otype option').css('color', '#ffffff');

      } else if(selectedVal == 'received') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#3f51b5');
         \$('.otype option').css('color', '#ffffff');
         
      }
   }
   \$('.otype').change(function(){
  
   changeBackgroundColor();

   var value=this.value;
   var val=\$('.otype').find('option:selected').text();

   // alert(val);
   if(val=='Assign To Delivery Boy' || val=='Reassign Order')
   {
    \$('.slot-time').hide();
    \$('#dboy').show();
       \$('#dboy').html('<div class=\"form-group\"><label for=\"appbundle_customerorder_orderBoy\" class=\"required\">Assign Task To</label><select class=\"form-control db\" name=\"delivery_boy\"></select></div>');
       getDelivery();
   }
   else if(val=='Reassign Picker' || val=='Assign To Picker')
   {
    \$('.slot-time').hide();
    \$('#dboy').show();
       \$('#dboy').html('<div class=\"form-group\"><label for=\"appbundle_customerorder_orderBoy\" class=\"required\">Assign Task To</label><select class=\"form-control db\" name=\"picker\"></select></div>');
       getPicker();
   }
      else if(val=='Reschedule Order')
   {
    // alert('delivery boy names come here!');
      \$('#dboy').hide();   
  \$('.slot-time').show();
   }

   else
   {
    \$('.slot-time').hide();
    \$('#dboy').hide();   
   }
   });
   
      function getPicker()
   {
   var out ={'branch':";
        // line 1196
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "branch", array()), "html", null, true);
        echo "};                      // alert(x);
   \$.ajax({
       type: \"POST\",
       url: \"/restaurant-manager/get-picker\",
       data: out,
       success: function (res, dataType) {
    // console.log('";
        // line 1202
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_get_cat");
        echo "');
   send(res);
             
   // console.log(datas);
   
       },
       error: function (XMLHttpRequest, textStatus, errorThrown) {
           alert('Error : ' + errorThrown);
       }
   });
}
   function getDelivery()
   {
   var out ={'branch':";
        // line 1215
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "branch", array()), "html", null, true);
        echo "};                      // alert(x);
   \$.ajax({
       type: \"POST\",
       url: \"/restaurant-manager/get-del\",
       data: out,
       success: function (res, dataType) {
    // console.log('";
        // line 1221
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_get_cat");
        echo "');
   send(res);
             
   // console.log(datas);
   
       },
       error: function (XMLHttpRequest, textStatus, errorThrown) {
           alert('Error : ' + errorThrown);
       }
   });
}
   function send(myObjects)
   {
   \$('.subcat').html('');
   \$.each(myObjects, function () {
       \$('.db').append('<option value=\"'+this.id+'\">'+this.value+'</option>');
         
       });            
      }
       function removeVariant(obj){
   // \$(this).attr(\"data-usr\" , '');
   
           \$(obj).parent().parent().remove();
   
       }
    \$('#sel').click(function () {
    var id=\$('#sels').val();
    var name = \$('#sels option:selected').attr('data-name');
    var qty=\$('#quantity').val();
    var barcode=\$('#barcode').val();
    if(barcode=='' || barcode == '0')
    {
    var oqty= \$('#sels option:selected').attr('data-qty');
    // alert(oqty);
   if(qty > oqty)
   {
       qty=qty;
   }
   // alert(qty);
    var output = \$('input[name=\"qty[]\"]').val();
   // if(typeof(output)=='undefined')
   // {
   // \$('#myTable').append('<tr><td><input type=\"hidden\" value=\"'+id+'\" name=\"id[]\">'+name+'</td><td><input type=\"hidden\" value=\"'+qty+'\" name=\"qty[]\">'+qty+'</td><td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\"><i class=\"fa fa-trash\"></i></button></td></tr>'); 
   // }   
     \$('#myTable').append('<tr><td><input type=\"hidden\" value=\"'+oqty+'\" name=\"oqty[]\"><input type=\"hidden\" value=\"'+id+'\" name=\"id[]\">'+name+'</td><td><input type=\"hidden\" value=\"'+qty+'\" name=\"qty[]\">'+qty+'</td><td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\"><i class=\"fa fa-trash\"></i></button></td></tr>'); 
        \$('#quantity').val(0);
//      \$('input[name=\"id[]\"]').each(function() {
//       var comp= \$(this).val(); 
//       console.log(comp);
//    if(id == comp)
//    {
//    // alert('item already in tray!');
//    \$(this).parent().parent().remove();


// } else
//   {

  

//  }
//  });
          
   }
   else
   {
   
   }
   
   // }
     // });
     
   
   
    });
    \$('#barcode').on('input propertychange paste', function() {
    var id=\$('#barcode').val();
     var inputlength = \$('#barcode').val().length;
       if (inputlength>4) {
   var out ={'order':";
        // line 1300
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? $this->getContext($context, "order")), "id", array()), "html", null, true);
        echo ",'barcode':id};                      // alert(x);
   
   \$.ajax({
       type: \"POST\",
       url: \"";
        // line 1304
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("api_get_item_by_barcode");
        echo "\",
       data: out,
       success: function (res, dataType) {
    // console.log('";
        // line 1307
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_get_cat");
        echo "');
   // send(res);
   addbar(res);
             
   // console.log(datas);
   
       },
       error: function (XMLHttpRequest, textStatus, errorThrown) {
           alert('Error : ' + errorThrown);
       }
   });
   
             return false;
       }
     
   
   });
 
    function addbar(x)
    {
     var txt;
     if(x.status=='0')
     {
       \$('#barcode').val(0);
   alert('barcode is invalid!!');
     }
     else
     {
        var person = prompt(\"Please enter Quantity:\", x.quantity);
     if (person == null || person == \"\") {
       txt = \"User cancelled the prompt.\";
     } else {
       if(person > x.quantity)
   {
       person=x.quantity;
   }
             \$('#myTable').append('<tr><td><input type=\"hidden\" value=\"'+x.quantity+'\" name=\"oqty[]\"><input type=\"hidden\" value=\"'+x.id+'\" name=\"id[]\">'+x.name+'('+x.variation+')</td><td><input type=\"hidden\" value=\"'+person+'\" name=\"qty[]\">'+person+'</td><td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\"><i class=\"fa fa-trash\"></i></button></td></tr>'); 
        \$('#quantity').val(0);
     } 
     }
   
   }
   

                  \$('#payment_statuss').change(function(){
                    var status=\$('#payment_statuss').val();
                    // alert(status);
                    if(status=='cash')
                    {
                      \$('.ons').hide();
                    }
                    else
                    {
                       \$('.ons').show();
                    }

                  });
\$('#locationSlot').change(function(){
      var id=\$('#locationSlot').val();
    var date=\$('#locationSlot option:selected').attr('data-date');
    var time=\$('#locationSlot option:selected').attr('data-time');
        \$('#fixdate').val(date);
        \$('#fixtime').val(time);

});
  \$('#locationName').change(function(){
    var id=\$('#locationName').val();
        var area=\$('#locationName option:selected').attr('data-name');
        \$('#area').val(area);

    // alert(id);
var out ={'id':id};                      // alert(x);
\$.ajax({
  type: \"POST\",
  url: \"";
        // line 1381
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("get_slot_by_id");
        echo "\",
  data: out,
  success: function (res, dataType) {
  \$('#locationSlot').html('<option>Select Slot</option>');
              \$.each(res,function () {
                \$('#locationSlot').append('<option value=\"'+this.time+'\"  data-time=\"'+this.time+'\"  data-date=\"'+this.date+'\" >'+this.time+' on '+this.date+'</option>');   
                }); 
},
error: function (XMLHttpRequest, textStatus, errorThrown) {
  alert('Error : ' + errorThrown);
}
});
});

                  </script>
";
        
        $__internal_cf2a5d2e447a9e00b00b1de1dea1762d88deb328cb35bc8d988a8c6fac6d4d57->leave($__internal_cf2a5d2e447a9e00b00b1de1dea1762d88deb328cb35bc8d988a8c6fac6d4d57_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Orders/orderForm.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  2364 => 1381,  2287 => 1307,  2281 => 1304,  2274 => 1300,  2192 => 1221,  2183 => 1215,  2167 => 1202,  2158 => 1196,  2044 => 1084,  2038 => 1083,  2029 => 1079,  2019 => 1078,  2016 => 1077,  2010 => 1075,  2006 => 1074,  1985 => 1056,  1982 => 1055,  1963 => 1053,  1959 => 1052,  1947 => 1043,  1920 => 1019,  1916 => 1018,  1907 => 1012,  1866 => 973,  1859 => 970,  1855 => 969,  1848 => 965,  1845 => 964,  1835 => 961,  1832 => 960,  1823 => 958,  1819 => 957,  1809 => 954,  1805 => 953,  1801 => 952,  1797 => 951,  1794 => 950,  1790 => 949,  1786 => 948,  1774 => 939,  1746 => 914,  1739 => 910,  1733 => 907,  1725 => 902,  1700 => 880,  1693 => 876,  1687 => 873,  1673 => 862,  1665 => 857,  1632 => 839,  1620 => 834,  1608 => 829,  1595 => 823,  1592 => 822,  1588 => 821,  1584 => 819,  1582 => 818,  1570 => 814,  1561 => 807,  1554 => 805,  1552 => 804,  1543 => 802,  1538 => 799,  1523 => 795,  1509 => 794,  1506 => 793,  1503 => 792,  1492 => 791,  1490 => 790,  1484 => 787,  1480 => 786,  1477 => 785,  1471 => 783,  1469 => 782,  1464 => 781,  1462 => 780,  1457 => 779,  1454 => 778,  1448 => 776,  1445 => 775,  1443 => 774,  1435 => 771,  1429 => 768,  1426 => 767,  1421 => 766,  1419 => 765,  1413 => 761,  1409 => 760,  1405 => 758,  1403 => 757,  1397 => 753,  1393 => 751,  1390 => 750,  1388 => 749,  1376 => 739,  1364 => 733,  1360 => 732,  1355 => 730,  1351 => 729,  1347 => 728,  1343 => 727,  1337 => 725,  1333 => 724,  1325 => 719,  1318 => 715,  1308 => 710,  1299 => 706,  1292 => 702,  1282 => 695,  1278 => 694,  1274 => 693,  1270 => 692,  1266 => 691,  1262 => 690,  1245 => 676,  1241 => 675,  1231 => 668,  1227 => 667,  1192 => 634,  1187 => 631,  1162 => 609,  1149 => 607,  1145 => 606,  1139 => 602,  1135 => 600,  1131 => 598,  1129 => 597,  1119 => 590,  1114 => 588,  1096 => 572,  1091 => 570,  1088 => 569,  1085 => 567,  1081 => 566,  1075 => 562,  1065 => 554,  1062 => 553,  1052 => 545,  1050 => 544,  1046 => 542,  1040 => 539,  1034 => 537,  1032 => 536,  1029 => 535,  1023 => 532,  1019 => 530,  1016 => 529,  1013 => 528,  1005 => 525,  999 => 523,  997 => 522,  988 => 520,  973 => 513,  969 => 511,  963 => 508,  957 => 506,  955 => 505,  952 => 504,  944 => 502,  940 => 500,  937 => 499,  934 => 498,  926 => 495,  922 => 493,  919 => 492,  917 => 491,  912 => 489,  903 => 485,  876 => 460,  870 => 457,  846 => 453,  838 => 448,  827 => 446,  821 => 443,  812 => 441,  802 => 438,  799 => 437,  795 => 436,  791 => 434,  789 => 433,  781 => 432,  775 => 428,  769 => 426,  767 => 425,  762 => 424,  759 => 423,  749 => 419,  743 => 415,  736 => 413,  734 => 412,  731 => 411,  725 => 409,  723 => 408,  718 => 407,  715 => 406,  709 => 404,  707 => 403,  702 => 402,  700 => 401,  694 => 397,  679 => 393,  669 => 390,  661 => 389,  658 => 388,  655 => 387,  649 => 385,  647 => 384,  642 => 383,  639 => 382,  634 => 379,  629 => 377,  627 => 376,  619 => 374,  617 => 373,  615 => 372,  609 => 369,  606 => 368,  604 => 367,  588 => 366,  584 => 364,  578 => 362,  576 => 361,  571 => 360,  569 => 359,  566 => 358,  562 => 356,  559 => 355,  556 => 354,  553 => 353,  550 => 352,  547 => 351,  545 => 350,  543 => 349,  541 => 348,  539 => 347,  537 => 346,  531 => 343,  527 => 342,  524 => 341,  519 => 340,  510 => 339,  503 => 338,  497 => 337,  494 => 336,  488 => 335,  485 => 334,  481 => 333,  477 => 332,  469 => 326,  465 => 325,  461 => 323,  459 => 322,  424 => 292,  416 => 289,  404 => 286,  398 => 283,  370 => 258,  366 => 257,  362 => 256,  358 => 255,  351 => 251,  347 => 250,  335 => 241,  310 => 219,  307 => 218,  299 => 216,  290 => 215,  284 => 213,  278 => 210,  273 => 208,  268 => 206,  263 => 204,  258 => 202,  253 => 200,  250 => 199,  248 => 198,  245 => 197,  243 => 196,  239 => 195,  230 => 189,  226 => 188,  39 => 3,  33 => 2,  18 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/'~ myExtend ~'/base.html.twig' %}
{% block body %}
<style type=\"text/css\">
thead.ban td {
    padding: 5px !important;
    font-size: 11px;
    font-weight: 600;
    text-transform: capitalize;
}

.pr
   {
    font-size: 10px;
    text-transform: uppercase;
   }
   @media print{
   .noprint{
   display:none;
   }

 
      .print-area
   {
    display: block !important;
    background: #fff !important;
   }
   }
      .print-area
   {
    display: none;
   }
   .edit-order
   {
   float: right;
   font-weight: bolder;
   text-transform: uppercase;
   font-size: 11px;
   }
   .borderless tr {
    border: none;
}
 @media print
      {
         @page {
           margin-top: 0;
           margin-bottom: 0;
         }
         body  {
           padding-top: 72px;
           padding-bottom: 72px ;
         }
         *
         {
          background: #fff !important;
         }
      } 

.x td, .x th {
    border-color: #f3f1f1;
    padding: 0px;
    font-weight: 500;
    font-size: 11px;
}
.xx td, .xx th {
    border-color: #f3f1f1;
    padding: 0px;
    font-weight: 500;
    font-size: 13px;
}

      .ss
      {
        background: #fff0;
    color: #000 !important;
    border: none;
    box-shadow: none;
    }
    .select1{
       padding: 7px 16px;
    }
    .card-header{
        background-color: #fff;
        border-color: #fff;
    }
    .card-header section > div.collapsed {
        color: #000;
       }

     select.info {

  /* styling */
  background-color: white;
  border: thin solid blue;
  border-radius: 4px;
  display: inline-block;
  font: inherit;
  line-height: 1.5em;
  padding: 0.5em 3.5em 0.5em 1em;

  /* reset */

  margin: 0;      
  -webkit-box-sizing: border-box; 
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-appearance: none;
  -moz-appearance: none;
}
 
 .form-control.form-control-sm {
    padding: 6px 16px;
 }
      
select.classic {
  background-image:
    linear-gradient(45deg, transparent 50%, #000 50%),
    linear-gradient(135deg, #000 50%, transparent 50%),
    linear-gradient(to right, #c7c7c7, #c7c7c7);
  background-position:
    calc(100% - 20px) calc(1em + 2px),
    calc(100% - 15px) calc(1em + 2px),
    100% 0;
  background-size:
    5px 5px,
    5px 5px,
    2.5em 2.5em;
  background-repeat: no-repeat;
}

select.classic:focus {
  background-image:
    linear-gradient(45deg, #000 50%, transparent 50%),
    linear-gradient(135deg, transparent 50%, #000 50%),
    linear-gradient(to right, #c7c7c7, #c7c7c7);
  background-position:
    calc(100% - 15px) 1em,
    calc(100% - 20px) 1em,
    100% 0;
  background-size:
    5px 5px,
    5px 5px,
    2.5em 2.5em;
  background-repeat: no-repeat;
  border-color: grey;
  outline: 0;
}
.right-sidebar-option {
      background: #f1f2f3;
}

.card-header section > div:not(.collapsed) {
    color: #000;
}
.right-sidebar-card {
  margin-bottom:0;
  border-radius:0;
}

.select2-container .select2-selection--single{
  height: 100% !important;
}

select.form-control.form-control-sm.fa.fa-angle-down {
    background: #E2A03F;
    color: #fff !important;
}

input.submit-btn.submit-btn.btn-block {
    background: #2F4ACA;
    border: none;
    height: 33px;
    color: #ffff;
    font-size: 15px;
    font-weight: 700;
}

.otype {
   font-weight:700;
}
.importantRule{
   color:#fff !important;
}
</style>
<div class=\"noprint\">
<!-- new invoice start -->


  {{ form_start(form) }}
            {% form_theme form '@AppBundle/Themes/widget.html.twig' %}  
<div class=\"layout-px-spacing\">
    <div class=\"row layout-top-spacing\">
    <div class=\"col-md-12\">
      <div class=\"card\">
         <div class=\"p-2\">
                <h4 class=\"\"><span class=\"badge badge-primary\">#{{ order.id }}</span> 
                 {% if order.orderStatus == 'dispatched' %}
                    <span class=\"badge\" style=\"background: #ff5722;text-transform: capitalize !important;color: #fff;\">Assigned To Delivey Boy</span>
                      {% elseif order.orderStatus == 'onway' %}
                    <span class=\"badge\" style=\"background: #ff5722;text-transform: capitalize !important;color: #fff;\">Out For Delivery</span>
                        {% elseif order.orderStatus == 'ready' %} 
                    <span class=\"badge\" style=\"background: #4caf50;text-transform: capitalize !important;color: #fff;\">Order Ready</span>
                   {% elseif order.orderStatus == 'received' %} 
                    <span class=\"badge\" style=\"background: #3f51b5;text-transform: capitalize !important;color: #fff;\">Received</span>
                     {% elseif order.orderStatus == 'processing' %} 
                    <span class=\"badge\" style=\"background: #009688;text-transform: capitalize !important;color: #fff;\">Processing</span>
                     {% elseif order.orderStatus == 'processing' %} 
                    <span class=\"badge\" style=\"background: #009688;text-transform: capitalize !important;color: #fff;\">Processing</span>
                     {% elseif order.orderStatus == 'delivered' %} 
                    <span class=\"badge\" style=\"background: #4caf50;text-transform: capitalize !important;color: #fff;\">delivered</span>
                     {% elseif order.orderStatus == 'delivered' %} 
                    <span class=\"badge\" style=\"background: #4caf50;text-transform: capitalize !important;color: #fff;\">delivered</span>
                   {% else %}
                 <span class=\"badge\" style=\"background: #4caf50;text-transform: capitalize !important;color: #fff;\">{{ order.orderStatus }} </span>
               {% endif %}
               {% if order.orderType == 'Delivery' %}<span class=\"badge badge-success\">Home Delivery </span>{% elseif order.orderType == 'pickup' %} <span class=\"badge badge-warning\">Pickup From Store</span> {% else %} <span class=\"badge badge-danger\">Express Delivery</span> {% endif %}
               {% if order.membership == '0' %}<span class=\"badge badge-default\">Normal Order</span>{% else %}<span class=\"badge badge-danger\">Membership Applied</span>
               {% endif %}
               
               <span class=\"badge badge-danger\" style=\"text-transform:capitalize;\">{{ order.paymentStatus }}</span>
                <span style=\"float:right;\">
                 <a href=\"#kot\" onclick=\"frames['prints'].print()\" value=\"printletter\" style=\"width:100%\"  data-placement=\"bottom\" title=\"KOT Print\">
                  <img src=\"/assets/images/KOT.png\" style=\"width:24px;\"></a>
                  <a href=\"#download\" onclick=\"window.print()\" style=\"width:100%;margin-top:5px;\"   data-placement=\"bottom\" title=\"A4 Print\">
                      <img src=\"/assets/images/A4.png\" style=\"width:24px;\"></a>
                      </a>
                     <a href=\"#thermal\"  onclick=\"frames['frame'].print()\" value=\"printletter\"  style=\"width:100%;margin-top:5px;\"   data-placement=\"bottom\" title=\"Thermal Print\">
                      <img src=\"/assets/images/thermal.png\" style=\"width:24px;\"></a>
                    </span>
                     </h4>
         </div>
      </div>
    </div>
      <!--col-md-9-->
      <div class=\"col-md-9\">
        <div class=\"row\">
          <div class=\"col-md-6 mb-4\">
            <div class=\"card h-100\">
              <div class=\"row form-row\">
                <div class=\"col-md-12 form-group\">
                 <div class=\"card-header\">
                         <!--a href=\"#\" style=\"background: #3F51B5;color:#fff;font-size: 12px;padding: 6px;\">{{ order.orderType|upper }}</a-->
          </h4>
        </div>
                  <div id=\"user\">
                     <div class=\"col-md-12 form-group\">
                  <div class=\"card-body\">
                    <!--address-->
                    <h5 class=\"mb-4\">Customer Details</h5>
                    <div class=\"\">
                        <p> {{ order.customerName }}</p>
                        <p>{{ order.customer.email }}</p>
                     </div>
                     <hr>
                     <div class=\"\">
                          <p> {{ order.address }}</p>
                          <p> {{ order.landmark }}</p>
                          <p> Gst No : {{ order.customer.gst }}</p>
                          <p> Mobile : {{ order.customer.mobileNumber }}</p>
                        
                     </div>
                  </div>

                  <!--end-->
                </div>
                  
                     </div>
                  </div>
                 

               
              </div>
            </div>
          </div>

          <div class=\"col-md-6 mb-4\">
            <div class=\"card h-100\">
                <div class=\"form-group col-md-12\">
 <div class=\"card-body\">
                    <!--address-->
                    <h5 class=\"mb-4\">Payment Details</h5>
                    <div class=\"row form-row\">
                        <div class=\"col-md-12 form-group\">
                           <input  type=\"text\" name=\"txt\" class=\"form-control form-control-sm\" required=\"\" value=\"{{ order.paymentType }}\" readonly>
                        </div>
                          <div class=\"col-md-12 form-group\">
                           <input  type=\"text\" name=\"txt\" class=\"form-control form-control-sm\" required=\"\" value=\"{% if order.orderType == 'Delivery' %} Home Delivery {% elseif order.orderType == 'pickup' %} Pickup From Store {% else %} Express Delivery {% endif %} \" readonly>
                        </div>
                         <div class=\"col-md-12 form-group\">
                           <input  type=\"text\" name=\"txt\" class=\"form-control form-control-sm\" required=\"\" value=\"{{  order.orderDate.date|date(\"d-m-Y\") }} at {{  order.orderDate.date|date(\"h-i A\") }}\" readonly>
                        </div>
                        <div class=\"col-md-12 form-group\">
                           <input  type=\"text\" name=\"txt\" class=\"form-control form-control-sm\" required=\"\" value=\"{{ order.fixDate }} around {{ order.fixtime }}\" readonly>
                        </div>
                    </div>
                    
             
            </div>
          </div>
          </div>
        </div>
        <div class=\"col-md-12 mb-4\">        
          <div class=\"card\">
           <div class=\"card-body\">
             <h5 class=\"mb-4\">Order Items</h5>

                   <!--div class=\"col-md-12 text-right\">
                      <a href=\"#\" class=\"btn btn-primary btn-sm mb-4\"  data-toggle=\"modal\" data-target=\"#uploadCSV\">Add Items</a> 
                    </div-->
              
                    <div class=\"col-md-12\">
                      <div class=\"table-responsive m-t-10 row table-show\" style=\"display:block;\">
                       <table class=\"table table-hovered\">
                              <thead class=\"bg-primary text-white\" style=\"color:#fff;\">
                                 <tr>
                                    <th style=\"color:#fff;\">Item name</th>
                                    <th style=\"color:#fff;\">price variation</th>
                                    <th style=\"color:#fff;\">Barcode</th>
                                    <th style=\"color:#fff;\">price</th>
                                    <th style=\"color:#fff;\">quantity</th>
                                  <th style=\"color:#fff;\">Discount</th>

                                    {% if currency == 'AED' %}
                                   <th style=\"color:#fff;\">VAT</th>
                                    {% else %}
                                    <th style=\"color:#fff;\">Tax</th>
                                    {% endif %}     

                               <th style=\"color:#fff;\">Sub total</th>
                                 </tr>
                              </thead>
                              <tbody>
                                {% set tax= 0 %} 
                                 {% for item in order.customerOrderItems %}
                                 <tr style=\"font-size:10px;\">
                                    <td>{% if item.isTray == '0' or item.isTray == '' %} <span style=\"color:#2196f3;font-weight:400;\">{{ item.itemName }}</span> {% endif %}
                                   
    {% if item.isTray == '3'%} <span style=\"color:#e91e63;font-weight:400;\">{{ item.itemName }}</span> {% endif %}
                                       {% if item.isTray == '1' %} <span style=\"color:#F44337;font-weight:400;\">{{ item.itemName }}</span> {% endif %}
                                       {% if item.isTray == '2' %} <span style=\"color:#014c0a;font-weight:400;\">{{ item.itemName }}</span> {% endif %}<br>
                                         {% if item.edited == 1 %} Edited | Reason : {{ item.reason }}{% endif %}
                                    </td>
                                    <td>{{ item.priceVariavtion }}</td>
                                    <td>{{ item.barcode }}</td>
                                    <td>

                                      {% if item.discount != 0 %}
{% set discount = item.discount %}
{% set quantity = item.quantity %}
{% set priceO = discount/quantity %}
{% set price = item.price + priceO %}
                                      {% else %}
                                      {% set price = item.price %}
                                      {% endif %}
                                      {% set x= 100+item.tax %}

                                     {% set pr=price*100/x %} 
                                     {# {{ pr|round(2, 'floor') }} #}

                                     {% if numberFormat == 0 %}
                                       {{ pr|round(2, 'floor') }}
                                     {% elseif numberFormat == 1 %}
                                       {{ pr|number_format(2, '.', '') }}
                                     {% endif %}

                                   </td>
                                    <td>{{ item.quantity }}  {% if item.isTray == '1' %} <span style=\"color:#F44337;font-weight:400;\">({{ item.trayQty }})</span> {% endif %} {% if item.trayQty > item.quantity %} <span style=\"color:green;font-weight:400;\">({{ item.trayQty-item.quantity }})</span> {% endif %}</td>
                                    {% set st = item.price*item.tax/100 * item.quantity %}
                                      <td class=\"\"> 
{{ item.discount }}</td>
   
                                       <td class=\"text-right\">
{% if currency == 'AED' %}
{% if numberFormat == 0 %}
 {% set f=price-pr|round(2, 'floor') %} {% set ft=f*item.quantity %} 

{% elseif numberFormat == 1 %}
{% set f=price-pr|number_format(2, '.', '') %} 
{% endif %}
{% set ft=f*item.quantity %} 

 {# {{ ft|round(2, 'floor') }} #}
      {% if numberFormat == 0 %}
         {{ ft|round(2, 'floor') }}
      {% elseif numberFormat == 1 %}
         {{ ft|number_format(2, '.', '') }}
      {% endif %}
 {% else %}
<div class=\"tax\" style=\"display:flex;\">
  <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 7px;\">CGST <br> {{ item.tax/2 }}%  {% set f=price-pr %} <br> ({% set ft=f*item.quantity%} 
  {% if numberFormat == 0 %}{{ ft|round(2, 'floor')/2 }}{% elseif numberFormat == 1 %}{{ ft|number_format(2, '.', '')/2 }}{% endif %})

  </div>
    <div style=\"padding: 3px;font-size: 7px;\">SGST <br>{{ item.tax/2 }}% <br> ({% set ft=f*item.quantity%} {% if numberFormat == 0 %}{{ ft|round(2, 'floor')/2 }}{% elseif numberFormat == 1 %}{{ ft|number_format(2, '.', '')/2 }}{% endif %})</div>
</div>

 {% endif %}

                                       </td>

                                                                      <td class=\"text-right\"> 
                                      {% if numberFormat == 0 %}
                                      {% set subTotals = pr|round(2, 'floor') * item.quantity %} 
                                       {% elseif numberFormat == 1 %}
                                      {% set subTotals = pr|number_format(2, '.', '') * item.quantity %} 
                                    {% endif %}
                                    {% if numberFormat == 0 %}
                                       {{ subTotals - item.discount|round(2, 'floor') }}
                                    {% elseif numberFormat == 1 %}
                                       {{ subTotals - item.discount|number_format(2, '.', '') }}
                                    {% endif %}
                                    </td>
                                    {% set tax = tax+ft %}
                                 </tr>
                                 {% endfor %}
                                
                              </tbody>
                                  <tfoot>
                                    <tr>
                                <th class=\"text-left\">Online/Cash : {% if numberFormat == 0 %}{{ order.orderAmount|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.orderAmount|number_format(2, '.', '') }}{% endif %}</span></th>
                              <th colspan=\"6\" class=\"text-right\">Total</th>
                              <th> <span class=\"sums\">
                                 {# {{ order.actualAmount|round(2, 'floor')-tax|round(2, 'floor') }} #}
                                    {% if numberFormat == 0 %}
                                       {{ order.actualAmount|round(2, 'floor')-tax|round(2, 'floor') }}
                                    {% elseif numberFormat == 1 %}
                                       {{ order.actualAmount|number_format(2, '.', '')-tax|number_format(2, '.', '') }}
                                    {% endif %}
                                    </span></th>
                            </tr>

                            <tr>
                               <th class=\"text-left\">Loyalty :  {% if numberFormat == 0 %}{{ order.loyalty|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.loyalty|number_format(2, '.', '') }}{% endif %}</span></th>
                              <th colspan=\"6\" class=\"text-right\">{% if currency == 'AED' %}
                              Vat
                              {% else %}
                              Tax
                             {% endif %}  </th>
                              <th>{% if numberFormat == 0 %}{{ tax|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ tax|number_format(2, '.', '') }}{% endif %}</th>
                            </tr>
                            <tr>
                               <th class=\"text-left\">Wallet : {% if numberFormat == 0 %}{{ order.wallet|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.wallet|number_format(2, '.', '') }}{% endif %}</span></th>
                              <th colspan=\"6\" class=\"text-right\">Discount</th>
                              <th>{{ order.totalDiscount }}</th>
                            </tr>
                            <tr>
                               <th class=\"text-left\">Total : {% set totals = order.wallet + order.loyalty + order.orderAmount  %} {% if numberFormat == 0 %}{{ totals|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ totals|number_format(2, '.', '') }}{% endif %}</span></th>
                              <th colspan=\"6\" class=\"text-right\">Delivery Charge</th>
                              <th> <span class=\"delivery\">{{ order.deliveryCharge|round(2, 'floor') }}</span></th>
                            </tr>
                           
                            <tr>
                              <th colspan=\"7\" class=\"text-right\">Grand Total</th>
                              <th> <span class=\"sums\"> {% if order.paymentType == 'wallet' %} {% set total = order.actualAmount + order.deliveryCharge - order.totalDiscount %} {% if numberFormat == 0 %}{{ total|round }}{% elseif numberFormat == 1 %}{{ total|number_format(2, '.', '') }}{% endif %} {% else %}{% set total = order.orderAmount  %}{% if numberFormat == 0 %}{{ total|round }}{% elseif numberFormat == 1 %}{{ total|number_format(2, '.', '') }}{% endif %}{% endif %}</span></th>
                            </tr>
                          </tfoot>
                           </table>
  {% if order.orderStatus == \"received\" or order.orderStatus == \"processing\" or order.orderStatus == \"ready\" or order.orderStatus == \"pick\" %} 
                           <a href=\"#\" class=\"noprint edit-order\" data-toggle=\"modal\" data-target=\"#edit-order\">edit order</a>
{% endif %}

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class=\"col-md-3 mb-4\">
           <div class=\"h-100\">
            <div id=\"toggleAccordion\">
              
              <div class=\"card right-sidebar-card\">
                <div class=\"card-header\" id=\"headingOne1\">
                  <section class=\"mb-0 mt-0\">

                    <div role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#defaultAccordionOne\" aria-expanded=\"true\" aria-controls=\"defaultAccordionOne\">
                      Order Info <div class=\"icons\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-down\"><polyline points=\"6 9 12 15 18 9\"></polyline></svg></div>
                    </div>
                  </section>
                </div>
                <div id=\"defaultAccordionOne\" class=\"collapse show\" aria-labelledby=\"headingOne1\" data-parent=\"#toggleAccordion\">
                  <div class=\"card-body right-sidebar-option\">
                    <div class=\"\">
                      <p style=\"\"><b>Ordered on</b></p>
                      <p>{{  order.orderDate.date|date(\"d-m-Y\") }} at {{  order.orderDate.date|date(\"h-i A\") }}</p>
                    </div>
                    <div>
                     <p style=\"\"><b>Device</b></p>
                     <p>{{  order.channel }}</p>
                   </div>
                    {% if dname == '' %}
                    {% else %}
                   <div>
                     <p style=\"\"><b>Delivery Boy</b></p>
                     <p>{{ dname }}-({{ dmobile }})</p>
                   </div>
                   {% endif %}
                   {% if pname == '' %}
                           {% else %}
                      <div>
                     <p style=\"\"><b>Picker Name</b></p>
                     <p>{{ pname }}-({{ pmobile }})</p>
                   </div>
                                              {% endif %}          
                   {% if order.note == ''%}
                   {% else %}                    <div>
                     <p style=\"\"><b>Note</b></p>
                     <p>{{ order.note }}</p>
                   </div>
                   {% endif %}
                   <div>
                     <p style=\"\"><b>Tray Number</b></p>
                     <p>{% if order.tray == ''  or order.tray == '0' or order.tray is null %} <i style=\"color:red;\">not created </i>{% else %} {{ order.tray }}{% endif %}  

                      (<a href=\"#ssss\"  data-toggle=\"modal\" data-target=\"#myModal\">edit</a>)</p>
                   </div>

                      <div>
                     <p style=\"\"><b>Tray Status</b></p>
                     <p> {% if order.tray == ''  or order.tray == '0'  or order.tray is null %} <i style=\"color:red;\">Tray number not assigned</i>{% else %} in Tray {% endif %}   (<a href=\"#ssss\"  data-toggle=\"modal\" data-target=\"#trayStatus\">edit</a>)</p>
                   </div>
                    {% if order.deliveryTime == ''%}
                   {% else %}                    <div>
                     <p style=\"\"><b>Delivery Time</b></p>
                     <p>{{  order.deliveryTime.date|date(\"d-m-Y\") }} at {{  order.deliveryTime.date|date(\"h-i A\") }}</p>
                   </div>
                   {% endif %}
                   {% if order.slotReason == ''%}
                   {% else %}
                   <div>
                     <p style=\"\"><b>Reason For Reschedule</b></p>
                     <p>{{ order.slotReason }}</p>
                   </div>
                   {% endif %}

                    {% if order.promocode == ''%}
                   {% else %}                    <div>
                     <p style=\"\"><b>Promocode</b></p>
                     <p>{{  order.promocode }}</p>
                   </div>
                   {% endif %}

                         <div>
                          {% if order.paymentStatus == 'paid' %}
                  <div class=\"form-group\">
                     <p style=\"cursor:pointer;\"><b>Payment Status</b></p>
                     <div class=\"form-group \" >
                     <span  class=\"badge badge-success\">Paid</span>
                      
                    </div>
                  </div>
                  {% endif %}
                  {% if order.paymentStatus == 'pending'  or order.paymentStatus == '' or order.paymentStatus == 'cancelled' or order.paymentStatus == 'failed' %}
                  <div class=\"form-group\">
                     <p style=\"cursor:pointer;\"><b>Payment Status</b></p>
                     <div class=\"form-group \" >
                      <span id=\"payment_status\"  data-toggle=\"modal\" data-target=\"#edit-payment-status\" class=\"badge badge-danger\">Mark As Paid </span>
                      
                    </div>
                  </div>
                  {% endif %}


</div>
<p style=\"\"><b>Version</b></p>
<p>{{  order.version }}</p>
{% if order.transactionId == '' or  order.transactionId == ' '  %}
{% else %}
<p style=\"\"><b>Transction Id</b></p>
<p>{{  order.transactionId }}</p>
{% endif %}

                              </div>
                            </div>


                          </div>
                          <div class=\"card right-sidebar-card\">
                            <div class=\"card-header\" id=\"headingTwo1\">
                              <section class=\"mb-0 mt-0\">
                                <div role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#defaultAccordionTwo\" aria-expanded=\"true\" aria-controls=\"defaultAccordionTwo\">
                                  Order Status<div class=\"icons\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-down\"><polyline points=\"6 9 12 15 18 9\"></polyline></svg></div>
                                </div>
                              </section>
                            </div>
                            <div id=\"defaultAccordionTwo\" class=\"collapse show\" aria-labelledby=\"headingTwo1\" data-parent=\"#toggleAccordion\">
                              <div class=\"card-body right-sidebar-option\">
                                  {% if order.orderStatus != \"completed\" and order.orderStatus != \"cancelled\" %} 
               <div class=\"form-group\">
                     {{ form_row(form.orderStatus,{'attr':{'class':'form-control otype'}}) }}
                  </div>
                  <div id=\"dboy\">
                  </div>
<input type=\"hidden\" name=\"fixtime\" id=\"fixtime\">
<input type=\"hidden\" name=\"fixdate\" id=\"fixdate\">

{% if order.orderStatus == 'reschedule' %}
<div class=\"slot-time\">
  {% else %}
<div class=\"slot-time\" style=\"display:none;\">
  {% endif %}
                   <div class=\"row form-row\">
                    <div class=\"col-md-12 form-group\">
                     <select class=\"form-control form-control-sm classic info\" name=\"area\" id=\"locationName\">
                      <option value=\"\">Select Area</option>
                      {% for loc in location %}
                      <option value=\"{{ loc.id }}\" data-name=\"{{ loc.title }}\">{{ loc.title }}</option>
                      {% endfor %}
                    </select>
                  </div>
                </div>
                  <div class=\"row form-row\">
                  <div class=\"col-md-12 form-group\">
                    <select class=\"form-control form-control-sm classic info\" name=\"slot\" id=\"locationSlot\">
                      <option value=\"\">Slots</option>
                      
                    </select>
                  </div>
                </div>
</div>
                   <div class=\"form-group\">
                     <button type=\"submit\" class=\"btn btn-primary pr\" style=\"width:100% !important;margin-bottom:5px;\">Update order</button>
                            
                          </div>
           
                      </div>
                    </div>
                  </div>

                      
                           {% else %} 
                      
               {% endif %}
                </div>
                
              </div>




<!-- new invoice end -->





















   <div class=\"col-12\">
     
              
            </div>
            {{ form_widget(form._token) }}
            {{ form_end(form,{'render_rest':false}) }}
         </div>

 </div>
 </div>
</div>
</div>
<iframe src=\"{{ path('thermal_print',{'id':order.id}) }}\" style=\"display:none;\" name=\"frame\"></iframe>
<iframe src=\"{{ path('normal_print',{'id':order.id}) }}\" style=\"display:none;\" name=\"prints\"></iframe>
</div>
<!-- starty of  card -->
<div class=\"print-area\" style=\"display:none\">
  <div class=\"container\">
<div class=\"row\">
  <div class=\"col-12\">
<center><span>O  R  I  G  I  N  A  L     T  A  X     I  N  V  O  I  C  E</span></center>
</div>
</div>
<div class=\"row\">
  <div class=\"col-6\">
      <p>Bill to/Ship to:<br>
                           <small>
                           {{ order.customerName }}<br>
                           {{ order.address }}<br>
                           {{ order.landmark }}
                           Mobile : {{ order.customer.mobileNumber }}<br>
                           Email : {{ order.customer.email }}<br>
                           Gst No: {{ order.customer.gst }}

                           </small>
                        </p>
                         <table class=\"table xx table-bordered\">
                                 <tr>
                                  <td>Order Id</td>
                                   <td>{{ order.id }}</td> 
                                 </tr>
                                 <tr>
                                  <td>Order Date</td>
                                   <td>{{  order.orderDate.date|date(\"d-m-Y\") }} at {{  order.orderDate.date|date(\"h-i A\") }}</td> 
                                 </tr>
                                  <tr>
                                  <td>Slot</td>
                                   <td>{{ order.fixtime }} - {{ order.fixDate}}</td> 
                                 </tr>
                                 
                                  <tr>
                                  <td>Order Type</td>
                                   <td>{{ order.paymentType|upper }}</td> 
                                 </tr>
                                 <tr>
                                  <td>Delivery Area</td>
                                   <td>{{ order.area|upper }}</td> 
                                 </tr>
                            </table>
</div>
  <div class=\"col-6\">
    {% for res in restaurant %}
          <p style=\"float:right\"><img src=\"/uploads/restaurant/icons/{{ res.iconImage }}\" style=\"height:50px;\"><br>
                           <small>
                           {{ res.restaurantName }}<br>
                           {{ res.restaurantAddress }}<br>
                           {{ res.restaurantLocation }}<br>
                            Gst No:{{ res.gst }}<br>

                           Mobile : {{ res.primaryMobile }}<br>
                           Email : {{ res.primaryEmail }} 
                           </small>

                        </p>
                                   
                        {% endfor %}
                    
</div>
</div>

<div class=\"table-responsive\">
                           <table class=\"table x table-bordered\">
                              <thead class=\"ban\">
                                 <tr>
                                  <td>#</th>
                                    <td>Item name</td>
                                  {% if currency == 'AED' %}
                                  {% else %}
                                      <td>Hsn</td>
                                      {% endif %}

                                    <td>Price</td>
                                     <td>Quantity</td>
                                         <td>Discount</td>
                                  {% if currency == 'AED' %}
                                   <th style=\"color:#fff;\">VAT</th>
                                    {% else %}
                                    <th style=\"color:#fff;\">Tax</th>
                                    {% endif %}                                     <td> Total Value</td>
                                 </tr>
                              </thead>
                              <tbody>
                                {% set count= 1 %}
                                 {% for item in order.customerOrderItems %}
                                 <tr>
                                  <td>{{ count }}</td>
                                           

                                    <td>{{ item.itemName }} - {{ item.priceVariavtion }}
                                   
                                    </td>
                                    {% if currency == 'AED' %}
                                    {% else %}
                                  <td>{{ item.hsn }}</td>
                                  {% endif %}
                                    <td>{% set x= 100+item.tax %}
                                     {% set pr=item.price*100/x %} 
                                       {% if numberFormat == 0 %}
                                          {{ pr|round(2, 'floor') }}
                                       {% elseif numberFormat == 1 %}
                                          {{ pr|number_format(2, '.', '') }}
                                       {% endif %}
                                    </td>
                                    <td>{{ item.quantity }}</td>
                                     <td>{{ item.discount }}</td>
                                    <td>

                                      {% if currency == 'AED' %}
 {% set f=item.price-pr %} {% set ft=f*item.quantity %} {% if numberFormat == 0 %}{{ ft|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ ft|number_format(2, '.', '') }}{% endif %}
 {% else %}
<div class=\"tax\" style=\"display:flex;\">
  <div class=\"\"style=\"border-right: 1px solid;padding: 3px;font-size: 7px;\">CGST <br> {{ item.tax/2 }}%  {% set f=item.price-pr %} <br> ({% set ft=f*item.quantity%} {% if numberFormat == 0 %}{{ ft|round(2, 'floor')/2 }}{% elseif numberFormat == 1 %}{{ ft|number_format(2, '.', '')/2 }}{% endif %} )</div>
    <div style=\"padding: 3px;font-size: 7px;\">SGST <br>{{ item.tax/2 }}% <br> ({% set ft=f*item.quantity%} {% if numberFormat == 0 %}{{ ft|round(2, 'floor')/2 }}{% elseif numberFormat == 1 %}{{ ft|number_format(2, '.', '')/2 }}{% endif %})</div>
</div>

 {% endif %}


</td>
                                    <td class=\"text-right\">{% if numberFormat == 0 %}{{ item.subTotal|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ item.subTotal|number_format(2, '.', '') }}{% endif %}</td>
                                 </tr>
                                                                 {% set count= count+1 %}

                                 {% endfor %}


                                   <tr>
                                  <th colspan=\"6\"></th>
                               

                                    <th>Total</th>
                                  <th>{% set m=order.actualAmount-tax %}{% if numberFormat == 0 %}{{ m|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ m|number_format(2, '.', '') }}{% endif %}</th>
                                 </tr>
                                  <tr>
                                       <th colspan=\"6\"></th>                                         
                                    <th>  {% if currency == 'AED' %}
                       Vat
                        {% else %}
                          Tax
                        {% endif %}    </th>
                                  <th>{% if numberFormat == 0 %}{{ tax|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ tax|number_format(2, '.', '') }}{% endif %}</th>
                                 </tr>
                                  <tr>
                                   <tr>
                                       <th colspan=\"6\"></th>                                         
                                    <th>Delivery Charge</th>
                                  <th>{% if numberFormat == 0 %}{{ order.deliveryCharge|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.deliveryCharge|number_format(2, '.', '') }}{% endif %}</th>
                                 </tr>
                                  <tr>
                                   <th colspan=\"6\"></th>                               
                                    <th>Discount</th>
                                  <th>{% if numberFormat == 0 %}{{ order.totalDiscount|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.totalDiscount|number_format(2, '.', '') }}{% endif %}</th>
                                 </tr>
                                 <tr>
                                    <th colspan=\"6\"></th>                              
                                    <th>Grand Total</th>
                                  <th>{% if order.paymentType == 'wallet' %} {% set total = order.actualAmount + order.deliveryCharge - order.totalDiscount %} {% if numberFormat == 0 %}{{ total|round(2, 'floor') }}{% elseif numberFormat == 1 %}{% endif %}{{ total|round(2, 'floor') }} {% else %}{{ order.orderAmount }}{% endif %}</th>
                                 </tr>
                              </tbody>
                           </table>
</div>


</div>
</div>
<!-- end of card -->

<!-- Modal
for payment approval -->
<div id=\"edit-payment-status\" class=\"modal\" role=\"dialog\">
   <div class=\"modal-dialog\">
      <!-- Modal content-->
      <div class=\"modal-content\">
         <div class=\"modal-header\">
            <h4 class=\"modal-title\">Payment Status | {{ order.paymentStatus|upper }}</h4>
         </div>
         <div class=\"modal-body\">
            <div class=\"row\">
               <div class=\"col-12\">
                  <form method=\"post\" action=\"{{ path('update_payment') }}\">
                     <div class=\"form-group\" >
                  <label class=\"label\" style=\"color:#000;margin-left: -9px;\">Payment Mode</label>
                  <select class=\"form-control\" name=\"mode\" id=\"payment_statuss\">
                  <option value=\"Online\">Online Payment</option>
                       <option value=\"cash\">Cash</option>
                     </select>
                   </div>
                   <div class=\"ons\">
                 <div class=\"form-group\">
                  <label class=\"label\" style=\"color:#000;margin-left: -9px;\">Transaction Id</label>
                  <input type=\"tex\" name=\"transactionId\" class=\"form-control\" value=\" {{ order.transactionId}}\">
                 </div>
                  </div>
  <input type=\"hidden\" name=\"orderid\" class=\"form-control\" required=\"\" value=\"{{ order.id }}\">
                 <div class=\"form-group\">
                  <label class=\"label\" style=\"color:#000;margin-left: -9px;\">Date / Payment Through / Note</label>
                  <textarea class=\"form-control\" rows=\"3\"  name=\"note\">
                     {{ order.note}}
                  </textarea>
               </div>
                     <button class=\"btn btn-success\" type=\"submit\">Mark as Paid</button>
                     <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
               </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<!-- end of modal -->

<!-- Modal 
incase of payment caancelling and all-->
<div id=\"payment_status_remain\" class=\"modal\" role=\"dialog\">
   <div class=\"modal-dialog\">
      <!-- Modal content-->
      <div class=\"modal-content\">
         <div class=\"modal-header\">
            <h4 class=\"modal-title\">Payment Status  | {{ order.paymentStatus|upper }}</h4>
         </div>
         <div class=\"modal-body\">
            <div class=\"row\">
               <div class=\"col-12\">
                  <form method=\"post\" action=\"{{ path('update_payment_pending') }}\">
                   
                 
  <input type=\"hidden\" name=\"orderid\" class=\"form-control\" required=\"\" value=\"{{ order.id }}\">
                 <div class=\"form-group\">
                  <label class=\"label\" style=\"color:#000;\">Reason for changing payment status</label>
                  <textarea class=\"form-control\" rows=\"3\"  name=\"note\">
                    {{ order.note}}
                  </textarea>
               </div>
                     <button class=\"btn btn-success\" type=\"submit\">Mark As Pending</button>
                     <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
               </div>
               </form>
            </div>
         </div>
      </div>
   </div> 
</div>
</div>
<!-- end of modal -->
<!-- Modal -->
<div id=\"edit-order\" class=\"modal \" role=\"dialog\">
   <div class=\"modal-dialog\">
      <!-- Modal content-->
      <div class=\"modal-content\">
         <div class=\"modal-header\">
            <h4 class=\"modal-title\">Edit Orders</h4>
         </div>
         <div class=\"modal-body\">
            <div class=\"row\">
               <div class=\"col-12\">
                  <form method=\"post\" action=\"{{ path('update_order') }}\">
                     <div class=\"table-responsive\">
                        <table class=\"table table-hovered\">
                           <thead class=\"bg-primary text-white\">
                              <tr>
                                 <th style=\"color:#fff;\">Item</th>
                                 <th style=\"color:#fff;\">Qty</th>
                              </tr>
                           </thead>
                           <input type=\"hidden\" value=\"{{ order.id }}\" name=\"order\">
                           {% for item in order.customerOrderItems %}
                           <tr>
                              <td><input type=\"hidden\" value=\"{{ item.price }}\" name=\"price[]\">
<input type=\"hidden\" value=\"{{ item.quantity }}\" name=\"oqty[]\">
<input type=\"hidden\" value=\"{{ item.loyalty }}\" name=\"loyalty[]\">
<input type=\"hidden\" value=\"{{ item.id }}\" name=\"id[]\">{{ item.itemName }} - {{ item.priceVariavtion }}</td>
                              <td>
                                <select class=\"form-control\" name=\"qty[]\">
{% for i in item.quantity..0 %}
    <option>{{ i }}</option>
{% endfor %}
                                </select>
<textarea name=\"reason[]\" class=\"form-control\" style=\"display:block;width:100%\">{{ item.reason }}</textarea>
                              </td>
                           </tr>
                           {% endfor %} 
                            {% if order.promocode != '' %} 
                           <tr id=\"promo-a\">
                            <td>
                              <br>
                           <b>Promocode : {{ order.promocode }} <br>
                           Discount : {{ order.totalDiscount }}</b></td>
                            <td> <label for=\"promos\" id=\"trashs\"> <input type=\"checkbox\" name=\"promocheck\" id=\"promos\" class=\"form-control\" style=\"display:none;\"> <i class=\"fa fa-trash\" style=\"cursor:pointer;\" id=\"trash\"> </i> </label></td>                              
                            </tr> 
                             {% endif %} 
                        </table>
                       
                     
                      
                       
                     </div>
                     <button class=\"btn btn-success\" type=\"submit\">Save</button>
                     <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
               </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<!-- end of modal -->
<script type=\"text/javascript\">
\$('#trash').click(function(){
\$('#promo-a').hide();
// \$('#promos').prop('checked', true);

});
\$('#trashs').click(function(){
\$('#promo-a').hide();

});
</script>
<!-- Modal -->
<div id=\"myModal\" class=\"modal \" role=\"dialog\">
   <div class=\"modal-dialog\">
      <!-- Modal content-->
      <div class=\"modal-content\">
         <div class=\"modal-header\">
            <h4 class=\"modal-title\">Confirm Tray Items</h4>
         </div>
         <div class=\"modal-body\">
            <div class=\"row m-t-20\">
               <form method=\"post\" action=\"{{ path('create_tray_number') }}\">


                  <div class=\"col-md-12\">
                     <div class=\"form-group\">
                        <label>Update Tray Number</label> 
                        <input type=\"text\" name=\"traynumber\" class=\"form-control\" required=\"\" value=\"{{ order.tray }}\">
                        <input type=\"hidden\" name=\"orderid\" class=\"form-control\" required=\"\" value=\"{{ order.id }}\">
                     </div>
                     <button class=\"btn btn-primary\" type=\"submit\">update Tray Number</button>
                  </div>
               </form>
            </div>
         </div>
         <div class=\"modal-footer\">
            <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
         </div>
      </div>
   </div>
</div>
<!-- end of modal -->
<!-- tray status -->
<div id=\"trayStatus\" class=\"modal \" role=\"dialog\">
   <div class=\"modal-dialog\">
      <!-- Modal content-->
      <div class=\"modal-content\">
         <div class=\"modal-header\">
            <h4 class=\"modal-title\">Confirm Tray Items</h4>
         </div>
         <div class=\"modal-body\">
            <div class=\"row m-t-20\">
               <form method=\"post\" action=\"{{ path('update_tray_quantity') }}\" class=\"col-12\">
                  <div class=\"col-md-12\">
                     <div class=\"form-group\">
                        <label>Item Id</label> 
                        <input type=\"text\" id=\"barcode\" class=\"form-control\" placeholder=\"scan barcode here\">
                     </div>
                     <div class=\"form-group\">
                        <label>Select Item</label> 
                        <select name=\"traynumber\" class=\"form-control\" id=\"sels\">
                           {% for item in order.customerOrderItems %}
                           <option value=\"{{ item.id }}\" data-name=\"{{ item.itemName }}  - {{ item.priceVariavtion }}\" data-qty=\"{{ item.quantity }}\">{{ item.itemName }}  - {{ item.priceVariavtion }}</option>
                           {% endfor %}
                        </select>
                        <input type=\"hidden\" name=\"orderid\" class=\"form-control\" required=\"\" value=\"{{ order.id }}\">
                     </div>
                     <div class=\"form-group\">
                        <label>Enter Quantity</label> 
                        <input type=\"number\" id=\"quantity\" class=\"form-control\" >
                     </div>
                     <button class=\"btn btn-primary btn-sm\" type=\"button\" id=\"sel\">Add</button>
                  </div>
                  <br>
                  <div class=\"table-responsive\">
                     <table class=\"table table-hovered\" id=\"myTable\">
                        <thead class=\"bg-primary text-white\">
                           <tr>
                              <th>Item</th>
                              <th>Qty</th>
                              <th>Action</th>
                           </tr>
                        </thead>
                        {% for item in order.customerOrderItems %}
                        {% if item.isTray == '0' or item.isTray == ''  %} 
                        {% else %}
                        <tr>
                           <td><input type=\"hidden\" value=\"{{ item.quantity }}\" name=\"oqty[]\"><input type=\"hidden\" value=\"{{ item.id }}\" name=\"id[]\">{{ item.itemName }} - {{ item.priceVariavtion }}</td>
                           <td><input type=\"hidden\" value=\"{{ item.trayQty }}\" name=\"qty[]\">{{ item.trayQty }}</td>
                           <td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\"><i class=\"fa fa-trash\"></i></button></td>
                        </tr>
                        {% endif %}
                        {% endfor %}
                     </table>
                  </div>
                  <div class=\"form-group\">
                     <button class=\"btn btn-success\" type=\"submit\">Save</button>
                     <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>









<!-- end of tray status -->
<script type=\"text/javascript\">
\$( document ).ready(function() {
changeBackgroundColor();
});
   function changeBackgroundColor() {

      var select = \$('.otype');
      var selectedVal = \$('.otype').val();

      if(selectedVal == 'processing') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#009688');
         \$('.otype option').css('color', '#ffffff');

      } else if(selectedVal == 'ready') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#4caf50');
         \$('.otype option').css('color', '#ffffff');

      } else if(selectedVal == 'dispatched') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#ff5722');
         \$('.otype option').css('color', '#ffffff');

      } else if(selectedVal == 'delivered') {
         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#4caf50');
         \$('.otype option').css('color', '#ffffff');
         
      } else if(selectedVal == 'cancelled') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#e2a03f');
         \$('.otype option').css('color', '#ffffff');
         
      } else if(selectedVal == 'completed') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#8dbf42');
         \$('.otype option').css('color', '#ffffff');

      } else if(selectedVal == 'received') {

         \$('.otype').addClass('importantRule');
         \$('.otype').css('background-color', '#3f51b5');
         \$('.otype option').css('color', '#ffffff');
         
      }
   }
   \$('.otype').change(function(){
  
   changeBackgroundColor();

   var value=this.value;
   var val=\$('.otype').find('option:selected').text();

   // alert(val);
   if(val=='Assign To Delivery Boy' || val=='Reassign Order')
   {
    \$('.slot-time').hide();
    \$('#dboy').show();
       \$('#dboy').html('<div class=\"form-group\"><label for=\"appbundle_customerorder_orderBoy\" class=\"required\">Assign Task To</label><select class=\"form-control db\" name=\"delivery_boy\"></select></div>');
       getDelivery();
   }
   else if(val=='Reassign Picker' || val=='Assign To Picker')
   {
    \$('.slot-time').hide();
    \$('#dboy').show();
       \$('#dboy').html('<div class=\"form-group\"><label for=\"appbundle_customerorder_orderBoy\" class=\"required\">Assign Task To</label><select class=\"form-control db\" name=\"picker\"></select></div>');
       getPicker();
   }
      else if(val=='Reschedule Order')
   {
    // alert('delivery boy names come here!');
      \$('#dboy').hide();   
  \$('.slot-time').show();
   }

   else
   {
    \$('.slot-time').hide();
    \$('#dboy').hide();   
   }
   });
   
      function getPicker()
   {
   var out ={'branch':{{ app.user.branch }}};                      // alert(x);
   \$.ajax({
       type: \"POST\",
       url: \"/restaurant-manager/get-picker\",
       data: out,
       success: function (res, dataType) {
    // console.log('{{ path('manage_restaurant_get_cat') }}');
   send(res);
             
   // console.log(datas);
   
       },
       error: function (XMLHttpRequest, textStatus, errorThrown) {
           alert('Error : ' + errorThrown);
       }
   });
}
   function getDelivery()
   {
   var out ={'branch':{{ app.user.branch }}};                      // alert(x);
   \$.ajax({
       type: \"POST\",
       url: \"/restaurant-manager/get-del\",
       data: out,
       success: function (res, dataType) {
    // console.log('{{ path('manage_restaurant_get_cat') }}');
   send(res);
             
   // console.log(datas);
   
       },
       error: function (XMLHttpRequest, textStatus, errorThrown) {
           alert('Error : ' + errorThrown);
       }
   });
}
   function send(myObjects)
   {
   \$('.subcat').html('');
   \$.each(myObjects, function () {
       \$('.db').append('<option value=\"'+this.id+'\">'+this.value+'</option>');
         
       });            
      }
       function removeVariant(obj){
   // \$(this).attr(\"data-usr\" , '');
   
           \$(obj).parent().parent().remove();
   
       }
    \$('#sel').click(function () {
    var id=\$('#sels').val();
    var name = \$('#sels option:selected').attr('data-name');
    var qty=\$('#quantity').val();
    var barcode=\$('#barcode').val();
    if(barcode=='' || barcode == '0')
    {
    var oqty= \$('#sels option:selected').attr('data-qty');
    // alert(oqty);
   if(qty > oqty)
   {
       qty=qty;
   }
   // alert(qty);
    var output = \$('input[name=\"qty[]\"]').val();
   // if(typeof(output)=='undefined')
   // {
   // \$('#myTable').append('<tr><td><input type=\"hidden\" value=\"'+id+'\" name=\"id[]\">'+name+'</td><td><input type=\"hidden\" value=\"'+qty+'\" name=\"qty[]\">'+qty+'</td><td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\"><i class=\"fa fa-trash\"></i></button></td></tr>'); 
   // }   
     \$('#myTable').append('<tr><td><input type=\"hidden\" value=\"'+oqty+'\" name=\"oqty[]\"><input type=\"hidden\" value=\"'+id+'\" name=\"id[]\">'+name+'</td><td><input type=\"hidden\" value=\"'+qty+'\" name=\"qty[]\">'+qty+'</td><td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\"><i class=\"fa fa-trash\"></i></button></td></tr>'); 
        \$('#quantity').val(0);
//      \$('input[name=\"id[]\"]').each(function() {
//       var comp= \$(this).val(); 
//       console.log(comp);
//    if(id == comp)
//    {
//    // alert('item already in tray!');
//    \$(this).parent().parent().remove();


// } else
//   {

  

//  }
//  });
          
   }
   else
   {
   
   }
   
   // }
     // });
     
   
   
    });
    \$('#barcode').on('input propertychange paste', function() {
    var id=\$('#barcode').val();
     var inputlength = \$('#barcode').val().length;
       if (inputlength>4) {
   var out ={'order':{{ order.id }},'barcode':id};                      // alert(x);
   
   \$.ajax({
       type: \"POST\",
       url: \"{{ path('api_get_item_by_barcode')}}\",
       data: out,
       success: function (res, dataType) {
    // console.log('{{ path('manage_restaurant_get_cat') }}');
   // send(res);
   addbar(res);
             
   // console.log(datas);
   
       },
       error: function (XMLHttpRequest, textStatus, errorThrown) {
           alert('Error : ' + errorThrown);
       }
   });
   
             return false;
       }
     
   
   });
 
    function addbar(x)
    {
     var txt;
     if(x.status=='0')
     {
       \$('#barcode').val(0);
   alert('barcode is invalid!!');
     }
     else
     {
        var person = prompt(\"Please enter Quantity:\", x.quantity);
     if (person == null || person == \"\") {
       txt = \"User cancelled the prompt.\";
     } else {
       if(person > x.quantity)
   {
       person=x.quantity;
   }
             \$('#myTable').append('<tr><td><input type=\"hidden\" value=\"'+x.quantity+'\" name=\"oqty[]\"><input type=\"hidden\" value=\"'+x.id+'\" name=\"id[]\">'+x.name+'('+x.variation+')</td><td><input type=\"hidden\" value=\"'+person+'\" name=\"qty[]\">'+person+'</td><td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\"><i class=\"fa fa-trash\"></i></button></td></tr>'); 
        \$('#quantity').val(0);
     } 
     }
   
   }
   

                  \$('#payment_statuss').change(function(){
                    var status=\$('#payment_statuss').val();
                    // alert(status);
                    if(status=='cash')
                    {
                      \$('.ons').hide();
                    }
                    else
                    {
                       \$('.ons').show();
                    }

                  });
\$('#locationSlot').change(function(){
      var id=\$('#locationSlot').val();
    var date=\$('#locationSlot option:selected').attr('data-date');
    var time=\$('#locationSlot option:selected').attr('data-time');
        \$('#fixdate').val(date);
        \$('#fixtime').val(time);

});
  \$('#locationName').change(function(){
    var id=\$('#locationName').val();
        var area=\$('#locationName option:selected').attr('data-name');
        \$('#area').val(area);

    // alert(id);
var out ={'id':id};                      // alert(x);
\$.ajax({
  type: \"POST\",
  url: \"{{ path('get_slot_by_id') }}\",
  data: out,
  success: function (res, dataType) {
  \$('#locationSlot').html('<option>Select Slot</option>');
              \$.each(res,function () {
                \$('#locationSlot').append('<option value=\"'+this.time+'\"  data-time=\"'+this.time+'\"  data-date=\"'+this.date+'\" >'+this.time+' on '+this.date+'</option>');   
                }); 
},
error: function (XMLHttpRequest, textStatus, errorThrown) {
  alert('Error : ' + errorThrown);
}
});
});

                  </script>
{% endblock %}", "AppBundle:Admin:Orders/orderForm.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Orders/orderForm.html.twig");
    }
}

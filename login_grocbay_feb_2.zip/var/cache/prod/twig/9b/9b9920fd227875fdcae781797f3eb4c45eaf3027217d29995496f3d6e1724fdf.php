<?php

/* AppBundle:Admin:AppManager/categoryList.html.twig */
class __TwigTemplate_d8b3d00410c0f21dbcd3be53082d5771510b87df74863de1c7f70d9589e4269e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:AppManager/categoryList.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06b482f4a1191f28e3e4fb725686ead1d9fb54513b11e1b16180dfff1ed31961 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06b482f4a1191f28e3e4fb725686ead1d9fb54513b11e1b16180dfff1ed31961->enter($__internal_06b482f4a1191f28e3e4fb725686ead1d9fb54513b11e1b16180dfff1ed31961_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:AppManager/categoryList.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_06b482f4a1191f28e3e4fb725686ead1d9fb54513b11e1b16180dfff1ed31961->leave($__internal_06b482f4a1191f28e3e4fb725686ead1d9fb54513b11e1b16180dfff1ed31961_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_002f9426dcc060d8ad2f4de6613e8608692e7593416a2954a450b0f939c6f9f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_002f9426dcc060d8ad2f4de6613e8608692e7593416a2954a450b0f939c6f9f0->enter($__internal_002f9426dcc060d8ad2f4de6613e8608692e7593416a2954a450b0f939c6f9f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "<!--nestable CSS -->

<style>
</style>

";
        
        $__internal_002f9426dcc060d8ad2f4de6613e8608692e7593416a2954a450b0f939c6f9f0->leave($__internal_002f9426dcc060d8ad2f4de6613e8608692e7593416a2954a450b0f939c6f9f0_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_181c8794f12483b0f3bf96236dc458741f6b82fa8198858ca0d8ef159ad66a67 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_181c8794f12483b0f3bf96236dc458741f6b82fa8198858ca0d8ef159ad66a67->enter($__internal_181c8794f12483b0f3bf96236dc458741f6b82fa8198858ca0d8ef159ad66a67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"card\">
            ";
        // line 15
        echo "            <div class=\"card-body\">
                   <h4 class=\"card-title\">Manage Main Categories <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("export_category");
        echo "\" class=\"btn btn-primary btn-sm pull-right\">Export to CSV</a></h4>
                   <form method=\"post\" action=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("bulk_action_category");
        echo "\">


<div class=\"row order-info mt-3 mb-3 pl-3\" >
<div class=\"col-lg-2 col-md-2 col-8 mb-3 \">
<select class=\"form-control\" name=\"type\">
  <option value=\"0\">Activate</option>
  <option value=\"1\">Deactivate</option>
</select>
</div>
<div class=\"col-lg-2 col-md-2 col-8 mb-3 \">
<input type=\"submit\" class=\"btn btn-primary\" value=\"Update\">
</div>
</div>

                <table class=\"table table-hovered\" id=\"myTable\">
                    <thead>
                    <tr>
<th data-orderable=\"false\"><input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"selectThemAll\"></th>
                        <th>id</th>
                        <th>Category name</th>
                        <th>Visble</th>
                       <th>Priority</th>
                       <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                      <tbody>

                      </tbody>
                </table>
                </form>
            </div>
        </div>
    </div>
</div>
";
        
        $__internal_181c8794f12483b0f3bf96236dc458741f6b82fa8198858ca0d8ef159ad66a67->leave($__internal_181c8794f12483b0f3bf96236dc458741f6b82fa8198858ca0d8ef159ad66a67_prof);

    }

    // line 55
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_82f5ddf8dc34107ce0b136e21ff106486f9d416d24a167b29f02eccb571b799e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82f5ddf8dc34107ce0b136e21ff106486f9d416d24a167b29f02eccb571b799e->enter($__internal_82f5ddf8dc34107ce0b136e21ff106486f9d416d24a167b29f02eccb571b799e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 56
        echo "<!--Nestable js -->
<script src=\"/assets/plugins/nestable/jquery.nestable.js\"></script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
   \$(document).ready(function() {
      \$('#myTable').DataTable({   
         
      'processing': true,
      'serverSide': true,
      'serverMethod': 'post',
      'ajax': {
          'url':\"";
        // line 67
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_ajax_main_list");
        echo "\",
          'type': \"post\",
      },
      'columns': [
         {data: 'nested'},
         { data: 'id' },
         { data: 'categoryName' },
         { data: 'featured' },
         { data: 'priority' },
         { data: 'status' },
         { data: 'iconImage' },
      ],
   });
    });
      \$(function() {
    jQuery(\"[name=selectThemAll]\").click(function(source) { 
        checkboxes = jQuery('.tst');
        for(var i in checkboxes){
            checkboxes[i].checked = source.target.checked;
        }
    });
});

</script>
<script type=\"text/javascript\">
    \$(document).ready(function() {
        // Nestable

        //updateOutput(\$('#nestable').data('output', \$('#nestable-output')));
/*
        \$('#nestable-menu').on('click', function(e) {
            var target = \$(e.target),
                action = target.data('action');
            if (action === 'expand-all') {
                \$('.dd').nestable('expandAll');
            }
            if (action === 'collapse-all') {
                \$('.dd').nestable('collapseAll');
            }
        });*/

        \$('#nestable-menu').nestable();/*
        \$('.dd').nestable('collapseAll');*/
    });
    </script>

";
        
        $__internal_82f5ddf8dc34107ce0b136e21ff106486f9d416d24a167b29f02eccb571b799e->leave($__internal_82f5ddf8dc34107ce0b136e21ff106486f9d416d24a167b29f02eccb571b799e_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:AppManager/categoryList.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  136 => 67,  123 => 56,  117 => 55,  73 => 17,  69 => 16,  66 => 15,  60 => 10,  54 => 9,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}
{% block styles %}
<!--nestable CSS -->

<style>
</style>

{% endblock %}
{% block body %}

<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"card\">
            {# {{ path('category_create') }} #}
            <div class=\"card-body\">
                   <h4 class=\"card-title\">Manage Main Categories <a href=\"{{ path('export_category') }}\" class=\"btn btn-primary btn-sm pull-right\">Export to CSV</a></h4>
                   <form method=\"post\" action=\"{{ path('bulk_action_category')}}\">


<div class=\"row order-info mt-3 mb-3 pl-3\" >
<div class=\"col-lg-2 col-md-2 col-8 mb-3 \">
<select class=\"form-control\" name=\"type\">
  <option value=\"0\">Activate</option>
  <option value=\"1\">Deactivate</option>
</select>
</div>
<div class=\"col-lg-2 col-md-2 col-8 mb-3 \">
<input type=\"submit\" class=\"btn btn-primary\" value=\"Update\">
</div>
</div>

                <table class=\"table table-hovered\" id=\"myTable\">
                    <thead>
                    <tr>
<th data-orderable=\"false\"><input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"selectThemAll\"></th>
                        <th>id</th>
                        <th>Category name</th>
                        <th>Visble</th>
                       <th>Priority</th>
                       <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                      <tbody>

                      </tbody>
                </table>
                </form>
            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block scripts %}
<!--Nestable js -->
<script src=\"/assets/plugins/nestable/jquery.nestable.js\"></script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
   \$(document).ready(function() {
      \$('#myTable').DataTable({   
         
      'processing': true,
      'serverSide': true,
      'serverMethod': 'post',
      'ajax': {
          'url':\"{{ path('category_ajax_main_list')}}\",
          'type': \"post\",
      },
      'columns': [
         {data: 'nested'},
         { data: 'id' },
         { data: 'categoryName' },
         { data: 'featured' },
         { data: 'priority' },
         { data: 'status' },
         { data: 'iconImage' },
      ],
   });
    });
      \$(function() {
    jQuery(\"[name=selectThemAll]\").click(function(source) { 
        checkboxes = jQuery('.tst');
        for(var i in checkboxes){
            checkboxes[i].checked = source.target.checked;
        }
    });
});

</script>
<script type=\"text/javascript\">
    \$(document).ready(function() {
        // Nestable

        //updateOutput(\$('#nestable').data('output', \$('#nestable-output')));
/*
        \$('#nestable-menu').on('click', function(e) {
            var target = \$(e.target),
                action = target.data('action');
            if (action === 'expand-all') {
                \$('.dd').nestable('expandAll');
            }
            if (action === 'collapse-all') {
                \$('.dd').nestable('collapseAll');
            }
        });*/

        \$('#nestable-menu').nestable();/*
        \$('.dd').nestable('collapseAll');*/
    });
    </script>

{% endblock %}", "AppBundle:Admin:AppManager/categoryList.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/AppManager/categoryList.html.twig");
    }
}

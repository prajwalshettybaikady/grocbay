<?php

/* AppBundle:Admin:Pages/adminList.html.twig */
class __TwigTemplate_72ed4a623530b17af45eab1c5719c3a4c419f2a7aeba712a9fed363f781b221c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/adminList.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4ae3b876000933c51861b901db7b039c4c2cf0520280307f7b3b484ba732422b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4ae3b876000933c51861b901db7b039c4c2cf0520280307f7b3b484ba732422b->enter($__internal_4ae3b876000933c51861b901db7b039c4c2cf0520280307f7b3b484ba732422b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/adminList.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4ae3b876000933c51861b901db7b039c4c2cf0520280307f7b3b484ba732422b->leave($__internal_4ae3b876000933c51861b901db7b039c4c2cf0520280307f7b3b484ba732422b_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_14ca2bd93b356dd73c20f98a51de750ee31ec5063999dcff3618fee4c223ca96 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14ca2bd93b356dd73c20f98a51de750ee31ec5063999dcff3618fee4c223ca96->enter($__internal_14ca2bd93b356dd73c20f98a51de750ee31ec5063999dcff3618fee4c223ca96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                            <thead>
                                <tr>
                                    <th>User Name</th>
                                    <th>Email Id</th>
                                    <th>Mobile Number</th>
                                    <th>User Type</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["users"] ?? $this->getContext($context, "users")));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 22
            echo "                                <tr>
                                    <td>";
            // line 23
            echo twig_escape_filter($this->env, (($this->getAttribute($context["user"], "firstName", array()) . " ") . $this->getAttribute($context["user"], "lastName", array())), "html", null, true);
            echo "</td>
                                    <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "email", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "mobileNumber", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "userType", array()), "html", null, true);
            echo "</td>
                                    <td>
                                        ";
            // line 28
            if ($this->getAttribute($context["user"], "isActive", array())) {
                // line 29
                echo "                                            <a href=\"javascript:;\" class=\"btn btn-success btn-xs\">active</a>
                                            <a href=\"";
                // line 30
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_activate", array("id" => $this->getAttribute($context["user"], "id", array()))), "html", null, true);
                echo "\" class=\"btn btn-danger btn-xs\">X</a>
                                        ";
            } else {
                // line 32
                echo "                                            <a href=\"javascript:;\" class=\"btn btn-danger btn-xs\">inactive</a>
                                            <a href=\"";
                // line 33
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_activate", array("id" => $this->getAttribute($context["user"], "id", array()))), "html", null, true);
                echo "\" class=\"btn btn-success btn-xs\">
                                                <i class=\"fa fa-check\"></i>
                                            </a>
                                        ";
            }
            // line 37
            echo "                                    </td>
                                    <td>
                                        <a href=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_edit", array("id" => $this->getAttribute($context["user"], "id", array()))), "html", null, true);
            echo "\" title=\"Edit\" class=\"btn btn-primary btn-sm\">
                                            <i class=\"fa fa-edit\"></i>
                                        </a>
                                    </td>
                                </tr>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
";
        
        $__internal_14ca2bd93b356dd73c20f98a51de750ee31ec5063999dcff3618fee4c223ca96->leave($__internal_14ca2bd93b356dd73c20f98a51de750ee31ec5063999dcff3618fee4c223ca96_prof);

    }

    // line 54
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_357a347424f9c4bbd0ffc4151a5355f416c071d797b8e5a2b208c2b285543084 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_357a347424f9c4bbd0ffc4151a5355f416c071d797b8e5a2b208c2b285543084->enter($__internal_357a347424f9c4bbd0ffc4151a5355f416c071d797b8e5a2b208c2b285543084_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 55
        echo "
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
</script>
";
        
        $__internal_357a347424f9c4bbd0ffc4151a5355f416c071d797b8e5a2b208c2b285543084->leave($__internal_357a347424f9c4bbd0ffc4151a5355f416c071d797b8e5a2b208c2b285543084_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/adminList.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 55,  134 => 54,  120 => 45,  108 => 39,  104 => 37,  97 => 33,  94 => 32,  89 => 30,  86 => 29,  84 => 28,  79 => 26,  75 => 25,  71 => 24,  67 => 23,  64 => 22,  60 => 21,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}
<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                            <thead>
                                <tr>
                                    <th>User Name</th>
                                    <th>Email Id</th>
                                    <th>Mobile Number</th>
                                    <th>User Type</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {% for user in users %}
                                <tr>
                                    <td>{{ user.firstName ~ \" \" ~ user.lastName }}</td>
                                    <td>{{ user.email }}</td>
                                    <td>{{ user.mobileNumber }}</td>
                                    <td>{{ user.userType }}</td>
                                    <td>
                                        {% if user.isActive %}
                                            <a href=\"javascript:;\" class=\"btn btn-success btn-xs\">active</a>
                                            <a href=\"{{ path('admin_activate',{'id':user.id}) }}\" class=\"btn btn-danger btn-xs\">X</a>
                                        {% else %}
                                            <a href=\"javascript:;\" class=\"btn btn-danger btn-xs\">inactive</a>
                                            <a href=\"{{ path('admin_activate',{'id':user.id}) }}\" class=\"btn btn-success btn-xs\">
                                                <i class=\"fa fa-check\"></i>
                                            </a>
                                        {% endif %}
                                    </td>
                                    <td>
                                        <a href=\"{{ path('admin_edit',{'id':user.id})}}\" title=\"Edit\" class=\"btn btn-primary btn-sm\">
                                            <i class=\"fa fa-edit\"></i>
                                        </a>
                                    </td>
                                </tr>
                                {% endfor %}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
</script>
{% endblock %}", "AppBundle:Admin:Pages/adminList.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/adminList.html.twig");
    }
}

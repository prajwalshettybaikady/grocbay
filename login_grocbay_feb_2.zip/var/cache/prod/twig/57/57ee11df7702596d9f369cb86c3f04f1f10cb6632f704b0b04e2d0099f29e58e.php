<?php

/* AppBundle:Admin:Customers/viewWalletUser.html.twig */
class __TwigTemplate_a63c3441360a99ee00bd77110dfe326b1fab96c1423b281f5a46718d7c964ee7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Customers/viewWalletUser.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_88cf0a370e285bd0b6738fb2636cc67fe2b2f3202a6ffa347f00c9e81ac039c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88cf0a370e285bd0b6738fb2636cc67fe2b2f3202a6ffa347f00c9e81ac039c7->enter($__internal_88cf0a370e285bd0b6738fb2636cc67fe2b2f3202a6ffa347f00c9e81ac039c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Customers/viewWalletUser.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_88cf0a370e285bd0b6738fb2636cc67fe2b2f3202a6ffa347f00c9e81ac039c7->leave($__internal_88cf0a370e285bd0b6738fb2636cc67fe2b2f3202a6ffa347f00c9e81ac039c7_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_1987179d5c94be6f59cee5a4e7171e3edd6a2f70c0dc3d10ae787fa397d84a8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1987179d5c94be6f59cee5a4e7171e3edd6a2f70c0dc3d10ae787fa397d84a8d->enter($__internal_1987179d5c94be6f59cee5a4e7171e3edd6a2f70c0dc3d10ae787fa397d84a8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "<link rel=\"stylesheet\" type=\"text/css\" media=\"all\" href=\"/assets/css/star/rating.css\"/>
";
        
        $__internal_1987179d5c94be6f59cee5a4e7171e3edd6a2f70c0dc3d10ae787fa397d84a8d->leave($__internal_1987179d5c94be6f59cee5a4e7171e3edd6a2f70c0dc3d10ae787fa397d84a8d_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_dbd7b22f20a3040df356a56710065889f234d412fd9177475f9e590299242edf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dbd7b22f20a3040df356a56710065889f234d412fd9177475f9e590299242edf->enter($__internal_dbd7b22f20a3040df356a56710065889f234d412fd9177475f9e590299242edf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
<!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
      
<!-- Modal -->
<div id=\"edit\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Edit ";
        // line 20
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "username", array())), "html", null, true);
        echo "  </h4>
      </div>
      <div class=\"modal-body\">
<form method=\"post\" action=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("save_customer");
        echo "\">
  <div class=\"form-row\">
    <div class=\"col-12\">
      <label>First Name</label>
      <input type=\"text\" class=\"form-control\" placeholder=\"User Name\" value=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "username", array()), "html", null, true);
        echo "\" name=\"name\">
            <input type=\"hidden\" class=\"form-control\" placeholder=\"User Name\" value=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "id", array()), "html", null, true);
        echo "\" name=\"id\">

    </div>

  </div><br>
   <div class=\"form-group\">
            <label>Email</label>
      <input type=\"email\" class=\"form-control\" placeholder=\"Email\" value=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "email", array()), "html", null, true);
        echo "\" name=\"email\">
    </div>
      <div class=\"form-group\">
            <label>Gst</label>
      <input type=\"text\" class=\"form-control\" placeholder=\"Gst Number\" value=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "gst", array()), "html", null, true);
        echo "\" name=\"gst\">
    </div>
       <div class=\"form-group\">
            <label>Mobile Number</label>
      <input type=\"text\" class=\"form-control\" placeholder=\"Mobile Number\" value=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "mobileNumber", array()), "html", null, true);
        echo "\" required name=\"mobile\">
    </div>
</div>
      <div class=\"modal-footer\">
                <button type=\"submit\" class=\"btn btn-primary\">Save</button>

        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
      </form>

    </div>

  </div>
</div>


    <div class=\"row\">
            <!-- Column -->
            <div class=\"col-lg-3 col-xlg-3 col-md-4\">
                <div class=\"card\">
                    <div class=\"card-body\">

                        <center class=\"m-t-30\">
                            <h4 class=\"card-title m-t-10\">";
        // line 66
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "username", array())), "html", null, true);
        echo "</h4>
                             <input type=\"hidden\" id=\"userID\" value=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "id", array()), "html", null, true);
        echo "\" >

                            <h6 class=\"card-subtitle\">";
        // line 69
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "mobileNumber", array()), "html", null, true);
        echo "</h6>
                            <div class=\"row text-center justify-content-md-center\">
                                <div class=\"col-4\"><a href=\"javascript:void(0)\" class=\"link\"><i class=\"fa fa-shopping-cart\"></i> <font class=\"font-medium\">";
        // line 71
        echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "customerOrder", array())), "html", null, true);
        echo "</font></a></div>
                                <div class=\"col-4\"><a href=\"javascript:void(0)\" class=\"link\"><i class=\"fa fa-star-o\"></i> <font class=\"font-medium\">";
        // line 72
        echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "restaurantRatings", array())), "html", null, true);
        echo "</font></a></div>
                            </div>
                                                        <a href=\"#edit\"  data-toggle=\"modal\" data-target=\"#edit\"> <i class=\"fa fa-edit\"></i>edit</a>

                        </center>
                    </div>
                    <div>
                        <hr> 
                    </div>
                    <div class=\"card-body\"> 
                        <small class=\"text-muted\">Primary Email address </small>
                        <h6>";
        // line 83
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "email", array()), "html", null, true);
        echo "</h6>  <hr>
                           <small class=\"text-muted\">Gst Number </small>
                        <h6>";
        // line 85
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "gst", array()), "html", null, true);
        echo "</h6>  <hr>
                         <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Wallet Balance</small>
                        <h6>";
        // line 87
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["balance"] ?? $this->getContext($context, "balance")));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "prepaid", array()), "html", null, true);
            echo " ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</h6>  
<hr>    
        <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Loyalty Points</small>
                        <h6>";
        // line 90
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["balance"] ?? $this->getContext($context, "balance")));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "loyalty", array()), "html", null, true);
            echo " ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</h6>  
<hr>    

                <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Ip Address</small>
                <h6>";
        // line 94
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "ip", array()), "html", null, true);
        echo "</h6>  <hr>

                <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Device</small>
                <h6>";
        // line 97
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "device", array()), "html", null, true);
        echo "</h6>  <hr>

                <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Channel</small>
                <h6>";
        // line 100
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "channel", array()), "html", null, true);
        echo "</h6>  <hr>

                <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Registered Date</small>
                <h6>";
        // line 103
        echo twig_escape_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "createdDate", array()), "html", null, true);
        echo "</h6>  <hr>

            ";
        // line 117
        echo "                    </div>
                </div>
            </div>
    
    
                                
                             


";
        // line 127
        echo "

<!-- Trigger the modal with a button -->

<!-- Modal -->
<div id=\"setings\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Current Balance : ";
        // line 138
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["balance"] ?? $this->getContext($context, "balance")));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "postpaid", array()), "html", null, true);
            echo " ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</small>

        <h4 class=\"modal-title\">Settings</h4>
      </div>
      <div class=\"modal-body\">
        <div class=\"container-fluid\">
        <form>
<div class=\"form-group\">
<div class=\"row\">
<label>Duration For Credits</label>
<select class=\"form-control\" id=\"settingsDrop\">
    <option value=\"10\">10 Days</option>
    <option value=\"15\">15 Days</option>
     <option value=\"20\">20 Days</option>
      <option value=\"25\">25 Days</option>
       <option value=\"30\">30 Days</option>
        <option value=\"35\">35 Days</option>
         <option value=\"40\">40 Days</option>
          <option value=\"45\">45 Days</option>
          <option value=\"50\">50 Days</option>
          <option value=\"60\">60 Days</option>
</select>
</div>
</div>

<div class=\"form-group\">
<div class=\"row\">
<button type=\"button\" class=\"btn btn-success\" id=\"settingsSave\">Save</button>&nbsp;

</div>
</div>



</form>

<div class=\"form-group\">
<div class=\"row\">
</div>
</div>

</div>
</div>
  <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
</div>
</div>
    
            <!-- Column -->
            <!-- Column -->
            <div class=\"col-lg-9 col-xlg-9 col-md-8\">
                <div class=\"card\">
                    <!-- Nav tabs -->
                    <ul class=\"nav nav-tabs profile-tab\" role=\"tablist\">
                       
                        <li class=\"nav-item\"> <a class=\"nav-link active\" data-toggle=\"tab\" href=\"#prepaid\" role=\"tab\">Wallet</a> </li>
                        <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#loyalty\" role=\"tab\">Loyalty</a> </li>
                      ";
        // line 199
        echo "                           <!-- <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#reviews\" role=\"tab\">Reviews</a> </li> -->
                         <li class=\"nav-item\"> <a class=\"nav-link \" data-toggle=\"tab\" href=\"#latest-orders\" role=\"tab\">Order History</a> </li>
                        <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#customer-address\" role=\"tab\">Address</a> </li>
                        <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#membership-logs\" role=\"tab\">Membership History</a> </li>
                        <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#customer-logs\" role=\"tab\">Logs</a> </li>
                    </ul>

                    ";
        // line 207
        echo "     <div class=\"tab-content\">
                        <div class=\"tab-pane active\" id=\"prepaid\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <button class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#add-prepaid-credits\">Add Credits</button>
                                    <div class=\"table-responsive m-t-10\">
                                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                     <th>Description</th>
                                                    <th>Debit</th>
                                                    <th>Credit</th>
                                                    <th>Available Balance</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                             ";
        // line 224
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["prepaid"] ?? $this->getContext($context, "prepaid")));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            // line 225
            echo "                                             ";
            if ((($this->getAttribute($context["wallet"], "debit", array()) == 0) && ($this->getAttribute($context["wallet"], "credit", array()) == 0))) {
                // line 226
                echo "                                             ";
            } else {
                // line 227
                echo "                                                <tr>
                                                <th>";
                // line 228
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "id", array()), "html", null, true);
                echo "</th>
                                               <th>";
                // line 229
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "date", array()), "html", null, true);
                echo " at ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "dateTime", array()), "html", null, true);
                echo "</th>
                                                <th>";
                // line 230
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "note", array()), "html", null, true);
                echo "</th>
                                                <th>";
                // line 231
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "debit", array()), "html", null, true);
                echo "</th>
                                                <th>";
                // line 232
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "credit", array()), "html", null, true);
                echo "</th>
                                                <th>";
                // line 233
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "balance", array()), "html", null, true);
                echo "</th>
                                            </tr>
                                            ";
            }
            // line 236
            echo "                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 237
        echo "                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>
<!-- start of loyalty -->
    <div class=\"tab-pane\" id=\"loyalty\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <button class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#add-loyalty-points\">Add Loyalty Points</button>
                                    <div class=\"table-responsive m-t-10\">
                                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                     <th>Description</th>
                                                    <th>Debit</th>
                                                    <th>Credit</th>
                                                    <th>Available Points</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                             ";
        // line 259
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["loyaltyData"] ?? $this->getContext($context, "loyaltyData")));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            // line 260
            echo "                                             ";
            if ((($this->getAttribute($context["wallet"], "debit", array()) == 0) && ($this->getAttribute($context["wallet"], "credit", array()) == 0))) {
                // line 261
                echo "                                             ";
            } else {
                // line 262
                echo "                                                <tr>
                                                <th>";
                // line 263
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "id", array()), "html", null, true);
                echo "</th>
                                               <th>";
                // line 264
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "date", array()), "html", null, true);
                echo " at ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "dateTime", array()), "html", null, true);
                echo "</th>
                                                <th>";
                // line 265
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "note", array()), "html", null, true);
                echo "</th>
                                                <th>";
                // line 266
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "debit", array()), "html", null, true);
                echo "</th>
                                                <th>";
                // line 267
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "credit", array()), "html", null, true);
                echo "</th>
                                                <th>";
                // line 268
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "balance", array()), "html", null, true);
                echo "</th>
                                            </tr>
                                            ";
            }
            // line 271
            echo "                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 272
        echo "                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>
<!-- end of loyalty -->
                    ";
        // line 280
        echo "
<!-- Trigger the modal with a button -->
<div id=\"add-loyalty-points\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Current Points : ";
        // line 288
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["balance"] ?? $this->getContext($context, "balance")));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "loyalty", array()), "html", null, true);
            echo " ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</small>

        <h4 class=\"modal-title\">Add Points</h4>
      </div>
      <div class=\"modal-body\">
        <div class=\"container-fluid\">
        <form>
<div class=\"form-group\">
<div class=\"row\">
<label>No. Of Points</label>
<input type=\"text\" name=\"credits\" placeholder=\"100 credits\" required=\"\" class=\"form-control\" id=\"lprepaidcredit\">
</div>
</div>

<div class=\"form-group\">
<div class=\"row\">
<label>Note *</label>
<textarea name=\"credits\" placeholder=\"Added By Admin\" required=\"\" class=\"form-control\" id=\"lwalletnote\">Added by Admin</textarea>
</div>
</div>
<div class=\"form-group\">
<div class=\"row\">
<label>Payment Mode</label>
<select class=\"form-control\" required=\"\" name=\"duration\" id=\"lprepaidmode\">
    <option value=\"cash\">Cash</option>
    <option value=\"card\">Card</option>
    <option value=\"check\">Check</option>
    <option value=\"online\">Online Payment</option>
   </select>
</div>
</div>



<input class=\"form-control\" type=\"hidden\" id=\"lprepaidnotes\">


<div class=\"form-group\">
<div class=\"row\">
<button class=\"btn btn-success\" type=\"button\" id=\"addloyalty\">Add Credit</button>
</div>
</div>

        </form>

    
      </div>
  </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
";
        // line 344
        echo "<!-- Modal -->
<div id=\"add-prepaid-credits\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Current Balance : ";
        // line 351
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["balance"] ?? $this->getContext($context, "balance")));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "prepaid", array()), "html", null, true);
            echo " ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</small>

        <h4 class=\"modal-title\">Add Credits</h4>
      </div>
      <div class=\"modal-body\">
        <div class=\"container-fluid\">
        <form>
<div class=\"form-group\">
<div class=\"row\">
<label>No. Of Credits</label>
<input type=\"text\" name=\"credits\" placeholder=\"100 credits\" required=\"\" class=\"form-control\" id=\"prepaidcredit\">
</div>
</div>

<div class=\"form-group\">
<div class=\"row\">
<label>Note *</label>
<textarea name=\"credits\" placeholder=\"Added By Admin\" required=\"\" class=\"form-control\" id=\"walletnote\">Added by Admin</textarea>
</div>
</div>
<div class=\"form-group\">
<div class=\"row\">
<label>Payment Mode</label>
<select class=\"form-control\" required=\"\" name=\"duration\" id=\"prepaidmode\">
    <option value=\"cash\">Cash</option>
    <option value=\"card\">Card</option>
    <option value=\"check\">Check</option>
    <option value=\"online\">Online Payment</option>
   </select>
</div>
</div>



<input class=\"form-control\" type=\"hidden\" id=\"prepaidnotes\">


<div class=\"form-group\">
<div class=\"row\">
<button class=\"btn btn-success\" type=\"button\" id=\"addcredit\">Add Credit</button>
</div>
</div>

        </form>

    
      </div>
  </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
";
        // line 407
        echo "
";
        // line 409
        echo "


                       ";
        // line 413
        echo "                        <div class=\"tab-pane \" id=\"postpaid\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <button class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#add-credits\">Add Credits</button>

                             


";
        // line 421
        echo "

<!-- Trigger the modal with a button -->

<!-- Modal -->
<div id=\"add-credits\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Current Balance : ";
        // line 432
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["balance"] ?? $this->getContext($context, "balance")));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "postpaid", array()), "html", null, true);
            echo " ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</small>

        <h4 class=\"modal-title\">Add Credits</h4>
      </div>
      <div class=\"modal-body\">
        <div class=\"container-fluid\">
        <form>
<div class=\"form-group\">
<div class=\"row\">
<label>No. Of Credits</label>
<input type=\"text\" name=\"credits\" placeholder=\"100 credits\" required=\"\" class=\"form-control\" id=\"pocredits\">
</div>
</div>
";
        // line 456
        echo "
";
        // line 469
        echo "<div class=\"form-group\">
<div class=\"row\">
<button class=\"btn btn-success\" type=\"button\" id=\"poadd\">Add Credit</button>
</div>
</div>

        </form>
      </div>
  </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
";
        // line 486
        echo "
";
        // line 488
        echo "

<!-- Trigger the modal with a button -->







                                    <div class=\"table-responsive m-t-10\">
                                    <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                     <th>Description</th>
                                                    <th>Debit</th>
                                                    <th>Credit</th>
                                                    <th>Available Balance</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                             ";
        // line 511
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_reverse_filter($this->env, ($context["postpaid"] ?? $this->getContext($context, "postpaid"))));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            // line 512
            echo "                                                <tr>
                                                <th>";
            // line 513
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "id", array()), "html", null, true);
            echo "</th>
                                               <th>";
            // line 514
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "date", array()), "html", null, true);
            echo " at ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "dateTime", array()), "html", null, true);
            echo "</th>
                                                <th>";
            // line 515
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "note", array()), "html", null, true);
            echo "</th>
                                                <th>";
            // line 516
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "debit", array()), "html", null, true);
            echo "</th>
                                                <th>";
            // line 517
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "credit", array()), "html", null, true);
            echo "</th>
                                                <th>";
            // line 518
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "balance", array()), "html", null, true);
            echo "</th>
                                            </tr>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 521
        echo "                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>
                    ";
        // line 527
        echo "                    <!-- Tab panes -->
                        <div class=\"tab-pane\" id=\"latest-orders\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                    <div class=\"table-responsive m-t-10\">
                                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                            <thead>
                                                <tr>
                                                    <th>Order Number</th>
                                                    <th>Order Date</th>
                                                    <th>Status</th>
                                                    <th>Order Amount</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                ";
        // line 542
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_reverse_filter($this->env, $this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "customerOrder", array())));
        foreach ($context['_seq'] as $context["_key"] => $context["order"]) {
            // line 543
            echo "                                                    <tr>
                                                        <td>";
            // line 544
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "id", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 545
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["order"], "orderDate", array()), "d F Y"), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 546
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "orderStatus", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 547
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "orderAmount", array()), "html", null, true);
            echo "</td>
                                                        <td>  
                                                            <a href=\"";
            // line 549
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_orders_panel_update", array("id" => $this->getAttribute($context["order"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary btn-sm\"><i class=\"fa fa-eye\"></i></a>
                                                        </td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['order'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 553
        echo "                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>
  <!--second tab-->
                        <div class=\"tab-pane\" id=\"reccive\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                   <button class=\"btn btn-primary\"  data-toggle=\"modal\" data-target=\"#reccive-payment\">Reccive Payments</button>

                                <div class=\"table-responsive m-t-10\">
                                    <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                    <th>Due Balance</th>
                                                    <th>Due Duration</th>
                                                    <th>Paid Balance</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                             ";
        // line 576
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_reverse_filter($this->env, ($context["due"] ?? $this->getContext($context, "due"))));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            // line 577
            echo "                                                <tr>
                                                <th>";
            // line 578
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "id", array()), "html", null, true);
            echo "</th>
                                               <th>";
            // line 579
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "date", array()), "html", null, true);
            echo "</th>
                                                <th><a href=\"#\">
                                                    ";
            // line 581
            if (($this->getAttribute($context["wallet"], "balance", array()) < 0)) {
                // line 582
                echo "
                                                       Payement Reccived
                                                         ";
            } else {
                // line 585
                echo "                                                            ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "balance", array()), "html", null, true);
                echo "
                                                    ";
            }
            // line 587
            echo "                                                    </a></th>
                                                <th>";
            // line 588
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "duedate", array()), "html", null, true);
            echo " Days</th>
                                                <th>";
            // line 589
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "paid", array()), "html", null, true);
            echo "</th>
                                                 <th>

    ";
            // line 592
            if (($this->getAttribute($context["wallet"], "status", array()) == 0)) {
                // line 593
                echo "         <span style=\"font-weight:bold;color:red;font-size:14px;\">Pending</span> 
    ";
            } else {
                // line 595
                echo "         <span  style=\"font-weight:bold;color:green;font-size:14px;\">Paid</span> 
    ";
            }
            // line 597
            echo " </th>
                                            </tr>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 600
        echo "                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>

                        <!--second tab-->
                        <div class=\"tab-pane\" id=\"reviews\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <table class=\"table table-hovered\">
                                    <tr>
                                        <th>Restaurant</th>
                                        <th>Ratings</th>
                                        <th>Reviews</th>
                                    </tr>
                                ";
        // line 615
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "restaurantRatings", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["rating"]) {
            // line 616
            echo "                                    <tr>
                                        <td>";
            // line 617
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["rating"], "restaurant", array()), "restaurantName", array()), "html", null, true);
            echo "</td>
                                        <td>
                                            <div class=\"rating-wrap text-left margin-top-10\">
                                                <div class=\"star-ratings-sprite pull-left\">
                                                    <span style=\"width:";
            // line 621
            echo twig_escape_filter($this->env, ($this->getAttribute($context["rating"], "ratings", array()) * 20), "html", null, true);
            echo "%\" class=\"star-ratings-sprite-rating\"></span>
                                                </div>
                                                <span class=\"star-count pull-left margin-left-5\">(";
            // line 623
            echo twig_escape_filter($this->env, $this->getAttribute($context["rating"], "ratings", array()), "html", null, true);
            echo ")</span>
                                                <div class=\"clearfix\"></div>
                                            </div>
                                        </td>
                                        <td>";
            // line 627
            echo twig_escape_filter($this->env, $this->getAttribute($context["rating"], "reviews", array()), "html", null, true);
            echo "</td>
                                    </tr>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['rating'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 630
        echo "                            </table>
                            </div>
                        </div>

                        <div class=\"tab-pane\" id=\"customer-address\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <div class=\"table-responsive m-t-10\">
                                    <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                        <thead>
                                            <tr>
                                                <th>Type</th>
                                                <th>Name</th>
                                                <th>Address</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ";
        // line 646
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["customer"] ?? $this->getContext($context, "customer")), "billingAddress", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["address"]) {
            // line 647
            echo "                                            <tr>
                                                <td>
                                                    ";
            // line 649
            if (($this->getAttribute($context["address"], "addressType", array()) == "Home")) {
                // line 650
                echo "                                                        <a href=\"javascipt:;\"><i class=\"fa fa-home\"> Home</i></a>
                                                    ";
            } elseif (($this->getAttribute(            // line 651
$context["address"], "addressType", array()) == "Work")) {
                // line 652
                echo "                                                        <a href=\"javascipt:;\"><i class=\"fa fa-building\"></i> Work</a>
                                                    ";
            } else {
                // line 654
                echo "                                                        <a href=\"javascipt:;\"><i class=\"fa fa-universal-access\"></i> Others</a>
                                                    ";
            }
            // line 656
            echo "                                                </td>
                                                <td>";
            // line 657
            echo twig_escape_filter($this->env, $this->getAttribute($context["address"], "fullName", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 658
            echo twig_escape_filter($this->env, $this->getAttribute($context["address"], "address", array()), "html", null, true);
            echo "</td>
                                            </tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['address'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 661
        echo "                                        </tbody>
                                    </table>
                                </div>
                                <div class=\"clearfix\"></div>
                            </div>
                        </div>

                        <div class=\"tab-pane\" id=\"membership-logs\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <div class=\"table-responsive m-t-10\">
                                    <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Purchased Date</th>
                                                <th>Expiry Date</th>
                                                <th>Login Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                      ";
        // line 681
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["membership"] ?? $this->getContext($context, "membership")));
        foreach ($context['_seq'] as $context["_key"] => $context["mem"]) {
            echo "                                   
                                             <tr>
                                                <td>";
            // line 683
            echo twig_escape_filter($this->env, $this->getAttribute($context["mem"], "name", array()), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mem"], "duration", array()), "html", null, true);
            echo " Month </td>
                                                <td>";
            // line 684
            echo twig_escape_filter($this->env, $this->getAttribute($context["mem"], "purchased_date", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 685
            echo twig_escape_filter($this->env, $this->getAttribute($context["mem"], "expiry_date", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 686
            if (($this->getAttribute($context["mem"], "status", array()) == 0)) {
                echo " Deactivated ";
            } elseif (($this->getAttribute($context["mem"], "status", array()) == 2)) {
                echo "Hold";
            } else {
                echo "Active ";
            }
            echo "</td>
                                            </tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mem'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 689
        echo "                                        </tbody>
                                    </table>
                                </div>
                                <div class=\"clearfix\"></div>
                            </div>
                        </div>
                        <div class=\"tab-pane\" id=\"customer-logs\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <div class=\"table-responsive m-t-10\">
                                    <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                        <thead>
                                            <tr>
                                                <th>IP Address</th>
                                                <th>Device</th>
                                                <th>Channel</th>
                                                <th>Login Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ";
        // line 708
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["cutomerlogs"] ?? $this->getContext($context, "cutomerlogs")));
        foreach ($context['_seq'] as $context["_key"] => $context["logs"]) {
            // line 709
            echo "                                            <tr>
                                                <td>";
            // line 710
            echo twig_escape_filter($this->env, $this->getAttribute($context["logs"], "ip", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 711
            echo twig_escape_filter($this->env, $this->getAttribute($context["logs"], "device", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 712
            echo twig_escape_filter($this->env, $this->getAttribute($context["logs"], "channel", array()), "html", null, true);
            echo "</td>
                                                <td>";
            // line 713
            echo twig_escape_filter($this->env, $this->getAttribute($context["logs"], "created_date", array()), "html", null, true);
            echo "</td>
                                            </tr>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['logs'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 716
        echo "                                        </tbody>
                                    </table>
                                </div>
                                <div class=\"clearfix\"></div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
        <!-- Row -->


<!-- Modal -->
<div id=\"reccive-payment\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Current Balance : ";
        // line 738
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["balance"] ?? $this->getContext($context, "balance")));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "postpaid", array()), "html", null, true);
            echo " ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</small>

        <h4 class=\"modal-title\">Reccive Payments</h4>
      </div>
      <div class=\"modal-body\">
        <div class=\"container-fluid\">
        <form>
<div class=\"form-group\">
<div class=\"row\">
<label>Select Credit</label>
<select class=\"form-control\" required=\"\" name=\"duration\" id=\"rid\">
      ";
        // line 749
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["due"] ?? $this->getContext($context, "due")));
        foreach ($context['_seq'] as $context["_key"] => $context["wallet"]) {
            // line 750
            echo "        ";
            if (($this->getAttribute($context["wallet"], "status", array()) == 0)) {
                // line 751
                echo "    <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "balance", array()), "html", null, true);
                echo " on ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["wallet"], "date", array()), "html", null, true);
                echo "</option>

        ";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wallet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 755
        echo "   </select>
</div>
</div>

<div class=\"form-group\">
<div class=\"row\">
<label>Reccived Amount</label>
<input type=\"text\" class=\"form-control\" placeholder=\"1000\" id=\"ramount\">
</textarea>
</div>
</div>

<div class=\"form-group\">
<div class=\"row\">
<label>Payment Mode</label>
<select class=\"form-control\" required=\"\" name=\"duration\" id=\"rmode\">
    <option value=\"cash\">Cash</option>
    <option value=\"card\">Card</option>
    <option value=\"check\">Check</option>
    <option value=\"online\">Online Payment</option>
   </select>
</div>
</div>





<div class=\"form-group\">
<div class=\"row\">
<button class=\"btn btn-success\" type=\"submit\" id=\"radd\">Reccive Payment</button>
</div>
</div>

        </form>
      </div>
  </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
";
        // line 800
        echo "
     
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
";
        
        $__internal_dbd7b22f20a3040df356a56710065889f234d412fd9177475f9e590299242edf->leave($__internal_dbd7b22f20a3040df356a56710065889f234d412fd9177475f9e590299242edf_prof);

    }

    // line 809
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_a753d69206d0e273960fcfd0e41c86e55502606ee4cdc69ebed3459a6af74a63 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a753d69206d0e273960fcfd0e41c86e55502606ee4cdc69ebed3459a6af74a63->enter($__internal_a753d69206d0e273960fcfd0e41c86e55502606ee4cdc69ebed3459a6af74a63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 810
        echo "<script type=\"text/javascript\">
  //to add prepaid
        \$('#addcredit').click(function(){
          var credits=parseInt(\$('#prepaidcredit').val());
          var mode=\$('#prepaidmode').val();
          var notes=\$('#prepaidnotes').val();
          var userID=\$('#userID').val();
          var walletnote=\$('#walletnote').val();
          
if(isNaN(credits))
{
    alert('Please enter valid Credits');
}
else
{
    var url='";
        // line 825
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_credit_to_wallet");
        echo "';
 
    var data={\"userID\":userID,\"mode\":mode,\"credits\":credits,\"note\":walletnote};

ajax(url,data,location.reload());
}
});
\$('#radd').click(function(){
var credits=parseInt(\$('#ramount').val());
var mode=\$('#rmode').val();
var id=\$('#rid').val();
var userID=\$('#userID').val();
if(credits<1 || isNaN(credits))
{
    alert('Please enter valid amount');
}
else
{
    var url='";
        // line 843
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("reccive_postpaid_payments");
        echo "';
 
    var data={\"userID\":userID,\"mode\":mode,\"credits\":credits,\"id\":id};

ajax(url,data,location.reload());
}
}); 
//to add loyalty
        \$('#addloyalty').click(function(){
          var credits=parseInt(\$('#lprepaidcredit').val());
          var mode=\$('#lprepaidmode').val();
          var notes=\$('#lprepaidnotes').val();
          var userID=\$('#userID').val();
          var walletnote=\$('#lwalletnote').val();
          
if(isNaN(credits))
{
    alert('Please enter valid Points');
}
else
{
    var url='";
        // line 864
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_credit_to_loyalty");
        echo "';
 
    var data={\"userID\":userID,\"mode\":mode,\"credits\":credits,\"note\":walletnote};
// alert(url)
 ajax(url,data,location.reload());
}
});
\$('#radd').click(function(){
var credits=parseInt(\$('#ramount').val());
var mode=\$('#rmode').val();
var id=\$('#rid').val();
var userID=\$('#userID').val();
if(credits<1 || isNaN(credits))
{
    alert('Please enter valid amount');
}
else
{
    var url='";
        // line 882
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("reccive_postpaid_payments");
        echo "';
 
    var data={\"userID\":userID,\"mode\":mode,\"credits\":credits,\"id\":id};

ajax(url,data,location.reload());
}
});
addloyalty
//to add postpaid
 \$('#poadd').click(function(){
          var credits=parseInt(\$('#pocredits').val());
          var mode='dummy';
          var duration='15';
          var userID=\$('#userID').val();
if(credits==0 || isNaN(credits))
{
    alert('Please enter valid Credits');
}
else
{
    var url='";
        // line 902
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_credit_to_wallet_postpaid");
        echo "';
 
    var data={\"userID\":userID,\"mode\":'null',\"credits\":credits,\"note\":'Credit From Marketbhaav',\"duration\":duration};
// console.log()
ajax(url,data,location.reload());
}
 });
 //to add postpaid
 \$('#settingsSave').click(function(){
          var drop=\$('#settingsDrop').val();
          
          var userID=\$('#userID').val();


    var url='";
        // line 916
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_duration_postpaid");
        echo "';
 
    var data={\"userID\":userID,\"drop\":drop};
    // alert(data)
// console.log()
ajax(url,data,alert('Credit Duration changed to '+drop+' Days'));

 });

// blockP
 //to add postpaid
 \$('#blockP').click(function(){
          
          var userID=\$('#userID').val();
      


    var url='";
        // line 933
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("block_duration_postpaid");
        echo "';
 
    var data={\"userID\":userID,\"status\":'1'};
    // alert(data)
// console.log()
ajax(url,data,location.reload());

 });
 \$('#unblockP').click(function(){
          
          var userID=\$('#userID').val();
      


    var url='";
        // line 947
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("block_duration_postpaid");
        echo "';
 
    var data={\"userID\":userID,\"status\":'0'};
    // alert(data)
// console.log()
ajax(url,data,location.reload());

 });
function ajax(url,data,output)
 {

\$.ajax({
    type: \"POST\",
    url: url,
    data: data,
    success: function (data, dataType) {
output;
location.reload();
    },
    error: function (XMLHttpRequest, textStatus, errorThrown) {
        alert('Error : ' + errorThrown);
    }
});
}
 </script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable(
            {
                \"aaSorting\": [[0, 'desc']],
            }
        );
    });



</script>
";
        
        $__internal_a753d69206d0e273960fcfd0e41c86e55502606ee4cdc69ebed3459a6af74a63->leave($__internal_a753d69206d0e273960fcfd0e41c86e55502606ee4cdc69ebed3459a6af74a63_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Customers/viewWalletUser.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1424 => 947,  1407 => 933,  1387 => 916,  1370 => 902,  1347 => 882,  1326 => 864,  1302 => 843,  1281 => 825,  1264 => 810,  1258 => 809,  1246 => 800,  1200 => 755,  1185 => 751,  1182 => 750,  1178 => 749,  1156 => 738,  1132 => 716,  1123 => 713,  1119 => 712,  1115 => 711,  1111 => 710,  1108 => 709,  1104 => 708,  1083 => 689,  1068 => 686,  1064 => 685,  1060 => 684,  1054 => 683,  1047 => 681,  1025 => 661,  1016 => 658,  1012 => 657,  1009 => 656,  1005 => 654,  1001 => 652,  999 => 651,  996 => 650,  994 => 649,  990 => 647,  986 => 646,  968 => 630,  959 => 627,  952 => 623,  947 => 621,  940 => 617,  937 => 616,  933 => 615,  916 => 600,  908 => 597,  904 => 595,  900 => 593,  898 => 592,  892 => 589,  888 => 588,  885 => 587,  879 => 585,  874 => 582,  872 => 581,  867 => 579,  863 => 578,  860 => 577,  856 => 576,  831 => 553,  821 => 549,  816 => 547,  812 => 546,  808 => 545,  804 => 544,  801 => 543,  797 => 542,  780 => 527,  773 => 521,  764 => 518,  760 => 517,  756 => 516,  752 => 515,  746 => 514,  742 => 513,  739 => 512,  735 => 511,  710 => 488,  707 => 486,  689 => 469,  686 => 456,  662 => 432,  649 => 421,  640 => 413,  635 => 409,  632 => 407,  566 => 351,  557 => 344,  491 => 288,  481 => 280,  473 => 272,  467 => 271,  461 => 268,  457 => 267,  453 => 266,  449 => 265,  443 => 264,  439 => 263,  436 => 262,  433 => 261,  430 => 260,  426 => 259,  402 => 237,  396 => 236,  390 => 233,  386 => 232,  382 => 231,  378 => 230,  372 => 229,  368 => 228,  365 => 227,  362 => 226,  359 => 225,  355 => 224,  336 => 207,  327 => 199,  257 => 138,  244 => 127,  233 => 117,  228 => 103,  222 => 100,  216 => 97,  210 => 94,  195 => 90,  181 => 87,  176 => 85,  171 => 83,  157 => 72,  153 => 71,  148 => 69,  143 => 67,  139 => 66,  113 => 43,  106 => 39,  99 => 35,  89 => 28,  85 => 27,  78 => 23,  72 => 20,  56 => 6,  50 => 5,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}
{% block styles %}
<link rel=\"stylesheet\" type=\"text/css\" media=\"all\" href=\"/assets/css/star/rating.css\"/>
{% endblock %}
{% block body %}

<!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
      
<!-- Modal -->
<div id=\"edit\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Edit {{ customer.username|upper }}  </h4>
      </div>
      <div class=\"modal-body\">
<form method=\"post\" action=\"{{ path('save_customer')}}\">
  <div class=\"form-row\">
    <div class=\"col-12\">
      <label>First Name</label>
      <input type=\"text\" class=\"form-control\" placeholder=\"User Name\" value=\"{{ customer.username}}\" name=\"name\">
            <input type=\"hidden\" class=\"form-control\" placeholder=\"User Name\" value=\"{{ customer.id}}\" name=\"id\">

    </div>

  </div><br>
   <div class=\"form-group\">
            <label>Email</label>
      <input type=\"email\" class=\"form-control\" placeholder=\"Email\" value=\"{{ customer.email}}\" name=\"email\">
    </div>
      <div class=\"form-group\">
            <label>Gst</label>
      <input type=\"text\" class=\"form-control\" placeholder=\"Gst Number\" value=\"{{ customer.gst}}\" name=\"gst\">
    </div>
       <div class=\"form-group\">
            <label>Mobile Number</label>
      <input type=\"text\" class=\"form-control\" placeholder=\"Mobile Number\" value=\"{{ customer.mobileNumber}}\" required name=\"mobile\">
    </div>
</div>
      <div class=\"modal-footer\">
                <button type=\"submit\" class=\"btn btn-primary\">Save</button>

        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
      </form>

    </div>

  </div>
</div>


    <div class=\"row\">
            <!-- Column -->
            <div class=\"col-lg-3 col-xlg-3 col-md-4\">
                <div class=\"card\">
                    <div class=\"card-body\">

                        <center class=\"m-t-30\">
                            <h4 class=\"card-title m-t-10\">{{ customer.username|upper }}</h4>
                             <input type=\"hidden\" id=\"userID\" value=\"{{ customer.id }}\" >

                            <h6 class=\"card-subtitle\">{{ customer.mobileNumber }}</h6>
                            <div class=\"row text-center justify-content-md-center\">
                                <div class=\"col-4\"><a href=\"javascript:void(0)\" class=\"link\"><i class=\"fa fa-shopping-cart\"></i> <font class=\"font-medium\">{{ customer.customerOrder|length }}</font></a></div>
                                <div class=\"col-4\"><a href=\"javascript:void(0)\" class=\"link\"><i class=\"fa fa-star-o\"></i> <font class=\"font-medium\">{{ customer.restaurantRatings|length }}</font></a></div>
                            </div>
                                                        <a href=\"#edit\"  data-toggle=\"modal\" data-target=\"#edit\"> <i class=\"fa fa-edit\"></i>edit</a>

                        </center>
                    </div>
                    <div>
                        <hr> 
                    </div>
                    <div class=\"card-body\"> 
                        <small class=\"text-muted\">Primary Email address </small>
                        <h6>{{ customer.email }}</h6>  <hr>
                           <small class=\"text-muted\">Gst Number </small>
                        <h6>{{ customer.gst }}</h6>  <hr>
                         <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Wallet Balance</small>
                        <h6>{% for wallet in balance %}{{ wallet.prepaid }} {% endfor %}</h6>  
<hr>    
        <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Loyalty Points</small>
                        <h6>{% for wallet in balance %}{{ wallet.loyalty }} {% endfor %}</h6>  
<hr>    

                <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Ip Address</small>
                <h6>{{ customer.ip }}</h6>  <hr>

                <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Device</small>
                <h6>{{ customer.device }}</h6>  <hr>

                <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Channel</small>
                <h6>{{ customer.channel }}</h6>  <hr>

                <small class=\"text-muted\" style=\"color:#e91e63 !important;font-weight:bold;\">Registered Date</small>
                <h6>{{ customer.createdDate }}</h6>  <hr>

            {#                <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Postpaid Balance</small>
                        <h6>{% for wallet in balance %}{{ wallet.postpaid }} {% endfor %}</h6>  
<hr>
  <span data-toggle=\"modal\" data-target=\"#setings\" style=\"font-size: 10px;/* font-weight:bold; */color:#fff;background: #9d498a;color: #fff;cursor: pointer;padding: 6px;border-radius: 4px;text-align: center;\">Change Credit Duration</span>
 {% for wallet in balance %}
  {% if wallet.status == 0 %}
   <span  style=\"font-size: 10px;/* font-weight:bold; */color:#fff;background: #9d498a;color: #fff;cursor: pointer;padding: 6px;border-radius: 4px;text-align: center;\" id=\"blockP\">Block</span>

{% else %}
      <span  style=\"font-size: 10px;/* font-weight:bold; */color:#fff;background:green;color: #fff;cursor: pointer;padding: 6px;border-radius: 4px;text-align: center;\" id=\"unblockP\">unblock</span>
{% endif %}
{% endfor %} #}
                    </div>
                </div>
            </div>
    
    
                                
                             


{# modal  1 for add postpaid credits#}


<!-- Trigger the modal with a button -->

<!-- Modal -->
<div id=\"setings\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Current Balance : {% for wallet in balance %}{{ wallet.postpaid }} {% endfor %}</small>

        <h4 class=\"modal-title\">Settings</h4>
      </div>
      <div class=\"modal-body\">
        <div class=\"container-fluid\">
        <form>
<div class=\"form-group\">
<div class=\"row\">
<label>Duration For Credits</label>
<select class=\"form-control\" id=\"settingsDrop\">
    <option value=\"10\">10 Days</option>
    <option value=\"15\">15 Days</option>
     <option value=\"20\">20 Days</option>
      <option value=\"25\">25 Days</option>
       <option value=\"30\">30 Days</option>
        <option value=\"35\">35 Days</option>
         <option value=\"40\">40 Days</option>
          <option value=\"45\">45 Days</option>
          <option value=\"50\">50 Days</option>
          <option value=\"60\">60 Days</option>
</select>
</div>
</div>

<div class=\"form-group\">
<div class=\"row\">
<button type=\"button\" class=\"btn btn-success\" id=\"settingsSave\">Save</button>&nbsp;

</div>
</div>



</form>

<div class=\"form-group\">
<div class=\"row\">
</div>
</div>

</div>
</div>
  <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
</div>
</div>
    
            <!-- Column -->
            <!-- Column -->
            <div class=\"col-lg-9 col-xlg-9 col-md-8\">
                <div class=\"card\">
                    <!-- Nav tabs -->
                    <ul class=\"nav nav-tabs profile-tab\" role=\"tablist\">
                       
                        <li class=\"nav-item\"> <a class=\"nav-link active\" data-toggle=\"tab\" href=\"#prepaid\" role=\"tab\">Wallet</a> </li>
                        <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#loyalty\" role=\"tab\">Loyalty</a> </li>
                      {#   <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#postpaid\" role=\"tab\">Postpaid</a> </li>
                          <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#reccive\" role=\"tab\">Receive Payments</a> </li> #}
                           <!-- <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#reviews\" role=\"tab\">Reviews</a> </li> -->
                         <li class=\"nav-item\"> <a class=\"nav-link \" data-toggle=\"tab\" href=\"#latest-orders\" role=\"tab\">Order History</a> </li>
                        <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#customer-address\" role=\"tab\">Address</a> </li>
                        <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#membership-logs\" role=\"tab\">Membership History</a> </li>
                        <li class=\"nav-item\"> <a class=\"nav-link\" data-toggle=\"tab\" href=\"#customer-logs\" role=\"tab\">Logs</a> </li>
                    </ul>

                    {# prepaid start #}
     <div class=\"tab-content\">
                        <div class=\"tab-pane active\" id=\"prepaid\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <button class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#add-prepaid-credits\">Add Credits</button>
                                    <div class=\"table-responsive m-t-10\">
                                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                     <th>Description</th>
                                                    <th>Debit</th>
                                                    <th>Credit</th>
                                                    <th>Available Balance</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                             {% for wallet in prepaid %}
                                             {% if wallet.debit == 0  and wallet.credit == 0 %}
                                             {% else %}
                                                <tr>
                                                <th>{{ wallet.id }}</th>
                                               <th>{{ wallet.date }} at {{ wallet.dateTime }}</th>
                                                <th>{{ wallet.note }}</th>
                                                <th>{{ wallet.debit }}</th>
                                                <th>{{ wallet.credit }}</th>
                                                <th>{{ wallet.balance }}</th>
                                            </tr>
                                            {% endif %}
                                        {% endfor %}
                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>
<!-- start of loyalty -->
    <div class=\"tab-pane\" id=\"loyalty\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <button class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#add-loyalty-points\">Add Loyalty Points</button>
                                    <div class=\"table-responsive m-t-10\">
                                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                     <th>Description</th>
                                                    <th>Debit</th>
                                                    <th>Credit</th>
                                                    <th>Available Points</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                             {% for wallet in loyaltyData %}
                                             {% if wallet.debit == 0  and wallet.credit == 0 %}
                                             {% else %}
                                                <tr>
                                                <th>{{ wallet.id }}</th>
                                               <th>{{ wallet.date }} at {{ wallet.dateTime }}</th>
                                                <th>{{ wallet.note }}</th>
                                                <th>{{ wallet.debit }}</th>
                                                <th>{{ wallet.credit }}</th>
                                                <th>{{ wallet.balance }}</th>
                                            </tr>
                                            {% endif %}
                                        {% endfor %}
                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>
<!-- end of loyalty -->
                    {# end prepaid #}
{# modal  for add postpaid credits#}

<!-- Trigger the modal with a button -->
<div id=\"add-loyalty-points\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Current Points : {% for wallet in balance %}{{ wallet.loyalty }} {% endfor %}</small>

        <h4 class=\"modal-title\">Add Points</h4>
      </div>
      <div class=\"modal-body\">
        <div class=\"container-fluid\">
        <form>
<div class=\"form-group\">
<div class=\"row\">
<label>No. Of Points</label>
<input type=\"text\" name=\"credits\" placeholder=\"100 credits\" required=\"\" class=\"form-control\" id=\"lprepaidcredit\">
</div>
</div>

<div class=\"form-group\">
<div class=\"row\">
<label>Note *</label>
<textarea name=\"credits\" placeholder=\"Added By Admin\" required=\"\" class=\"form-control\" id=\"lwalletnote\">Added by Admin</textarea>
</div>
</div>
<div class=\"form-group\">
<div class=\"row\">
<label>Payment Mode</label>
<select class=\"form-control\" required=\"\" name=\"duration\" id=\"lprepaidmode\">
    <option value=\"cash\">Cash</option>
    <option value=\"card\">Card</option>
    <option value=\"check\">Check</option>
    <option value=\"online\">Online Payment</option>
   </select>
</div>
</div>



<input class=\"form-control\" type=\"hidden\" id=\"lprepaidnotes\">


<div class=\"form-group\">
<div class=\"row\">
<button class=\"btn btn-success\" type=\"button\" id=\"addloyalty\">Add Credit</button>
</div>
</div>

        </form>

    
      </div>
  </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
{# prepaid #}
<!-- Modal -->
<div id=\"add-prepaid-credits\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Current Balance : {% for wallet in balance %}{{ wallet.prepaid }} {% endfor %}</small>

        <h4 class=\"modal-title\">Add Credits</h4>
      </div>
      <div class=\"modal-body\">
        <div class=\"container-fluid\">
        <form>
<div class=\"form-group\">
<div class=\"row\">
<label>No. Of Credits</label>
<input type=\"text\" name=\"credits\" placeholder=\"100 credits\" required=\"\" class=\"form-control\" id=\"prepaidcredit\">
</div>
</div>

<div class=\"form-group\">
<div class=\"row\">
<label>Note *</label>
<textarea name=\"credits\" placeholder=\"Added By Admin\" required=\"\" class=\"form-control\" id=\"walletnote\">Added by Admin</textarea>
</div>
</div>
<div class=\"form-group\">
<div class=\"row\">
<label>Payment Mode</label>
<select class=\"form-control\" required=\"\" name=\"duration\" id=\"prepaidmode\">
    <option value=\"cash\">Cash</option>
    <option value=\"card\">Card</option>
    <option value=\"check\">Check</option>
    <option value=\"online\">Online Payment</option>
   </select>
</div>
</div>



<input class=\"form-control\" type=\"hidden\" id=\"prepaidnotes\">


<div class=\"form-group\">
<div class=\"row\">
<button class=\"btn btn-success\" type=\"button\" id=\"addcredit\">Add Credit</button>
</div>
</div>

        </form>

    
      </div>
  </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
{# end of modal 1 #}

{# modal     for recive postpaid credits#}



                       {# postpaid start #}
                        <div class=\"tab-pane \" id=\"postpaid\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <button class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#add-credits\">Add Credits</button>

                             


{# modal  1 for add postpaid credits#}


<!-- Trigger the modal with a button -->

<!-- Modal -->
<div id=\"add-credits\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Current Balance : {% for wallet in balance %}{{ wallet.postpaid }} {% endfor %}</small>

        <h4 class=\"modal-title\">Add Credits</h4>
      </div>
      <div class=\"modal-body\">
        <div class=\"container-fluid\">
        <form>
<div class=\"form-group\">
<div class=\"row\">
<label>No. Of Credits</label>
<input type=\"text\" name=\"credits\" placeholder=\"100 credits\" required=\"\" class=\"form-control\" id=\"pocredits\">
</div>
</div>
{# <div class=\"form-group\">
<div class=\"row\">
<label>Payment Mode</label>
<select class=\"form-control\" required=\"\" name=\"duration\" id=\"pomode\">
    <option value=\"cash\">Cash</option>
    <option value=\"card\">Card</option>
    <option value=\"check\">Check</option>
    <option value=\"online\">Online Payment</option>
   </select>
</div>
</div> #}

{# <div class=\"form-group\">
<div class=\"row\">
<label>Credit Duration</label>
<select class=\"form-control\" required=\"\" name=\"duration\" id=\"poduration\">
    <option value=\"15\">15 Days</option>
    <option value=\"20\">20 Days</option>
    <option value=\"25\">25 Days</option>
    <option value=\"30\">30 Days</option>

</select>
</div>
</div> #}
<div class=\"form-group\">
<div class=\"row\">
<button class=\"btn btn-success\" type=\"button\" id=\"poadd\">Add Credit</button>
</div>
</div>

        </form>
      </div>
  </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
{# end of modal 1 #}

{# modal 2 for recive postpaid credits#}


<!-- Trigger the modal with a button -->







                                    <div class=\"table-responsive m-t-10\">
                                    <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                     <th>Description</th>
                                                    <th>Debit</th>
                                                    <th>Credit</th>
                                                    <th>Available Balance</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                             {% for wallet in postpaid|reverse %}
                                                <tr>
                                                <th>{{ wallet.id }}</th>
                                               <th>{{ wallet.date }} at {{ wallet.dateTime }}</th>
                                                <th>{{ wallet.note }}</th>
                                                <th>{{ wallet.debit }}</th>
                                                <th>{{ wallet.credit }}</th>
                                                <th>{{ wallet.balance }}</th>
                                            </tr>
                                        {% endfor %}
                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>
                    {# end postpaid #}
                    <!-- Tab panes -->
                        <div class=\"tab-pane\" id=\"latest-orders\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                    <div class=\"table-responsive m-t-10\">
                                        <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                            <thead>
                                                <tr>
                                                    <th>Order Number</th>
                                                    <th>Order Date</th>
                                                    <th>Status</th>
                                                    <th>Order Amount</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {% for order in customer.customerOrder|reverse %}
                                                    <tr>
                                                        <td>{{ order.id }}</td>
                                                        <td>{{ order.orderDate|date('d F Y') }}</td>
                                                        <td>{{ order.orderStatus }}</td>
                                                        <td>{{ order.orderAmount }}</td>
                                                        <td>  
                                                            <a href=\"{{ path('restaurant_orders_panel_update',{'id':order.id}) }}\" class=\"btn btn-primary btn-sm\"><i class=\"fa fa-eye\"></i></a>
                                                        </td>
                                                    </tr>
                                                {% endfor %}
                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>
  <!--second tab-->
                        <div class=\"tab-pane\" id=\"reccive\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                   <button class=\"btn btn-primary\"  data-toggle=\"modal\" data-target=\"#reccive-payment\">Reccive Payments</button>

                                <div class=\"table-responsive m-t-10\">
                                    <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                    <th>Due Balance</th>
                                                    <th>Due Duration</th>
                                                    <th>Paid Balance</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                             {% for wallet in due|reverse %}
                                                <tr>
                                                <th>{{ wallet.id }}</th>
                                               <th>{{ wallet.date }}</th>
                                                <th><a href=\"#\">
                                                    {% if wallet.balance <  0 %}

                                                       Payement Reccived
                                                         {% else %}
                                                            {{ wallet.balance }}
                                                    {% endif %}
                                                    </a></th>
                                                <th>{{ wallet.duedate }} Days</th>
                                                <th>{{ wallet.paid }}</th>
                                                 <th>

    {% if wallet.status == 0 %}
         <span style=\"font-weight:bold;color:red;font-size:14px;\">Pending</span> 
    {% else %}
         <span  style=\"font-weight:bold;color:green;font-size:14px;\">Paid</span> 
    {% endif %}
 </th>
                                            </tr>
                                        {% endfor %}
                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>

                        <!--second tab-->
                        <div class=\"tab-pane\" id=\"reviews\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <table class=\"table table-hovered\">
                                    <tr>
                                        <th>Restaurant</th>
                                        <th>Ratings</th>
                                        <th>Reviews</th>
                                    </tr>
                                {% for rating in customer.restaurantRatings %}
                                    <tr>
                                        <td>{{ rating.restaurant.restaurantName }}</td>
                                        <td>
                                            <div class=\"rating-wrap text-left margin-top-10\">
                                                <div class=\"star-ratings-sprite pull-left\">
                                                    <span style=\"width:{{ rating.ratings * 20 }}%\" class=\"star-ratings-sprite-rating\"></span>
                                                </div>
                                                <span class=\"star-count pull-left margin-left-5\">({{rating.ratings}})</span>
                                                <div class=\"clearfix\"></div>
                                            </div>
                                        </td>
                                        <td>{{ rating.reviews }}</td>
                                    </tr>
                                {% endfor %}
                            </table>
                            </div>
                        </div>

                        <div class=\"tab-pane\" id=\"customer-address\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <div class=\"table-responsive m-t-10\">
                                    <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                        <thead>
                                            <tr>
                                                <th>Type</th>
                                                <th>Name</th>
                                                <th>Address</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {% for address in customer.billingAddress %}
                                            <tr>
                                                <td>
                                                    {% if address.addressType == \"Home\" %}
                                                        <a href=\"javascipt:;\"><i class=\"fa fa-home\"> Home</i></a>
                                                    {% elseif address.addressType == \"Work\" %}
                                                        <a href=\"javascipt:;\"><i class=\"fa fa-building\"></i> Work</a>
                                                    {% else %}
                                                        <a href=\"javascipt:;\"><i class=\"fa fa-universal-access\"></i> Others</a>
                                                    {% endif %}
                                                </td>
                                                <td>{{ address.fullName }}</td>
                                                <td>{{ address.address }}</td>
                                            </tr>
                                            {% endfor %}
                                        </tbody>
                                    </table>
                                </div>
                                <div class=\"clearfix\"></div>
                            </div>
                        </div>

                        <div class=\"tab-pane\" id=\"membership-logs\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <div class=\"table-responsive m-t-10\">
                                    <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Purchased Date</th>
                                                <th>Expiry Date</th>
                                                <th>Login Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                      {% for mem in membership %}                                   
                                             <tr>
                                                <td>{{ mem.name }} - {{ mem.duration }} Month </td>
                                                <td>{{ mem.purchased_date }}</td>
                                                <td>{{ mem.expiry_date }}</td>
                                                <td>{% if mem.status == 0 %} Deactivated {% elseif mem.status == 2  %}Hold{% else %}Active {% endif %}</td>
                                            </tr>
                                            {% endfor %}
                                        </tbody>
                                    </table>
                                </div>
                                <div class=\"clearfix\"></div>
                            </div>
                        </div>
                        <div class=\"tab-pane\" id=\"customer-logs\" role=\"tabpanel\">
                            <div class=\"card-body\">
                                <div class=\"table-responsive m-t-10\">
                                    <table id=\"myTable\" class=\"table table-bordered table-striped\">
                                        <thead>
                                            <tr>
                                                <th>IP Address</th>
                                                <th>Device</th>
                                                <th>Channel</th>
                                                <th>Login Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {% for logs in cutomerlogs %}
                                            <tr>
                                                <td>{{ logs.ip }}</td>
                                                <td>{{ logs.device }}</td>
                                                <td>{{ logs.channel }}</td>
                                                <td>{{ logs.created_date }}</td>
                                            </tr>
                                            {% endfor %}
                                        </tbody>
                                    </table>
                                </div>
                                <div class=\"clearfix\"></div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
        <!-- Row -->


<!-- Modal -->
<div id=\"reccive-payment\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <small class=\"text-muted\" style=\"color:#e91e63  !important;font-weight:bold;\">Current Balance : {% for wallet in balance %}{{ wallet.postpaid }} {% endfor %}</small>

        <h4 class=\"modal-title\">Reccive Payments</h4>
      </div>
      <div class=\"modal-body\">
        <div class=\"container-fluid\">
        <form>
<div class=\"form-group\">
<div class=\"row\">
<label>Select Credit</label>
<select class=\"form-control\" required=\"\" name=\"duration\" id=\"rid\">
      {% for wallet in due %}
        {% if wallet.status == 0 %}
    <option value=\"{{ wallet.id }}\">{{ wallet.balance }} on {{ wallet.date }}</option>

        {% endif %}
{% endfor %}
   </select>
</div>
</div>

<div class=\"form-group\">
<div class=\"row\">
<label>Reccived Amount</label>
<input type=\"text\" class=\"form-control\" placeholder=\"1000\" id=\"ramount\">
</textarea>
</div>
</div>

<div class=\"form-group\">
<div class=\"row\">
<label>Payment Mode</label>
<select class=\"form-control\" required=\"\" name=\"duration\" id=\"rmode\">
    <option value=\"cash\">Cash</option>
    <option value=\"card\">Card</option>
    <option value=\"check\">Check</option>
    <option value=\"online\">Online Payment</option>
   </select>
</div>
</div>





<div class=\"form-group\">
<div class=\"row\">
<button class=\"btn btn-success\" type=\"submit\" id=\"radd\">Reccive Payment</button>
</div>
</div>

        </form>
      </div>
  </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
{# end of modal 2 #}

     
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
{% endblock %}


 
{% block scripts %}
<script type=\"text/javascript\">
  //to add prepaid
        \$('#addcredit').click(function(){
          var credits=parseInt(\$('#prepaidcredit').val());
          var mode=\$('#prepaidmode').val();
          var notes=\$('#prepaidnotes').val();
          var userID=\$('#userID').val();
          var walletnote=\$('#walletnote').val();
          
if(isNaN(credits))
{
    alert('Please enter valid Credits');
}
else
{
    var url='{{ path('add_credit_to_wallet') }}';
 
    var data={\"userID\":userID,\"mode\":mode,\"credits\":credits,\"note\":walletnote};

ajax(url,data,location.reload());
}
});
\$('#radd').click(function(){
var credits=parseInt(\$('#ramount').val());
var mode=\$('#rmode').val();
var id=\$('#rid').val();
var userID=\$('#userID').val();
if(credits<1 || isNaN(credits))
{
    alert('Please enter valid amount');
}
else
{
    var url='{{ path('reccive_postpaid_payments') }}';
 
    var data={\"userID\":userID,\"mode\":mode,\"credits\":credits,\"id\":id};

ajax(url,data,location.reload());
}
}); 
//to add loyalty
        \$('#addloyalty').click(function(){
          var credits=parseInt(\$('#lprepaidcredit').val());
          var mode=\$('#lprepaidmode').val();
          var notes=\$('#lprepaidnotes').val();
          var userID=\$('#userID').val();
          var walletnote=\$('#lwalletnote').val();
          
if(isNaN(credits))
{
    alert('Please enter valid Points');
}
else
{
    var url='{{ path('add_credit_to_loyalty') }}';
 
    var data={\"userID\":userID,\"mode\":mode,\"credits\":credits,\"note\":walletnote};
// alert(url)
 ajax(url,data,location.reload());
}
});
\$('#radd').click(function(){
var credits=parseInt(\$('#ramount').val());
var mode=\$('#rmode').val();
var id=\$('#rid').val();
var userID=\$('#userID').val();
if(credits<1 || isNaN(credits))
{
    alert('Please enter valid amount');
}
else
{
    var url='{{ path('reccive_postpaid_payments') }}';
 
    var data={\"userID\":userID,\"mode\":mode,\"credits\":credits,\"id\":id};

ajax(url,data,location.reload());
}
});
addloyalty
//to add postpaid
 \$('#poadd').click(function(){
          var credits=parseInt(\$('#pocredits').val());
          var mode='dummy';
          var duration='15';
          var userID=\$('#userID').val();
if(credits==0 || isNaN(credits))
{
    alert('Please enter valid Credits');
}
else
{
    var url='{{ path('add_credit_to_wallet_postpaid') }}';
 
    var data={\"userID\":userID,\"mode\":'null',\"credits\":credits,\"note\":'Credit From Marketbhaav',\"duration\":duration};
// console.log()
ajax(url,data,location.reload());
}
 });
 //to add postpaid
 \$('#settingsSave').click(function(){
          var drop=\$('#settingsDrop').val();
          
          var userID=\$('#userID').val();


    var url='{{ path('add_duration_postpaid') }}';
 
    var data={\"userID\":userID,\"drop\":drop};
    // alert(data)
// console.log()
ajax(url,data,alert('Credit Duration changed to '+drop+' Days'));

 });

// blockP
 //to add postpaid
 \$('#blockP').click(function(){
          
          var userID=\$('#userID').val();
      


    var url='{{ path('block_duration_postpaid') }}';
 
    var data={\"userID\":userID,\"status\":'1'};
    // alert(data)
// console.log()
ajax(url,data,location.reload());

 });
 \$('#unblockP').click(function(){
          
          var userID=\$('#userID').val();
      


    var url='{{ path('block_duration_postpaid') }}';
 
    var data={\"userID\":userID,\"status\":'0'};
    // alert(data)
// console.log()
ajax(url,data,location.reload());

 });
function ajax(url,data,output)
 {

\$.ajax({
    type: \"POST\",
    url: url,
    data: data,
    success: function (data, dataType) {
output;
location.reload();
    },
    error: function (XMLHttpRequest, textStatus, errorThrown) {
        alert('Error : ' + errorThrown);
    }
});
}
 </script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable(
            {
                \"aaSorting\": [[0, 'desc']],
            }
        );
    });



</script>
{% endblock %}", "AppBundle:Admin:Customers/viewWalletUser.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Customers/viewWalletUser.html.twig");
    }
}

<?php

/* AppBundle:Admin:Stock/stockDetail.html.twig */
class __TwigTemplate_1f2de2031e68dbe0f57837661e7c7727ddccf276cf56e032b9c8b36debebffd5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Stock/stockDetail.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_48107c163647b2307e4d9a714e12b4d61e18f8ede1a28ef49938f530083fa168 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48107c163647b2307e4d9a714e12b4d61e18f8ede1a28ef49938f530083fa168->enter($__internal_48107c163647b2307e4d9a714e12b4d61e18f8ede1a28ef49938f530083fa168_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Stock/stockDetail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_48107c163647b2307e4d9a714e12b4d61e18f8ede1a28ef49938f530083fa168->leave($__internal_48107c163647b2307e4d9a714e12b4d61e18f8ede1a28ef49938f530083fa168_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_000b77a52b923671a9a8892ad002f5ee62795deec483cb5236b39b46ba30cc69 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_000b77a52b923671a9a8892ad002f5ee62795deec483cb5236b39b46ba30cc69->enter($__internal_000b77a52b923671a9a8892ad002f5ee62795deec483cb5236b39b46ba30cc69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<!-- Modal -->
<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Upload Menu Items</h4>
      </div>
      <div class=\"modal-body\">
        <p><form>
        <input type=\"file\" class=\"form-control\">
        </form></p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                                                <h3>Details</h3>

                        
                        ";
        // line 35
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["stock"] ?? $this->getContext($context, "stock")));
        foreach ($context['_seq'] as $context["_key"] => $context["st"]) {
            // line 36
            echo "                              
                              
<div class=\"container\">
  <div class=\"card\">
<div class=\"card-header\">
Invoice : 
<strong>#";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "ref", array()), "html", null, true);
            echo "</strong> 
  <span class=\"float-right\"> <strong> ";
            // line 43
            if (($this->getAttribute($context["st"], "mode", array()) == 0)) {
                echo " Purchase Inwards ";
            } else {
                echo " Purchase Return ";
            }
            echo "</strong></span>

</div>
<div class=\"card-body\">
<div class=\"row mb-4\">
<div class=\"col-sm-6\">
<div>
Date and time : ";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "date", array()), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "time", array()), "html", null, true);
            echo "
</div>
<div>Description : ";
            // line 52
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "description", array()), "html", null, true);
            echo "</div>
<div>Added By : ";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "addedBy", array()), "html", null, true);
            echo "</div>


";
            // line 66
            echo "


</div><br><br>

<div class=\"table-responsive\">
<table class=\"table table-striped\" style=\"width:100%;\">
<thead>
<tr>
<th class=\"center\">#</th>
<th>Item Name</th>
  <th class=\"center\">Qty</th>
<th class=\"right\">Curent Stock</th>
</tr>
</thead>
<tbody>
     ";
            // line 82
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["menu"] ?? $this->getContext($context, "menu")));
            foreach ($context['_seq'] as $context["_key"] => $context["sl"]) {
                // line 83
                echo "<tr>
<td class=\"center\">";
                // line 84
                echo twig_escape_filter($this->env, $this->getAttribute($context["sl"], "id", array()), "html", null, true);
                echo "</td>
<td class=\"left strong\"> ";
                // line 85
                echo twig_escape_filter($this->env, $this->getAttribute($context["sl"], "itemName", array()), "html", null, true);
                echo " - ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["sl"], "variationName", array()), "html", null, true);
                echo "</td>
<td class=\"left\">";
                // line 86
                echo twig_escape_filter($this->env, $this->getAttribute($context["sl"], "qty", array()), "html", null, true);
                echo "</td>
<td class=\"right\">";
                // line 87
                echo twig_escape_filter($this->env, $this->getAttribute($context["sl"], "stock", array()), "html", null, true);
                echo "</td>
</tr>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sl'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 90
            echo "</tbody>
</table>
</div>
<div class=\"row\">
<div class=\"col-lg-4 col-sm-5\">

</div>


</div>

</div>
</div>
</div>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['st'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 105
        echo "
<span class=\"pull-right\">
                    ";
        // line 108
        echo "                            <a href=\"#back\" class=\"btn btn-primary\" onclick=\"window.history.go(-1); return false;\">Back</a>
                        </span>



                    </div>
                </div>
            </div>
    </div>
</div>
";
        
        $__internal_000b77a52b923671a9a8892ad002f5ee62795deec483cb5236b39b46ba30cc69->leave($__internal_000b77a52b923671a9a8892ad002f5ee62795deec483cb5236b39b46ba30cc69_prof);

    }

    // line 120
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_00589194536e49815fd0c9d9ccb5ea2c55a5bceb6b9977766e0eef75e6491407 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00589194536e49815fd0c9d9ccb5ea2c55a5bceb6b9977766e0eef75e6491407->enter($__internal_00589194536e49815fd0c9d9ccb5ea2c55a5bceb6b9977766e0eef75e6491407_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 121
        echo "
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
   
</script>
";
        
        $__internal_00589194536e49815fd0c9d9ccb5ea2c55a5bceb6b9977766e0eef75e6491407->leave($__internal_00589194536e49815fd0c9d9ccb5ea2c55a5bceb6b9977766e0eef75e6491407_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Stock/stockDetail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 121,  210 => 120,  193 => 108,  189 => 105,  169 => 90,  160 => 87,  156 => 86,  150 => 85,  146 => 84,  143 => 83,  139 => 82,  121 => 66,  115 => 53,  111 => 52,  104 => 50,  90 => 43,  86 => 42,  78 => 36,  74 => 35,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}

<!-- Modal -->
<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Upload Menu Items</h4>
      </div>
      <div class=\"modal-body\">
        <p><form>
        <input type=\"file\" class=\"form-control\">
        </form></p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                                                <h3>Details</h3>

                        
                        {% for st in stock %}
                              
                              
<div class=\"container\">
  <div class=\"card\">
<div class=\"card-header\">
Invoice : 
<strong>#{{ st.ref }}</strong> 
  <span class=\"float-right\"> <strong> {% if st.mode == 0 %} Purchase Inwards {% else %} Purchase Return {% endif %}</strong></span>

</div>
<div class=\"card-body\">
<div class=\"row mb-4\">
<div class=\"col-sm-6\">
<div>
Date and time : {{ st.date }} - {{ st.time }}
</div>
<div>Description : {{ st.description }}</div>
<div>Added By : {{ st.addedBy }}</div>


{# <div class=\"col-sm-6\">
<h6 class=\"mb-3\">To:</h6>
<div>
<strong>Bob Mart</strong>
</div>
<div>Attn: Daniel Marek</div>
<div>43-190 Mikolow, Poland</div>
<div>Email: marek@daniel.com</div>
<div>Phone: +48 123 456 789</div>
</div> #}



</div><br><br>

<div class=\"table-responsive\">
<table class=\"table table-striped\" style=\"width:100%;\">
<thead>
<tr>
<th class=\"center\">#</th>
<th>Item Name</th>
  <th class=\"center\">Qty</th>
<th class=\"right\">Curent Stock</th>
</tr>
</thead>
<tbody>
     {% for sl in menu %}
<tr>
<td class=\"center\">{{ sl.id }}</td>
<td class=\"left strong\"> {{ sl.itemName }} - {{ sl.variationName }}</td>
<td class=\"left\">{{ sl.qty }}</td>
<td class=\"right\">{{ sl.stock }}</td>
</tr>
    {% endfor %}
</tbody>
</table>
</div>
<div class=\"row\">
<div class=\"col-lg-4 col-sm-5\">

</div>


</div>

</div>
</div>
</div>
  {% endfor %}

<span class=\"pull-right\">
                    {#      <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\">Upload CSV</a> #}
                            <a href=\"#back\" class=\"btn btn-primary\" onclick=\"window.history.go(-1); return false;\">Back</a>
                        </span>



                    </div>
                </div>
            </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
   
</script>
{% endblock %}
", "AppBundle:Admin:Stock/stockDetail.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Stock/stockDetail.html.twig");
    }
}

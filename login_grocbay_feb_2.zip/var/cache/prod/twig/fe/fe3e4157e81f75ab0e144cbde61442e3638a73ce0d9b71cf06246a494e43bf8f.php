<?php

/* AppBundle:Admin:Stock/addStock.html.twig */
class __TwigTemplate_eb6157e8e06f182a2cea42838be94d0fb929f289f1cd32ad239d13301e8f5650 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Stock/addStock.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3bbc43b8957e9944edbc49d6d9e18e24834fda89039d1488c435da0536c0aa72 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3bbc43b8957e9944edbc49d6d9e18e24834fda89039d1488c435da0536c0aa72->enter($__internal_3bbc43b8957e9944edbc49d6d9e18e24834fda89039d1488c435da0536c0aa72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Stock/addStock.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3bbc43b8957e9944edbc49d6d9e18e24834fda89039d1488c435da0536c0aa72->leave($__internal_3bbc43b8957e9944edbc49d6d9e18e24834fda89039d1488c435da0536c0aa72_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_8447e5681044b780de0b231a96e944ed60d997ff71f5fbba965e981ac947bb78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8447e5681044b780de0b231a96e944ed60d997ff71f5fbba965e981ac947bb78->enter($__internal_8447e5681044b780de0b231a96e944ed60d997ff71f5fbba965e981ac947bb78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
      
      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
<script src=\"/assets/js/selectize.min.js\" integrity=\"sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=\" crossorigin=\"anonymous\"></script>
<link rel=\"stylesheet\" href=\"/assets/css/selectize.bootstrap3.min.css\" integrity=\"sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=\" crossorigin=\"anonymous\" />
";
        // line 18
        echo "<!-- Modal -->

<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                        <span class=\"pull-right\">
                    ";
        // line 27
        echo "                          
                        </span>
                    </div>
                    <h2>Purchase Inwards</h2>

                    <div>
                    <form action=\"";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_add_stock_item");
        echo "\" method=\"post\">
                        <div class=\"row\">
                           
                        <div class=\"form-group col-md-4\">
                            <label>Date *</label>
                            <input type=\"text\" name=\"date\" class=\"form-control\" required=\"\" id = \"datepicker-13\" autocomplete=\"off\">

                        </div>
                        <div class=\"form-group col-md-8\">
                            <label>Description *</label>
                            <textarea class=\"form-control\" name=\"description\" required></textarea> 
                        </div>
                    </div>
                        <hr>
                          <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\" style=\"float:right;\">Add Items</a> 
 <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>Item Name</th>
                                     <th>Variation</th>
                                    <th>Quantity</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                               
                            </tbody>
                        </table>
                    </div>
                    <button class=\"btn btn-success\" type=\"submit\" style=\"float:right;\">Save</button>
                    </form> 
                    </div>
     
                </div>
            </div>
    </div>
</div>

";
        // line 73
        echo "<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Add Stock</h4>
      </div>
      <div class=\"modal-body\">
        <p><form>
            <div class=\"form-group\">
            <label>Search Item *</label>
  <select id=\"select-state\" placeholder=\"Pick a Menu Item...\" class=\"form-control select\"><option>Select Products</option>
    ";
        // line 87
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["menuItems"] ?? $this->getContext($context, "menuItems")));
        foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
            // line 88
            echo "    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "id", array()), "html", null, true);
            echo "\" data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "id", array()), "html", null, true);
            echo "\" data-name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "itemName", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "itemName", array()), "html", null, true);
            echo "</option>
   ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 90
        echo "  </select>
            </div>

            <div class=\"form-group\">
            <label>Select Variation *</label>
  <select class=\"form-control var\"  id=\"vars\" style=\"display:block !important;\">
   
  </select>
</div>
<div id=\"stocks\"></div><br>
<div class=\"form-group\">
<label>Quantity *</label>
<input type=\"number\" class=\"form-control\" id=\"quantity\">
</div>
         
        <span style=\"margin-top:10px;\">
            <button class=\"btn btn-success\" id=\"sel\" type=\"button\">add</button>
        </span>
        
        </form></p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
";
        
        $__internal_8447e5681044b780de0b231a96e944ed60d997ff71f5fbba965e981ac947bb78->leave($__internal_8447e5681044b780de0b231a96e944ed60d997ff71f5fbba965e981ac947bb78_prof);

    }

    // line 121
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_667b187495c109b36d77b0a9a1639952342bf83acb277bb5cad65407c96b398b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_667b187495c109b36d77b0a9a1639952342bf83acb277bb5cad65407c96b398b->enter($__internal_667b187495c109b36d77b0a9a1639952342bf83acb277bb5cad65407c96b398b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 122
        echo "
<script>
function send(myObjects)
{
\$('#quantity').val('');
\$('#stocks').html('');
\$('.var').html('');    
\$.each(myObjects, function () {
    \$('.var').append('<option value=\"'+this.id+'\"   data-stock=\"'+this.stock+'\" data-type=\"'+this.type+'\"  data-name=\"'+this.name+'\">'+this.name+'</option>');
        \$('#stocks').html('<span style=\"color:red;font-weight:bold;\">Curent Stock : '+this.stock+' </span>');
    });       
         
   }
 function removeVariant(obj){
// \$(this).attr(\"data-usr\" , '');

        \$(obj).parent().parent().remove();

    }
    \$(document).ready(function() {
        \$('#myTables').DataTable();
    });
    

 \$(document).ready(function () {
  \$('.var').change(function(){
     var x=\$('.var').val();
var stock = \$(this).find(':selected').attr('data-stock')
\$('#stocks').html('<span style=\"color:red;font-weight:bold;\">Curent Stock : '+stock+' </span>');
  });
\$('#select-state').change(function(){
var id=\$('#select-state').val();
var out ={'data':id};      
// alert(id);                 // alert(x);
\$.ajax({
    type: \"POST\",
    url: \"";
        // line 158
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_get_var");
        echo "\",
    data: {
      'data' : id
    },
    success: function (res, dataType) {
 // console.log('";
        // line 163
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_get_cat");
        echo "');
send(res);
          
// console.log(datas);

    },
    error: function (XMLHttpRequest, textStatus, errorThrown) {
        alert('Error : ' + errorThrown);
    }
});
                                        

});

 \$('#sel').click(function () {
// var selid=\$('#select-state').val();
var selvalue = \$('#select-state').find(':selected').attr('data-name');
var varid=\$('.var').val();
var varvalue = \$('.var').find(':selected').attr('data-name');
var selid = \$('#select-state').find(':selected').attr('data-id');

var quantity=\$('#quantity').val();
var type = \$('.var').find(':selected').attr('data-type');
if(quantity=='' || quantity=='0')
{
    alert('please enter quantity!');
    return false;
}
// \$('#myTable tr').each(function() {
//   // need this to skip the first row
// console.log(\$(this).find(\"td:first\").length);
//     var cutomerId = \$(this).find(\"td:first\").html();

//    if(cutomerId==='<input type=\"hidden\" value=\"'+selid+'\" name=\"selid[]\">'+selvalue+'')
//    {
//     alert('Item already in list please try with different list!');
//    }
//    else
//    {
    
//     alert('no');
//    }

// });

 \$('#myTable').append('<tr><td><input type=\"hidden\" value=\"'+type+'\" name=\"type[]\"><input type=\"hidden\" value=\"'+varid+'\" name=\"selid[]\">'+selvalue+'</td><td><input type=\"hidden\" value=\"'+varid+'\" name=\"varid[]\">'+varvalue+'</td><td><input type=\"hidden\" value=\"'+quantity+'\" name=\"selqty[]\">'+quantity+'</td><td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\">remove</button></td></tr>'); 
 });
\$(\".remove a\").click(function() {
    \$(this).parent().remove();
});
 });
</script>

<script>
";
        
        $__internal_667b187495c109b36d77b0a9a1639952342bf83acb277bb5cad65407c96b398b->leave($__internal_667b187495c109b36d77b0a9a1639952342bf83acb277bb5cad65407c96b398b_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Stock/addStock.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  238 => 163,  230 => 158,  192 => 122,  186 => 121,  151 => 90,  136 => 88,  132 => 87,  116 => 73,  74 => 33,  66 => 27,  56 => 18,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}

      
      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
<script src=\"/assets/js/selectize.min.js\" integrity=\"sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=\" crossorigin=\"anonymous\"></script>
<link rel=\"stylesheet\" href=\"/assets/css/selectize.bootstrap3.min.css\" integrity=\"sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=\" crossorigin=\"anonymous\" />
{# {{ dump(res) }} #}
<!-- Modal -->

<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                        <span class=\"pull-right\">
                    {#      <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\">Upload CSV</a> #}
                          
                        </span>
                    </div>
                    <h2>Purchase Inwards</h2>

                    <div>
                    <form action=\"{{ path('manage_restaurant_add_stock_item') }}\" method=\"post\">
                        <div class=\"row\">
                           
                        <div class=\"form-group col-md-4\">
                            <label>Date *</label>
                            <input type=\"text\" name=\"date\" class=\"form-control\" required=\"\" id = \"datepicker-13\" autocomplete=\"off\">

                        </div>
                        <div class=\"form-group col-md-8\">
                            <label>Description *</label>
                            <textarea class=\"form-control\" name=\"description\" required></textarea> 
                        </div>
                    </div>
                        <hr>
                          <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\" style=\"float:right;\">Add Items</a> 
 <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>Item Name</th>
                                     <th>Variation</th>
                                    <th>Quantity</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                               
                            </tbody>
                        </table>
                    </div>
                    <button class=\"btn btn-success\" type=\"submit\" style=\"float:right;\">Save</button>
                    </form> 
                    </div>
     
                </div>
            </div>
    </div>
</div>

{# modal #}
<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Add Stock</h4>
      </div>
      <div class=\"modal-body\">
        <p><form>
            <div class=\"form-group\">
            <label>Search Item *</label>
  <select id=\"select-state\" placeholder=\"Pick a Menu Item...\" class=\"form-control select\"><option>Select Products</option>
    {% for menu in menuItems %}
    <option value=\"{{ menu.id }}\" data-id=\"{{ menu.id }}\" data-name=\"{{ menu.itemName }}\">{{ menu.itemName }}</option>
   {% endfor %}
  </select>
            </div>

            <div class=\"form-group\">
            <label>Select Variation *</label>
  <select class=\"form-control var\"  id=\"vars\" style=\"display:block !important;\">
   
  </select>
</div>
<div id=\"stocks\"></div><br>
<div class=\"form-group\">
<label>Quantity *</label>
<input type=\"number\" class=\"form-control\" id=\"quantity\">
</div>
         
        <span style=\"margin-top:10px;\">
            <button class=\"btn btn-success\" id=\"sel\" type=\"button\">add</button>
        </span>
        
        </form></p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
{# end modal #}
{% endblock %}

{% block scripts %}

<script>
function send(myObjects)
{
\$('#quantity').val('');
\$('#stocks').html('');
\$('.var').html('');    
\$.each(myObjects, function () {
    \$('.var').append('<option value=\"'+this.id+'\"   data-stock=\"'+this.stock+'\" data-type=\"'+this.type+'\"  data-name=\"'+this.name+'\">'+this.name+'</option>');
        \$('#stocks').html('<span style=\"color:red;font-weight:bold;\">Curent Stock : '+this.stock+' </span>');
    });       
         
   }
 function removeVariant(obj){
// \$(this).attr(\"data-usr\" , '');

        \$(obj).parent().parent().remove();

    }
    \$(document).ready(function() {
        \$('#myTables').DataTable();
    });
    

 \$(document).ready(function () {
  \$('.var').change(function(){
     var x=\$('.var').val();
var stock = \$(this).find(':selected').attr('data-stock')
\$('#stocks').html('<span style=\"color:red;font-weight:bold;\">Curent Stock : '+stock+' </span>');
  });
\$('#select-state').change(function(){
var id=\$('#select-state').val();
var out ={'data':id};      
// alert(id);                 // alert(x);
\$.ajax({
    type: \"POST\",
    url: \"{{ path('manage_restaurant_get_var') }}\",
    data: {
      'data' : id
    },
    success: function (res, dataType) {
 // console.log('{{ path('manage_restaurant_get_cat') }}');
send(res);
          
// console.log(datas);

    },
    error: function (XMLHttpRequest, textStatus, errorThrown) {
        alert('Error : ' + errorThrown);
    }
});
                                        

});

 \$('#sel').click(function () {
// var selid=\$('#select-state').val();
var selvalue = \$('#select-state').find(':selected').attr('data-name');
var varid=\$('.var').val();
var varvalue = \$('.var').find(':selected').attr('data-name');
var selid = \$('#select-state').find(':selected').attr('data-id');

var quantity=\$('#quantity').val();
var type = \$('.var').find(':selected').attr('data-type');
if(quantity=='' || quantity=='0')
{
    alert('please enter quantity!');
    return false;
}
// \$('#myTable tr').each(function() {
//   // need this to skip the first row
// console.log(\$(this).find(\"td:first\").length);
//     var cutomerId = \$(this).find(\"td:first\").html();

//    if(cutomerId==='<input type=\"hidden\" value=\"'+selid+'\" name=\"selid[]\">'+selvalue+'')
//    {
//     alert('Item already in list please try with different list!');
//    }
//    else
//    {
    
//     alert('no');
//    }

// });

 \$('#myTable').append('<tr><td><input type=\"hidden\" value=\"'+type+'\" name=\"type[]\"><input type=\"hidden\" value=\"'+varid+'\" name=\"selid[]\">'+selvalue+'</td><td><input type=\"hidden\" value=\"'+varid+'\" name=\"varid[]\">'+varvalue+'</td><td><input type=\"hidden\" value=\"'+quantity+'\" name=\"selqty[]\">'+quantity+'</td><td><button class=\"btn btn-danger\" type=\"button\" class=\"remove\" onclick=\"removeVariant(this)\">remove</button></td></tr>'); 
 });
\$(\".remove a\").click(function() {
    \$(this).parent().remove();
});
 });
</script>

<script>
{% endblock %}
", "AppBundle:Admin:Stock/addStock.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Stock/addStock.html.twig");
    }
}

<?php

/* AppBundle:Advertisement:adList.html.twig */
class __TwigTemplate_b3abdbdf028fbf4f177486fb9b2c1971e20bd0f9ef4251377c5ac2ab537fa377 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Advertisement:adList.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5da3dd8ab69745075e639f00a9082d7bcbf51a0a6bd9960e3759bed5224ee764 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5da3dd8ab69745075e639f00a9082d7bcbf51a0a6bd9960e3759bed5224ee764->enter($__internal_5da3dd8ab69745075e639f00a9082d7bcbf51a0a6bd9960e3759bed5224ee764_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Advertisement:adList.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5da3dd8ab69745075e639f00a9082d7bcbf51a0a6bd9960e3759bed5224ee764->leave($__internal_5da3dd8ab69745075e639f00a9082d7bcbf51a0a6bd9960e3759bed5224ee764_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_9573faa0b79a596aaeab2ea9dd15ec26b096d9542941cffd13f31da73e456ffb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9573faa0b79a596aaeab2ea9dd15ec26b096d9542941cffd13f31da73e456ffb->enter($__internal_9573faa0b79a596aaeab2ea9dd15ec26b096d9542941cffd13f31da73e456ffb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">


                      <div class=\"table-responsive mb-4 mt-4\">
                                <table id=\"zero-config\" class=\"table\" style=\"width:100%\">
                                 
                            <thead>
                                 <tr>
                                    <th>Banner Title</th>
                                    <th>Image</th>
                                    <th>Banner Type</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead> 
                            <tbody>
                            </tbody> 
                            </table> 
                          </div>
                </div>
            </div>
    </div>
</div>


";
        
        $__internal_9573faa0b79a596aaeab2ea9dd15ec26b096d9542941cffd13f31da73e456ffb->leave($__internal_9573faa0b79a596aaeab2ea9dd15ec26b096d9542941cffd13f31da73e456ffb_prof);

    }

    // line 34
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_93a93eaa68c14b90f397af94e01513fe53fbca654f7cc945f81dd1a8b551bad7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93a93eaa68c14b90f397af94e01513fe53fbca654f7cc945f81dd1a8b551bad7->enter($__internal_93a93eaa68c14b90f397af94e01513fe53fbca654f7cc945f81dd1a8b551bad7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 35
        echo "
<script>

    \$('#zero-config').DataTable({
            \"destroy\": true,
            \"oLanguage\": {
                \"oPaginate\": { \"sPrevious\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-left\"><line x1=\"19\" y1=\"12\" x2=\"5\" y2=\"12\"></line><polyline points=\"12 19 5 12 12 5\"></polyline></svg>', \"sNext\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-right\"><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line><polyline points=\"12 5 19 12 12 19\"></polyline></svg>' },
                \"sInfo\": \"Showing page _PAGE_ of _PAGES_\",
                \"sSearch\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-search\"><circle cx=\"11\" cy=\"11\" r=\"8\"></circle><line x1=\"21\" y1=\"21\" x2=\"16.65\" y2=\"16.65\"></line></svg>',
                \"sSearchPlaceholder\": \"Search...\",
               \"sLengthMenu\": \"Results :  _MENU_\",
            },
            \"stripeClasses\": [],
            \"lengthMenu\": [7, 10, 20, 50],
            \"pageLength\": 7,
            'ajax': { 
          'url':\"/app-manager/manage-advertisement-ajax\",
          'type': \"post\",      },
           'fnDrawCallback': function()
            {
                 // \$(\"#myTable_length\").prepend('');
            },
          'columns': [
            { data: 'title' },
            { data: 'image' },
            { data: 'type' },
            { data: 'isActive' },
            { data: 'action' }
          ], 
        });

</script>
";
        
        $__internal_93a93eaa68c14b90f397af94e01513fe53fbca654f7cc945f81dd1a8b551bad7->leave($__internal_93a93eaa68c14b90f397af94e01513fe53fbca654f7cc945f81dd1a8b551bad7_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Advertisement:adList.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 35,  76 => 34,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}
<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">


                      <div class=\"table-responsive mb-4 mt-4\">
                                <table id=\"zero-config\" class=\"table\" style=\"width:100%\">
                                 
                            <thead>
                                 <tr>
                                    <th>Banner Title</th>
                                    <th>Image</th>
                                    <th>Banner Type</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead> 
                            <tbody>
                            </tbody> 
                            </table> 
                          </div>
                </div>
            </div>
    </div>
</div>


{% endblock %}

{% block scripts %}

<script>

    \$('#zero-config').DataTable({
            \"destroy\": true,
            \"oLanguage\": {
                \"oPaginate\": { \"sPrevious\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-left\"><line x1=\"19\" y1=\"12\" x2=\"5\" y2=\"12\"></line><polyline points=\"12 19 5 12 12 5\"></polyline></svg>', \"sNext\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-right\"><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line><polyline points=\"12 5 19 12 12 19\"></polyline></svg>' },
                \"sInfo\": \"Showing page _PAGE_ of _PAGES_\",
                \"sSearch\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-search\"><circle cx=\"11\" cy=\"11\" r=\"8\"></circle><line x1=\"21\" y1=\"21\" x2=\"16.65\" y2=\"16.65\"></line></svg>',
                \"sSearchPlaceholder\": \"Search...\",
               \"sLengthMenu\": \"Results :  _MENU_\",
            },
            \"stripeClasses\": [],
            \"lengthMenu\": [7, 10, 20, 50],
            \"pageLength\": 7,
            'ajax': { 
          'url':\"/app-manager/manage-advertisement-ajax\",
          'type': \"post\",      },
           'fnDrawCallback': function()
            {
                 // \$(\"#myTable_length\").prepend('');
            },
          'columns': [
            { data: 'title' },
            { data: 'image' },
            { data: 'type' },
            { data: 'isActive' },
            { data: 'action' }
          ], 
        });

</script>
{% endblock %}", "AppBundle:Advertisement:adList.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Advertisement/adList.html.twig");
    }
}

<?php

/* AppBundle:Admin:Firebase/list.html.twig */
class __TwigTemplate_57dace5496a81424678eb565c6061c6608dc9826930e002631f8f695ce25311e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Firebase/list.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b0b49c14511f76a3da2e965bcb9d3582516f01dba90705801ad37aaa06bc71ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b0b49c14511f76a3da2e965bcb9d3582516f01dba90705801ad37aaa06bc71ac->enter($__internal_b0b49c14511f76a3da2e965bcb9d3582516f01dba90705801ad37aaa06bc71ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Firebase/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b0b49c14511f76a3da2e965bcb9d3582516f01dba90705801ad37aaa06bc71ac->leave($__internal_b0b49c14511f76a3da2e965bcb9d3582516f01dba90705801ad37aaa06bc71ac_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_09bb5402f06b41d4360546fe6b5abd17e2ecaaaba57cf743791c184a52ea0d2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09bb5402f06b41d4360546fe6b5abd17e2ecaaaba57cf743791c184a52ea0d2c->enter($__internal_09bb5402f06b41d4360546fe6b5abd17e2ecaaaba57cf743791c184a52ea0d2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Message</th>
                                    <th>Type</th>
                                    <th>Image</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 26
            echo "
                                <tr>
                                     <td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "ref", array()), "html", null, true);
            echo "</td>
                                     <td>";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "message", array()), "html", null, true);
            echo "</td>
                                       <td>";
            // line 30
            if (($this->getAttribute($context["product"], "notificationFor", array()) == 3)) {
                echo " Link ";
            }
            // line 31
            echo "                                       ";
            if (($this->getAttribute($context["product"], "notificationFor", array()) == 4)) {
                echo " Items ";
            }
            // line 32
            echo "                                     ";
            if (($this->getAttribute($context["product"], "notificationFor", array()) == 5)) {
                echo " Category ";
            }
            // line 33
            echo "                                        ";
            if (($this->getAttribute($context["product"], "notificationFor", array()) == 6)) {
                echo " Brands ";
            }
            // line 34
            echo "                                   ";
            if (($this->getAttribute($context["product"], "notificationFor", array()) == 6)) {
                echo " Redirect to Homepage ";
            }
            echo "</td>
                                    <td>";
            // line 35
            if (($this->getAttribute($context["product"], "image", array()) == "")) {
            } else {
                echo "<img class=\"img-responsive\" src=\"/uploads/";
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "image", array()), "html", null, true);
                echo "\" style=\"width:100px;height:100px\"/>";
            }
            echo "</td>
                                    <td>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "dateTime", array()), "html", null, true);
            echo "</td>
                                      
                                    <td>
                                        <a href=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("view_notification", array("id" => $this->getAttribute($context["product"], "ref", array()))), "html", null, true);
            echo "\" title=\"view\" class=\"btn btn-primary btn-sm\">
                                            <i class=\"fa fa-eye\"></i>
                                        </a>
                                      
                                    </td>
                                </tr>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
";
        
        $__internal_09bb5402f06b41d4360546fe6b5abd17e2ecaaaba57cf743791c184a52ea0d2c->leave($__internal_09bb5402f06b41d4360546fe6b5abd17e2ecaaaba57cf743791c184a52ea0d2c_prof);

    }

    // line 55
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_edb1cb367f889d858c3c4ae7066a96985871f4d1f77e04389cb6d249c3e2b8a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_edb1cb367f889d858c3c4ae7066a96985871f4d1f77e04389cb6d249c3e2b8a5->enter($__internal_edb1cb367f889d858c3c4ae7066a96985871f4d1f77e04389cb6d249c3e2b8a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 56
        echo "
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
   
</script>
 <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
";
        
        $__internal_edb1cb367f889d858c3c4ae7066a96985871f4d1f77e04389cb6d249c3e2b8a5->leave($__internal_edb1cb367f889d858c3c4ae7066a96985871f4d1f77e04389cb6d249c3e2b8a5_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Firebase/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  154 => 56,  148 => 55,  134 => 46,  121 => 39,  115 => 36,  106 => 35,  99 => 34,  94 => 33,  89 => 32,  84 => 31,  80 => 30,  76 => 29,  72 => 28,  68 => 26,  64 => 25,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}


<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Message</th>
                                    <th>Type</th>
                                    <th>Image</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                {% for product in data %}

                                <tr>
                                     <td>{{ product.ref }}</td>
                                     <td>{{ product.message }}</td>
                                       <td>{% if product.notificationFor == 3 %} Link {% endif %}
                                       {% if product.notificationFor == 4 %} Items {% endif %}
                                     {% if product.notificationFor == 5 %} Category {% endif %}
                                        {% if product.notificationFor == 6 %} Brands {% endif %}
                                   {% if product.notificationFor == 6 %} Redirect to Homepage {% endif %}</td>
                                    <td>{% if product.image == '' %}{% else %}<img class=\"img-responsive\" src=\"/uploads/{{ product.image }}\" style=\"width:100px;height:100px\"/>{% endif %}</td>
                                    <td>{{ product.dateTime }}</td>
                                      
                                    <td>
                                        <a href=\"{{ path('view_notification',{'id':product.ref})}}\" title=\"view\" class=\"btn btn-primary btn-sm\">
                                            <i class=\"fa fa-eye\"></i>
                                        </a>
                                      
                                    </td>
                                </tr>
                                {% endfor %}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
   
</script>
 <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
{% endblock %}
", "AppBundle:Admin:Firebase/list.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Firebase/list.html.twig");
    }
}

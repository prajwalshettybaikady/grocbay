<?php

/* AppBundle:Admin:Pages/search.html.twig */
class __TwigTemplate_a8f2e4f9e0c9d48eb8384eda66dfc592cf6d3e970555f6759eee3bfb6104fd7f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/search.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f4a6aa6117e9e87bfa29c78fac87dc53c322391838aa78db3713a26a0e1b448e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4a6aa6117e9e87bfa29c78fac87dc53c322391838aa78db3713a26a0e1b448e->enter($__internal_f4a6aa6117e9e87bfa29c78fac87dc53c322391838aa78db3713a26a0e1b448e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/search.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f4a6aa6117e9e87bfa29c78fac87dc53c322391838aa78db3713a26a0e1b448e->leave($__internal_f4a6aa6117e9e87bfa29c78fac87dc53c322391838aa78db3713a26a0e1b448e_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_0a06744c0d43e74db556dbeba93b38edd85df98b259449d52386fababadc0f62 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a06744c0d43e74db556dbeba93b38edd85df98b259449d52386fababadc0f62->enter($__internal_0a06744c0d43e74db556dbeba93b38edd85df98b259449d52386fababadc0f62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "

<div class=\"container\">
<h3>Search Result For  <b>";
        // line 6
        echo twig_escape_filter($this->env, ($context["data"] ?? $this->getContext($context, "data")), "html", null, true);
        echo "</b></h3>

<br>
<div class=\"list-group \">
  ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["ordernumber"] ?? $this->getContext($context, "ordernumber")));
        foreach ($context['_seq'] as $context["_key"] => $context["order"]) {
            // line 11
            echo "    <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_orders_panel_update", array("id" => $this->getAttribute($context["order"], "id", array()))), "html", null, true);
            echo "\" class=\"list-group-item list-group-item-action\">Order : #";
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "id", array()), "html", null, true);
            echo " , ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "customerName", array()), "html", null, true);
            echo "  , Order Date : ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["order"], "orderDate", array()), "d-m-Y"), "html", null, true);
            echo " at ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["order"], "orderDate", array()), "h-i A"), "html", null, true);
            echo " </a>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['order'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["itemData"] ?? $this->getContext($context, "itemData")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 14
            echo "    <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_edit_menu_item", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"list-group-item list-group-item-action\">Item Id : #";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo " , ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
            echo " </a>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "
  ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["customerData"] ?? $this->getContext($context, "customerData")));
        foreach ($context['_seq'] as $context["_key"] => $context["customer"]) {
            // line 18
            echo "    <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("users_view", array("id" => $this->getAttribute($context["customer"], "id", array()))), "html", null, true);
            echo "\" class=\"list-group-item list-group-item-action\">Customer : #";
            echo twig_escape_filter($this->env, $this->getAttribute($context["customer"], "id", array()), "html", null, true);
            echo " , ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["customer"], "username", array()), "html", null, true);
            echo " </a>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['customer'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "
</div>
</div>







";
        
        $__internal_0a06744c0d43e74db556dbeba93b38edd85df98b259449d52386fababadc0f62->leave($__internal_0a06744c0d43e74db556dbeba93b38edd85df98b259449d52386fababadc0f62_prof);

    }

    // line 34
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_edb5b1a1da0098535345e0532395e04df23fe2ccf038de8a541d1a717bfa3184 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_edb5b1a1da0098535345e0532395e04df23fe2ccf038de8a541d1a717bfa3184->enter($__internal_edb5b1a1da0098535345e0532395e04df23fe2ccf038de8a541d1a717bfa3184_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 35
        echo "
<script>

        </script>
";
        
        $__internal_edb5b1a1da0098535345e0532395e04df23fe2ccf038de8a541d1a717bfa3184->leave($__internal_edb5b1a1da0098535345e0532395e04df23fe2ccf038de8a541d1a717bfa3184_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/search.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 35,  129 => 34,  112 => 20,  99 => 18,  95 => 17,  92 => 16,  79 => 14,  74 => 13,  57 => 11,  53 => 10,  46 => 6,  41 => 3,  35 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}
{% block body %}


<div class=\"container\">
<h3>Search Result For  <b>{{ data }}</b></h3>

<br>
<div class=\"list-group \">
  {% for order in ordernumber %}
    <a href=\"{{ path('restaurant_orders_panel_update',{'id':order.id}) }}\" class=\"list-group-item list-group-item-action\">Order : #{{ order.id }} , {{ order.customerName }}  , Order Date : {{  order.orderDate|date(\"d-m-Y\") }} at {{  order.orderDate|date(\"h-i A\") }} </a>
  {% endfor %}
    {% for item in itemData %}
    <a href=\"{{ path('restaurant_edit_menu_item',{'id':item.id}) }}\" class=\"list-group-item list-group-item-action\">Item Id : #{{ item.id }} , {{ item.itemName }} </a>
  {% endfor %}

  {% for customer in customerData %}
    <a href=\"{{ path('users_view',{'id':customer.id}) }}\" class=\"list-group-item list-group-item-action\">Customer : #{{ customer.id }} , {{ customer.username }} </a>
  {% endfor %}

</div>
</div>







{% endblock %}



{% block scripts %}

<script>

        </script>
{% endblock %}
", "AppBundle:Admin:Pages/search.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/search.html.twig");
    }
}

<?php

/* AppBundle:Admin:Stock/stockReturn.html.twig */
class __TwigTemplate_c057aa33abb70ea88ca7b56143bb8063f82773b776bf30dd7011be3bd4e7df75 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Stock/stockReturn.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eae4359e5f5868cf48402fe263654a2e801752919e9707935fe14ec1e677cc8a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eae4359e5f5868cf48402fe263654a2e801752919e9707935fe14ec1e677cc8a->enter($__internal_eae4359e5f5868cf48402fe263654a2e801752919e9707935fe14ec1e677cc8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Stock/stockReturn.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eae4359e5f5868cf48402fe263654a2e801752919e9707935fe14ec1e677cc8a->leave($__internal_eae4359e5f5868cf48402fe263654a2e801752919e9707935fe14ec1e677cc8a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_fb68ed2833e030b9908d2463281bf4beb1add5251c2d5688192e3c50b4b68d46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb68ed2833e030b9908d2463281bf4beb1add5251c2d5688192e3c50b4b68d46->enter($__internal_fb68ed2833e030b9908d2463281bf4beb1add5251c2d5688192e3c50b4b68d46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<!-- Modal -->
<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Upload Menu Items</h4>
      </div>
      <div class=\"modal-body\">
        <p><form>
        <input type=\"file\" class=\"form-control\">
        </form></p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                                                <h3>Purchase Returns</h3>

                        <span class=\"pull-right\">
                    ";
        // line 36
        echo "                            <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_purchase_return");
        echo "\" class=\"btn btn-primary btn-sm\"> Purchase Return</a>
                        </span>
                    </div>
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                ";
        // line 49
        $context["id"] = 1;
        // line 50
        echo "                                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["menuItems"] ?? $this->getContext($context, "menuItems")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 51
            echo "                                <tr>
                                     <td>";
            // line 52
            echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
            echo "</td>
                                    <td>";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "date", array()), "html", null, true);
            echo "</td>
                                    <td>
                                       <a href=\"";
            // line 55
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_restaurant_stock_detail", array("id" => $this->getAttribute($context["product"], "ref", array()))), "html", null, true);
            echo "\" title=\"Manage item\" class=\"btn btn-primary btn-sm\">
                                            <i class=\"fa fa-eye\"></i>
                                        </a>
                                      
                                    </td>
                                </tr>
                                                                ";
            // line 61
            $context["id"] = (($context["id"] ?? $this->getContext($context, "id")) + 1);
            // line 62
            echo "
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 64
        echo "                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
";
        
        $__internal_fb68ed2833e030b9908d2463281bf4beb1add5251c2d5688192e3c50b4b68d46->leave($__internal_fb68ed2833e030b9908d2463281bf4beb1add5251c2d5688192e3c50b4b68d46_prof);

    }

    // line 73
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_fbd885cb598b27e04c0715f80730d487caf25e1f4133fbbf7f3efb51e7caef5d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbd885cb598b27e04c0715f80730d487caf25e1f4133fbbf7f3efb51e7caef5d->enter($__internal_fbd885cb598b27e04c0715f80730d487caf25e1f4133fbbf7f3efb51e7caef5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 74
        echo "
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
   
</script>
";
        
        $__internal_fbd885cb598b27e04c0715f80730d487caf25e1f4133fbbf7f3efb51e7caef5d->leave($__internal_fbd885cb598b27e04c0715f80730d487caf25e1f4133fbbf7f3efb51e7caef5d_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Stock/stockReturn.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  148 => 74,  142 => 73,  128 => 64,  121 => 62,  119 => 61,  110 => 55,  105 => 53,  101 => 52,  98 => 51,  93 => 50,  91 => 49,  74 => 36,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}

<!-- Modal -->
<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Upload Menu Items</h4>
      </div>
      <div class=\"modal-body\">
        <p><form>
        <input type=\"file\" class=\"form-control\">
        </form></p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                                                <h3>Purchase Returns</h3>

                        <span class=\"pull-right\">
                    {#      <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\">Upload CSV</a> #}
                            <a href=\"{{ path('manage_restaurant_purchase_return') }}\" class=\"btn btn-primary btn-sm\"> Purchase Return</a>
                        </span>
                    </div>
                    <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {% set id = 1 %}
                                {% for product in menuItems %}
                                <tr>
                                     <td>{{ id }}</td>
                                    <td>{{ product.date }}</td>
                                    <td>
                                       <a href=\"{{ path('manage_restaurant_stock_detail',{'id':product.ref})}}\" title=\"Manage item\" class=\"btn btn-primary btn-sm\">
                                            <i class=\"fa fa-eye\"></i>
                                        </a>
                                      
                                    </td>
                                </tr>
                                                                {% set id = id + 1 %}

                                {% endfor %}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
   
</script>
{% endblock %}
", "AppBundle:Admin:Stock/stockReturn.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Stock/stockReturn.html.twig");
    }
}

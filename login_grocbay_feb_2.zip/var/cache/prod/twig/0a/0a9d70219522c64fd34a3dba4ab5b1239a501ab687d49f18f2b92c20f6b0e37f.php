<?php

/* @AppBundle/Themes/widget.html.twig */
class __TwigTemplate_e49b9a86a6b3c6afb3e1205b2b4b3bfdfc28f8fbc6364148b5042cca0618261e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'form_row' => array($this, 'block_form_row'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a85dfe24dbf1203959a7787386704255d10c9c273e6ce67603bfb98f9700131 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a85dfe24dbf1203959a7787386704255d10c9c273e6ce67603bfb98f9700131->enter($__internal_1a85dfe24dbf1203959a7787386704255d10c9c273e6ce67603bfb98f9700131_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@AppBundle/Themes/widget.html.twig"));

        // line 2
        $this->displayBlock('form_row', $context, $blocks);
        
        $__internal_1a85dfe24dbf1203959a7787386704255d10c9c273e6ce67603bfb98f9700131->leave($__internal_1a85dfe24dbf1203959a7787386704255d10c9c273e6ce67603bfb98f9700131_prof);

    }

    public function block_form_row($context, array $blocks = array())
    {
        $__internal_3e90b678f8b346b1772757746d2a918eea81bd7094fd2ff77a24578ebb9c7206 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e90b678f8b346b1772757746d2a918eea81bd7094fd2ff77a24578ebb9c7206->enter($__internal_3e90b678f8b346b1772757746d2a918eea81bd7094fd2ff77a24578ebb9c7206_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 3
        ob_start();
        // line 4
        echo "    <div id=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "vars", array()), "id", array()), "html", null, true);
        echo "_form_group\" class=\"form-group ";
        echo (($this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors')) ? ("has-error") : (""));
        echo "\">


  ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
  ";
        // line 8
        if ($this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors')) {
            // line 9
            echo "      ";
            ob_start();
            // line 10
            echo "   ";
            if (array_key_exists("errors", $context)) {
                // line 11
                echo "    ";
                if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
                    // line 12
                    echo "        ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
                    foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                        // line 13
                        echo "          <div class=\"alert alert-danger fade in\">
               <a href=\"javascript:;\" class=\"close\" data-dismiss=\"alert\">&times;</a>
               <strong>Error!</strong> ";
                        // line 15
                        echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                        echo ".
          </div>
        
        ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 19
                    echo "    ";
                }
                // line 20
                echo "   ";
            }
            // line 21
            echo "      ";
            echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
            // line 22
            echo "  ";
        }
        // line 23
        echo "  </div>

";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_3e90b678f8b346b1772757746d2a918eea81bd7094fd2ff77a24578ebb9c7206->leave($__internal_3e90b678f8b346b1772757746d2a918eea81bd7094fd2ff77a24578ebb9c7206_prof);

    }

    public function getTemplateName()
    {
        return "@AppBundle/Themes/widget.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  92 => 23,  89 => 22,  86 => 21,  83 => 20,  80 => 19,  70 => 15,  66 => 13,  61 => 12,  58 => 11,  55 => 10,  52 => 9,  50 => 8,  46 => 7,  37 => 4,  35 => 3,  23 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# app/Resources/views/template/fields.html.twig #}
{% block form_row %}
{% spaceless %}
    <div id=\"{{ form.vars.id }}_form_group\" class=\"form-group {{ form_errors(form) ? \"has-error\" : \"\" }}\">


  {{ form_widget(form) }}
  {% if form_errors(form) %}
      {% spaceless %}
   {% if errors is defined %}
    {% if errors|length > 0 %}
        {% for error in errors %}
          <div class=\"alert alert-danger fade in\">
               <a href=\"javascript:;\" class=\"close\" data-dismiss=\"alert\">&times;</a>
               <strong>Error!</strong> {{ error.message }}.
          </div>
        
        {% endfor %}
    {% endif %}
   {% endif %}
      {% endspaceless %}
  {% endif %}
  </div>

{% endspaceless %}
{% endblock form_row %}", "@AppBundle/Themes/widget.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Themes/widget.html.twig");
    }
}

<?php

/* AppBundle:Admin:Orders/thermal.html.twig */
class __TwigTemplate_0ea70d76b62af76f4c3b37c7bc16013028740febe8708dfb2712e6586dc8d471 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7365e3ccbfe0b83e8a8e5da7f125498b4c3504d6ed1c8f819694b0a536313d7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7365e3ccbfe0b83e8a8e5da7f125498b4c3504d6ed1c8f819694b0a536313d7c->enter($__internal_7365e3ccbfe0b83e8a8e5da7f125498b4c3504d6ed1c8f819694b0a536313d7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Orders/thermal.html.twig"));

        // line 1
        echo "  <style type=\"text/css\">
/* Our Font */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;700&display=swap');
/* Global */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins';
  color: #000 !important;
}
 
body {
  margin-top: 10px;
  height: 100vh;
}

/* The Receipt */
.receipt {
    width: 400px;
    background-color: white;
    border-radius: 30px;
    position: relative;
    /* top: 30%; */
    /* left: 50%; */
    /* margin-top: -360px; */
    /* margin-left: -180px; */
    padding: 20px;
    margin: 0px auto;
}
.body {
    width: 100%;
    display: inline-block;
    margin: 0 auto;
}
/* Heading */
.name {
  text-transform: uppercase;
  text-align: center;
  color: #6c8b8e;
  letter-spacing: 1px;
  font-size: 1.8em;
  margin-top: 10px
}

/* Big thank */
.greeting {
  font-size: 21px;
  text-transform: capitalize;
  text-align: center;
  color: #6f8d90;
  margin: 35px 0;
  letter-spacing: 1.2px
}

/* Order info */
.order p {
  font-size: 15px;
  color: #aaa;
  padding-left: 10px;
  letter-spacing: .7px
}

/* Our line */
hr {
  border: .7px solid #ddd;
  margin: 15px 0;
}

/* Order details */
.details {
  padding-left: 10px;
  margin-bottom: 3px;
  overflow: hidden
}

.details h3 {
  font-weight: 400;
  color: #6c8b8e;
  font-size: 1.5em;
  margin-bottom: 8px
}

/* Image and the info of the order */
.product {
  float: left;
  width: 83%
}

.product img {
  width: 65px;
  float: left
}

.product .info {
  float: left;
  margin-left: 15px
}

.product .info h4 {
  color: #6f8d90;
  font-weight: 400;
  text-transform: uppercase;
  margin-top: 5px
}

.product .info p {
  font-size: 12px;
  color: #aaa;
}

/* Net price */
.details > p {
  color: #6f8d90;
  margin-top: 25px;
  font-size: 15px
}

/* Total price */
.totalprice p {
  padding-left: 10px
}

.totalprice .sub,
.totalprice .del {
  font-size: 13px;
  color: #aaa
}

.totalprice span {
  float: right;
  margin-right: 17px
}

.totalprice .tot {
  color: #6f8d90;
  font-size: 15px
}

/* Footer */
footer {
  font-size: 10px;
  text-align: center;
  margin-top: 15px; /* You can make it with position try it */
  color: #aaa
}
.td
{
      padding-left: 24px !important;
    background: white;
    padding: 3px;
    font-size: 12px;
}
.tdd
{
     
    font-size: 12px;
}
.tds {
    padding-left: 20px !important;
    background: white;
    padding: 3px;
    font-size: 12px;
    font-weight: bold;  
}
.tdds {
    background: white;
    padding: 3px;
    font-size: 12px;
    font-weight: bold;  
}
.tdss {
    padding-left: 18px !important;
    background: white;
    padding: 3px;
    font-size: 10px;
    font-weight: bold;  
}
.tdsss {
    padding-left: 50px !important;
    background: white;
    padding: 3px;
    font-size: 10px;
    font-weight: bold;  
}
hr {
    border: .7px solid #ddd;
    margin: 3px 0;
}
 @media print
      {
         @page {
           margin-top: 0;
           margin-bottom: 0;
         }
         body  {
           padding-top: 72px;
           padding-bottom: 72px ;
         }
      } 
    </style>
    ";
        // line 202
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["restaurant"] ?? $this->getContext($context, "restaurant")));
        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
            // line 203
            echo "       <div class=\"body\">

    <div class=\"receipt\">

      <h2 class=\"name\"> ";
            // line 207
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantName", array()), "html", null, true);
            echo " </h2>
      
    <center> 
     ";
            // line 210
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["orders"] ?? $this->getContext($context, "orders")));
            foreach ($context['_seq'] as $context["_key"] => $context["order"]) {
                // line 211
                echo "    <b>#";
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "id", array()), "html", null, true);
                echo "</b>
    <h4>";
                // line 212
                if (($this->getAttribute($context["order"], "orderType", array()) == "Delivery")) {
                    echo " Home Delivery ";
                } elseif (($this->getAttribute($context["order"], "orderType", array()) == "pickup")) {
                    echo " Pickup From Store ";
                } else {
                    echo " Express Delivery ";
                }
                echo "</h4>
 ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['order'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 213
            echo "   
  <div class=\"order\"><small>
                           ";
            // line 215
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantAddress", array()), "html", null, true);
            echo "<br>
                           ";
            // line 216
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantLocation", array()), "html", null, true);
            echo "<br>
                            Gst No:";
            // line 217
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "gst", array()), "html", null, true);
            echo "<br>

                           Mobile : ";
            // line 219
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "primaryMobile", array()), "html", null, true);
            echo "<br>
                           Email : ";
            // line 220
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "primaryEmail", array()), "html", null, true);
            echo " 
                         </small>
                         </div></center>

<hr>
      <!-- Order info -->
      <div class=\"order\">
    ";
            // line 227
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["orders"] ?? $this->getContext($context, "orders")));
            foreach ($context['_seq'] as $context["_key"] => $context["order"]) {
                // line 228
                echo "
      <p>Bill to/Ship to:<br>
                           <small>
                           ";
                // line 231
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "customerName", array()), "html", null, true);
                echo "<br>
                           ";
                // line 232
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "address", array()), "html", null, true);
                echo "<br>
                           ";
                // line 233
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "landmark", array()), "html", null, true);
                echo "<br>
                           Mobile : ";
                // line 234
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "mobileNo", array()), "html", null, true);
                echo "<br>
                           Email : ";
                // line 235
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "email", array()), "html", null, true);
                echo "<br>
                           Gst No: ";
                // line 236
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "gst", array()), "html", null, true);
                echo "<br>
                           Delivery Date :  ";
                // line 237
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "fixDate", array()), "html", null, true);
                echo "<br>
Delivery Time : ";
                // line 238
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "fixtime", array()), "html", null, true);
                echo "<br>
Note : <b>";
                // line 239
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "note", array()), "html", null, true);
                echo "</b><br>
Order Date :";
                // line 240
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["order"], "orderDate", array()), "d-m-Y"), "html", null, true);
                echo " at ";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["order"], "orderDate", array()), "h-i A"), "html", null, true);
                echo "<br>
Payment Type : ";
                // line 241
                if (($this->getAttribute($context["order"], "paymentType", array()) == "cod")) {
                    echo "Cash On Delivery ";
                } elseif (($this->getAttribute($context["order"], "paymentType", array()) == "sod")) {
                    echo " Swipe On Delivery ";
                } else {
                    echo " ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "paymentType", array()), "html", null, true);
                    echo " ";
                }
                // line 242
                echo "                           </small>
      </div>

      <hr>

      <!-- Details -->

<table>
  <tr>
    <td class=\"tdds\">Item</td>
      <td class=\"tds\">Net. Price</td>
    <td class=\"tds\">Qty</td>
    <td class=\"tds\">Discount</td>
    <td class=\"tds\">Total </td>
 </tr>
 ";
                // line 257
                $context["count"] = 0;
                // line 258
                echo " ";
                $context["sum"] = 0;
                // line 259
                echo " ";
                $context["discount"] = 0;
                // line 260
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["items"] ?? $this->getContext($context, "items")));
                foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                    // line 261
                    if (($this->getAttribute($context["item"], "order_d", array()) == $this->getAttribute($context["order"], "id", array()))) {
                        // line 262
                        if ((($this->getAttribute($context["item"], "tax", array()) == 0) || ($this->getAttribute($context["item"], "tax", array()) == ""))) {
                            // line 263
                            $context["taxp"] = $this->getAttribute($context["item"], "tax", array());
                            echo " 
<tr>
    <td class=\"tdd\">";
                            // line 265
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
                            echo " - ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "priceVariavtion", array()), "html", null, true);
                            echo "<br>
    ";
                            // line 266
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "barcode", array()), "html", null, true);
                            echo "</td>
  ";
                            // line 267
                            $context["dis"] = ($this->getAttribute($context["item"], "discount", array()) + $this->getAttribute($context["item"], "discountPrice", array()));
                            // line 268
                            echo "    <td class=\"td\">";
                            $context["final"] = $this->getAttribute($context["item"], "price", array());
                            // line 269
                            echo "        ";
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                // line 270
                                echo "          ";
                                echo twig_escape_filter($this->env, twig_round(($context["final"] ?? $this->getContext($context, "final")), 2, "floor"), "html", null, true);
                                echo "
        ";
                            } elseif ((                            // line 271
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                // line 272
                                echo "          ";
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["final"] ?? $this->getContext($context, "final")), 2, ".", ""), "html", null, true);
                                echo "
        ";
                            }
                            // line 274
                            echo "    </td>
    <td class=\"td\">";
                            // line 275
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", array()), "html", null, true);
                            echo "</td>
    <td class=\"td\">";
                            // line 276
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "discount", array()), "html", null, true);
                            echo "</td>
    <td class=\"td\">";
                            // line 277
                            $context["x"] = ($this->getAttribute($context["item"], "price", array()) * $this->getAttribute($context["item"], "quantity", array()));
                            echo " 
        ";
                            // line 278
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                // line 279
                                echo "          ";
                                echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["item"], "subTotal", array()), 2, "floor"), "html", null, true);
                                echo "
        ";
                            } elseif ((                            // line 280
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                // line 281
                                echo "          ";
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["item"], "subTotal", array()), 2, ".", ""), "html", null, true);
                                echo "
        ";
                            }
                            // line 283
                            echo "    </td>
 </tr>
 ";
                            // line 285
                            $context["fts"] = (0 * $this->getAttribute($context["item"], "quantity", array()));
                            echo " 
 ";
                            // line 286
                            $context["stotal"] = ($this->getAttribute($context["item"], "subTotal", array()) - twig_round($this->getAttribute($context["item"], "discount", array()), 2, "floor"));
                            // line 287
                            echo "
";
                        } else {
                            // line 288
                            echo " 
<tr>
    <td class=\"tdd\">";
                            // line 290
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "itemName", array()), "html", null, true);
                            echo " - ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "priceVariavtion", array()), "html", null, true);
                            echo "<br>
    ";
                            // line 291
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "barcode", array()), "html", null, true);
                            echo " </td>
  ";
                            // line 292
                            $context["dis"] = ($this->getAttribute($context["item"], "discount", array()) + $this->getAttribute($context["item"], "discountPrice", array()));
                            // line 293
                            echo "    ";
                            if ((($context["orders"] ?? $this->getContext($context, "orders")) == "")) {
                                // line 294
                                echo "    <center>No Data Found!</center>
";
                            }
                            // line 295
                            echo "  
";
                            // line 296
                            if (($this->getAttribute($context["item"], "discount", array()) != 0)) {
                                // line 297
                                $context["discount"] = $this->getAttribute($context["item"], "discount", array());
                                // line 298
                                $context["quantity"] = $this->getAttribute($context["item"], "quantity", array());
                                // line 299
                                $context["priceO"] = (($context["discount"] ?? $this->getContext($context, "discount")) / ($context["quantity"] ?? $this->getContext($context, "quantity")));
                                // line 300
                                $context["price"] = ($this->getAttribute($context["item"], "price", array()) + ($context["priceO"] ?? $this->getContext($context, "priceO")));
                            } else {
                                // line 302
                                $context["price"] = $this->getAttribute($context["item"], "price", array());
                            }
                            // line 304
                            echo " ";
                            $context["taxp"] = (($context["price"] ?? $this->getContext($context, "price")) / $this->getAttribute($context["item"], "tax", array()));
                            echo " ";
                            $context["finals"] = ($context["price"] ?? $this->getContext($context, "price"));
                            echo " 
";
                            // line 305
                            $context["xs"] = (100 + $this->getAttribute($context["item"], "tax", array()));
                            // line 306
                            echo " ";
                            $context["finals"] = ((($context["price"] ?? $this->getContext($context, "price")) * 100) / ($context["xs"] ?? $this->getContext($context, "xs")));
                            echo " 
                                     ";
                            // line 307
                            $context["final"] = ($context["finals"] ?? $this->getContext($context, "finals"));
                            // line 308
                            echo "   ";
                            $context["f"] = (($context["price"] ?? $this->getContext($context, "price")) - ($context["final"] ?? $this->getContext($context, "final")));
                            echo " 

   ";
                            // line 310
                            $context["ft"] = (($context["f"] ?? $this->getContext($context, "f")) * $this->getAttribute($context["item"], "quantity", array()));
                            echo " 

    <td class=\"td\">";
                            // line 312
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round(($context["final"] ?? $this->getContext($context, "final")), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["final"] ?? $this->getContext($context, "final")), 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
  
    <td class=\"td\">";
                            // line 314
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", array()), "html", null, true);
                            echo "</td>
    <td class=\"td\">";
                            // line 315
                            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "discount", array()), "html", null, true);
                            echo "</td>
      ";
                            // line 316
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                // line 317
                                $context["subTotals"] = (twig_round(($context["final"] ?? $this->getContext($context, "final")), 2, "floor") * $this->getAttribute($context["item"], "quantity", array()));
                                echo " 
";
                            } elseif ((                            // line 318
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                // line 319
                                $context["subTotals"] = (twig_number_format_filter($this->env, ($context["final"] ?? $this->getContext($context, "final")), 2, ".", "") * $this->getAttribute($context["item"], "quantity", array()));
                                echo " 
";
                            }
                            // line 321
                            echo "    <td class=\"td\"> 
";
                            // line 322
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                // line 323
                                echo " ";
                                $context["f"] = (($context["price"] ?? $this->getContext($context, "price")) - twig_round(($context["final"] ?? $this->getContext($context, "final")), 2, "floor"));
                                echo " ";
                                $context["ft"] = (($context["f"] ?? $this->getContext($context, "f")) * $this->getAttribute($context["item"], "quantity", array()));
                                echo " 

";
                            } elseif ((                            // line 325
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                // line 326
                                $context["f"] = (($context["price"] ?? $this->getContext($context, "price")) - twig_number_format_filter($this->env, ($context["final"] ?? $this->getContext($context, "final")), 2, ".", ""));
                                echo " 
";
                            }
                            // line 328
                            $context["fts"] = (($context["f"] ?? $this->getContext($context, "f")) * $this->getAttribute($context["item"], "quantity", array()));
                            echo " 

      ";
                            // line 330
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                $context["x"] = twig_round(($context["subTotals"] ?? $this->getContext($context, "subTotals")), 2, "floor");
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                $context["x"] = twig_number_format_filter($this->env, ($context["subTotals"] ?? $this->getContext($context, "subTotals")), 2, ".", "");
                            }
                            // line 331
                            echo " ";
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                // line 332
                                echo " ";
                                $context["stotal"] = (($context["x"] ?? $this->getContext($context, "x")) - twig_round($this->getAttribute($context["item"], "discount", array()), 2, "floor"));
                                // line 333
                                echo "                                       ";
                                echo twig_escape_filter($this->env, (($context["x"] ?? $this->getContext($context, "x")) - twig_round($this->getAttribute($context["item"], "discount", array()), 2, "floor")), "html", null, true);
                                echo "
                                    ";
                            } elseif ((                            // line 334
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                // line 335
                                echo "                                       ";
                                echo twig_escape_filter($this->env, (($context["x"] ?? $this->getContext($context, "x")) - twig_number_format_filter($this->env, $this->getAttribute($context["item"], "discount", array()), 2, ".", "")), "html", null, true);
                                echo "
                                        ";
                                // line 336
                                $context["stotal"] = (($context["x"] ?? $this->getContext($context, "x")) - twig_number_format_filter($this->env, $this->getAttribute($context["item"], "discount", array()), 2, ".", ""));
                                // line 337
                                echo "
                                    ";
                            }
                            // line 339
                            echo "    </td>

 </tr>

 ";
                        }
                        // line 344
                        echo "    ";
                        $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + ($context["fts"] ?? $this->getContext($context, "fts")));
                        // line 345
                        echo "    ";
                        $context["sum"] = (($context["sum"] ?? $this->getContext($context, "sum")) + ($context["stotal"] ?? $this->getContext($context, "stotal")));
                        // line 346
                        echo "    ";
                        $context["discount"] = (($context["discount"] ?? $this->getContext($context, "discount")) + ($context["dis"] ?? $this->getContext($context, "dis")));
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 349
                echo "</table>
<hr>  
";
                // line 351
                if (((($context["count"] ?? $this->getContext($context, "count")) == 0) || (($context["count"] ?? $this->getContext($context, "count")) == ""))) {
                    // line 352
                    echo "<div class=\"totalprice\">

        <p class=\"sub\"> Subtotal <span> ";
                    // line 354
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round(($context["sum"] ?? $this->getContext($context, "sum")), 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["sum"] ?? $this->getContext($context, "sum")), 2, ".", ""), "html", null, true);
                    }
                    echo "</span></p>
        <!-- <p class=\"del\"> Tax <span>   ";
                    // line 355
                    echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                    echo " </span> </p> -->
        <!-- <p class=\"del\"> Discount <span> ";
                    // line 356
                    echo twig_escape_filter($this->env, ($this->getAttribute($context["order"], "totalDiscount", array()) + $this->getAttribute($context["order"], "discountTotal", array())), "html", null, true);
                    echo " </span> </p> -->
 <p class=\"del\"> Delivery <span> ";
                    // line 357
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["order"], "deliveryCharge", array()), 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["order"], "deliveryCharge", array()), 2, ".", ""), "html", null, true);
                    }
                    echo " </span> </p>
  ";
                    // line 358
                    if (($this->getAttribute($context["order"], "promocode", array()) == "")) {
                        // line 359
                        echo "        ";
                    } else {
                        // line 360
                        echo "        ";
                    }
                    // line 361
                    echo "      ";
                    if (($this->getAttribute($context["order"], "loyalty", array()) == 0)) {
                        // line 362
                        echo "        ";
                    } else {
                        // line 363
                        echo "        <p class=\"del\"> Loyalty <span>-";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "loyalty", array()), "html", null, true);
                        echo "</span> </p>
        ";
                    }
                    // line 365
                    echo "        <hr>

        <p class=\"del\"> Total <span> ";
                    // line 367
                    if (($this->getAttribute($context["order"], "paymentType", array()) == "wallet")) {
                        echo " ";
                        $context["total"] = (($this->getAttribute($context["order"], "actualAmount", array()) + $this->getAttribute($context["order"], "deliveryCharge", array())) - $this->getAttribute($context["order"], "totalDiscount", array()));
                        echo " ";
                        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                            echo twig_escape_filter($this->env, twig_round(($context["total"] ?? $this->getContext($context, "total")), 2, "floor"), "html", null, true);
                        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["total"] ?? $this->getContext($context, "total")), 2, ".", ""), "html", null, true);
                        }
                        echo " ";
                    } else {
                        echo twig_escape_filter($this->env, ($this->getAttribute($context["order"], "orderAmount", array()) - $this->getAttribute($context["order"], "totalDiscount", array())), "html", null, true);
                    }
                    echo "</span> </p>

      </div>

      ";
                    // line 371
                    if ((($context["discount"] ?? $this->getContext($context, "discount")) == 0)) {
                        // line 372
                        echo "      ";
                    } else {
                        // line 373
                        echo "          ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(($context["restaurant"] ?? $this->getContext($context, "restaurant")));
                        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
                            // line 374
                            echo "       <center><b>You Saved ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "currencyFormat", array()), "html", null, true);
                            $context["d"] = ($context["discount"] ?? $this->getContext($context, "discount"));
                            echo " ";
                            echo twig_escape_filter($this->env, ($context["d"] ?? $this->getContext($context, "d")), "html", null, true);
                            echo "</b></center>
        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 376
                        echo "        ";
                    }
                    // line 377
                    echo "<center style=\"font-size:10px;\"> 
    ";
                    // line 378
                    if (($this->getAttribute($context["order"], "promocode", array()) != "")) {
                        // line 379
                        echo "  <span> Promocode (";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "promocode", array()), "html", null, true);
                        echo ")<span> <b>";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "totalDiscount", array()), "html", null, true);
                        echo " OFF!</b></span><br>
";
                    }
                    // line 381
                    echo "<span>Wallet Payment : ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "wallet", array()), "html", null, true);
                    echo " | Cash/Online Payment :  ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "orderAmount", array()), "html", null, true);
                    echo "</span></center>
";
                } else {
                    // line 383
                    echo "      <div class=\"totalprice\">

        <p class=\"sub\"> Subtotal <span> ";
                    // line 385
                    $context["x"] = (($this->getAttribute($context["order"], "actualAmount", array()) * ($context["count"] ?? $this->getContext($context, "count"))) / 100);
                    echo " ";
                    $context["fin"] = (($context["sum"] ?? $this->getContext($context, "sum")) - ($context["x"] ?? $this->getContext($context, "x")));
                    echo " ";
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["sum"] ?? $this->getContext($context, "sum")), 2, ".", ""), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["sum"] ?? $this->getContext($context, "sum")), 2, ".", ""), "html", null, true);
                    }
                    echo "</span></p>
        ";
                    // line 386
                    if (($this->getAttribute($context["res"], "currencyFormat", array()) == "AED")) {
                        // line 387
                        echo "<p class=\"del\"> VAT <span>   ";
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), 2, ".", ""), "html", null, true);
                        echo " </span> </p> 
";
                    } else {
                        // line 389
                        echo "<p class=\"del\"> Tax <span>   ";
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), 2, ".", ""), "html", null, true);
                        echo " </span> </p> 

        ";
                    }
                    // line 392
                    echo "  

        <p class=\"del\"> Delivery <span> ";
                    // line 394
                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                        echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["order"], "deliveryCharge", array()), 2, "floor"), "html", null, true);
                    } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["order"], "deliveryCharge", array()), 2, ".", ""), "html", null, true);
                    }
                    echo " </span> </p>
  ";
                    // line 395
                    if (($this->getAttribute($context["order"], "promocode", array()) == "")) {
                        // line 396
                        echo "        ";
                    } else {
                        // line 397
                        echo "        ";
                    }
                    // line 398
                    echo "      ";
                    if (($this->getAttribute($context["order"], "loyalty", array()) == 0)) {
                        // line 399
                        echo "        ";
                    } else {
                        // line 400
                        echo "        <p class=\"del\"> Loyalty <span>-";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "loyalty", array()), "html", null, true);
                        echo "</span> </p>
        ";
                    }
                    // line 402
                    echo " 
         
               <hr>

        <p class=\"del\"> Total <span> ";
                    // line 406
                    if (($this->getAttribute($context["order"], "paymentType", array()) == "wallet")) {
                        echo " ";
                        $context["total"] = (($this->getAttribute($context["order"], "actualAmount", array()) + $this->getAttribute($context["order"], "deliveryCharge", array())) - $this->getAttribute($context["order"], "totalDiscount", array()));
                        echo " ";
                        if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["total"] ?? $this->getContext($context, "total")), 2, ".", ""), "html", null, true);
                        } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["total"] ?? $this->getContext($context, "total")), 2, ".", ""), "html", null, true);
                        }
                        echo " ";
                    } else {
                        $context["total"] = (((($this->getAttribute($context["order"], "actualAmount", array()) + $this->getAttribute($context["order"], "wallet", array())) + $this->getAttribute($context["order"], "loyalty", array())) + $this->getAttribute($context["order"], "deliveryCharge", array())) - $this->getAttribute($context["order"], "totalDiscount", array()));
                        echo " ";
                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["total"] ?? $this->getContext($context, "total")), 2, ".", ""), "html", null, true);
                    }
                    echo "</span> </p>

      </div>
      ";
                    // line 409
                    if ((($context["discount"] ?? $this->getContext($context, "discount")) == 0)) {
                        // line 410
                        echo "      ";
                    } else {
                        // line 411
                        echo "          ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(($context["restaurant"] ?? $this->getContext($context, "restaurant")));
                        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
                            // line 412
                            echo "       <center><b>You Saved ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "currencyFormat", array()), "html", null, true);
                            $context["d"] = ($context["discount"] ?? $this->getContext($context, "discount"));
                            echo " ";
                            echo twig_escape_filter($this->env, ($context["d"] ?? $this->getContext($context, "d")), "html", null, true);
                            echo "</b></center>
        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 414
                        echo "     ";
                    }
                    // line 415
                    echo "<center style=\"font-size:10px;\">
  ";
                    // line 416
                    if (($this->getAttribute($context["order"], "promocode", array()) != "")) {
                        // line 417
                        echo "  <span> Promocode (";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "promocode", array()), "html", null, true);
                        echo ")<span> <b>";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "totalDiscount", array()), "html", null, true);
                        echo " OFF!</b></span><br>
";
                    }
                    // line 419
                    echo "Wallet Payment : ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "wallet", array()), "html", null, true);
                    echo " | Cash/Online Payment :  ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "orderAmount", array()), "html", null, true);
                    echo "</span></center>
";
                    // line 420
                    if (($this->getAttribute($context["res"], "currencyFormat", array()) == "AED")) {
                    } else {
                        // line 422
                        if (((($context["count"] ?? $this->getContext($context, "count")) == 0) || (($context["count"] ?? $this->getContext($context, "count")) == ""))) {
                        } else {
                            // line 424
                            echo " 
<table>
  <tr>
    <td class=\"tdss\">GST Index</td>
    <td class=\"tdss\">Taxable Amount</td>
    <td class=\"tdss\">CGST</td>
    <td class=\"tdss\">SGST</td>
    <td class=\"tdss\">Total</td>
 </tr>
 <hr>       

 ";
                            // line 435
                            $context["count"] = 1;
                            // line 436
                            echo "  ";
                            $context["res"] = 0;
                            // line 437
                            echo "  ";
                            $context["data"] = 0;
                            // line 438
                            echo "
 ";
                            // line 439
                            $context['_parent'] = $context;
                            $context['_seq'] = twig_ensure_traversable(($context["tax"] ?? $this->getContext($context, "tax")));
                            foreach ($context['_seq'] as $context["_key"] => $context["ta"]) {
                                // line 440
                                echo " ";
                                if (($this->getAttribute($context["ta"], "tax", array()) == 0)) {
                                    // line 441
                                    echo " ";
                                } else {
                                    // line 442
                                    echo "  <tr> 
    <td class=\"td\">";
                                    // line 443
                                    echo twig_escape_filter($this->env, $this->getAttribute($context["ta"], "tax", array()), "html", null, true);
                                    echo "</td>
    <td class=\"td\">";
                                    // line 444
                                    $context["x"] = (100 + $this->getAttribute($context["ta"], "tax", array()));
                                    // line 445
                                    echo "                                     ";
                                    $context["pr"] = (($this->getAttribute($context["ta"], "subTotal", array()) * 100) / ($context["x"] ?? $this->getContext($context, "x")));
                                    echo " 
                                     ";
                                    // line 446
                                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                        // line 447
                                        echo "                                      ";
                                        echo twig_escape_filter($this->env, twig_round(($context["pr"] ?? $this->getContext($context, "pr")), 2, "floor"), "html", null, true);
                                        echo "
                                    ";
                                    } elseif ((                                    // line 448
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                        // line 449
                                        echo "                                      ";
                                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["pr"] ?? $this->getContext($context, "pr")), 2, ".", ""), "html", null, true);
                                        echo "
                                    ";
                                    }
                                    // line 451
                                    echo "</td>
";
                                    // line 452
                                    $context["cgst"] = ($this->getAttribute($context["ta"], "subTotal", array()) - ($context["pr"] ?? $this->getContext($context, "pr")));
                                    echo " 
    <td class=\"td\">";
                                    // line 453
                                    $context["cg"] = (($context["cgst"] ?? $this->getContext($context, "cgst")) / 2);
                                    echo " 
    ";
                                    // line 454
                                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                        // line 455
                                        echo "      ";
                                        echo twig_escape_filter($this->env, twig_round(($context["cg"] ?? $this->getContext($context, "cg")), 2, "floor"), "html", null, true);
                                        echo "
    ";
                                    } elseif ((                                    // line 456
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                        // line 457
                                        echo "      ";
                                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["cg"] ?? $this->getContext($context, "cg")), 2, ".", ""), "html", null, true);
                                        echo "
    ";
                                    }
                                    // line 459
                                    echo "      </td>
    <td class=\"td\">  
    ";
                                    // line 461
                                    if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                        // line 462
                                        echo "      ";
                                        echo twig_escape_filter($this->env, twig_round(($context["cg"] ?? $this->getContext($context, "cg")), 2, "floor"), "html", null, true);
                                        echo "
    ";
                                    } elseif ((                                    // line 463
($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                        // line 464
                                        echo "      ";
                                        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["cg"] ?? $this->getContext($context, "cg")), 2, ".", ""), "html", null, true);
                                        echo "
    ";
                                    }
                                    // line 466
                                    echo "    </td>
    <td class=\"td\">";
                                    // line 467
                                    echo twig_escape_filter($this->env, $this->getAttribute($context["ta"], "subTotal", array()), "html", null, true);
                                    echo "</td>
 </tr>
 ";
                                    // line 469
                                    $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
                                    // line 470
                                    echo " ";
                                    $context["res"] = ($context["res"] + ($context["cg"] ?? $this->getContext($context, "cg")));
                                    // line 471
                                    echo "  ";
                                    $context["data"] = (($context["data"] ?? $this->getContext($context, "data")) + ($context["pr"] ?? $this->getContext($context, "pr")));
                                    // line 472
                                    echo " ";
                                }
                                // line 473
                                echo "
";
                            }
                            $_parent = $context['_parent'];
                            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ta'], $context['_parent'], $context['loop']);
                            $context = array_intersect_key($context, $_parent) + $_parent;
                            // line 475
                            echo "<tr>
<th colspan=\"5\"><hr></th></tr>
  <tr>

    <td class=\"tdss\">Total</td>
    <td class=\"tdss\">";
                            // line 480
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round(($context["data"] ?? $this->getContext($context, "data")), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["data"] ?? $this->getContext($context, "data")), 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
    <td class=\"tdss\">";
                            // line 481
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round($context["res"], 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $context["res"], 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
    <td class=\"tdss\">";
                            // line 482
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round($context["res"], 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $context["res"], 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
    <td class=\"tdss\">";
                            // line 483
                            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                                echo twig_escape_filter($this->env, twig_round($this->getAttribute($context["order"], "actualAmount", array()), 2, "floor"), "html", null, true);
                            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["order"], "actualAmount", array()), 2, ".", ""), "html", null, true);
                            }
                            echo "</td>
 </tr>
</table>
";
                        }
                    }
                    // line 488
                    echo " ";
                }
                // line 489
                echo "
<hr>
   ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['order'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 492
            echo "      <!-- Footer -->
      <footer><b> Thank you for ordering with      ";
            // line 493
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["restaurant"] ?? $this->getContext($context, "restaurant")));
            foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
                // line 494
                echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "restaurantName", array()), "html", null, true);
                echo "</b> ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "</footer>

    </div>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 497
        echo "  </div>";
        
        $__internal_7365e3ccbfe0b83e8a8e5da7f125498b4c3504d6ed1c8f819694b0a536313d7c->leave($__internal_7365e3ccbfe0b83e8a8e5da7f125498b4c3504d6ed1c8f819694b0a536313d7c_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Orders/thermal.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1114 => 497,  1100 => 494,  1096 => 493,  1093 => 492,  1085 => 489,  1082 => 488,  1070 => 483,  1062 => 482,  1054 => 481,  1046 => 480,  1039 => 475,  1032 => 473,  1029 => 472,  1026 => 471,  1023 => 470,  1021 => 469,  1016 => 467,  1013 => 466,  1007 => 464,  1005 => 463,  1000 => 462,  998 => 461,  994 => 459,  988 => 457,  986 => 456,  981 => 455,  979 => 454,  975 => 453,  971 => 452,  968 => 451,  962 => 449,  960 => 448,  955 => 447,  953 => 446,  948 => 445,  946 => 444,  942 => 443,  939 => 442,  936 => 441,  933 => 440,  929 => 439,  926 => 438,  923 => 437,  920 => 436,  918 => 435,  905 => 424,  902 => 422,  899 => 420,  892 => 419,  884 => 417,  882 => 416,  879 => 415,  876 => 414,  864 => 412,  859 => 411,  856 => 410,  854 => 409,  834 => 406,  828 => 402,  822 => 400,  819 => 399,  816 => 398,  813 => 397,  810 => 396,  808 => 395,  800 => 394,  796 => 392,  789 => 389,  783 => 387,  781 => 386,  769 => 385,  765 => 383,  757 => 381,  749 => 379,  747 => 378,  744 => 377,  741 => 376,  729 => 374,  724 => 373,  721 => 372,  719 => 371,  700 => 367,  696 => 365,  690 => 363,  687 => 362,  684 => 361,  681 => 360,  678 => 359,  676 => 358,  668 => 357,  664 => 356,  660 => 355,  652 => 354,  648 => 352,  646 => 351,  642 => 349,  634 => 346,  631 => 345,  628 => 344,  621 => 339,  617 => 337,  615 => 336,  610 => 335,  608 => 334,  603 => 333,  600 => 332,  597 => 331,  591 => 330,  586 => 328,  581 => 326,  579 => 325,  571 => 323,  569 => 322,  566 => 321,  561 => 319,  559 => 318,  555 => 317,  553 => 316,  549 => 315,  545 => 314,  536 => 312,  531 => 310,  525 => 308,  523 => 307,  518 => 306,  516 => 305,  509 => 304,  506 => 302,  503 => 300,  501 => 299,  499 => 298,  497 => 297,  495 => 296,  492 => 295,  488 => 294,  485 => 293,  483 => 292,  479 => 291,  473 => 290,  469 => 288,  465 => 287,  463 => 286,  459 => 285,  455 => 283,  449 => 281,  447 => 280,  442 => 279,  440 => 278,  436 => 277,  432 => 276,  428 => 275,  425 => 274,  419 => 272,  417 => 271,  412 => 270,  409 => 269,  406 => 268,  404 => 267,  400 => 266,  394 => 265,  389 => 263,  387 => 262,  385 => 261,  381 => 260,  378 => 259,  375 => 258,  373 => 257,  356 => 242,  346 => 241,  340 => 240,  336 => 239,  332 => 238,  328 => 237,  324 => 236,  320 => 235,  316 => 234,  312 => 233,  308 => 232,  304 => 231,  299 => 228,  295 => 227,  285 => 220,  281 => 219,  276 => 217,  272 => 216,  268 => 215,  264 => 213,  250 => 212,  245 => 211,  241 => 210,  235 => 207,  229 => 203,  225 => 202,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("  <style type=\"text/css\">
/* Our Font */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;700&display=swap');
/* Global */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins';
  color: #000 !important;
}
 
body {
  margin-top: 10px;
  height: 100vh;
}

/* The Receipt */
.receipt {
    width: 400px;
    background-color: white;
    border-radius: 30px;
    position: relative;
    /* top: 30%; */
    /* left: 50%; */
    /* margin-top: -360px; */
    /* margin-left: -180px; */
    padding: 20px;
    margin: 0px auto;
}
.body {
    width: 100%;
    display: inline-block;
    margin: 0 auto;
}
/* Heading */
.name {
  text-transform: uppercase;
  text-align: center;
  color: #6c8b8e;
  letter-spacing: 1px;
  font-size: 1.8em;
  margin-top: 10px
}

/* Big thank */
.greeting {
  font-size: 21px;
  text-transform: capitalize;
  text-align: center;
  color: #6f8d90;
  margin: 35px 0;
  letter-spacing: 1.2px
}

/* Order info */
.order p {
  font-size: 15px;
  color: #aaa;
  padding-left: 10px;
  letter-spacing: .7px
}

/* Our line */
hr {
  border: .7px solid #ddd;
  margin: 15px 0;
}

/* Order details */
.details {
  padding-left: 10px;
  margin-bottom: 3px;
  overflow: hidden
}

.details h3 {
  font-weight: 400;
  color: #6c8b8e;
  font-size: 1.5em;
  margin-bottom: 8px
}

/* Image and the info of the order */
.product {
  float: left;
  width: 83%
}

.product img {
  width: 65px;
  float: left
}

.product .info {
  float: left;
  margin-left: 15px
}

.product .info h4 {
  color: #6f8d90;
  font-weight: 400;
  text-transform: uppercase;
  margin-top: 5px
}

.product .info p {
  font-size: 12px;
  color: #aaa;
}

/* Net price */
.details > p {
  color: #6f8d90;
  margin-top: 25px;
  font-size: 15px
}

/* Total price */
.totalprice p {
  padding-left: 10px
}

.totalprice .sub,
.totalprice .del {
  font-size: 13px;
  color: #aaa
}

.totalprice span {
  float: right;
  margin-right: 17px
}

.totalprice .tot {
  color: #6f8d90;
  font-size: 15px
}

/* Footer */
footer {
  font-size: 10px;
  text-align: center;
  margin-top: 15px; /* You can make it with position try it */
  color: #aaa
}
.td
{
      padding-left: 24px !important;
    background: white;
    padding: 3px;
    font-size: 12px;
}
.tdd
{
     
    font-size: 12px;
}
.tds {
    padding-left: 20px !important;
    background: white;
    padding: 3px;
    font-size: 12px;
    font-weight: bold;  
}
.tdds {
    background: white;
    padding: 3px;
    font-size: 12px;
    font-weight: bold;  
}
.tdss {
    padding-left: 18px !important;
    background: white;
    padding: 3px;
    font-size: 10px;
    font-weight: bold;  
}
.tdsss {
    padding-left: 50px !important;
    background: white;
    padding: 3px;
    font-size: 10px;
    font-weight: bold;  
}
hr {
    border: .7px solid #ddd;
    margin: 3px 0;
}
 @media print
      {
         @page {
           margin-top: 0;
           margin-bottom: 0;
         }
         body  {
           padding-top: 72px;
           padding-bottom: 72px ;
         }
      } 
    </style>
    {% for res in restaurant%}
       <div class=\"body\">

    <div class=\"receipt\">

      <h2 class=\"name\"> {{ res.restaurantName }} </h2>
      
    <center> 
     {% for order in orders %}
    <b>#{{ order.id }}</b>
    <h4>{% if order.orderType == 'Delivery' %} Home Delivery {% elseif order.orderType == 'pickup' %} Pickup From Store {% else %} Express Delivery {% endif %}</h4>
 {% endfor %}   
  <div class=\"order\"><small>
                           {{ res.restaurantAddress }}<br>
                           {{ res.restaurantLocation }}<br>
                            Gst No:{{ res.gst }}<br>

                           Mobile : {{ res.primaryMobile }}<br>
                           Email : {{ res.primaryEmail }} 
                         </small>
                         </div></center>

<hr>
      <!-- Order info -->
      <div class=\"order\">
    {% for order in orders %}

      <p>Bill to/Ship to:<br>
                           <small>
                           {{ order.customerName }}<br>
                           {{ order.address }}<br>
                           {{ order.landmark }}<br>
                           Mobile : {{ order.mobileNo }}<br>
                           Email : {{ order.email }}<br>
                           Gst No: {{ order.gst }}<br>
                           Delivery Date :  {{ order.fixDate }}<br>
Delivery Time : {{ order.fixtime }}<br>
Note : <b>{{ order.note }}</b><br>
Order Date :{{  order.orderDate|date(\"d-m-Y\") }} at {{  order.orderDate|date(\"h-i A\") }}<br>
Payment Type : {% if order.paymentType == 'cod' %}Cash On Delivery {% elseif order.paymentType == 'sod'%} Swipe On Delivery {% else %} {{ order.paymentType }} {% endif %}
                           </small>
      </div>

      <hr>

      <!-- Details -->

<table>
  <tr>
    <td class=\"tdds\">Item</td>
      <td class=\"tds\">Net. Price</td>
    <td class=\"tds\">Qty</td>
    <td class=\"tds\">Discount</td>
    <td class=\"tds\">Total </td>
 </tr>
 {% set count = 0 %}
 {% set sum = 0 %}
 {% set discount = 0 %}
{% for item in items %}
{% if item.order_d == order.id %}
{% if item.tax == 0 or item.tax == ''%}
{% set taxp = item.tax %} 
<tr>
    <td class=\"tdd\">{{ item.itemName }} - {{ item.priceVariavtion }}<br>
    {{ item.barcode }}</td>
  {% set dis = item.discount+item.discountPrice %}
    <td class=\"td\">{% set final = item.price  %}
        {% if numberFormat == 0 %}
          {{ final|round(2, 'floor') }}
        {% elseif numberFormat == 1 %}
          {{ final|number_format(2, '.', '') }}
        {% endif %}
    </td>
    <td class=\"td\">{{ item.quantity }}</td>
    <td class=\"td\">{{ item.discount }}</td>
    <td class=\"td\">{% set x =  item.price * item.quantity  %} 
        {% if numberFormat == 0 %}
          {{ item.subTotal|round(2, 'floor') }}
        {% elseif numberFormat == 1 %}
          {{ item.subTotal|number_format(2, '.', '') }}
        {% endif %}
    </td>
 </tr>
 {% set fts=0*item.quantity %} 
 {% set stotal = item.subTotal - item.discount|round(2, 'floor')%}

{% else %} 
<tr>
    <td class=\"tdd\">{{ item.itemName }} - {{ item.priceVariavtion }}<br>
    {{ item.barcode }} </td>
  {% set dis = item.discount+item.discountPrice %}
    {% if orders == '' %}
    <center>No Data Found!</center>
{% endif %}  
{% if item.discount != 0 %}
{% set discount = item.discount %}
{% set quantity = item.quantity %}
{% set priceO = discount/quantity %}
{% set price = item.price + priceO %}
{% else %}
{% set price = item.price %}
{% endif %}
 {% set taxp = price / item.tax %} {% set finals = price  %} 
{% set xs= 100+item.tax %}
 {% set finals=price*100/xs %} 
                                     {% set final =  finals %}
   {% set f=price-final %} 

   {% set ft=f*item.quantity %} 

    <td class=\"td\">{% if numberFormat == 0 %}{{ final|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ final|number_format(2, '.', '') }}{% endif %}</td>
  
    <td class=\"td\">{{ item.quantity }}</td>
    <td class=\"td\">{{ item.discount }}</td>
      {% if numberFormat == 0 %}
{% set subTotals = final|round(2, 'floor') * item.quantity %} 
{% elseif numberFormat == 1 %}
{% set subTotals = final|number_format(2, '.', '') * item.quantity %} 
{% endif %}
    <td class=\"td\"> 
{% if numberFormat == 0 %}
 {% set f=price-final|round(2, 'floor') %} {% set ft=f*item.quantity %} 

{% elseif numberFormat == 1 %}
{% set f=price-final|number_format(2, '.', '') %} 
{% endif %}
{% set fts=f*item.quantity %} 

      {% if numberFormat == 0 %}{% set x = subTotals|round(2, 'floor') %}{% elseif numberFormat == 1 %}{% set x = subTotals|number_format(2, '.', '') %}{% endif %}
 {% if numberFormat == 0 %}
 {% set stotal = x - item.discount|round(2, 'floor')%}
                                       {{ x - item.discount|round(2, 'floor') }}
                                    {% elseif numberFormat == 1 %}
                                       {{ x - item.discount|number_format(2, '.', '') }}
                                        {% set stotal = x - item.discount|number_format(2, '.', '') %}

                                    {% endif %}
    </td>

 </tr>

 {% endif %}
    {% set count = count + fts %}
    {% set sum = sum + stotal %}
    {% set discount = discount + dis %}
{% endif %}
{% endfor %}
</table>
<hr>  
{% if count == 0 or count == ''%}
<div class=\"totalprice\">

        <p class=\"sub\"> Subtotal <span> {% if numberFormat == 0 %}{{ sum|round(2,'floor')}}{% elseif numberFormat == 1 %}{{ sum|number_format(2, '.', '')}}{% endif %}</span></p>
        <!-- <p class=\"del\"> Tax <span>   {{ count }} </span> </p> -->
        <!-- <p class=\"del\"> Discount <span> {{ order.totalDiscount + order.discountTotal }} </span> </p> -->
 <p class=\"del\"> Delivery <span> {% if numberFormat == 0 %}{{ order.deliveryCharge|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.deliveryCharge|number_format(2, '.', '') }}{% endif %} </span> </p>
  {% if order.promocode == ''%}
        {% else %}
        {% endif %}
      {% if order.loyalty == 0 %}
        {% else %}
        <p class=\"del\"> Loyalty <span>-{{ order.loyalty }}</span> </p>
        {% endif %}
        <hr>

        <p class=\"del\"> Total <span> {% if order.paymentType == 'wallet' %} {% set total = order.actualAmount + order.deliveryCharge - order.totalDiscount %} {% if numberFormat == 0 %}{{ total|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ total|number_format(2, '.', '') }}{% endif %} {% else %}{{ order.orderAmount - order.totalDiscount }}{% endif %}</span> </p>

      </div>

      {% if discount == 0  %}
      {% else %}
          {% for res in restaurant%}
       <center><b>You Saved {{ res.currencyFormat }}{% set d = discount %} {{ d }}</b></center>
        {% endfor %}
        {% endif %}
<center style=\"font-size:10px;\"> 
    {% if order.promocode != '' %}
  <span> Promocode ({{ order.promocode }})<span> <b>{{ order.totalDiscount }} OFF!</b></span><br>
{% endif %}
<span>Wallet Payment : {{ order.wallet }} | Cash/Online Payment :  {{ order.orderAmount }}</span></center>
{% else %}
      <div class=\"totalprice\">

        <p class=\"sub\"> Subtotal <span> {% set x = order.actualAmount * count / 100 %} {%  set fin = sum - x %} {% if numberFormat == 0 %}{{ sum|number_format(2, '.', '')}}{% elseif numberFormat == 1 %}{{ sum|number_format(2, '.', '')}}{% endif %}</span></p>
        {% if res.currencyFormat == 'AED' %}
<p class=\"del\"> VAT <span>   {{ count|number_format(2, '.', '') }} </span> </p> 
{% else %}
<p class=\"del\"> Tax <span>   {{ count|number_format(2, '.', '') }} </span> </p> 

        {% endif %}
  

        <p class=\"del\"> Delivery <span> {% if numberFormat == 0 %}{{ order.deliveryCharge|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ order.deliveryCharge|number_format(2, '.', '') }}{% endif %} </span> </p>
  {% if order.promocode == ''%}
        {% else %}
        {% endif %}
      {% if order.loyalty == 0 %}
        {% else %}
        <p class=\"del\"> Loyalty <span>-{{ order.loyalty }}</span> </p>
        {% endif %}
 
         
               <hr>

        <p class=\"del\"> Total <span> {% if order.paymentType == 'wallet' %} {% set total = order.actualAmount + order.deliveryCharge - order.totalDiscount %} {% if numberFormat == 0 %}{{ total|number_format(2, '.', '') }}{% elseif numberFormat == 1 %}{{ total|number_format(2, '.', '') }}{% endif %} {% else %}{% set total = order.actualAmount + order.wallet + order.loyalty + order.deliveryCharge - order.totalDiscount %} {{ total|number_format(2, '.', '') }}{% endif %}</span> </p>

      </div>
      {% if discount == 0  %}
      {% else %}
          {% for res in restaurant%}
       <center><b>You Saved {{ res.currencyFormat }}{% set d = discount %} {{ d }}</b></center>
        {% endfor %}
     {% endif %}
<center style=\"font-size:10px;\">
  {% if order.promocode != '' %}
  <span> Promocode ({{ order.promocode }})<span> <b>{{ order.totalDiscount }} OFF!</b></span><br>
{% endif %}
Wallet Payment : {{ order.wallet }} | Cash/Online Payment :  {{ order.orderAmount }}</span></center>
{% if res.currencyFormat == 'AED' %}
{% else %}
{% if count == 0 or count == '' %}
{% else %}
 
<table>
  <tr>
    <td class=\"tdss\">GST Index</td>
    <td class=\"tdss\">Taxable Amount</td>
    <td class=\"tdss\">CGST</td>
    <td class=\"tdss\">SGST</td>
    <td class=\"tdss\">Total</td>
 </tr>
 <hr>       

 {% set count = 1 %}
  {% set res = 0 %}
  {% set data = 0 %}

 {% for ta in tax %}
 {% if ta.tax == 0 %}
 {% else %}
  <tr> 
    <td class=\"td\">{{ ta.tax }}</td>
    <td class=\"td\">{% set x= 100+ta.tax %}
                                     {% set pr=ta.subTotal*100/x %} 
                                     {% if numberFormat == 0 %}
                                      {{ pr|round(2, 'floor') }}
                                    {% elseif numberFormat == 1 %}
                                      {{ pr|number_format(2, '.', '') }}
                                    {% endif %}
</td>
{% set cgst = ta.subTotal-pr %} 
    <td class=\"td\">{% set cg = cgst/2 %} 
    {% if numberFormat == 0 %}
      {{ cg|round(2,'floor') }}
    {% elseif numberFormat == 1 %}
      {{ cg|number_format(2, '.', '') }}
    {% endif %}
      </td>
    <td class=\"td\">  
    {% if numberFormat == 0 %}
      {{ cg|round(2,'floor') }}
    {% elseif numberFormat == 1 %}
      {{ cg|number_format(2, '.', '') }}
    {% endif %}
    </td>
    <td class=\"td\">{{ ta.subTotal }}</td>
 </tr>
 {% set count = count + 1 %}
 {% set res = res + cg %}
  {% set data = data + pr %}
 {% endif %}

{% endfor %}
<tr>
<th colspan=\"5\"><hr></th></tr>
  <tr>

    <td class=\"tdss\">Total</td>
    <td class=\"tdss\">{% if numberFormat == 0 %}{{ data|round(2,'floor') }}{% elseif numberFormat == 1 %}{{ data|number_format(2, '.', '') }}{% endif %}</td>
    <td class=\"tdss\">{% if numberFormat == 0 %}{{ res|round(2,'floor') }}{% elseif numberFormat == 1 %}{{ res|number_format(2, '.', '') }}{% endif %}</td>
    <td class=\"tdss\">{% if numberFormat == 0 %}{{ res|round(2,'floor') }}{% elseif numberFormat == 1 %}{{ res|number_format(2, '.', '') }}{% endif %}</td>
    <td class=\"tdss\">{% if numberFormat == 0 %}{{ order.actualAmount|round(2,'floor') }}{% elseif numberFormat == 1 %}{{ order.actualAmount|number_format(2, '.', '') }}{% endif %}</td>
 </tr>
</table>
{% endif %}
{% endif %}
 {% endif %}

<hr>
   {% endfor %}
      <!-- Footer -->
      <footer><b> Thank you for ordering with      {% for res in restaurant%}
{{ res.restaurantName }}</b> {% endfor %}</footer>

    </div>{% endfor %}
  </div>", "AppBundle:Admin:Orders/thermal.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Orders/thermal.html.twig");
    }
}

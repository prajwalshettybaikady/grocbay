<?php

/* AppBundle:Admin:Loyalty/manage.html.twig */
class __TwigTemplate_9727aa4082743b35bc263f8704aeafddf6d943d2222b0a503563169591607499 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Loyalty/manage.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_99a68a2657e631db9786ab967724cc1c116117773f98568b3ca8018b82622a4f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_99a68a2657e631db9786ab967724cc1c116117773f98568b3ca8018b82622a4f->enter($__internal_99a68a2657e631db9786ab967724cc1c116117773f98568b3ca8018b82622a4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Loyalty/manage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_99a68a2657e631db9786ab967724cc1c116117773f98568b3ca8018b82622a4f->leave($__internal_99a68a2657e631db9786ab967724cc1c116117773f98568b3ca8018b82622a4f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_202dd6df06bd4dad7bdbf2b354d7b978f684526d7072ce126310851f65124b97 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_202dd6df06bd4dad7bdbf2b354d7b978f684526d7072ce126310851f65124b97->enter($__internal_202dd6df06bd4dad7bdbf2b354d7b978f684526d7072ce126310851f65124b97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "      <link href = \"https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css\"
         rel = \"stylesheet\">
      <script src = \"https://code.jquery.com/jquery-1.10.2.js\"></script>
      <script src = \"https://code.jquery.com/ui/1.10.4/jquery-ui.js\"></script>
      
      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
      <style type=\"text/css\">
           html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
  

      #type-selector {
        color: #fff;
        background-color: #4d90fe;
        padding: 5px 11px 0px 11px;
      }

      #type-selector label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }
      footer.footer.noprint
      {
        display: none;
      }
      </style>
     
";
        // line 44
        echo "<!-- Modal -->
";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["da"]) {
            // line 46
            echo "<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                        <span class=\"pull-right\">
                    ";
            // line 53
            echo "                          
                        </span>
                    </div>
                    <h2>Manage Loyalty</h2>
                    <form action=\"";
            // line 57
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_loyalty");
            echo "\" class=\"\">
                      <div class=\"form-row\">
                          <div class=\"form-group col-4\">
    <label for=\"Status\">Status</label>
    <select class=\"form-control\" id=\"Status\" placeholder=\"eg : 100\" name=\"status\" >
      <option value=\"0\" ";
            // line 62
            if (($this->getAttribute($context["da"], "status", array()) == 0)) {
                echo " selected ";
            }
            echo ">Enabled</option>
      <option value=\"1\"  ";
            // line 63
            if (($this->getAttribute($context["da"], "status", array()) == 1)) {
                echo " selected ";
            }
            echo ">Disabled</option>
    </select>
  </div>
  <div class=\"form-group col-4\">
    <label for=\"uname\">Minimum Order Amount</label>
    <input type=\"number\" class=\"form-control\" id=\"uname\" placeholder=\"eg : 100\" name=\"order\" value=\"";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "minimum_order_amount", array()), "html", null, true);
            echo "\" >
  </div>
  <div class=\"form-group col-4\">
    <label for=\"Points\">Points For 1 ";
            // line 71
            echo twig_escape_filter($this->env, ($context["currency"] ?? $this->getContext($context, "currency")), "html", null, true);
            echo ":</label>
    <input type=\"number\" class=\"form-control\" id=\"Points\" placeholder=\"eg : 100\" name=\"rupee\" value=\"";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "points", array()), "html", null, true);
            echo "\"  >
    <input type=\"hidden\" class=\"form-control\" id=\"loy\" placeholder=\"eg : 100\" name=\"id\" value=\"";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "id", array()), "html", null, true);
            echo "\"  >
   
  </div>
</div>
                   <div class=\"form-row\">
  <div class=\"form-group col-4\">
    <label for=\"type\">Redeem Type</label>
    <select class=\"form-control\" id=\"type\" placeholder=\"eg : 100\" name=\"type\" >
           <option value=\"0\" ";
            // line 81
            if (($this->getAttribute($context["da"], "type", array()) == 0)) {
                echo " selected ";
            }
            echo ">Default</option>
      <option value=\"1\" ";
            // line 82
            if (($this->getAttribute($context["da"], "type", array()) == 1)) {
                echo " selected ";
            }
            echo ">Percentage</option>
    </select>
  </div>
  <div class=\"form-group col-4\">
    <label for=\"redeem\">Percentage</label>
    <input type=\"number\" class=\"form-control\" id=\"redeem\" placeholder=\"eg : 100\" name=\"value\"  value=\"";
            // line 87
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "maximum_redeem", array()), "html", null, true);
            echo "\"  >
  </div>
    <div class=\"form-group col-4\">
    <label for=\"redeem\">Discount Amount/Maximum Redeem value.</label>
    <input type=\"number\" class=\"form-control\" id=\"redeem\" placeholder=\"eg : 100\" name=\"discount\"  value=\"";
            // line 91
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "discount", array()), "html", null, true);
            echo "\"  >
   
  </div>
</div>

  <button type=\"submit\" class=\"btn btn-primary\">Update</button>
</form>












                    <div>
                       
                        <hr>
                       
                    </div>
                   
                    </div>
     
             </div>
           </div>
         </div>
         
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['da'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_202dd6df06bd4dad7bdbf2b354d7b978f684526d7072ce126310851f65124b97->leave($__internal_202dd6df06bd4dad7bdbf2b354d7b978f684526d7072ce126310851f65124b97_prof);

    }

    // line 125
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_084cc273ca4a95197485150a4b43262e8ac5ae47eb8a0fe094d0afbb57142138 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_084cc273ca4a95197485150a4b43262e8ac5ae47eb8a0fe094d0afbb57142138->enter($__internal_084cc273ca4a95197485150a4b43262e8ac5ae47eb8a0fe094d0afbb57142138_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 126
        echo "

    
";
        
        $__internal_084cc273ca4a95197485150a4b43262e8ac5ae47eb8a0fe094d0afbb57142138->leave($__internal_084cc273ca4a95197485150a4b43262e8ac5ae47eb8a0fe094d0afbb57142138_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Loyalty/manage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  224 => 126,  218 => 125,  175 => 91,  168 => 87,  158 => 82,  152 => 81,  141 => 73,  137 => 72,  133 => 71,  127 => 68,  117 => 63,  111 => 62,  103 => 57,  97 => 53,  89 => 46,  85 => 45,  82 => 44,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}
      <link href = \"https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css\"
         rel = \"stylesheet\">
      <script src = \"https://code.jquery.com/jquery-1.10.2.js\"></script>
      <script src = \"https://code.jquery.com/ui/1.10.4/jquery-ui.js\"></script>
      
      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
      <style type=\"text/css\">
           html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
  

      #type-selector {
        color: #fff;
        background-color: #4d90fe;
        padding: 5px 11px 0px 11px;
      }

      #type-selector label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }
      footer.footer.noprint
      {
        display: none;
      }
      </style>
     
{# {{ dump(res) }} #}
<!-- Modal -->
{% for da in data %}
<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                        <span class=\"pull-right\">
                    {#      <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\">Upload CSV</a> #}
                          
                        </span>
                    </div>
                    <h2>Manage Loyalty</h2>
                    <form action=\"{{ path('update_loyalty') }}\" class=\"\">
                      <div class=\"form-row\">
                          <div class=\"form-group col-4\">
    <label for=\"Status\">Status</label>
    <select class=\"form-control\" id=\"Status\" placeholder=\"eg : 100\" name=\"status\" >
      <option value=\"0\" {% if da.status == 0 %} selected {% endif %}>Enabled</option>
      <option value=\"1\"  {% if da.status == 1 %} selected {% endif %}>Disabled</option>
    </select>
  </div>
  <div class=\"form-group col-4\">
    <label for=\"uname\">Minimum Order Amount</label>
    <input type=\"number\" class=\"form-control\" id=\"uname\" placeholder=\"eg : 100\" name=\"order\" value=\"{{ da.minimum_order_amount }}\" >
  </div>
  <div class=\"form-group col-4\">
    <label for=\"Points\">Points For 1 {{ currency }}:</label>
    <input type=\"number\" class=\"form-control\" id=\"Points\" placeholder=\"eg : 100\" name=\"rupee\" value=\"{{ da.points }}\"  >
    <input type=\"hidden\" class=\"form-control\" id=\"loy\" placeholder=\"eg : 100\" name=\"id\" value=\"{{ da.id }}\"  >
   
  </div>
</div>
                   <div class=\"form-row\">
  <div class=\"form-group col-4\">
    <label for=\"type\">Redeem Type</label>
    <select class=\"form-control\" id=\"type\" placeholder=\"eg : 100\" name=\"type\" >
           <option value=\"0\" {% if da.type == 0 %} selected {% endif %}>Default</option>
      <option value=\"1\" {% if da.type == 1 %} selected {% endif %}>Percentage</option>
    </select>
  </div>
  <div class=\"form-group col-4\">
    <label for=\"redeem\">Percentage</label>
    <input type=\"number\" class=\"form-control\" id=\"redeem\" placeholder=\"eg : 100\" name=\"value\"  value=\"{{ da.maximum_redeem }}\"  >
  </div>
    <div class=\"form-group col-4\">
    <label for=\"redeem\">Discount Amount/Maximum Redeem value.</label>
    <input type=\"number\" class=\"form-control\" id=\"redeem\" placeholder=\"eg : 100\" name=\"discount\"  value=\"{{ da.discount }}\"  >
   
  </div>
</div>

  <button type=\"submit\" class=\"btn btn-primary\">Update</button>
</form>












                    <div>
                       
                        <hr>
                       
                    </div>
                   
                    </div>
     
             </div>
           </div>
         </div>
         
{% endfor %}
{% endblock %}

{% block scripts %}


    
{% endblock %}
", "AppBundle:Admin:Loyalty/manage.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Loyalty/manage.html.twig");
    }
}

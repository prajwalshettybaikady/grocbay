<?php

/* AppBundle:Admin:Firebase/view.html.twig */
class __TwigTemplate_86d9bc00a9f13e5dec05ebadd3d7c69f5af04e57b0271f1f67e20a14b57e8e22 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Firebase/view.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5250d96bb122a391743086bbb6bd81801b0fbe440883b67e1a21d235609b0715 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5250d96bb122a391743086bbb6bd81801b0fbe440883b67e1a21d235609b0715->enter($__internal_5250d96bb122a391743086bbb6bd81801b0fbe440883b67e1a21d235609b0715_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Firebase/view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5250d96bb122a391743086bbb6bd81801b0fbe440883b67e1a21d235609b0715->leave($__internal_5250d96bb122a391743086bbb6bd81801b0fbe440883b67e1a21d235609b0715_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_c8189752ecfa9683e302f1efffc585ecaec4c6c8f84a942f493aa391635529fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8189752ecfa9683e302f1efffc585ecaec4c6c8f84a942f493aa391635529fd->enter($__internal_c8189752ecfa9683e302f1efffc585ecaec4c6c8f84a942f493aa391635529fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                                                

                        
                        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 15
            echo "                              
                              
<div class=\"container\">
  <div class=\"card\">
<div class=\"card-header\">
<strong><h3>Notification Details</h3></strong> 
  <span class=\"float-right\"> <strong> </strong></span>

</div>
<div class=\"card-body\">
<div class=\"row mb-4\">
<div class=\"col-sm-6\">
<div>
Date and time : ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "dateTime", array()), "html", null, true);
            echo " 
</div>
<div>Message : ";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "message", array()), "html", null, true);
            echo "</div>
<div>Notification Trigger : ";
            // line 31
            if (($this->getAttribute($context["product"], "notificationFor", array()) == 3)) {
                echo " Link ";
            }
            // line 32
            echo "                                       ";
            if (($this->getAttribute($context["product"], "notificationFor", array()) == 4)) {
                echo " Items ";
            }
            // line 33
            echo "                                     ";
            if (($this->getAttribute($context["product"], "notificationFor", array()) == 5)) {
                echo " Category ";
            }
            // line 34
            echo "                                     ";
            if (($this->getAttribute($context["product"], "notificationFor", array()) == 10)) {
                echo " Brands ";
            }
            // line 35
            echo "                                   ";
            if (($this->getAttribute($context["product"], "notificationFor", array()) == 6)) {
                echo " Redirect to Homepage ";
            }
            echo "</div>
<div>Data : ";
            // line 36
            echo twig_escape_filter($this->env, ($context["response"] ?? $this->getContext($context, "response")), "html", null, true);
            echo "</div>
<div>";
            // line 37
            if (($this->getAttribute($context["product"], "image", array()) == "")) {
            } else {
                echo "<img class=\"img-responsive\" src=\"/uploads/";
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "image", array()), "html", null, true);
                echo "\" style=\"width:100px;height:100px\"/>";
            }
            echo "</div>


";
            // line 50
            echo "


</div><br><br>

<div class=\"table-responsive\">
<table class=\"table table-striped\" style=\"width:100%;\" id=\"myTable\">
<thead>
<tr>
<th class=\"center\">#</th>
<th>Name</th>
<th class=\"right\">Status</th>
</tr>
</thead>
<tbody>
     ";
            // line 65
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["history"] ?? $this->getContext($context, "history")));
            foreach ($context['_seq'] as $context["_key"] => $context["sl"]) {
                // line 66
                echo "<tr>
<td class=\"center\">";
                // line 67
                echo twig_escape_filter($this->env, $this->getAttribute($context["sl"], "id", array()), "html", null, true);
                echo "</td>
<td class=\"left strong\"> ";
                // line 68
                echo twig_escape_filter($this->env, $this->getAttribute($context["sl"], "username", array()), "html", null, true);
                echo "</td>
<td class=\"right\">";
                // line 69
                if (($this->getAttribute($context["sl"], "status", array()) == 0)) {
                    echo "Pending";
                } else {
                    echo " Opened ";
                }
                echo "</td>
</tr>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sl'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 72
            echo "</tbody>
</table>
</div>
<div class=\"row\">
<div class=\"col-lg-4 col-sm-5\">

</div>


</div>

</div>
</div>
</div>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 87
        echo "
<span class=\"pull-right\">
                    ";
        // line 90
        echo "                            <a href=\"#back\" class=\"btn btn-primary\" onclick=\"window.history.go(-1); return false;\">Back</a>
                        </span>



                    </div>
                </div>
            </div>
    </div>
</div>
";
        
        $__internal_c8189752ecfa9683e302f1efffc585ecaec4c6c8f84a942f493aa391635529fd->leave($__internal_c8189752ecfa9683e302f1efffc585ecaec4c6c8f84a942f493aa391635529fd_prof);

    }

    // line 102
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_22914873c807d304ea7036173b266eec755bf01ac711ce66b8b6580bd8fa3847 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22914873c807d304ea7036173b266eec755bf01ac711ce66b8b6580bd8fa3847->enter($__internal_22914873c807d304ea7036173b266eec755bf01ac711ce66b8b6580bd8fa3847_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 103
        echo "
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
   
</script>
";
        
        $__internal_22914873c807d304ea7036173b266eec755bf01ac711ce66b8b6580bd8fa3847->leave($__internal_22914873c807d304ea7036173b266eec755bf01ac711ce66b8b6580bd8fa3847_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Firebase/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  214 => 103,  208 => 102,  191 => 90,  187 => 87,  167 => 72,  154 => 69,  150 => 68,  146 => 67,  143 => 66,  139 => 65,  122 => 50,  111 => 37,  107 => 36,  100 => 35,  95 => 34,  90 => 33,  85 => 32,  81 => 31,  77 => 30,  72 => 28,  57 => 15,  53 => 14,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}


<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                                                

                        
                        {% for product in data %}
                              
                              
<div class=\"container\">
  <div class=\"card\">
<div class=\"card-header\">
<strong><h3>Notification Details</h3></strong> 
  <span class=\"float-right\"> <strong> </strong></span>

</div>
<div class=\"card-body\">
<div class=\"row mb-4\">
<div class=\"col-sm-6\">
<div>
Date and time : {{ product.dateTime }} 
</div>
<div>Message : {{ product.message }}</div>
<div>Notification Trigger : {% if product.notificationFor == 3 %} Link {% endif %}
                                       {% if product.notificationFor == 4 %} Items {% endif %}
                                     {% if product.notificationFor == 5 %} Category {% endif %}
                                     {% if product.notificationFor == 10 %} Brands {% endif %}
                                   {% if product.notificationFor == 6 %} Redirect to Homepage {% endif %}</div>
<div>Data : {{ response }}</div>
<div>{% if product.image == '' %}{% else %}<img class=\"img-responsive\" src=\"/uploads/{{ product.image }}\" style=\"width:100px;height:100px\"/>{% endif %}</div>


{# <div class=\"col-sm-6\">
<h6 class=\"mb-3\">To:</h6>
<div>
<strong>Bob Mart</strong>
</div>
<div>Attn: Daniel Marek</div>
<div>43-190 Mikolow, Poland</div>
<div>Email: marek@daniel.com</div>
<div>Phone: +48 123 456 789</div>
</div> #}



</div><br><br>

<div class=\"table-responsive\">
<table class=\"table table-striped\" style=\"width:100%;\" id=\"myTable\">
<thead>
<tr>
<th class=\"center\">#</th>
<th>Name</th>
<th class=\"right\">Status</th>
</tr>
</thead>
<tbody>
     {% for sl in history %}
<tr>
<td class=\"center\">{{ sl.id }}</td>
<td class=\"left strong\"> {{ sl.username }}</td>
<td class=\"right\">{% if sl.status == 0 %}Pending{% else %} Opened {% endif %}</td>
</tr>
    {% endfor %}
</tbody>
</table>
</div>
<div class=\"row\">
<div class=\"col-lg-4 col-sm-5\">

</div>


</div>

</div>
</div>
</div>
  {% endfor %}

<span class=\"pull-right\">
                    {#      <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\">Upload CSV</a> #}
                            <a href=\"#back\" class=\"btn btn-primary\" onclick=\"window.history.go(-1); return false;\">Back</a>
                        </span>



                    </div>
                </div>
            </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
   
</script>
{% endblock %}
", "AppBundle:Admin:Firebase/view.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Firebase/view.html.twig");
    }
}

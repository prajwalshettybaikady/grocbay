<?php

/* AppBundle:Admin:Pages/manageCategories.html.twig */
class __TwigTemplate_3b7e06cb52b70676c534f57b24af62fda8308a5b1bf62fbbdcba93a9c8348029 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/manageCategories.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fe8b0f5b45d03e7b264ece6b1fe21617a2392c675a90e895a66f861ba395d311 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe8b0f5b45d03e7b264ece6b1fe21617a2392c675a90e895a66f861ba395d311->enter($__internal_fe8b0f5b45d03e7b264ece6b1fe21617a2392c675a90e895a66f861ba395d311_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/manageCategories.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fe8b0f5b45d03e7b264ece6b1fe21617a2392c675a90e895a66f861ba395d311->leave($__internal_fe8b0f5b45d03e7b264ece6b1fe21617a2392c675a90e895a66f861ba395d311_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_50972043902cbd628f6d0de609671ae72febf701e159616a79394eda8a96b372 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50972043902cbd628f6d0de609671ae72febf701e159616a79394eda8a96b372->enter($__internal_50972043902cbd628f6d0de609671ae72febf701e159616a79394eda8a96b372_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"main-content\">
    <div class=\"layout-px-spacing\">
        <div class=\"row scrumboard\" id=\"cancel-row\">
            <div class=\"col-lg-12 layout-spacing\">
                <!--add main category-->
                <div class=\"task-list-section\">
                    <div data-section=\"s-new\" class=\"task-list-container\">
                        <div class=\"connect-sorting\">
                            <div class=\"task-container-header\">
                                <h6 class=\"s-heading\" data-listTitle=\"In Progress\">Main Categories</h6>
                                <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("export_category");
        echo "\" class=\"badge outline-badge-danger pull-right\">Export to CSV</a>
                            </div>
                            <form data-2 method=\"post\" action=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("bulk_action_category");
        echo "\">
                                <div class=\"row order-info mt-3 mb-3 pl-3\" >
                                    <input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"category\">
                                    <div class=\"col-lg-8 col-md-8 col-12 mb-3 \">
                                        <select class=\"form-control form-control-sm\" name=\"type\">
                                          <option value=\"0\">Activate</option>
                                          <option value=\"1\">Deactivate</option>
                                          <option value=\"2\">Delete</option>
                                        </select>
                                    </div>
                                    <div class=\"col-lg-3 col-md-3 col-12 mb-3  align-self-end\">
                                        <input type=\"submit\" class=\"btn btn-sm btn-primary\" value=\"Update\">
                                    </div>
                                </div>
                                <div class=\"connect-sorting-content\" >
                                ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["category"] ?? $this->getContext($context, "category")));
        foreach ($context['_seq'] as $context["_key"] => $context["main"]) {
            // line 31
            echo "                                <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_category_get", array("id" => $this->getAttribute($context["main"], "id", array()))), "html", null, true);
            echo "\">
                                    <div  class=\"card main-category-list simple-title-task ";
            // line 32
            if (($this->getAttribute($context["main"], "id", array()) == ($context["mainid"] ?? $this->getContext($context, "mainid")))) {
                echo " active ";
            }
            echo "\">
                                        <div class=\"card-body\">
                                            <div class=\"task-header background-white main-category\">
                                                <!--task header start-->
                                                <div class=\"row \">
                                                    <div class=\"col-md-4\">
                                                        <div class=\"row h-100\">
                                                            <div class=\"col-md-12 align-self-center\">
                                                                <div class=\"category-img-wrapper\">
                                                                    <img class=\"img-fluid img-responsive\" src='/uploads/sub-category/icons/";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "iconImage", array()), "html", null, true);
            echo "'>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-8\">
                                                        <div class=\"bg-inner\">
                                                            <div class=\"row h-100 p-3\">
                                                                <div class=\"col-md-12 mb-3 text-left\" >
                                                                    <input type=\"checkbox\" name=\"all[]\" class=\"category\" value=\"";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "id", array()), "html", null, true);
            echo "\">
                                                                    <span class=\"text-right\" style=\"font-size:16px; font-weight:700;float:right;\">#";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "id", array()), "html", null, true);
            echo "</span>
                                                                </div>
                                                                <div class=\"col-md-12\">
                                                                    <h4 class=\"text-left mb-3\" data-taskTitle=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "categoryName", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "categoryName", array()), "html", null, true);
            echo "</h4>
                                                                </div>
                                                                <div class=\"col-md-12\">
                                                                    <i class=\"fa\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-edit-2 s-task-edit\"><path d=\"M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z\"   data-toggle=\"modal\" data-target=\"#category";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "id", array()), "html", null, true);
            echo "\"></path></svg></i>
                                                                    ";
            // line 58
            if (($this->getAttribute($context["main"], "featured", array()) == 0)) {
                // line 59
                echo "                                                                    <i class=\"fa fa-eye\"></i>
                                                                    ";
            } else {
                // line 61
                echo "                                                                    <i class=\"fa fa-eye-slash\"></i>
                                                                    ";
            }
            // line 63
            echo "                                                                    ";
            if (($this->getAttribute($context["main"], "status", array()) == 1)) {
                // line 64
                echo "                                                                    <i class=\"fa fa-circle\" style=\"color:red;\"></i> 
                                                                    ";
            } else {
                // line 66
                echo "                                                                    <i class=\"fa fa-circle\" style=\"color:green;\"></i>
                                                                    ";
            }
            // line 68
            echo "                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--task header ends-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['main'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 79
        echo "                            </form>
                             <!-- add category -->
                            ";
        // line 81
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["category"] ?? $this->getContext($context, "category")));
        foreach ($context['_seq'] as $context["_key"] => $context["main"]) {
            // line 82
            echo "                            <div class=\"modal fade\" id=\"category";
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "id", array()), "html", null, true);
            echo "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                                <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <div class=\"modal-body\">
                                            <div class=\"compose-box\">
                                                <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                                    <h5 class=\"add-task-title\">Edit Category</h5>

                                                    <form data-3 method=\"post\"  enctype=\"multipart/form-data\" action=\"";
            // line 90
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_category");
            echo "\">
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"name\">Category Name</label>
                                                            <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\" value=\"";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "categoryName", array()), "html", null, true);
            echo "\">
                                                            <input type=\"hidden\" name=\"id\" placeholder=\"Category  Name*\" required=\"\"  value=\"";
            // line 94
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "id", array()), "html", null, true);
            echo "\">
                                                        </div>

                                                        <div class=\"form-row mb-4\">
                                                            <div class=\"form-group col-md-8\">
                                                                <label for=\"Priority\">Priority</label>
                                                                <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" name=\"priority\" value=\"";
            // line 100
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "priority", array()), "html", null, true);
            echo "\">
                                                            </div>
                                                            <input type=\"hidden\" id=\"parent\" class=\"form-control form-control-sm\" name=\"parent\" value=\"0\">
                                                            <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"0\">
                                                            <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"0\">

                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Status</label>
                                                                <label class=\"switch s-success mr-2\"> 
                                                                    <input type=\"checkbox\" ";
            // line 109
            if (($this->getAttribute($context["main"], "status", array()) == 0)) {
                echo "checked";
            }
            echo " class=\"form-control form-control-sm\" name=\"status\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "status", array()), "html", null, true);
            echo "\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Visiblity</label>
                                                                <label class=\"switch s-danger mr-2\"> 
                                                                    <input type=\"checkbox\"  ";
            // line 116
            if (($this->getAttribute($context["main"], "featured", array()) == 0)) {
                echo "checked";
            }
            echo " class=\"form-control form-control-sm\" name=\"visiblity\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "featured", array()), "html", null, true);
            echo "\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"Status\">Icon </label>
                                                            <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"/uploads/sub-category/icons/";
            // line 123
            echo twig_escape_filter($this->env, $this->getAttribute($context["main"], "iconImage", array()), "html", null, true);
            echo "\"> 
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class=\"modal-footer\">
                                                <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                                <button  class=\"btn btn-primary\" >Update</button>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['main'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 139
        echo "
                            <!-- end of add category -->
                        </div>
                    ";
        // line 142
        if (((($context["branch_type"] ?? $this->getContext($context, "branch_type")) == 0) || ($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "branch", array()) == 0))) {
            // line 143
            echo "                         <div class=\"add-s-task\">
                            <a class=\"addTask main-category-btn\" data-toggle=\"modal\" data-target=\"#category\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus-circle\"><circle cx=\"12\" cy=\"12\" r=\"10\"></circle><line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"16\"></line><line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\"></line></svg> Add Category</a>
                        </div>
                      ";
        }
        // line 147
        echo "                    </div>
                <!--ends main category-->
                <!--starts main category modal -->
                    <div class=\"modal fade\" id=\"category\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                        <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                            <div class=\"modal-content\">
                                <div class=\"modal-body\">
                                    <div class=\"compose-box\">
                                        <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                            <h5 class=\"add-task-title\">Add Category -main catgory</h5>

                                            <form data-4 method=\"post\"  enctype=\"multipart/form-data\" action=\"";
        // line 158
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create_category");
        echo "\">
                                                <div class=\"form-group mb-4\">
                                                    <label for=\"name\">Category Name</label>
                                                    <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\">
                                                    <input type=\"hidden\" id=\"parent\" class=\"form-control form-control-sm\" name=\"parent\" value=\"0\">
                                                    <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"0\">
                                                    <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"0\">
                                                </div>
                                                <div class=\"form-row mb-4\">
                                                    <div class=\"form-group col-md-8\">
                                                        <label for=\"Priority\">Priority</label>
                                                        <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" value=\"0\" name=\"priority\">
                                                    </div>
                                                    <div class=\"form-group col-md-2 align-self-end text-right\">
                                                        <label>Status</label>
                                                        <label class=\"switch s-success mr-2\"> 
                                                            <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"status\">
                                                            <span class=\"slider round\"></span>
                                                        </label>
                                                    </div>
                                                    <div class=\"form-group col-md-2 align-self-end text-right\">
                                                        <label>Visiblity</label>
                                                        <label class=\"switch s-danger mr-2\"> 
                                                            <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"visiblity\">
                                                            <span class=\"slider round\"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class=\"form-group mb-4\">
                                                    <label for=\"Status\">Icon </label>
                                                    <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"\"> 
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class=\"modal-footer\">
                                        <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                        <button  class=\"btn btn-primary\" >Save</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
               
                 <div data-section=\"s-new\" class=\"task-list-container\">
                        <div class=\"connect-sorting\">
                            <div class=\"task-container-header\">
                                <h6 class=\"s-heading\" data-listTitle=\"In Progress\">Sub Categories</h6>
                                <a href=\"";
        // line 209
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("export_subcategory");
        echo "\" class=\"badge outline-badge-danger pull-right\">Export to CSV</a>
                            </div>
                            <form data-5 method=\"post\" action=\"";
        // line 211
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("bulk_action_category");
        echo "\">
                                <div class=\"row order-info mt-3 mb-3 pl-3 align-self-center\" >
                                    <input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"subcategory\">
                                    <div class=\"col-lg-8 col-md-8 col-12 mb-3 \">
                                        <select class=\"form-control form-control-sm\" name=\"type\">
                                        <option value=\"0\">Activate</option>
                                        <option value=\"1\">Deactivate</option>
                                          <option value=\"2\">Delete</option>
                                    </select>
                                    </div>
                                    <div class=\"col-lg-2 col-md-2 mb-3 align-self-end\">
                                        <input type=\"submit\" class=\"btn btn-sm btn-primary\" value=\"Update\" >
                                    </div>
                                </div>
                                <div class=\"connect-sorting-content\" >
                                    ";
        // line 226
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["subcategory"] ?? $this->getContext($context, "subcategory")));
        foreach ($context['_seq'] as $context["_key"] => $context["sub"]) {
            // line 227
            echo "                                    <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_category_get_nested", array("parent" => $this->getAttribute($context["sub"], "parent_id", array()), "id" => $this->getAttribute($context["sub"], "id", array()))), "html", null, true);
            echo "\">
                                        <div  class=\"card sub-category-list simple-title-task ";
            // line 228
            if (($this->getAttribute($context["sub"], "id", array()) == ($context["subid"] ?? $this->getContext($context, "subid")))) {
                echo " active ";
            }
            echo "\">
                                            <div class=\"card-body\">
                                                <div class=\"task-header background-white sub-category\">
                                                    <!--task header start-->
                                                     <div class=\"row\">
                                                        <div class=\"col-md-4\">
                                                             <div class=\"row h-100\">
                                                                <div class=\"col-md-12 align-self-center\">
                                                                     <div class=\"category-img-wrapper\">
                                                                        <img src='/uploads/sub-category/icons/";
            // line 237
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "iconImage", array()), "html", null, true);
            echo "' class=\"img-fluid img-responsive rounded\">
                                                                    </div>
                                                                </div>
                                                             </div>
                                                            <!--end-->
                                                        </div>
                                                        <div class=\"col-md-8\">
                                                            <div class=\"bg-inner\">
                                                              <div class=\"row h-100 p-3\">
                                                                    <div class=\"col-md-12 mb-3 text-left\" >
                                                                        <input type=\"checkbox\" name=\"all[]\" class=\"subcategory\" value=\"";
            // line 247
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
            echo "\">
                                                                        <span  style=\"font-size:16px; font-weight:700;float:right;\">#";
            // line 248
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
            echo "</span>
                                                                    </div>
                                                                    <div class=\"col-md-12\">
                                                                        <h4 class=\"text-left mb-3\" data-taskTitle=\"";
            // line 251
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "categoryName", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "categoryName", array()), "html", null, true);
            echo "</h4>
                                                                    </div>
                                                                    <div class=\"col-md-12\">
                                                                        <i class=\"fa\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-edit-2 s-task-edit\"><path d=\"M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z\"   data-toggle=\"modal\" data-target=\"#subcategory";
            // line 254
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
            echo "\"></path></svg></i>
                                                                        ";
            // line 255
            if (($this->getAttribute($context["sub"], "featured", array()) == 0)) {
                // line 256
                echo "                                                                        <i class=\"fa fa-eye\"></i>
                                                                        ";
            } else {
                // line 258
                echo "                                                                        <i class=\"fa fa-eye-slash\"></i>
                                                                        ";
            }
            // line 260
            echo "                                                                        ";
            if (($this->getAttribute($context["sub"], "status", array()) == 1)) {
                // line 261
                echo "                                                                        <i class=\"fa fa-circle\" style=\"color:red;\"></i> 
                                                                        ";
            } else {
                // line 263
                echo "                                                                        <i class=\"fa fa-circle\" style=\"color:green;\"></i>
                                                                        ";
            }
            // line 265
            echo "                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--end-->
                                                                    <!--task header ends-->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sub'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 277
        echo "                                </div>
                            </form>
                            ";
        // line 279
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["subcategory"] ?? $this->getContext($context, "subcategory")));
        foreach ($context['_seq'] as $context["_key"] => $context["sub"]) {
            echo " 
                                 <!-- add sub category -->
                            <div class=\"modal fade\" id=\"subcategory";
            // line 281
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
            echo "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                                <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <form data-6 method=\"post\"  enctype=\"multipart/form-data\" action=\"";
            // line 284
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_category");
            echo "\">
                                            <div class=\"modal-body\">
                                                <div class=\"compose-box\">
                                                    <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                                        <h5 class=\"add-task-title\">Edit Category</h5>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"name\">Category Name</label>
                                                            <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\" value=\"";
            // line 291
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "categoryName", array()), "html", null, true);
            echo "\">
                                                            <input type=\"hidden\" name=\"id\" placeholder=\"Category  Name*\" required=\"\"  value=\"";
            // line 292
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
            echo "\">
                                                        </div>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"name\">Parent Category</label>
                                                            <select id=\"name\" class=\"form-control form-control-sm\" name=\"parent\">
                                                                ";
            // line 297
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["category"] ?? $this->getContext($context, "category")));
            foreach ($context['_seq'] as $context["_key"] => $context["mainc"]) {
                // line 298
                echo "                                                                <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["mainc"], "id", array()), "html", null, true);
                echo "\" ";
                if (($this->getAttribute($context["mainc"], "id", array()) == $this->getAttribute($context["sub"], "parent_id", array()))) {
                    echo " selected ";
                }
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["mainc"], "categoryName", array()), "html", null, true);
                echo "</option>
                                                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mainc'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 300
            echo "                                                            </select>
                                                        </div>
                                                        <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"0\">
                                                        <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                                        <div class=\"form-row mb-4\">
                                                            <div class=\"form-group col-md-8\">
                                                                <label for=\"Priority\">Priority</label>
                                                                <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" name=\"priority\" value=\"";
            // line 307
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "priority", array()), "html", null, true);
            echo "\">
                                                            </div>
                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Status</label>
                                                                <label class=\"switch s-success mr-2\"> 
                                                                    <input type=\"checkbox\" ";
            // line 312
            if (($this->getAttribute($context["sub"], "status", array()) == 0)) {
                echo "checked";
            }
            echo " class=\"form-control form-control-sm\" name=\"status\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "status", array()), "html", null, true);
            echo "\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Visiblity</label>
                                                                <label class=\"switch s-danger mr-2\"> 
                                                                    <input type=\"checkbox\"  ";
            // line 319
            if (($this->getAttribute($context["sub"], "featured", array()) == 0)) {
                echo "checked";
            }
            echo " class=\"form-control form-control-sm\" name=\"visiblity\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "featured", array()), "html", null, true);
            echo "\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"Status\">Icon </label>
                                                            <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"/uploads/sub-category/icons/";
            // line 326
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "iconImage", array()), "html", null, true);
            echo "\"> 
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class=\"modal-footer\">
                                                <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                                <button  class=\"btn btn-primary\" >Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                                <!-- end of add category --> 
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sub'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 341
        echo "                            ";
        if (((($context["branch_type"] ?? $this->getContext($context, "branch_type")) == 0) || ($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "branch", array()) == 0))) {
            // line 342
            echo "                            ";
            if ((($context["subadd"] ?? $this->getContext($context, "subadd")) == "0")) {
                // line 343
                echo "                            <div class=\"add-s-task\">
                                <a class=\"addTask\" data-toggle=\"modal\" data-target=\"#subcategory\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus-circle\"><circle cx=\"12\" cy=\"12\" r=\"10\"></circle><line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"16\"></line><line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\"></line></svg> Add Category</a>
                            </div>
                            ";
            }
            // line 347
            echo "                            ";
        }
        // line 348
        echo "                         </div>
                    </div>
                 <!--end sub category-->

                <!-- starts sub category add modal -->
                <div class=\"modal fade\" id=\"subcategory\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                    <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                        <div class=\"modal-content\">
                            <div class=\"modal-body\">
                                <div class=\"compose-box\">
                                    <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                        <h5 class=\"add-task-title\">Add Category</h5>

                                        <form data-7 method=\"post\"  enctype=\"multipart/form-data\" action=\"";
        // line 361
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create_category");
        echo "\">
                                            <div class=\"form-group mb-4\">
                                                <label for=\"name\">Category Name</label>
                                                <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\">
                                            </div>
                                            <div class=\"form-group mb-4\">
                                                <label for=\"name\">Parent Category</label>
                                                <select id=\"name\" class=\"form-control\" name=\"parent\">
                                                    ";
        // line 369
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["category"] ?? $this->getContext($context, "category")));
        foreach ($context['_seq'] as $context["_key"] => $context["mainc"]) {
            // line 370
            echo "                                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mainc"], "id", array()), "html", null, true);
            echo "\" >";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mainc"], "categoryName", array()), "html", null, true);
            echo "</option>
                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mainc'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 372
        echo "                                                </select>
                                            </div>
                                            <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"0\">
                                            <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                            <div class=\"form-row mb-4\">
                                                <div class=\"form-group col-md-8\">
                                                    <label for=\"Priority\">Priority</label>
                                                    <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" value=\"0\" name=\"priority\">
                                                </div>
                                                <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"0\">
                                                <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                                <div class=\"form-group col-md-2 align-self-end text-right\">
                                                    <label>Status</label>
                                                    <label class=\"switch s-success mr-2\"> 
                                                        <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"status\">
                                                        <span class=\"slider round\"></span>
                                                    </label>
                                                </div>
                                                <div class=\"form-group col-md-2 align-self-end text-right\">
                                                    <label>Visiblity</label>
                                                    <label class=\"switch s-danger mr-2\"> 
                                                        <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"visiblity\">
                                                        <span class=\"slider round\"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=\"form-group mb-4\">
                                                <label for=\"Status\">Icon </label>
                                                <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"\"> 
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class=\"modal-footer\">
                                    <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                    <button  class=\"btn btn-primary\" >Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!--it ends here-->


                <!-- add nested category -->
                
                    <div data-section=\"s-new\" class=\"task-list-container\">
                        <div class=\"connect-sorting\">
                            <div class=\"task-container-header\">
                                <h6 class=\"s-heading\" data-listTitle=\"In Progress\">Nested Categories</h6>
                                <a href=\"";
        // line 423
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("export_nestedcategory");
        echo "\" class=\"badge outline-badge-danger pull-right\">Export to CSV</a>
                            </div>
                            <form data-8 method=\"post\" action=\"";
        // line 425
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("bulk_action_category");
        echo "\">
                                <div class=\"row order-info mt-3 mb-3 pl-3\" >
                                    <input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"nestedcategory\">
                                    <div class=\"col-lg-8 col-md-8 col-12 mb-3 \">
                                        <select class=\"form-control form-control-sm\" name=\"type\">
                                        <option value=\"0\">Activate</option>
                                        <option value=\"1\">Deactivate</option>
                                           <option value=\"2\">Delete</option>
                                       </select>
                                    </div>
                                    <div class=\"col-lg-2 col-md-2 mb-3 align-self-end\">
                                        <input type=\"submit\" class=\"btn btn-sm btn-primary\" value=\"Update\">
                                    </div>
                                </div>
                                <div class=\"connect-sorting-content\" >
                                    ";
        // line 440
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["nestedcategory"] ?? $this->getContext($context, "nestedcategory")));
        foreach ($context['_seq'] as $context["_key"] => $context["sub"]) {
            // line 441
            echo "                                    <a href=\"#nestedtedit\">
                                        <div  class=\"card  nested-category-list simple-title-task ";
            // line 442
            if (($this->getAttribute($context["sub"], "id", array()) == ($context["mainid"] ?? $this->getContext($context, "mainid")))) {
                echo " active ";
            }
            echo "\">
                                            <div class=\"card-body\">
                                                <div class=\"task-header background-white nested-category\">
                                                    <!--task header start-->
                                                    <div class=\"row \">
                                                        <div class=\"col-md-4\">
                                                              <div class=\"row h-100\">
                                                                <div class=\"col-md-12 align-self-center\">
                                                                    <div class=\"category-img-wrapper\">
                                                                         <img src='/uploads/sub-category/icons/";
            // line 451
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "iconImage", array()), "html", null, true);
            echo "' class=\"img-fluid  img-responsive\">
                                                                    </div>
                                                                 </div>
                                                             </div>
                                                        </div>
                                                        <div class=\"col-md-8\">
                                                            <div class=\"bg-inner\">
                                                                <div class=\"row h-100 p-3\">
                                                                    <div class=\"col-md-12 mb-3 text-left\" >
                                                                        <input type=\"checkbox\" name=\"all[]\" class=\"category\" value=\"";
            // line 460
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
            echo "\">
                                                                        <span class=\"text-right\" style=\"font-size:16px; font-weight:700;float:right;\">#";
            // line 461
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
            echo "</span>
                                                                    </div>
                                                                    <div class=\"col-md-12\">
                                                                        <h4 class=\"text-left mb-3\" data-taskTitle=\"";
            // line 464
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "categoryName", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "categoryName", array()), "html", null, true);
            echo "</h4>
                                                                    </div>
                                                                    <div class=\"col-md-12\">
                                                                        <i class=\"fa\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-edit-2 s-task-edit\"><path d=\"M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z\"   data-toggle=\"modal\" data-target=\"#nestedcategory";
            // line 467
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
            echo "\"></path></svg></i>
                                                                        ";
            // line 468
            if (($this->getAttribute($context["sub"], "featured", array()) == 0)) {
                // line 469
                echo "                                                                        <i class=\"fa fa-eye\"></i>
                                                                        ";
            } else {
                // line 471
                echo "                                                                        <i class=\"fa fa-eye-slash\"></i>
                                                                        ";
            }
            // line 473
            echo "                                                                        ";
            if (($this->getAttribute($context["sub"], "status", array()) == 1)) {
                // line 474
                echo "                                                                        <i class=\"fa fa-circle\" style=\"color:red;\"></i> 
                                                                        ";
            } else {
                // line 476
                echo "                                                                        <i class=\"fa fa-circle\" style=\"color:green;\"></i>
                                                                        ";
            }
            // line 478
            echo "                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sub'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 488
        echo "                                </div>
                            </form>
                            <!-- add nested category -->
                             ";
        // line 491
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["nestedcategory"] ?? $this->getContext($context, "nestedcategory")));
        foreach ($context['_seq'] as $context["_key"] => $context["sub"]) {
            // line 492
            echo "                            <div class=\"modal fade\" id=\"nestedcategory";
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
            echo "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                                <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <!--form starts-->
                                        <form  method=\"post\"  enctype=\"multipart/form-data\" action=\"";
            // line 496
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_category");
            echo "\">      
                                            <div class=\"modal-body\">
                                                <div class=\"compose-box\">
                                                    <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                                        <h5 class=\"add-task-title\">Edit Nested Category</h5>
                                                        <div  class=\"form-group mb-4\">
                                                            <label for=\"name\">Category Name</label>
                                                            <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\" value=\"";
            // line 503
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "categoryName", array()), "html", null, true);
            echo "\">
                                                            <input type=\"hidden\" name=\"id\" placeholder=\"Category  Name*\" required=\"\"  value=\"";
            // line 504
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
            echo "\">
                                                        </div>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"name\">Parent Category</label>
                                                            <select id=\"name\" class=\"form-control form-control-sm\" name=\"parent\">
                                                                ";
            // line 509
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["nested"] ?? $this->getContext($context, "nested")));
            foreach ($context['_seq'] as $context["_key"] => $context["mainc"]) {
                // line 510
                echo "                                                                <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["mainc"], "id", array()), "html", null, true);
                echo "\" ";
                if (($this->getAttribute($context["mainc"], "id", array()) == $this->getAttribute($context["sub"], "parent_id", array()))) {
                    echo " selected ";
                }
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["mainc"], "categoryName", array()), "html", null, true);
                echo "</option>
                                                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mainc'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 512
            echo "                                                            </select>
                                                        </div>
                                                        <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"1\">
                                                        <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                                        <div class=\"form-row mb-4\">
                                                            <div class=\"form-group col-md-8\">
                                                                <label for=\"Priority\">Priority</label>
                                                                <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" name=\"priority\" value=\"";
            // line 519
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "priority", array()), "html", null, true);
            echo "\">
                                                            </div>
                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Status</label>
                                                                <label class=\"switch s-success mr-2\"> 
                                                                    <input type=\"checkbox\" ";
            // line 524
            if (($this->getAttribute($context["sub"], "status", array()) == 0)) {
                echo "checked";
            }
            echo " class=\"form-control form-control-sm\" name=\"status\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "status", array()), "html", null, true);
            echo "\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Visiblity</label>
                                                                <label class=\"switch s-danger mr-2\"> 
                                                                    <input type=\"checkbox\"  ";
            // line 531
            if (($this->getAttribute($context["sub"], "featured", array()) == 0)) {
                echo "checked";
            }
            echo " class=\"form-control form-control-sm\" name=\"visiblity\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "featured", array()), "html", null, true);
            echo "\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"Status\">Icon </label>
                                                            <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"/uploads/sub-category/icons/";
            // line 538
            echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "iconImage", array()), "html", null, true);
            echo "\"> 
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class=\"modal-footer\">
                                                <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                                <button  class=\"btn btn-primary\" >Update</button>
                                            </div>
                                        </form>
                                        <!--from ends-->
                                    </div>
                                </div>
                            </div>
                            <!-- end of nested category -->
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sub'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 555
        echo "                            ";
        if (((($context["branch_type"] ?? $this->getContext($context, "branch_type")) == 0) || ($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "branch", array()) == 0))) {
            // line 556
            echo "                        ";
            if ((($context["nestedadd"] ?? $this->getContext($context, "nestedadd")) == "0")) {
                // line 557
                echo "                            <div class=\"add-s-task\">
                                <a class=\"addTask\" data-toggle=\"modal\" data-target=\"#nestedcategory\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus-circle\"><circle cx=\"12\" cy=\"12\" r=\"10\"></circle><line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"16\"></line><line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\"></line></svg> Add Category</a>
                            </div>
                            ";
            }
            // line 561
            echo "                            ";
        }
        // line 562
        echo "                        </div>
                    </div>
                <!--nested add category -->
                <div class=\"modal fade\" data-myform id=\"nestedcategory\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                    <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                        <div class=\"modal-content\">
                        <form data-1 id=\"nestedcategoryform\"  method=\"post\"  enctype=\"multipart/form-data\" action=\"";
        // line 568
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create_category");
        echo "\">
                                <div class=\"modal-body\">
                                    <div class=\"compose-box\">
                                        <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                            <h5 class=\"add-task-title\">Add Category</h5>
                                            <div class=\"form-group mb-4\">
                                                <label for=\"name\">Category Name</label>
                                                <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\">
                                            </div>
                                            <div class=\"form-group mb-4\">
                                                <label for=\"name\">Parent Category</label>
                                                <select id=\"name\" class=\"form-control\" name=\"parent\">
                                                    ";
        // line 580
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["nested"] ?? $this->getContext($context, "nested")));
        foreach ($context['_seq'] as $context["_key"] => $context["mainc"]) {
            // line 581
            echo "                                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mainc"], "id", array()), "html", null, true);
            echo "\" >";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mainc"], "categoryName", array()), "html", null, true);
            echo "</option>
                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mainc'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 583
        echo "                                                </select>
                                            </div>
                                            <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                            <div class=\"form-row mb-4\">
                                                <div class=\"form-group col-md-8\">
                                                    <label for=\"Priority\">Priority</label>
                                                    <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" value=\"0\" name=\"priority\">
                                                </div>
                                                <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"1\">
                                                <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                                <div class=\"form-group col-md-2 align-self-end text-right\">
                                                    <label>Status</label>
                                                    <label class=\"switch s-success mr-2\"> 
                                                        <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"status\">
                                                        <span class=\"slider round\"></span>
                                                    </label>
                                                </div>
                                                <div class=\"form-group col-md-2 align-self-end text-right\">
                                                    <label>Visiblity</label>
                                                    <label class=\"switch s-danger mr-2\"> 
                                                        <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"visiblity\">
                                                        <span class=\"slider round\"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=\"form-group mb-4\">
                                                <label for=\"Status\">Icon </label>
                                                <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"\"> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"modal-footer\">
                                    <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                    <button  class=\"btn btn-primary\" >Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!--nested ends category-->
            </div>
          
        </div>
    </div>
</div>

";
        
        $__internal_50972043902cbd628f6d0de609671ae72febf701e159616a79394eda8a96b372->leave($__internal_50972043902cbd628f6d0de609671ae72febf701e159616a79394eda8a96b372_prof);

    }

    // line 631
    public function block_script($context, array $blocks = array())
    {
        $__internal_cf6cbedaf6861ad54d48db9e4f941891077b4ff2aed3f41116e52f0c0ab981cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf6cbedaf6861ad54d48db9e4f941891077b4ff2aed3f41116e52f0c0ab981cc->enter($__internal_cf6cbedaf6861ad54d48db9e4f941891077b4ff2aed3f41116e52f0c0ab981cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "script"));

        // line 632
        echo "<script type=\"text/javascript\">

</script>
";
        
        $__internal_cf6cbedaf6861ad54d48db9e4f941891077b4ff2aed3f41116e52f0c0ab981cc->leave($__internal_cf6cbedaf6861ad54d48db9e4f941891077b4ff2aed3f41116e52f0c0ab981cc_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/manageCategories.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1056 => 632,  1050 => 631,  996 => 583,  985 => 581,  981 => 580,  966 => 568,  958 => 562,  955 => 561,  949 => 557,  946 => 556,  943 => 555,  920 => 538,  906 => 531,  892 => 524,  884 => 519,  875 => 512,  860 => 510,  856 => 509,  848 => 504,  844 => 503,  834 => 496,  826 => 492,  822 => 491,  817 => 488,  802 => 478,  798 => 476,  794 => 474,  791 => 473,  787 => 471,  783 => 469,  781 => 468,  777 => 467,  769 => 464,  763 => 461,  759 => 460,  747 => 451,  733 => 442,  730 => 441,  726 => 440,  708 => 425,  703 => 423,  650 => 372,  639 => 370,  635 => 369,  624 => 361,  609 => 348,  606 => 347,  600 => 343,  597 => 342,  594 => 341,  573 => 326,  559 => 319,  545 => 312,  537 => 307,  528 => 300,  513 => 298,  509 => 297,  501 => 292,  497 => 291,  487 => 284,  481 => 281,  474 => 279,  470 => 277,  453 => 265,  449 => 263,  445 => 261,  442 => 260,  438 => 258,  434 => 256,  432 => 255,  428 => 254,  420 => 251,  414 => 248,  410 => 247,  397 => 237,  383 => 228,  378 => 227,  374 => 226,  356 => 211,  351 => 209,  297 => 158,  284 => 147,  278 => 143,  276 => 142,  271 => 139,  249 => 123,  235 => 116,  221 => 109,  209 => 100,  200 => 94,  196 => 93,  190 => 90,  178 => 82,  174 => 81,  170 => 79,  154 => 68,  150 => 66,  146 => 64,  143 => 63,  139 => 61,  135 => 59,  133 => 58,  129 => 57,  121 => 54,  115 => 51,  111 => 50,  99 => 41,  85 => 32,  80 => 31,  76 => 30,  58 => 15,  53 => 13,  41 => 3,  35 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}
{% block body %}
<div class=\"main-content\">
    <div class=\"layout-px-spacing\">
        <div class=\"row scrumboard\" id=\"cancel-row\">
            <div class=\"col-lg-12 layout-spacing\">
                <!--add main category-->
                <div class=\"task-list-section\">
                    <div data-section=\"s-new\" class=\"task-list-container\">
                        <div class=\"connect-sorting\">
                            <div class=\"task-container-header\">
                                <h6 class=\"s-heading\" data-listTitle=\"In Progress\">Main Categories</h6>
                                <a href=\"{{ path('export_category') }}\" class=\"badge outline-badge-danger pull-right\">Export to CSV</a>
                            </div>
                            <form data-2 method=\"post\" action=\"{{ path('bulk_action_category')}}\">
                                <div class=\"row order-info mt-3 mb-3 pl-3\" >
                                    <input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"category\">
                                    <div class=\"col-lg-8 col-md-8 col-12 mb-3 \">
                                        <select class=\"form-control form-control-sm\" name=\"type\">
                                          <option value=\"0\">Activate</option>
                                          <option value=\"1\">Deactivate</option>
                                          <option value=\"2\">Delete</option>
                                        </select>
                                    </div>
                                    <div class=\"col-lg-3 col-md-3 col-12 mb-3  align-self-end\">
                                        <input type=\"submit\" class=\"btn btn-sm btn-primary\" value=\"Update\">
                                    </div>
                                </div>
                                <div class=\"connect-sorting-content\" >
                                {% for main in category%}
                                <a href=\"{{ path('manage_category_get',{'id': main.id }) }}\">
                                    <div  class=\"card main-category-list simple-title-task {% if main.id == mainid %} active {% endif %}\">
                                        <div class=\"card-body\">
                                            <div class=\"task-header background-white main-category\">
                                                <!--task header start-->
                                                <div class=\"row \">
                                                    <div class=\"col-md-4\">
                                                        <div class=\"row h-100\">
                                                            <div class=\"col-md-12 align-self-center\">
                                                                <div class=\"category-img-wrapper\">
                                                                    <img class=\"img-fluid img-responsive\" src='/uploads/sub-category/icons/{{ main.iconImage }}'>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"col-md-8\">
                                                        <div class=\"bg-inner\">
                                                            <div class=\"row h-100 p-3\">
                                                                <div class=\"col-md-12 mb-3 text-left\" >
                                                                    <input type=\"checkbox\" name=\"all[]\" class=\"category\" value=\"{{ main.id }}\">
                                                                    <span class=\"text-right\" style=\"font-size:16px; font-weight:700;float:right;\">#{{ main.id }}</span>
                                                                </div>
                                                                <div class=\"col-md-12\">
                                                                    <h4 class=\"text-left mb-3\" data-taskTitle=\"{{ main.categoryName }}\">{{ main.categoryName }}</h4>
                                                                </div>
                                                                <div class=\"col-md-12\">
                                                                    <i class=\"fa\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-edit-2 s-task-edit\"><path d=\"M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z\"   data-toggle=\"modal\" data-target=\"#category{{ main.id }}\"></path></svg></i>
                                                                    {% if main.featured == 0 %}
                                                                    <i class=\"fa fa-eye\"></i>
                                                                    {% else %}
                                                                    <i class=\"fa fa-eye-slash\"></i>
                                                                    {% endif %}
                                                                    {% if main.status == 1 %}
                                                                    <i class=\"fa fa-circle\" style=\"color:red;\"></i> 
                                                                    {% else %}
                                                                    <i class=\"fa fa-circle\" style=\"color:green;\"></i>
                                                                    {% endif %}
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--task header ends-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                {% endfor %}
                            </form>
                             <!-- add category -->
                            {% for main in category%}
                            <div class=\"modal fade\" id=\"category{{main.id}}\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                                <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <div class=\"modal-body\">
                                            <div class=\"compose-box\">
                                                <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                                    <h5 class=\"add-task-title\">Edit Category</h5>

                                                    <form data-3 method=\"post\"  enctype=\"multipart/form-data\" action=\"{{ path('update_category')}}\">
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"name\">Category Name</label>
                                                            <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\" value=\"{{ main.categoryName }}\">
                                                            <input type=\"hidden\" name=\"id\" placeholder=\"Category  Name*\" required=\"\"  value=\"{{ main.id }}\">
                                                        </div>

                                                        <div class=\"form-row mb-4\">
                                                            <div class=\"form-group col-md-8\">
                                                                <label for=\"Priority\">Priority</label>
                                                                <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" name=\"priority\" value=\"{{ main.priority }}\">
                                                            </div>
                                                            <input type=\"hidden\" id=\"parent\" class=\"form-control form-control-sm\" name=\"parent\" value=\"0\">
                                                            <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"0\">
                                                            <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"0\">

                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Status</label>
                                                                <label class=\"switch s-success mr-2\"> 
                                                                    <input type=\"checkbox\" {% if main.status == 0 %}checked{% endif %} class=\"form-control form-control-sm\" name=\"status\"  value=\"{{ main.status }}\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Visiblity</label>
                                                                <label class=\"switch s-danger mr-2\"> 
                                                                    <input type=\"checkbox\"  {% if main.featured == 0 %}checked{% endif %} class=\"form-control form-control-sm\" name=\"visiblity\"  value=\"{{ main.featured }}\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"Status\">Icon </label>
                                                            <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"/uploads/sub-category/icons/{{ main.iconImage }}\"> 
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class=\"modal-footer\">
                                                <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                                <button  class=\"btn btn-primary\" >Update</button>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                            {% endfor %}

                            <!-- end of add category -->
                        </div>
                    {% if branch_type == 0 or app.user.branch == 0 %}
                         <div class=\"add-s-task\">
                            <a class=\"addTask main-category-btn\" data-toggle=\"modal\" data-target=\"#category\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus-circle\"><circle cx=\"12\" cy=\"12\" r=\"10\"></circle><line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"16\"></line><line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\"></line></svg> Add Category</a>
                        </div>
                      {% endif %}
                    </div>
                <!--ends main category-->
                <!--starts main category modal -->
                    <div class=\"modal fade\" id=\"category\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                        <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                            <div class=\"modal-content\">
                                <div class=\"modal-body\">
                                    <div class=\"compose-box\">
                                        <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                            <h5 class=\"add-task-title\">Add Category -main catgory</h5>

                                            <form data-4 method=\"post\"  enctype=\"multipart/form-data\" action=\"{{ path('create_category')}}\">
                                                <div class=\"form-group mb-4\">
                                                    <label for=\"name\">Category Name</label>
                                                    <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\">
                                                    <input type=\"hidden\" id=\"parent\" class=\"form-control form-control-sm\" name=\"parent\" value=\"0\">
                                                    <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"0\">
                                                    <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"0\">
                                                </div>
                                                <div class=\"form-row mb-4\">
                                                    <div class=\"form-group col-md-8\">
                                                        <label for=\"Priority\">Priority</label>
                                                        <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" value=\"0\" name=\"priority\">
                                                    </div>
                                                    <div class=\"form-group col-md-2 align-self-end text-right\">
                                                        <label>Status</label>
                                                        <label class=\"switch s-success mr-2\"> 
                                                            <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"status\">
                                                            <span class=\"slider round\"></span>
                                                        </label>
                                                    </div>
                                                    <div class=\"form-group col-md-2 align-self-end text-right\">
                                                        <label>Visiblity</label>
                                                        <label class=\"switch s-danger mr-2\"> 
                                                            <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"visiblity\">
                                                            <span class=\"slider round\"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class=\"form-group mb-4\">
                                                    <label for=\"Status\">Icon </label>
                                                    <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"\"> 
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class=\"modal-footer\">
                                        <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                        <button  class=\"btn btn-primary\" >Save</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
               
                 <div data-section=\"s-new\" class=\"task-list-container\">
                        <div class=\"connect-sorting\">
                            <div class=\"task-container-header\">
                                <h6 class=\"s-heading\" data-listTitle=\"In Progress\">Sub Categories</h6>
                                <a href=\"{{ path('export_subcategory') }}\" class=\"badge outline-badge-danger pull-right\">Export to CSV</a>
                            </div>
                            <form data-5 method=\"post\" action=\"{{ path('bulk_action_category')}}\">
                                <div class=\"row order-info mt-3 mb-3 pl-3 align-self-center\" >
                                    <input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"subcategory\">
                                    <div class=\"col-lg-8 col-md-8 col-12 mb-3 \">
                                        <select class=\"form-control form-control-sm\" name=\"type\">
                                        <option value=\"0\">Activate</option>
                                        <option value=\"1\">Deactivate</option>
                                          <option value=\"2\">Delete</option>
                                    </select>
                                    </div>
                                    <div class=\"col-lg-2 col-md-2 mb-3 align-self-end\">
                                        <input type=\"submit\" class=\"btn btn-sm btn-primary\" value=\"Update\" >
                                    </div>
                                </div>
                                <div class=\"connect-sorting-content\" >
                                    {% for sub in subcategory%}
                                    <a href=\"{{ path('manage_category_get_nested',{'parent': sub.parent_id,'id': sub.id }) }}\">
                                        <div  class=\"card sub-category-list simple-title-task {% if sub.id == subid %} active {% endif %}\">
                                            <div class=\"card-body\">
                                                <div class=\"task-header background-white sub-category\">
                                                    <!--task header start-->
                                                     <div class=\"row\">
                                                        <div class=\"col-md-4\">
                                                             <div class=\"row h-100\">
                                                                <div class=\"col-md-12 align-self-center\">
                                                                     <div class=\"category-img-wrapper\">
                                                                        <img src='/uploads/sub-category/icons/{{ sub.iconImage }}' class=\"img-fluid img-responsive rounded\">
                                                                    </div>
                                                                </div>
                                                             </div>
                                                            <!--end-->
                                                        </div>
                                                        <div class=\"col-md-8\">
                                                            <div class=\"bg-inner\">
                                                              <div class=\"row h-100 p-3\">
                                                                    <div class=\"col-md-12 mb-3 text-left\" >
                                                                        <input type=\"checkbox\" name=\"all[]\" class=\"subcategory\" value=\"{{ sub.id }}\">
                                                                        <span  style=\"font-size:16px; font-weight:700;float:right;\">#{{ sub.id }}</span>
                                                                    </div>
                                                                    <div class=\"col-md-12\">
                                                                        <h4 class=\"text-left mb-3\" data-taskTitle=\"{{ sub.categoryName }}\">{{ sub.categoryName }}</h4>
                                                                    </div>
                                                                    <div class=\"col-md-12\">
                                                                        <i class=\"fa\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-edit-2 s-task-edit\"><path d=\"M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z\"   data-toggle=\"modal\" data-target=\"#subcategory{{ sub.id }}\"></path></svg></i>
                                                                        {% if sub.featured == 0 %}
                                                                        <i class=\"fa fa-eye\"></i>
                                                                        {% else %}
                                                                        <i class=\"fa fa-eye-slash\"></i>
                                                                        {% endif %}
                                                                        {% if sub.status == 1 %}
                                                                        <i class=\"fa fa-circle\" style=\"color:red;\"></i> 
                                                                        {% else %}
                                                                        <i class=\"fa fa-circle\" style=\"color:green;\"></i>
                                                                        {% endif %}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--end-->
                                                                    <!--task header ends-->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    {% endfor %}
                                </div>
                            </form>
                            {% for sub in subcategory%} 
                                 <!-- add sub category -->
                            <div class=\"modal fade\" id=\"subcategory{{sub.id}}\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                                <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <form data-6 method=\"post\"  enctype=\"multipart/form-data\" action=\"{{ path('update_category')}}\">
                                            <div class=\"modal-body\">
                                                <div class=\"compose-box\">
                                                    <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                                        <h5 class=\"add-task-title\">Edit Category</h5>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"name\">Category Name</label>
                                                            <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\" value=\"{{ sub.categoryName }}\">
                                                            <input type=\"hidden\" name=\"id\" placeholder=\"Category  Name*\" required=\"\"  value=\"{{ sub.id }}\">
                                                        </div>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"name\">Parent Category</label>
                                                            <select id=\"name\" class=\"form-control form-control-sm\" name=\"parent\">
                                                                {% for mainc in category %}
                                                                <option value=\"{{ mainc.id }}\" {% if mainc.id == sub.parent_id %} selected {% endif %}>{{ mainc.categoryName }}</option>
                                                                {% endfor %}
                                                            </select>
                                                        </div>
                                                        <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"0\">
                                                        <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                                        <div class=\"form-row mb-4\">
                                                            <div class=\"form-group col-md-8\">
                                                                <label for=\"Priority\">Priority</label>
                                                                <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" name=\"priority\" value=\"{{ sub.priority }}\">
                                                            </div>
                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Status</label>
                                                                <label class=\"switch s-success mr-2\"> 
                                                                    <input type=\"checkbox\" {% if sub.status == 0 %}checked{% endif %} class=\"form-control form-control-sm\" name=\"status\"  value=\"{{ sub.status }}\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Visiblity</label>
                                                                <label class=\"switch s-danger mr-2\"> 
                                                                    <input type=\"checkbox\"  {% if sub.featured == 0 %}checked{% endif %} class=\"form-control form-control-sm\" name=\"visiblity\"  value=\"{{ sub.featured }}\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"Status\">Icon </label>
                                                            <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"/uploads/sub-category/icons/{{ sub.iconImage }}\"> 
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class=\"modal-footer\">
                                                <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                                <button  class=\"btn btn-primary\" >Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                                <!-- end of add category --> 
                            {% endfor %}
                            {% if branch_type == 0 or app.user.branch == 0 %}
                            {% if subadd == '0' %}
                            <div class=\"add-s-task\">
                                <a class=\"addTask\" data-toggle=\"modal\" data-target=\"#subcategory\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus-circle\"><circle cx=\"12\" cy=\"12\" r=\"10\"></circle><line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"16\"></line><line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\"></line></svg> Add Category</a>
                            </div>
                            {% endif %}
                            {% endif %}
                         </div>
                    </div>
                 <!--end sub category-->

                <!-- starts sub category add modal -->
                <div class=\"modal fade\" id=\"subcategory\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                    <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                        <div class=\"modal-content\">
                            <div class=\"modal-body\">
                                <div class=\"compose-box\">
                                    <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                        <h5 class=\"add-task-title\">Add Category</h5>

                                        <form data-7 method=\"post\"  enctype=\"multipart/form-data\" action=\"{{ path('create_category')}}\">
                                            <div class=\"form-group mb-4\">
                                                <label for=\"name\">Category Name</label>
                                                <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\">
                                            </div>
                                            <div class=\"form-group mb-4\">
                                                <label for=\"name\">Parent Category</label>
                                                <select id=\"name\" class=\"form-control\" name=\"parent\">
                                                    {% for mainc in category %}
                                                    <option value=\"{{ mainc.id }}\" >{{ mainc.categoryName }}</option>
                                                    {% endfor %}
                                                </select>
                                            </div>
                                            <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"0\">
                                            <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                            <div class=\"form-row mb-4\">
                                                <div class=\"form-group col-md-8\">
                                                    <label for=\"Priority\">Priority</label>
                                                    <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" value=\"0\" name=\"priority\">
                                                </div>
                                                <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"0\">
                                                <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                                <div class=\"form-group col-md-2 align-self-end text-right\">
                                                    <label>Status</label>
                                                    <label class=\"switch s-success mr-2\"> 
                                                        <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"status\">
                                                        <span class=\"slider round\"></span>
                                                    </label>
                                                </div>
                                                <div class=\"form-group col-md-2 align-self-end text-right\">
                                                    <label>Visiblity</label>
                                                    <label class=\"switch s-danger mr-2\"> 
                                                        <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"visiblity\">
                                                        <span class=\"slider round\"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=\"form-group mb-4\">
                                                <label for=\"Status\">Icon </label>
                                                <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"\"> 
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class=\"modal-footer\">
                                    <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                    <button  class=\"btn btn-primary\" >Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!--it ends here-->


                <!-- add nested category -->
                
                    <div data-section=\"s-new\" class=\"task-list-container\">
                        <div class=\"connect-sorting\">
                            <div class=\"task-container-header\">
                                <h6 class=\"s-heading\" data-listTitle=\"In Progress\">Nested Categories</h6>
                                <a href=\"{{ path('export_nestedcategory') }}\" class=\"badge outline-badge-danger pull-right\">Export to CSV</a>
                            </div>
                            <form data-8 method=\"post\" action=\"{{ path('bulk_action_category')}}\">
                                <div class=\"row order-info mt-3 mb-3 pl-3\" >
                                    <input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"nestedcategory\">
                                    <div class=\"col-lg-8 col-md-8 col-12 mb-3 \">
                                        <select class=\"form-control form-control-sm\" name=\"type\">
                                        <option value=\"0\">Activate</option>
                                        <option value=\"1\">Deactivate</option>
                                           <option value=\"2\">Delete</option>
                                       </select>
                                    </div>
                                    <div class=\"col-lg-2 col-md-2 mb-3 align-self-end\">
                                        <input type=\"submit\" class=\"btn btn-sm btn-primary\" value=\"Update\">
                                    </div>
                                </div>
                                <div class=\"connect-sorting-content\" >
                                    {% for sub in nestedcategory%}
                                    <a href=\"#nestedtedit\">
                                        <div  class=\"card  nested-category-list simple-title-task {% if sub.id == mainid %} active {% endif %}\">
                                            <div class=\"card-body\">
                                                <div class=\"task-header background-white nested-category\">
                                                    <!--task header start-->
                                                    <div class=\"row \">
                                                        <div class=\"col-md-4\">
                                                              <div class=\"row h-100\">
                                                                <div class=\"col-md-12 align-self-center\">
                                                                    <div class=\"category-img-wrapper\">
                                                                         <img src='/uploads/sub-category/icons/{{ sub.iconImage }}' class=\"img-fluid  img-responsive\">
                                                                    </div>
                                                                 </div>
                                                             </div>
                                                        </div>
                                                        <div class=\"col-md-8\">
                                                            <div class=\"bg-inner\">
                                                                <div class=\"row h-100 p-3\">
                                                                    <div class=\"col-md-12 mb-3 text-left\" >
                                                                        <input type=\"checkbox\" name=\"all[]\" class=\"category\" value=\"{{ sub.id }}\">
                                                                        <span class=\"text-right\" style=\"font-size:16px; font-weight:700;float:right;\">#{{ sub.id }}</span>
                                                                    </div>
                                                                    <div class=\"col-md-12\">
                                                                        <h4 class=\"text-left mb-3\" data-taskTitle=\"{{ sub.categoryName }}\">{{ sub.categoryName }}</h4>
                                                                    </div>
                                                                    <div class=\"col-md-12\">
                                                                        <i class=\"fa\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-edit-2 s-task-edit\"><path d=\"M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z\"   data-toggle=\"modal\" data-target=\"#nestedcategory{{ sub.id }}\"></path></svg></i>
                                                                        {% if sub.featured == 0 %}
                                                                        <i class=\"fa fa-eye\"></i>
                                                                        {% else %}
                                                                        <i class=\"fa fa-eye-slash\"></i>
                                                                        {% endif %}
                                                                        {% if sub.status == 1 %}
                                                                        <i class=\"fa fa-circle\" style=\"color:red;\"></i> 
                                                                        {% else %}
                                                                        <i class=\"fa fa-circle\" style=\"color:green;\"></i>
                                                                        {% endif %}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    {% endfor %}
                                </div>
                            </form>
                            <!-- add nested category -->
                             {% for sub in nestedcategory%}
                            <div class=\"modal fade\" id=\"nestedcategory{{sub.id}}\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                                <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <!--form starts-->
                                        <form  method=\"post\"  enctype=\"multipart/form-data\" action=\"{{ path('update_category')}}\">      
                                            <div class=\"modal-body\">
                                                <div class=\"compose-box\">
                                                    <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                                        <h5 class=\"add-task-title\">Edit Nested Category</h5>
                                                        <div  class=\"form-group mb-4\">
                                                            <label for=\"name\">Category Name</label>
                                                            <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\" value=\"{{ sub.categoryName }}\">
                                                            <input type=\"hidden\" name=\"id\" placeholder=\"Category  Name*\" required=\"\"  value=\"{{ sub.id }}\">
                                                        </div>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"name\">Parent Category</label>
                                                            <select id=\"name\" class=\"form-control form-control-sm\" name=\"parent\">
                                                                {% for mainc in nested %}
                                                                <option value=\"{{ mainc.id }}\" {% if mainc.id == sub.parent_id %} selected {% endif %}>{{ mainc.categoryName }}</option>
                                                                {% endfor %}
                                                            </select>
                                                        </div>
                                                        <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"1\">
                                                        <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                                        <div class=\"form-row mb-4\">
                                                            <div class=\"form-group col-md-8\">
                                                                <label for=\"Priority\">Priority</label>
                                                                <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" name=\"priority\" value=\"{{ sub.priority }}\">
                                                            </div>
                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Status</label>
                                                                <label class=\"switch s-success mr-2\"> 
                                                                    <input type=\"checkbox\" {% if sub.status == 0 %}checked{% endif %} class=\"form-control form-control-sm\" name=\"status\"  value=\"{{ sub.status }}\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                            <div class=\"form-group col-md-2 align-self-end text-right\">
                                                                <label>Visiblity</label>
                                                                <label class=\"switch s-danger mr-2\"> 
                                                                    <input type=\"checkbox\"  {% if sub.featured == 0 %}checked{% endif %} class=\"form-control form-control-sm\" name=\"visiblity\"  value=\"{{ sub.featured }}\">
                                                                    <span class=\"slider round\"></span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class=\"form-group mb-4\">
                                                            <label for=\"Status\">Icon </label>
                                                            <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"/uploads/sub-category/icons/{{ sub.iconImage }}\"> 
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class=\"modal-footer\">
                                                <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                                <button  class=\"btn btn-primary\" >Update</button>
                                            </div>
                                        </form>
                                        <!--from ends-->
                                    </div>
                                </div>
                            </div>
                            <!-- end of nested category -->
                            {% endfor %}
                            {% if branch_type == 0 or app.user.branch == 0 %}
                        {% if nestedadd == '0' %}
                            <div class=\"add-s-task\">
                                <a class=\"addTask\" data-toggle=\"modal\" data-target=\"#nestedcategory\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus-circle\"><circle cx=\"12\" cy=\"12\" r=\"10\"></circle><line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"16\"></line><line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\"></line></svg> Add Category</a>
                            </div>
                            {% endif %}
                            {% endif %}
                        </div>
                    </div>
                <!--nested add category -->
                <div class=\"modal fade\" data-myform id=\"nestedcategory\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
                    <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
                        <div class=\"modal-content\">
                        <form data-1 id=\"nestedcategoryform\"  method=\"post\"  enctype=\"multipart/form-data\" action=\"{{ path('create_category')}}\">
                                <div class=\"modal-body\">
                                    <div class=\"compose-box\">
                                        <div class=\"compose-content\" id=\"addTaskModalTitle\">
                                            <h5 class=\"add-task-title\">Add Category</h5>
                                            <div class=\"form-group mb-4\">
                                                <label for=\"name\">Category Name</label>
                                                <input type=\"text\" id=\"name\" class=\"form-control form-control-sm\" name=\"name\" placeholder=\"Category  Name*\" required=\"\" autocomplete=\"off\">
                                            </div>
                                            <div class=\"form-group mb-4\">
                                                <label for=\"name\">Parent Category</label>
                                                <select id=\"name\" class=\"form-control\" name=\"parent\">
                                                    {% for mainc in nested %}
                                                    <option value=\"{{ mainc.id }}\" >{{ mainc.categoryName }}</option>
                                                    {% endfor %}
                                                </select>
                                            </div>
                                            <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                            <div class=\"form-row mb-4\">
                                                <div class=\"form-group col-md-8\">
                                                    <label for=\"Priority\">Priority</label>
                                                    <input type=\"number\" class=\"form-control form-control-sm\" id=\"Priority\" placeholder=\"Priority\" autocomplete=\"off\" value=\"0\" name=\"priority\">
                                                </div>
                                                <input type=\"hidden\" id=\"nested\" class=\"form-control form-control-sm\" name=\"nested\" value=\"1\">
                                                <input type=\"hidden\" id=\"type\" class=\"form-control form-control-sm\" name=\"type\" value=\"1\">
                                                <div class=\"form-group col-md-2 align-self-end text-right\">
                                                    <label>Status</label>
                                                    <label class=\"switch s-success mr-2\"> 
                                                        <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"status\">
                                                        <span class=\"slider round\"></span>
                                                    </label>
                                                </div>
                                                <div class=\"form-group col-md-2 align-self-end text-right\">
                                                    <label>Visiblity</label>
                                                    <label class=\"switch s-danger mr-2\"> 
                                                        <input type=\"checkbox\" checked class=\"form-control form-control-sm\" name=\"visiblity\">
                                                        <span class=\"slider round\"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class=\"form-group mb-4\">
                                                <label for=\"Status\">Icon </label>
                                                <input type=\"file\" name=\"image\"  class=\"dropify\" id=\"icon\" data-default-file=\"\"> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"modal-footer\">
                                    <button class=\"btn\" data-dismiss=\"modal\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg> Close</button>
                                    <button  class=\"btn btn-primary\" >Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!--nested ends category-->
            </div>
          
        </div>
    </div>
</div>

{% endblock %}
{% block script %}
<script type=\"text/javascript\">

</script>
{% endblock %}", "AppBundle:Admin:Pages/manageCategories.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/manageCategories.html.twig");
    }
}

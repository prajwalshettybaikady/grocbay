<?php

/* AppBundle:Restaurant:Menu/addNew.html.twig */
class __TwigTemplate_c884a570ef42bd7e1aa3f483d047e9fa04fe59a1774797e9a46e4d43c971ff06 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((("@AppBundle/" . ($context["myExtend"] ?? $this->getContext($context, "myExtend"))) . "/base.html.twig"), "AppBundle:Restaurant:Menu/addNew.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_880ce71543f1e305778ff63bdc41d577d70c6a30e77a8c19cbc87b410a51f997 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_880ce71543f1e305778ff63bdc41d577d70c6a30e77a8c19cbc87b410a51f997->enter($__internal_880ce71543f1e305778ff63bdc41d577d70c6a30e77a8c19cbc87b410a51f997_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Restaurant:Menu/addNew.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_880ce71543f1e305778ff63bdc41d577d70c6a30e77a8c19cbc87b410a51f997->leave($__internal_880ce71543f1e305778ff63bdc41d577d70c6a30e77a8c19cbc87b410a51f997_prof);

    }

    // line 3
    public function block_styles($context, array $blocks = array())
    {
        $__internal_31abaaa7bb8c76d449c74a59b52c3351db3cb67ec3b6b43859fac79d2d1a990b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31abaaa7bb8c76d449c74a59b52c3351db3cb67ec3b6b43859fac79d2d1a990b->enter($__internal_31abaaa7bb8c76d449c74a59b52c3351db3cb67ec3b6b43859fac79d2d1a990b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 4
        echo "

<style type=\"text/css\">
table#priceVar th {
  font-size:10px;
  text-transform:uppercase;
  font-weight:bold;
}
  [type=checkbox]:checked, [type=checkbox]:not(:checked){


  }
   .fstElement { font-size: 9px; }
          .fstToggleBtn { min-width: 16.5em; }

          .submitBtn { display: none; }

          .fstMultipleMode { display: block; }
          .fstMultipleMode .fstControls { width: 100%; }
          .right-sidebar-option {
      background: #F1F2F3;
}
.margin-bottom{
  margin-bottom: 0px !important;
}
.cat-name{
  font-size: 14px !important;
  font-weight: 800;
}

.img-close{
    position: absolute;
    top: -10px;
    background: #fb1e1e;
    padding: 5px;
    border-radius: 50%;
    width: 25px;
    height: 25px;
    text-align: center;
    line-height: 1;
    right: 61px;
    color: #fff;
  }

  .savefont{
    font-size: 16px;
    font-weight: 700;
  }

</style>
";
        
        $__internal_31abaaa7bb8c76d449c74a59b52c3351db3cb67ec3b6b43859fac79d2d1a990b->leave($__internal_31abaaa7bb8c76d449c74a59b52c3351db3cb67ec3b6b43859fac79d2d1a990b_prof);

    }

    // line 56
    public function block_body($context, array $blocks = array())
    {
        $__internal_89d9a43e7034628477513b5744ccba7267e8ac1cfbc905bd8274e0739cf9054c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89d9a43e7034628477513b5744ccba7267e8ac1cfbc905bd8274e0739cf9054c->enter($__internal_89d9a43e7034628477513b5744ccba7267e8ac1cfbc905bd8274e0739cf9054c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 57
        echo "  <!-- ============================================================== -->
  <!-- Start Page Content -->
  <!-- ============================================================== -->
  <!-- Row -->
";
        // line 61
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
<div class=\"\">
<div class=\"layout-px-spacing\">
  <div class=\"row layout-top-spacing\">
      <div class=\"col-md-9\">
        <div class=\"row\"><div class=\"col-md-12\">
        <div class=\"card card-outline-info\">
          <div class=\"card-header\">
            <div class=\"row mt-4 mb-4\">
              <div class=\"col-md-6\">
                <h4 class=\"pl-4\">Item Update Panel </h4>
              </div>
              <div class=\"col-md-6 pr-4\">
              </div>
            </div>
          </div>
        
        <div class=\"card-body\">
          ";
        // line 80
        echo "            <div class=\"form-body\">
              <div class=\"row p-t-20\">
                <!--START-->
                ";
        // line 83
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/widget.html.twig"));
        // line 84
        echo "                <div class=\"col-md-12\">
                  <div class=\"row\">
                    <div class=\"col-md-12\">
                      <div class=\"form-group\">
                        ";
        // line 88
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "itemName", array()), 'label', array("label" => "Item Name"));
        echo "
                        ";
        // line 89
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "itemName", array()), 'row', array("attr" => array("class" => "form-control form-control-sm", "placeholder" => "Item Name")));
        echo "
                      </div>
                    </div>
                  </div>
                  ";
        // line 93
        $context["arr"] = twig_split_filter($this->env, $this->getAttribute(($context["menuItem"] ?? $this->getContext($context, "menuItem")), "category", array()), ",");
        echo "  
                  <div class=\"row\">
                <div class=\"col-md-4\">
                  <div class=\"form-group\">
                    ";
        // line 97
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), 'label', array("label" => "Stock Type"));
        echo "
                    ";
        // line 98
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), 'row', array("attr" => array("class" => "form-control form-control-sm")));
        echo "
                  </div>  
                </div>
                <div class=\"col-md-4\">
                  <div class=\"form-group\">
                    ";
        // line 103
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "delivery", array()), 'label', array("label" => "Delivery Duration"));
        echo "
                    ";
        // line 104
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "delivery", array()), 'row', array("attr" => array("class" => "form-control form-control-sm")));
        echo "
                  </div>
                </div>
                  <div class=\"col-md-4\">
                    <div class=\"form-group\">
                      ";
        // line 109
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "vegType", array()), 'label', array("label" => "Product Type"));
        echo "
                      ";
        // line 110
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "vegType", array()), 'row', array("attr" => array("class" => "form-control form-control-sm")));
        echo "
                    </div>  
                  </div>
                </div>
                <div class=\"row\">
                  
                  <div class=\"col-md-4\">
                    <div class=\"form-group\">
                      ";
        // line 118
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "alert", array()), 'label', array("label" => "Stock Notify"));
        echo "
                      ";
        // line 119
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "alert", array()), 'row', array("attr" => array("class" => "form-control form-control-sm", "placeholder" => "Stock Notify", "value" => "10")));
        echo "
                    </div>
                  </div>
                  <div class=\"col-md-4\">
                    <div class=\"form-group\">
                      ";
        // line 124
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "duration", array()), 'label', array("label" => "Return Duration"));
        echo "
                      ";
        // line 125
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "duration", array()), 'row', array("attr" => array("class" => "form-control form-control-sm")));
        echo "
                    </div>
                  </div>
                  <div class=\"col-md-4\">
                    ";
        // line 129
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "salesTax", array()), 'label', array("label" => "Gst"));
        echo "
                    ";
        // line 130
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "salesTax", array()), 'row', array("attr" => array("class" => "form-control form-control-sm", "placeholder" => "Tax")));
        echo "
                  </div>
                </div>
                <div class=\"row\">
                  <div class=\"col-md-6\">
                    ";
        // line 135
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "itemDescription", array()), 'label', array("label" => "Item description"));
        echo "
                    ";
        // line 136
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "itemDescription", array()), 'row', array("attr" => array("class" => "form-control form-control-sm", "placeholder" => "Doe")));
        echo "
                  </div>
                  <div class=\"col-md-6\">
                    ";
        // line 139
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "itemShortDescription", array()), 'label', array("label" => "Manufacturer description"));
        echo "
                    ";
        // line 140
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "itemShortDescription", array()), 'row', array("attr" => array("class" => "form-control form-control-sm", "placeholder" => "Doe")));
        echo "
                  </div>
                  
                </div>  
                    <div class=\"row\">

                      <div class=\"col-md-4\">
                    <div class=\"form-group\">
                        ";
        // line 148
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "itemPriority", array()), 'label', array("label" => "Item Priority"));
        echo "
                        ";
        // line 149
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "itemPriority", array()), 'row', array("attr" => array("class" => "form-control form-control-sm")));
        echo "
                    </div>
                  </div>

                    <div class=\"col-md-4\">
                        <label class=\"d-block\">Item Active Status</label>
                        <label class=\"switch s-success mr-2 mt-2\"> 
                            <input type=\"checkbox\" ";
        // line 156
        if ((($context["isActive"] ?? $this->getContext($context, "isActive")) == 1)) {
            echo "checked ";
        }
        echo " class=\"form-control form-control-sm\" name=\"isActive\"  value=\"";
        echo twig_escape_filter($this->env, ($context["isActive"] ?? $this->getContext($context, "isActive")), "html", null, true);
        echo "\">
                            <span class=\"slider round\"></span>
                        </label>
                    </div>

                      ";
        // line 161
        if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), "vars", array()), "value", array()) == "1")) {
            // line 162
            echo "                      <div class=\"col-md-4 fishprice\" style=\"display:block\">
                        ";
        } else {
            // line 164
            echo "                        <div class=\"col-md-4 fishprice\" style=\"display:none\">
                          ";
        }
        // line 166
        echo "                          <label for=\"pricess\">Price - 1 KG</label>
                          <div  class=\"form-group \"><input type=\"text\" id=\"pricess\" name=\"fishprice\" class=\"form-control form-control-sm\" placeholder=\"Price\" value=\"";
        // line 167
        echo twig_escape_filter($this->env, $this->getAttribute(($context["menuItem"] ?? $this->getContext($context, "menuItem")), "salePrice", array()), "html", null, true);
        echo "\">
                          </div>
                        </div>

                      </div>

                    </div>
                       <!--end-->
                  </div>
                </div>
              </div>
            </div>
            <!--end col-md-9 card-->
          </div>
           <div class=\"col-lg-12\">
      <div class=\"card card-outline-info\">
        <div class=\"card-header\">
          <div class=\"row mt-4 mb-4\">
           
          </div>
        </div>
        <div class=\"card-body\">
          ";
        // line 190
        echo "            <div class=\"form-body\">           

                
                <div class=\"\">
                  <h3 class=\"card-title\">Price variation
                    <span class=\"pull-right\">
                      <a href=\"javascript:;\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#variation\">Add new variant</a>
                    </span>
                  </h3>
                  <hr>
                  <div class=\"table-responsive\">
                    <table class=\"table table-hovered \"  id=\"priceVar\">
                      <thead>
                        <tr>
                          ";
        // line 205
        echo "                          <th>Variation Name </th>
                          <th>SKU</th>
                          <th>Barcode</th>
                          <th>MRP</th>
                          <th>Dis. Price</th>
                          <th>Membership. Price</th>
                          <th>Priority</th>
                          <th>Status</th> 
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody id=\"priceVariationTable\">
                        ";
        // line 217
        $context["count"] = 1;
        // line 218
        echo "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["variation"] ?? $this->getContext($context, "variation")));
        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
            // line 219
            echo "                        <tr>
                          
                          <td>
                            <input type=\"hidden\" name=\"id[]\" value=\"";
            // line 222
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "id", array()), "html", null, true);
            echo "\" class=\"0";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                               <input type=\"hidden\" name=\"unit[]\" value=\"";
            // line 223
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "subscription", array()), "html", null, true);
            echo "\" class=\"unit";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                            <input type=\"hidden\" name=\"variation[]\" value=\"";
            // line 224
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "variationName", array()), "html", null, true);
            echo "\" class=\"1";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                            <span class=\"var";
            // line 225
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "variationName", array()), "html", null, true);
            echo "</span> 
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"sku[]\" value=\"";
            // line 228
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "sku", array()), "html", null, true);
            echo "\" class=\"2";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\"><span class=\"sku";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "sku", array()), "html", null, true);
            echo "</span>
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"weight[]\" value=\"";
            // line 231
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "weight", array()), "html", null, true);
            echo "\"  class=\"w";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                            <input type=\"hidden\" name=\"barcode[]\" value=\"";
            // line 232
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "barcode", array()), "html", null, true);
            echo "\"  class=\"3";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\"><span class=\"barcode";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "barcode", array()), "html", null, true);
            echo "</span>
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"mrp[]\" value=\"";
            // line 235
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "mrp", array()), "html", null, true);
            echo "\"  class=\"4";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                            <span class=\"mrp";
            // line 236
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">";
            if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), "vars", array()), "value", array()) == "1")) {
                echo " ";
                $context["x"] = (($this->getAttribute($context["res"], "mrp", array()) * $this->getAttribute(($context["menuItem"] ?? $this->getContext($context, "menuItem")), "salePrice", array())) / 100);
                echo " ";
                $context["xx"] = (($context["x"] ?? $this->getContext($context, "x")) + $this->getAttribute(($context["menuItem"] ?? $this->getContext($context, "menuItem")), "salePrice", array()));
                echo " ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, twig_round(($context["xx"] ?? $this->getContext($context, "xx")), 2, "floor"), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["xx"] ?? $this->getContext($context, "xx")), 2, ".", ""), "html", null, true);
                }
                echo " ";
            } else {
                echo " ";
                $context["xx"] = $this->getAttribute($context["res"], "mrp", array());
                echo " ";
                echo twig_escape_filter($this->env, ($context["xx"] ?? $this->getContext($context, "xx")), "html", null, true);
                echo " ";
            }
            // line 237
            echo "                            </span>
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"price[]\" value=\"";
            // line 240
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "price", array()), "html", null, true);
            echo "\"  class=\"5";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                            <span class=\"price";
            // line 241
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                              ";
            // line 242
            if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), "vars", array()), "value", array()) == "1")) {
                echo " ";
                $context["resp"] = (($this->getAttribute($context["res"], "price", array()) * ($context["xx"] ?? $this->getContext($context, "xx"))) / 100);
                echo " ";
                $context["xs"] = (($this->getAttribute($context["res"], "price", array()) * ($context["resp"] ?? $this->getContext($context, "resp"))) / 100);
                echo " ";
                $context["r"] =  -(($context["resp"] ?? $this->getContext($context, "resp")) - ($context["xx"] ?? $this->getContext($context, "xx")));
                echo " ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, twig_round(($context["r"] ?? $this->getContext($context, "r")), 2, "floor"), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["r"] ?? $this->getContext($context, "r")), 2, ".", ""), "html", null, true);
                }
                echo " ";
            } else {
                $context["r"] = $this->getAttribute($context["res"], "price", array());
                echo "  ";
                echo twig_escape_filter($this->env, ($context["r"] ?? $this->getContext($context, "r")), "html", null, true);
                echo " ";
            }
            // line 243
            echo "                            </span>
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"membership[]\" value=\"";
            // line 246
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "membership_price", array()), "html", null, true);
            echo "\"  class=\"6";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\"><span class=\"membership";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">  ";
            if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), "vars", array()), "value", array()) == "1")) {
                echo " ";
                $context["resp"] = (($this->getAttribute($context["res"], "membership_price", array()) * ($context["xx"] ?? $this->getContext($context, "xx"))) / 100);
                echo " ";
                $context["xs"] = (($this->getAttribute($context["res"], "membership_price", array()) * ($context["resp"] ?? $this->getContext($context, "resp"))) / 100);
                echo " ";
                $context["member"] =  -(($context["resp"] ?? $this->getContext($context, "resp")) - ($context["xx"] ?? $this->getContext($context, "xx")));
                echo " ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, twig_round(($context["member"] ?? $this->getContext($context, "member")), 2, "floor"), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["member"] ?? $this->getContext($context, "member")), 2, ".", ""), "html", null, true);
                }
            } else {
                $context["member"] = $this->getAttribute($context["res"], "membership_price", array());
                echo "  ";
                echo twig_escape_filter($this->env, ($context["member"] ?? $this->getContext($context, "member")), "html", null, true);
                echo " ";
            }
            echo "</span>
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"priority[]\" value=\"";
            // line 249
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "priority", array()), "html", null, true);
            echo "\"  class=\"7";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\"><span class=\"priority";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "priority", array()), "html", null, true);
            echo "</span><input type=\"hidden\" name=\"min[]\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "minItem", array()), "html", null, true);
            echo "\"  class=\"8";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\"><input type=\"hidden\" name=\"max[]\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "maxItem", array()), "html", null, true);
            echo "\"  class=\"9";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\"><input type=\"hidden\" name=\"hsn[]\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "hsn", array()), "html", null, true);
            echo "\"  class=\"10";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\"><input type=\"hidden\" name=\"loyalty[]\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "loyalty", array()), "html", null, true);
            echo "\"  class=\"l";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                            <input type=\"hidden\" name=\"cost[]\" value=\"";
            // line 250
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "cost", array()), "html", null, true);
            echo "\"  class=\"cost";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                               <input type=\"hidden\" name=\"net_weight[]\" value=\"";
            // line 251
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "net_weight", array()), "html", null, true);
            echo "\"  class=\"net";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                          </td>
                          <td> 
                            <span class=\"stn";
            // line 254
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\"> ";
            if (($this->getAttribute($context["res"], "status", array()) == "0")) {
                echo " Active ";
            } else {
                echo " Inactive ";
            }
            echo "</span><input type=\"hidden\" name=\"status[]\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "status", array()), "html", null, true);
            echo "\"  class=\"11";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
                          </td>
                          <td>
                            <button type=\"button\"  class=\"btn btn-danger btn-sm\" data-toggle=\"modal\" data-target=\"#edit";
            // line 257
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\"><i class=\"fa fa-edit\"></i></button>&nbsp;<button type=\"button\" onclick=\"removeVariant(this)\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i></button>
                          </td>
                          <div id=\"edit";
            // line 259
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" class=\"modal\" role=\"dialog\">
                            <div class=\"modal-dialog modal-lg\">
                              <div class=\"modal-content\">
                                <div class=\"modal-header\">
                                  <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                                </div>
                                <div class=\"modal-body\">
                                  ";
            // line 267
            echo "                                      <div class=\"form-row\">

  <div class=\"form-group col-8\">
       <label for=\"variation_name\">Variation Name *</label>
  <input type=\"text\" class=\"form-control\" id=\"variation_names";
            // line 271
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"1 Kg\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "variationName", array()), "html", null, true);
            echo "\"> 
</div>
  <div class=\"form-group col-4\">
       <label for=\"variation_name\">Unit</label>
  <input type=\"text\" class=\"form-control\" id=\"unit";
            // line 275
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"1 Kg\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "subscription", array()), "html", null, true);
            echo "\"> 
</div>
</div>

  <div class=\"\"><br>
  <div class=\"form-row\">

  <div class=\"form-group col-4\">
    <label for=\"priority\">Priority</label>
    <input type=\"text\" class=\"form-control\" id=\"priority";
            // line 284
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"priority\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "priority", array()), "html", null, true);
            echo "\">
  </div>
      <div class=\"form-group col-4\">
    <label for=\"priority\">SKU </label>
    <input type=\"text\" class=\"form-control\" id=\"sku";
            // line 288
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"SKU\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "sku", array()), "html", null, true);
            echo "\">
  </div>
    <div class=\"form-group col-4\">
    <label for=\"priority\">HSN </label>
    <input type=\"text\" class=\"form-control\" id=\"hsn";
            // line 292
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"HSN\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "hsn", array()), "html", null, true);
            echo "\">
  </div>
  </div>
</div>
  <div class=\"form-row\">
  <div class=\"form-group col-md-3\">
    <label for=\"barcode\">barcode </label>
    <input type=\"text\" class=\"form-control\" id=\"barcode";
            // line 299
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"barcode\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "barcode", array()), "html", null, true);
            echo "\">
  </div>
     <div class=\"form-group col-md-3\">
    <label for=\"loyalty\">Loyalty </label>
    <input type=\"text\" class=\"form-control\" id=\"loyalty";
            // line 303
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"Loyalty Points\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "loyalty", array()), "html", null, true);
            echo "\">
  </div>
   <div class=\"form-group col-md-3\">
    <label for=\"barcode\">Gross Weight (in Kg) </label>
    <input type=\"text\" class=\"form-control\" id=\"weight";
            // line 307
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"weight\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "weight", array()), "html", null, true);
            echo "\">
  </div>
   <div class=\"form-group col-md-3\">
    <label for=\"barcode\">Net Weight (in Kg) </label>
    <input type=\"text\" class=\"form-control\" id=\"net_weight";
            // line 311
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"net weight\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "net_weight", array()), "html", null, true);
            echo "\">
  </div>
    
</div>
  <div class=\"form-row\">
     
  <div class=\"form-group col-md-4\">
    <label for=\"min\">Minimum Order Quantity </label>
    <input type=\"text\" class=\"form-control\" id=\"min";
            // line 319
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"minimum order Quantity\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "minItem", array()), "html", null, true);
            echo "\">
  </div>
  <div class=\"form-group col-md-4\">
    <label for=\"priority\">Maximum Order Quantity</label>
    <input type=\"text\" class=\"form-control\" id=\"max";
            // line 323
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"Maximum Order Quantity\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "maxItem", array()), "html", null, true);
            echo "\">
  </div>
   <div class=\"form-group col-md-4\">
    <label for=\"priority\">status</label>
    <select class=\"form-control\" id=\"status";
            // line 327
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">
      <option value='0' ";
            // line 328
            if (($this->getAttribute($context["res"], "status", array()) == "0")) {
                echo "selected ";
            }
            echo ">Active</option>
      <option value=\"2\" ";
            // line 329
            if (($this->getAttribute($context["res"], "status", array()) == "2")) {
                echo "selected ";
            }
            echo ">Inactive</option>
    </select>
  </div>
</div>
";
            // line 333
            if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), "vars", array()), "value", array()) == "1")) {
                // line 334
                echo "
  <div class=\"form-row\" style=\"display:none;\">
    ";
            } else {
                // line 337
                echo "      <div class=\"form-row sa\">
";
            }
            // line 338
            echo "  <div class=\"form-group col-md-4\">
    <label for=\"mrp\">Actual Price *</label>
    <input type=\"text\" class=\"form-control\" id=\"mrp";
            // line 340
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"mrp\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "mrp", array()), "html", null, true);
            echo "\">
  </div>
  <div class=\"form-group col-md-4\">
    <label for=\"price\">Discounted Price *</label>
    <input type=\"text\" class=\"form-control\" id=\"price";
            // line 344
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"price\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "price", array()), "html", null, true);
            echo "\">
  </div>
    <div class=\"form-group col-md-4\">
    <label for=\"price\">Cost Per Item</label>
    <input type=\"text\" class=\"form-control\" id=\"costprice";
            // line 348
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"Cost Per Price\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "cost", array()), "html", null, true);
            echo "\">
    ";
            // line 349
            if ((($context["r"] ?? $this->getContext($context, "r")) != 0)) {
                // line 350
                echo "          <small class=\"text\"><b>Margin : <span class=\"margin";
                echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                echo "\">";
                $context["margin"] = (((($context["r"] ?? $this->getContext($context, "r")) - $this->getAttribute($context["res"], "cost", array())) / ($context["r"] ?? $this->getContext($context, "r"))) * 100);
                echo " ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, twig_round(($context["margin"] ?? $this->getContext($context, "margin")), 2, "floor"), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["margin"] ?? $this->getContext($context, "margin")), 2, ".", ""), "html", null, true);
                }
                echo " </span>% | Profit : <span class=\"profit";
                echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                echo "\">";
                $context["profit"] = (($context["r"] ?? $this->getContext($context, "r")) - $this->getAttribute($context["res"], "cost", array()));
                echo " ";
                echo twig_escape_filter($this->env, twig_round(($context["profit"] ?? $this->getContext($context, "profit")), 2, "floor"), "html", null, true);
                echo "</span></b></small>
    ";
            } else {
                // line 352
                echo "          <small class=\"text\"><b>Margin : <span class=\"margin";
                echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                echo "\">0</span>% | Profit : <span class=\"profit";
                echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                echo "\">0</span></b></small>
    ";
            }
            // line 354
            echo "         
  </div>
  <div class=\"form-row\">
  <div class=\"form-group col-md-12\">
    <label for=\"price\">Membership Price *</label>
    <input type=\"text\" class=\"form-control\" id=\"membership";
            // line 359
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"price\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "membership_price", array()), "html", null, true);
            echo "\">
  </div>

</div>
      </div>

";
            // line 365
            if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), "vars", array()), "value", array()) == "1")) {
                // line 366
                echo "
   <div class=\"form-row fishprice\">
    ";
            } else {
                // line 369
                echo "   <div class=\"form-row fishprice\" style=\"display:none;\">

    ";
            }
            // line 371
            echo "  
      <div class=\"form-group col-md-6\">
    <label for=\"price\">MRP in Percentage (eg 40%) *</label>
    <input type=\"text\" class=\"form-control\" id=\"mrps";
            // line 374
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"price\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "mrp", array()), "html", null, true);
            echo "\">
  </div>
   <div class=\"form-group col-md-6\">
    <label for=\"price\">MRP </label>
    <input type=\"text\" class=\"form-control\" id=\"prs";
            // line 378
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"price\"  value=\"";
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round(($context["xx"] ?? $this->getContext($context, "xx")), 2, "floor"), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["xx"] ?? $this->getContext($context, "xx")), 2, ".", ""), "html", null, true);
            }
            echo "\">
  </div>

       <div class=\"form-group col-md-6\">
    <label for=\"price\">Discounted Price in Percentage (eg 40%) *</label>
    <input type=\"text\" class=\"form-control\" id=\"dprice";
            // line 383
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"price\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "price", array()), "html", null, true);
            echo "\">
  </div>
   <div class=\"form-group col-md-6\">
    <label for=\"price\">Discounted Price</label>
    <input type=\"text\" class=\"form-control\" id=\"dpr";
            // line 387
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"price\"  value=\"";
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round(($context["r"] ?? $this->getContext($context, "r")), 2, "floor"), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["r"] ?? $this->getContext($context, "r")), 2, ".", ""), "html", null, true);
            }
            echo "\">
  </div>
   <div class=\"form-group col-md-12\">
    <label for=\"price\">Cost Per Item</label>
    <input type=\"text\" class=\"form-control\" id=\"costpriceO";
            // line 391
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"Cost Per Price\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "cost", array()), "html", null, true);
            echo "\">
         ";
            // line 392
            if ((($context["r"] ?? $this->getContext($context, "r")) != 0)) {
                // line 393
                echo "          <small class=\"text\"><b>Margin : <span class=\"margin";
                echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                echo "\">";
                $context["margin"] = (((($context["r"] ?? $this->getContext($context, "r")) - $this->getAttribute($context["res"], "cost", array())) / ($context["r"] ?? $this->getContext($context, "r"))) * 100);
                echo " ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, twig_round(($context["margin"] ?? $this->getContext($context, "margin")), 2, "floor"), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["margin"] ?? $this->getContext($context, "margin")), 2, ".", ""), "html", null, true);
                }
                echo "</span>% | Profit : <span class=\"profit";
                echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                echo "\">";
                $context["profit"] = (($context["r"] ?? $this->getContext($context, "r")) - $this->getAttribute($context["res"], "cost", array()));
                echo " ";
                if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                    echo twig_escape_filter($this->env, twig_round(($context["profit"] ?? $this->getContext($context, "profit")), 2, "floor"), "html", null, true);
                } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["profit"] ?? $this->getContext($context, "profit")), 2, ".", ""), "html", null, true);
                }
                echo "</span></b></small>
    ";
            } else {
                // line 395
                echo "          <small class=\"text\"><b>Margin : <span class=\"margin";
                echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                echo "\">0</span>% | Profit : <span class=\"profit";
                echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                echo "\">0</span></b></small>
    ";
            }
            // line 397
            echo "  </div>
         <div class=\"form-group col-md-6\">
    <label for=\"price\">Membership Price in Percentage (eg 40%) *</label>
    <input type=\"text\" class=\"form-control\" id=\"dmprice";
            // line 400
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"Membership Price\"  value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "membership_price", array()), "html", null, true);
            echo "\">
  </div>
   <div class=\"form-group col-md-6\">
    <label for=\"price\">Membership Price</label>
    <input type=\"text\" class=\"form-control\" id=\"dmpr";
            // line 404
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" placeholder=\"Membership Price\"  value=\"";
            if ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 0)) {
                echo twig_escape_filter($this->env, twig_round(($context["member"] ?? $this->getContext($context, "member")), 2, "floor"), "html", null, true);
            } elseif ((($context["numberFormat"] ?? $this->getContext($context, "numberFormat")) == 1)) {
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["member"] ?? $this->getContext($context, "member")), 2, ".", ""), "html", null, true);
            }
            echo "\">
  </div>
</div>

<div class=\"form-group\">
    <label for=\"vimg\">Variation Image </label>
    <input type=\"file\" class=\"dropify\" name=\"image[]\" multiple>
  </div>
  
              ";
            // line 413
            if (twig_test_empty(($context["variation_images"] ?? $this->getContext($context, "variation_images")))) {
                // line 414
                echo "                  ";
            } else {
                // line 415
                echo "                  <div class=\"row\">

                  ";
                // line 417
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["variation_images"] ?? $this->getContext($context, "variation_images")));
                foreach ($context['_seq'] as $context["_key"] => $context["varimg"]) {
                    // line 418
                    echo "
                  ";
                    // line 419
                    if (twig_test_empty($context["varimg"])) {
                        // line 420
                        echo "                  ";
                    } else {
                        // line 421
                        echo "
                    ";
                        // line 422
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($context["varimg"]);
                        foreach ($context['_seq'] as $context["_key"] => $context["img"]) {
                            // line 423
                            echo "
                     ";
                            // line 424
                            if (twig_test_empty($context["img"])) {
                                // line 425
                                echo "                      ";
                            } else {
                                // line 426
                                echo "                  
                      ";
                                // line 427
                                if (($this->getAttribute($context["res"], "id", array()) == $this->getAttribute($context["img"], "ref", array()))) {
                                    // line 428
                                    echo "                        <div class=\"col-md-3 mb-2\" id=\"imgsec";
                                    echo twig_escape_filter($this->env, $this->getAttribute($context["img"], "id", array()), "html", null, true);
                                    echo "\">
                          <img src=\"";
                                    // line 429
                                    echo twig_escape_filter($this->env, $this->getAttribute($context["img"], "image", array()), "html", null, true);
                                    echo "\" class=\"img-responsive\" width=\"100\" height=\"100\">
                          <span class=\"img-close\" onclick=\"deleteimg(";
                                    // line 430
                                    echo twig_escape_filter($this->env, $this->getAttribute($context["img"], "id", array()), "html", null, true);
                                    echo ")\"><i class=\"fa fa-close\"></i></span>
                        </div>
                      ";
                                }
                                // line 433
                                echo "
                      ";
                            }
                            // line 435
                            echo "
                     ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['img'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 437
                        echo "
                    ";
                    }
                    // line 439
                    echo "                    
                  ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['varimg'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 441
                echo "
                  ";
                // line 452
                echo "                  </div>
                ";
            }
            // line 454
            echo "


<button type=\"button\" class=\"btn btn-primary\" id=\"addvar";
            // line 457
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\">Save</button>
";
            // line 459
            echo "    </div>
    <div class=\"modal-footer\">
      <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
    </div>
  </div>

</div>
</div>
<script type=\"text/javascript\">


\$('#costprice";
            // line 470
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').keyup(function(){
var price =\$('#costprice";
            // line 471
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var mrp =\$('#mrp";
            // line 472
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var discount =\$('#price";
            // line 473
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin";
            // line 477
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(Math.round(margin,2));
\$('.profit";
            // line 478
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(Math.round(profit,2));
});
\$('#price";
            // line 480
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').keyup(function(){
var price =\$('#costprice";
            // line 481
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var mrp =\$('#mrp";
            // line 482
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var discount =\$('#price";
            // line 483
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin";
            // line 487
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(Math.round(margin,2));
\$('.profit";
            // line 488
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(Math.round(profit,2));
});
\$('#costpriceO";
            // line 490
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').keyup(function(){
var price =\$('#costpriceO";
            // line 491
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var mrp =\$('#mrp";
            // line 492
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var discount =\$('#dpr";
            // line 493
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin";
            // line 497
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(Math.round(margin,2));
\$('.profit";
            // line 498
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(Math.round(profit,2));
});
\$('#mrps";
            // line 500
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').keyup(function(){
var x=\$('#pricess').val();
var price=\$('#mrps";
            // line 502
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) + eval(res);
\$('#prs";
            // line 506
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(fin);

});
\$('#dprice";
            // line 509
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').keyup(function(){
var x=\$('#prs";
            // line 510
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var price=\$('#dprice";
            // line 511
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) - eval(res);
\$('#dpr";
            // line 515
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(fin);
//start cost per price code
var prices =\$('#costpriceO";
            // line 517
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var mrp =\$('#mrp";
            // line 518
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var discount =\$('#dpr";
            // line 519
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var margin=(discount-prices)/discount*100;
// var margin =marg
var profit=discount-prices;
\$('.margin";
            // line 523
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(Math.round(margin,2));
\$('.profit";
            // line 524
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(Math.round(profit,2));
});
\$('#dmprice";
            // line 526
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').keyup(function(){
var x=\$('#prs";
            // line 527
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var price=\$('#dmprice";
            // line 528
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) - eval(res);
\$('#dmpr";
            // line 532
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(fin);
});
\$('#dpr";
            // line 534
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').keyup(function(){
var x=\$('#prs";
            // line 535
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var price=\$('#dpr";
            // line 536
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var res=eval(x) - eval(price);
var fin = res/eval(x)*100;
\$('#dprice";
            // line 539
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(fin);


//start cost per price code
var prices =\$('#costpriceO";
            // line 543
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var mrp =\$('#mrp";
            // line 544
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var discount =\$('#dpr";
            // line 545
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var margin=(discount-prices)/discount*100;
// var margin =marg
var profit=discount-prices;
\$('.margin";
            // line 549
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(Math.round(margin,2));
\$('.profit";
            // line 550
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(Math.round(profit,2));
});
\$('#dmpr";
            // line 552
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').keyup(function(){
var x=\$('#prs";
            // line 553
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var price=\$('#dmpr";
            // line 554
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var res=eval(x) - eval(price);
var fin = res/eval(x)*100;
// alert(fin);
\$('#dmprice";
            // line 558
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(fin);
});
\$('#prs";
            // line 560
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').keyup(function(){
var x=\$('#pricess').val();
var price=\$('#prs";
            // line 562
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var res=-(eval(x) - eval(price));
var fin = res/eval(x)*100;
\$('#mrps";
            // line 565
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(fin);
});
\$('#addvar";
            // line 567
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').click(function(){
var image=\$('#image');
var x=\$('#appbundle_menuitem_type').val();

if(x=='1')
{
var variation=\$('#variation_names";
            // line 573
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var mrp=\$('#mrps";
            // line 574
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var price=\$('#dprice";
            // line 575
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var membership=\$('#dmprice";
            // line 576
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
  var mrp1=\$('#prs";
            // line 577
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var price1=\$('#dpr";
            // line 578
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var membership1=\$('#dmpr";
            // line 579
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var cost=\$('#costpriceO";
            // line 580
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
}
else
{
  var variation=\$('#variation_names";
            // line 584
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
  var mrp=\$('#mrp";
            // line 585
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var price=\$('#price";
            // line 586
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var membership=\$('#membership";
            // line 587
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var membership1=\$('#membership";
            // line 588
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();

  var mrp1=\$('#mrp";
            // line 590
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var price1=\$('#price";
            // line 591
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var cost=\$('#costprice";
            // line 592
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();

}
var priority=\$('#priority";
            // line 595
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var barcode=\$('#barcode";
            // line 596
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var net=\$('#net_weight";
            // line 597
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var min=\$('#min";
            // line 598
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var max=\$('#max";
            // line 599
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var sku=\$('#sku";
            // line 600
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var hsn=\$('#hsn";
            // line 601
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var weight=\$('#weight";
            // line 602
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var status=\$('#status";
            // line 603
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var loyalty=\$('#loyalty";
            // line 604
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();
var unit=\$('#unit";
            // line 605
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val();

if(variation=='' || mrp == '' || cost == '')
{
  alert('please enter variation name or valid price!');
  return false;
}
var x=\$('#pricess').val();
if(status=='0')
{
  var statusd='Active';

}
else
{
    var statusd='Inactive';

}
// alert(membership);
\$('.var";
            // line 624
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(variation);
\$('.priority";
            // line 625
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(priority);
\$('.barcode";
            // line 626
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(barcode);
\$('.min";
            // line 627
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(min);
\$('.max";
            // line 628
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(max);
\$('.mrp";
            // line 629
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(mrp1);
\$('.price";
            // line 630
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(price1);
\$('.membership";
            // line 631
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(membership1);
\$('.sku";
            // line 632
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(sku);
\$('.hsn";
            // line 633
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(hsn);
\$('.stn";
            // line 634
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').html(statusd);

\$('.1";
            // line 636
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(variation);
\$('.cost";
            // line 637
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(cost);
\$('.net";
            // line 638
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(net);
\$('.2";
            // line 639
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(sku);
\$('.3";
            // line 640
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(barcode);
\$('.4";
            // line 641
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(mrp);
\$('.5";
            // line 642
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(price);
\$('.6";
            // line 643
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(membership);
\$('.7";
            // line 644
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(priority);
\$('.8";
            // line 645
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(min);
\$('.9";
            // line 646
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(max);
\$('.10";
            // line 647
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(hsn);
\$('.11";
            // line 648
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(status);
\$('.w";
            // line 649
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(weight);
\$('.l";
            // line 650
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(loyalty);
\$('.unit";
            // line 651
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').val(unit);

\$('#edit";
            // line 653
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "').fadeOut();

\$('.modal-backdrop').fadeOut();

\$('.modal-open').css({'overflow': 'visible'});
});
</script>
                                          ";
            // line 660
            $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
            // line 661
            echo "                                      </tr>
                                      ";
            // line 663
            echo "                                       ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 664
        echo "                                      </tbody>
                                  </table>
                              
                          </div>

</div>




                          ";
        // line 680
        echo "                  </div>
              </div>
          </div>
      </div>
      <!-- Row -->
      <!-- Modal -->
<div id=\"variation\" class=\"modal fade\" role=\"dialog\">
<div class=\"modal-dialog modal-lg\">

  <!-- Modal content-->
  <div class=\"modal-content\">
    <div class=\"modal-header\">
      <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
    </div>
    <div class=\"modal-body\">
     ";
        // line 696
        echo "
  <div class=\"form-row\">

   <div class=\"form-group col-8\" >

     <label for=\"variation_name \">Variation Name *</label>
    
   <input type=\"text\" class=\"form-control\" id=\"variation_names\" placeholder=\"1 Kg\"> 
</div>
   <div class=\"form-group col-4\" >

     <label for=\"variation_name \">Unit*</label>
    
   <input type=\"text\" class=\"form-control\" id=\"unit\" placeholder=\"1 Kg\"> 
</div>
    
</div>
  <div class=\"\"><br>
  <div class=\"form-row\">

  <div class=\"form-group col-4\">
    <label for=\"priority\">Priority</label>
    <input type=\"text\" class=\"form-control\" id=\"priority\" placeholder=\"priority\" value=\"0\">
  </div>
      <div class=\"form-group col-4\">
    <label for=\"priority\">SKU </label>
    <input type=\"text\" class=\"form-control\" id=\"sku\" placeholder=\"SKU\">
  </div>
     <div class=\"form-group col-4\">
    <label for=\"priority\">HSN </label>
    <input type=\"text\" class=\"form-control\" id=\"hsn\" placeholder=\"HSN\"  value=\"0\">
  </div>
  </div>
</div>

  <div class=\"form-row\">
  <div class=\"form-group col-md-3\">
    <label for=\"barcode\">barcode </label>
    <input type=\"text\" class=\"form-control\" id=\"barcode\" placeholder=\"barcode\"  value=\"0\">
  </div>
   <div class=\"form-group col-md-3\">
    <label for=\"weight\">Loyalty Points</label>
    <input type=\"text\" class=\"form-control\" id=\"loyalty\" placeholder=\"Loyalty Points\"  value=\"0\">
  </div>
   <div class=\"form-group col-md-3\">
    <label for=\"weight\">Gross Weight (in Kg) </label>
    <input type=\"text\" class=\"form-control\" id=\"weight\" placeholder=\"Gross weight\"  value=\"0\">
  </div>
   <div class=\"form-group col-md-3\">
    <label for=\"weight\">Net Weight (in Kg) </label>
    <input type=\"text\" class=\"form-control\" id=\"net_weight\" placeholder=\"net weight\"  value=\"0\">
  </div>
</div>
  <div class=\"form-row\">
  <div class=\"form-group col-md-4\">
    <label for=\"min\">Minimum Order Quantity </label>
    <input type=\"text\" class=\"form-control\" id=\"min\" placeholder=\"minimum order Quantity\" value=\"1\">
  </div>
  <div class=\"form-group col-md-4\">
    <label for=\"priority\">Maximum Order Quantity *</label>
    <input type=\"text\" class=\"form-control\" id=\"max\" placeholder=\"Maximum Order Quantity\" value=\"10\">
  </div>
  <div class=\"form-group col-md-4\">
    <label for=\"priority\">status</label>
    <select class=\"form-control\" id=\"status\">
      <option value='0'>Active</option>
      <option value=\"2\">Inactive</option>
    </select>
  </div>
</div>
";
        // line 766
        if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), "vars", array()), "value", array()) == "1")) {
            // line 767
            echo "
  <div class=\"form-row\" style=\"display:none;\">
    ";
        } else {
            // line 770
            echo "      <div class=\"form-row sa\">
";
        }
        // line 772
        echo "  <div class=\"form-group col-md-4\">
    <label for=\"mrp\">Actual Price *</label>
    <input type=\"text\" class=\"form-control \" id=\"mrp\" placeholder=\"Actual Price\" value=\"0\">
  </div>
  <div class=\"form-group col-md-4\">
    <label for=\"price\">Discounted Price *</label>
    <input type=\"text\" class=\"form-control \" id=\"price\" placeholder=\"price\" value=\"0\">
  </div>
         <div class=\"form-group col-md-4\">
    <label for=\"price\">Cost Per Item</label>
    <input type=\"text\" class=\"form-control\" id=\"costprice\" placeholder=\"Cost Per Price\"  value=\"0\">
          <small class=\"text\"><b>Margin : <span class=\"margin\"></span>% | Profit : <span class=\"profit\">10</span></b></small>
  </div>
      <div class=\"row\"> 
  <div class=\"form-group col-md-12\">
    <label for=\"price\">Membership Price *</label>
    <input type=\"text\" class=\"form-control \" id=\"membership\" placeholder=\"price\" value=\"0\"> 
  </div>
</div>

</div>

";
        // line 794
        if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), "vars", array()), "value", array()) == "1")) {
            // line 795
            echo "
   <div class=\"form-row fishprice\">
    ";
        } else {
            // line 798
            echo "   <div class=\"form-row fishprice\" style=\"display:none;\">

    ";
        }
        // line 801
        echo "  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Actual Price in Percentage (eg : 40%)</label>
    <input type=\"text\" class=\"form-control\" id=\"mrps\" placeholder=\"\">
  </div>
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Actual Price  </label>
    <input type=\"text\" class=\"form-control\" id=\"prs\" placeholder=\"\">
  </div>
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Discounted Price in Percentage (eg : 40%)</label>
    <input type=\"text\" class=\"form-control\" id=\"dprice\" placeholder=\"\">
  </div>
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Discounted Price  </label>
    <input type=\"text\" class=\"form-control\" id=\"dpr\" placeholder=\"\">
  </div>
     <div class=\"form-group col-md-12\">
    <label for=\"price\">Cost Per Item</label>
    <input type=\"text\" class=\"form-control\" id=\"costpriceO\" placeholder=\"Cost Per Price\"  value=\"0\">
          <small class=\"text\"><b>Margin : <span class=\"margin\"></span>% | Profit : <span class=\"profit\">10</span></b></small>
  </div>
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Membership Price in Percentage (eg : 40%)</label>
    <input type=\"text\" class=\"form-control\" id=\"dmprice\" placeholder=\"Membership price in %\">
  </div>
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Membership Price  </label>
    <input type=\"text\" class=\"form-control\" id=\"dmpr\" placeholder=\"membership price\">
  </div>
</div>
<div class=\"form-group\">
    <label for=\"vimg\">Variation Image </label>
    <input type=\"file\" class=\"dropify\" name=\"image[]\" multiple>
  </div>
<button type=\"button\" class=\"btn btn-primary\" id=\"addvar\">Add</button>
";
        // line 837
        echo "    </div>
    <div class=\"modal-footer\">
      <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
    </div>
  </div>

</div>
</div>
</div>


<div class=\"modal fade\" id=\"exampleModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
    <div class=\"modal-dialog\" role=\"document\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <h5 class=\"modal-title\" id=\"exampleModalLabel\">Upload (Allow Multiple)</h5>
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                </button>
            </div>
            <div class=\"modal-body\">
            <div class=\"custom-file-container\" data-upload-id=\"mySecondImage\">
    <label class=\"custom-file-container__image-clear\" > </label>
    <label class=\"custom-file-container__custom-file\" >
        <input type=\"file\" class=\"custom-file-container__custom-file__custom-file-input\" multiple>
        <input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"10485760\" />
        <span class=\"custom-file-container__custom-file__custom-file-control\"></span>
    </label>
    <div class=\"custom-file-container__image-preview\"></div>
</div> </div>
            <div class=\"modal-footer\">
                <button class=\"btn\" data-dismiss=\"modal\"><i class=\"flaticon-cancel-12\"></i> Discard</button>
                <button type=\"button\" class=\"btn btn-primary\">Save</button>
            </div>
        </div>
    </div>
</div>

        </div>
        <!--col-md-12 end-->

            <div class=\"col-md-3 mb-4\">
           <div class=\"h-100\">
                <div id=\"toggleAccordion\">
                     
                    
                  <div class=\"card right-sidebar-card\">
                      <div class=\"card-header\" id=\"headingOne1\">
                          <section class=\"mb-0 mt-0\">
                              <div role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#defaultAccordionOne\" aria-expanded=\"true\" aria-controls=\"defaultAccordionOne\">
                                  Category <div class=\"icons\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-down\"><polyline points=\"6 9 12 15 18 9\"></polyline></svg></div>
                              </div>
                          </section>
                      </div>
                      <div id=\"defaultAccordionOne\" class=\"collapse show\" aria-labelledby=\"headingOne1\" data-parent=\"#toggleAccordion\">
                          <div class=\"card-body right-sidebar-option\">
                            <div class=\"form-group\">
                        
                        <div id=\"toggleAccordion\">
                          <div style=\"Height:250px;overflow-x:auto\">
                            <div id=\"accordion\">
                              <div class=\" card-width\">
                              ";
        // line 898
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["category"] ?? $this->getContext($context, "category")));
        foreach ($context['_seq'] as $context["_key"] => $context["ca"]) {
            // line 899
            echo "                              
                                <div class=\"card-header\">
                                  <section class=\"mb-0 mt-0\">
                                    <a data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#a";
            // line 902
            echo twig_escape_filter($this->env, $this->getAttribute($context["ca"], "id", array()), "html", null, true);
            echo "\"> <p class=\"mb-2 cat-name\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ca"], "category_name", array()), "html", null, true);
            echo "</p></a>
                                  </section>
                                </div>
                                <div id=\"a";
            // line 905
            echo twig_escape_filter($this->env, $this->getAttribute($context["ca"], "id", array()), "html", null, true);
            echo "\" class=\"panel-collapse show\">
                                  <div class=\"\">
                                    ";
            // line 907
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["ca"], "SubCategory", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["sub"]) {
                // line 908
                echo "                                    ";
                if (($this->getAttribute($context["sub"], "nested", array()) != 0)) {
                    // line 909
                    echo "                                    <div>
                                      <b style=\"background: whitesmoke;padding:2px;width: 100% !important;color: #000;\"> ";
                    // line 910
                    echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "categoryName", array()), "html", null, true);
                    echo "</b>
                                    </div>
                                    ";
                    // line 912
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["sub"], "nested", array()));
                    foreach ($context['_seq'] as $context["_key"] => $context["sub"]) {
                        // line 913
                        echo "                                    <div >
                                      <label class=\"checkbox\"><input type=\"checkbox\" value=\"";
                        // line 914
                        echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
                        echo "\" name=\"category[]\" ";
                        if (twig_in_filter($this->getAttribute($context["sub"], "id", array()), ($context["arr"] ?? $this->getContext($context, "arr")))) {
                            echo " checked ";
                        }
                        // line 915
                        echo "                                        /> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "categoryName", array()), "html", null, true);
                        echo "
                                      </label>
                                    </div>
                                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sub'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 919
                    echo "                                    ";
                } else {
                    // line 920
                    echo "                                    <div >
                                      <label class=\"checkbox\"><input type=\"checkbox\" value=\"";
                    // line 921
                    echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "id", array()), "html", null, true);
                    echo "\" name=\"category[]\" ";
                    if (twig_in_filter($this->getAttribute($context["sub"], "id", array()), ($context["arr"] ?? $this->getContext($context, "arr")))) {
                        echo " checked ";
                    }
                    // line 922
                    echo "                                        /> ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["sub"], "categoryName", array()), "html", null, true);
                    echo "
                                      </label>
                                    </div>
                                    ";
                }
                // line 926
                echo "                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sub'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 927
            echo "                                  </div>
                                </div>
                              
                              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ca'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 931
        echo "                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                              <!-- <select class=\"form-control form-control-sm\" name=\"payment\">
                                  <option value=\"cod\">Cash On Delivery</option>
                                  <option value=\"sod\">Swipe On Delivery</option>
                                  <option value=\"online\">online Payment</option>
                              </select> -->
                          </div>
                      </div>
                  </div>
                  <div class=\"card right-sidebar-card\">
                      <div class=\"card-header\" id=\"headingTwo1\">
                          <section class=\"mb-0 mt-0\">
                              <div role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#defaultAccordionTwo\" aria-expanded=\"true\" aria-controls=\"defaultAccordionTwo\">
                                  Featued Image<div class=\"icons\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-down\"><polyline points=\"6 9 12 15 18 9\"></polyline></svg></div>
                              </div>
                          </section>
                      </div>
                      <div id=\"defaultAccordionTwo\" class=\"collapse show\" aria-labelledby=\"headingTwo1\" data-parent=\"#toggleAccordion\">
                          <div class=\"card-body right-sidebar-option\">
                                  <div class=\"row\">
                    ";
        // line 955
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/file.html.twig"));
        // line 956
        echo "                    <div class=\"form-group margin-bottom\">
                      <!-- ";
        // line 957
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "itemFeaturedImageFile", array()), 'label', array("label_attr" => array("class" => "m-l-20"), "label" => "Featured image"));
        echo " -->
                      ";
        // line 958
        $context["menuItemPic"] = "";
        // line 959
        echo "                      ";
        if (($this->getAttribute(($context["menuItem"] ?? $this->getContext($context, "menuItem")), "itemFeaturedImage", array()) != null)) {
            // line 960
            echo "                      ";
            $context["menuItemPic"] = ("/uploads/items/images/" . $this->getAttribute(($context["menuItem"] ?? $this->getContext($context, "menuItem")), "itemFeaturedImage", array()));
            // line 961
            echo "                      ";
        }
        // line 962
        echo "                      ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "itemFeaturedImageFile", array()), 'row', array("attr" => array("data-default-file" => ($context["menuItemPic"] ?? $this->getContext($context, "menuItemPic")))));
        echo "
                    </div>
                  </div>
                          </div>
                      </div>
                  </div>
                  <div class=\"card right-sidebar-card\">
                      <div class=\"card-header\" id=\"headingThree1\">
                          <section class=\"mb-0 mt-0\">
                          <div role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#defaultAccordionThree\" aria-expanded=\"false\" aria-controls=\"defaultAccordionThree\">
                              Select Brand<div class=\"icons\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-down\"><polyline points=\"6 9 12 15 18 9\"></polyline></svg></div>
                          </div>
                          </section>
                      </div>

                     
                      <div id=\"defaultAccordionThree\" class=\"collapse show\" aria-labelledby=\"headingThree1\" data-parent=\"#toggleAccordion\">
                          <div class=\"card-body right-sidebar-option\">
                             <div class=\"row form-row\">
                      <div class=\"col-md-12 form-group margin-bottom\">
                          <div class=\"form-group\">
                      
                      <select class=\"form-control form-control-sm select\" id=\"appbundle_menuitem_brand\" name=\"appbundle_menuitem[brand]\">
                        ";
        // line 985
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["brands"] ?? $this->getContext($context, "brands")));
        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
            // line 986
            echo "                        <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "id", array()), "html", null, true);
            echo "\" ";
            if (($this->getAttribute($context["res"], "id", array()) == $this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "vars", array()), "value", array()), "brand", array()))) {
                echo " selected ";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "categoryName", array()), "html", null, true);
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 988
        echo "                      </select>
                    </div>
                      </div>
                    </div>
                          </div>
                      </div>
                  </div>
                  <button type=\"submit\" class=\"btn btn-primary btn-sm btn-block mb-2 savefont\"> <i class=\"fa fa-check\"></i> Save</button>
                  
                </div>
            </div>
        </div>
          
                  </div>
      </div>
    </div>
                  ";
        // line 1018
        echo "
                       ";
        // line 1019
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'widget');
        echo "
                      ";
        // line 1020
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end', array("render_rest" => false));
        echo "
            

    
   ";
        
        $__internal_89d9a43e7034628477513b5744ccba7267e8ac1cfbc905bd8274e0739cf9054c->leave($__internal_89d9a43e7034628477513b5744ccba7267e8ac1cfbc905bd8274e0739cf9054c_prof);

    }

    // line 1027
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_7f03ca4021b40a776216671f2430f11a7e63a1606f5ac715bd248be5b74d35cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f03ca4021b40a776216671f2430f11a7e63a1606f5ac715bd248be5b74d35cc->enter($__internal_7f03ca4021b40a776216671f2430f11a7e63a1606f5ac715bd248be5b74d35cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 1028
        echo "
<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>
<script src=\"/assets/plugins/moment/moment.js\"></script>
<script src=\"/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js\"></script>
<script src=\"/assets/js/colorpicker.js\"></script>

<script>
\$('#appbundle_menuitem_type').change(function(){
var x=\$('#appbundle_menuitem_type').val();
if(x=='1')
{
  \$('.hides').hide().prop('required',false);
    \$('.fishprice').show();
\$('.sa').hide().prop('required',false);
}
else
{
    \$('.hides').show();
    \$('.fishprice').hide().prop('required',false);
\$('.sa').show();

}
});

\$('#costpriceO').keyup(function(){
var price =\$('#costpriceO').val();
var mrp =\$('#mrp').val();
var discount =\$('#dpr').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin').html(Math.round(margin,2));
\$('.profit').html(Math.round(profit,2));
});
\$('#costprice').keyup(function(){
var price =\$('#costprice').val();
var mrp =\$('#mrp').val();
var discount =\$('#price').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin').html(Math.round(margin,2));
\$('.profit').html(Math.round(profit,2));
});
\$('#price').keyup(function(){
var price =\$('#costprice').val();
var mrp =\$('#mrp').val();
var discount =\$('#price').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin').html(Math.round(margin,2));
\$('.profit').html(Math.round(profit,2));
});
\$('#mrps').keyup(function(){
var x=\$('#pricess').val();
var price=\$('#mrps').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) + eval(res);
\$('#prs').val(fin);
});
\$('#prs').keyup(function(){
var x=\$('#pricess').val();
var price=\$('#prs').val();
var res=-(eval(x) - eval(price));
var fin = res/eval(x)*100;

\$('#mrps').val(fin);
});
\$('#dprice').keyup(function(){
var x=\$('#prs').val();
var price=\$('#dprice').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) - eval(res);

\$('#dpr').val(fin);

//start cost per price code
var prices =\$('#costpriceO').val();
var mrp =\$('#mrp').val();
var discount =\$('#dpr').val();
var margin=(discount-prices)/discount*100;
// var margin =marg
var profit=discount-prices;
\$('.margin').html(Math.round(margin,2));
\$('.profit').html(Math.round(profit,2));

});
\$('#dpr').keyup(function(){
var x=\$('#prs').val();
var price=\$('#dpr').val();
var res=eval(x) - eval(price);
var fin = res/eval(x)*100;

\$('#dprice').val(fin);

//start cost per price code
var prices =\$('#costpriceO').val();
var mrp =\$('#mrp').val();
var discount =\$('#dpr').val();
var margin=(discount-prices)/discount*100;
// var margin =marg
var profit=discount-prices;
\$('.margin').html(Math.round(margin,2));
\$('.profit').html(Math.round(profit,2));
});
\$('#dmprice').keyup(function(){
var x=\$('#prs').val();
var price=\$('#dmprice').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) - eval(res);

\$('#dmpr').val(fin);

});
\$('#dmpr').keyup(function(){
var x=\$('#prs').val();
var price=\$('#dmpr').val();
var res=eval(x) - eval(price);
var fin = res/eval(x)*100;

\$('#dmprice').val(fin);
});
\$('#addvar').click(function(){

var image=\$('#image');
var x=\$('#appbundle_menuitem_type').val();
if(x=='1')
{
var variation=\$('#variation_names').val();
var mrp=\$('#mrps').val();
var price=\$('#dprice').val();
var membership=\$('#dmprice').val();
  var mrp1=\$('#prs').val();
var price1=\$('#dpr').val();
var cost =\$('#costpriceO').val();

}
else
{
  var variation=\$('#variation_names').val();
  var mrp=\$('#mrp').val();
var price=\$('#price').val();
  var mrp1=\$('#prs').val();
var price1=\$('#dpr').val();
var membership=\$('#membership').val();
var cost =\$('#costprice').val();

}
var priority=\$('#priority').val();
var barcode=\$('#barcode').val();
var weight=\$('#weight').val();
var net=\$('#net_weight').val();
var min=\$('#min').val();
var max=\$('#max').val();

var sku=\$('#sku').val();
var hsn=\$('#hsn').val();
var unit=\$('#unit').val();
var status=\$('#status').val();
var loyalty=\$('#loyalty').val();

if(status=='0')
{
  var statusd='Active';

}
else
{
    var statusd='Inactive';

}
if(variation=='' || mrp == '' || cost == '')
{
  alert('please enter variation name or valid price!');
  return false;
}
// var x = \$(\"#image\");
//      y = x.clone();
//  x.attr(\"id\", \"fileOld\");
//  y.insertAfter(\".n\");
// priceVariationTable
var x=\$('#pricess').val();
// var price=\$('#mrps').val();
// var res=eval(price) * eval(x) / 100;

// var fin=eval(x) + eval(res);
\$('#priceVariationTable').append('<tr><td><input type=\"hidden\" name=\"variation[]\" value=\"'+variation+'\"><input type=\"hidden\" name=\"unit[]\" value=\"'+unit+'\">'+variation+'</td><td><input type=\"hidden\" name=\"hsn[]\" value=\"'+hsn+'\"><input type=\"hidden\" name=\"sku[]\" value=\"'+sku+'\">'+sku+'</td><td><input type=\"hidden\" name=\"barcode[]\" value=\"'+barcode+'\"><input type=\"hidden\" name=\"weight[]\" value=\"'+weight+'\">'+barcode+'</td><td><input type=\"hidden\" name=\"mrp[]\" value=\"'+mrp+'\">'+mrp1+'</td><td><input type=\"hidden\" name=\"price[]\" value=\"'+price+'\">'+price1+'</td><td><input type=\"hidden\" name=\"membership[]\" value=\"'+membership+'\">'+membership+'</td><td><input type=\"hidden\" name=\"priority[]\" value=\"'+priority+'\">'+priority+'<input type=\"hidden\" name=\"min[]\" value=\"'+min+'\"><input type=\"hidden\" name=\"max[]\" value=\"'+max+'\"></td><td><input type=\"hidden\" name=\"loyalty[]\" value=\"'+loyalty+'\"><input type=\"hidden\" name=\"cost[]\" value=\"'+cost+'\"><input type=\"hidden\" name=\"net_weight[]\" value=\"'+net+'\"><input type=\"hidden\" name=\"status[]\" value=\"'+status+'\">'+statusd+'</td><td><button type=\"button\" onclick=\"removeVariant(this)\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i></button></td></tr>');
var variation=\$('#variation_name').val('');
var priority=\$('#priority').val('0');
var barcode=\$('#barcode').val('');

var mrp=\$('#mrp').val(0);
var price=\$('#price').val(0);
var membership=\$('#membership').val(0);
var sku=\$('#sku').val('');
});
      \$indexMesure=1;
      \$(document).ready(function() {



          \$collectionHolder = \$('#priceVariationTable');
  
          // count the current form inputs we have (e.g. 2), use that as the new
          // index when inserting a new item (e.g. 2)
          \$indexMesure = \$collectionHolder.find(':input').length;
          // Basic
          \$('.dropify').dropify();
          // Translated
          \$('.dropify-fr').dropify({
              messages: {
                  default: 'Glissez-déposez un fichier ici ou cliquez',
                  replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                  remove: 'Supprimer',
                  error: 'Désolé, le fichier trop volumineux'
              }
          });
  
          // Used events
          var drEvent = \$('#input-file-events').dropify();
  
          drEvent.on('dropify.beforeClear', function(event, element) {
              return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
          });
  
          drEvent.on('dropify.afterClear', function(event, element) {
              alert('File deleted');
          });
  
          drEvent.on('dropify.errors', function(event, element) {
              console.log('Has Errors');
          });
  
          var drDestroy = \$('#input-file-to-destroy').dropify();
          drDestroy = drDestroy.data('dropify')
          \$('#toggleDropify').on('click', function(e) {
              e.preventDefault();
              if (drDestroy.isDropified()) {
                  drDestroy.destroy();
              } else {
                  drDestroy.init();
              }
          })
      });

  function addNewPriceVeriation(){
      \$('#priceVar').attr('style','');
          // Get the ul that holds the collection of tags
      \$collectionHolder = \$('#priceVariationTable');

      var \$newFormLi=\"\";
      var \$holder=\$('div.prototype');
      // Get the data-prototype explained earlier
      var prototype = \$holder.data('prototype');

      // get the new index
      var index = \$indexMesure;
      \$indexMesure= \$indexMesure + 1;

      // Replace '__name__' in the prototype's HTML to
      // instead be a number based on how many items we have
      var newForm = prototype.replace(/__name__/g, index);

      // increase the index with one for the next item
      \$collectionHolder.data('index', index + 1);
      
      // Display the form in the page in an li, before the \"Add a tag\" link li
      \$newFormLi = \$('#priceVariationTable').prepend(newForm);

  }

  function removeVariant(obj){
      \$(obj).parent().parent().remove();
  }

    function deleteimg(id){
    var out ={'id':id}; 

    var r = confirm(\"Do you really want to delete this image?\");
    if (r == true) {

      \$.ajax({
          type: \"POST\",
          url: \"/api/app-manager/get-functionality/delete-variation-images/\"+id,
          data: out,
          success: function (res, dataType) {
            \$('#imgsec'+id).hide().prop('required',false);
          },
          error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert('Error : ' + errorThrown);
          }
      });
     
    } else {
      
    }

  }
</script>

<script>
  
      \$(document).ready(function() {
\$('.multipleSelect').fastselect();
});
      </script>
";
        
        $__internal_7f03ca4021b40a776216671f2430f11a7e63a1606f5ac715bd248be5b74d35cc->leave($__internal_7f03ca4021b40a776216671f2430f11a7e63a1606f5ac715bd248be5b74d35cc_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Restaurant:Menu/addNew.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  2055 => 1028,  2049 => 1027,  2037 => 1020,  2033 => 1019,  2030 => 1018,  2012 => 988,  1997 => 986,  1993 => 985,  1966 => 962,  1963 => 961,  1960 => 960,  1957 => 959,  1955 => 958,  1951 => 957,  1948 => 956,  1946 => 955,  1920 => 931,  1911 => 927,  1905 => 926,  1897 => 922,  1891 => 921,  1888 => 920,  1885 => 919,  1874 => 915,  1868 => 914,  1865 => 913,  1861 => 912,  1856 => 910,  1853 => 909,  1850 => 908,  1846 => 907,  1841 => 905,  1833 => 902,  1828 => 899,  1824 => 898,  1761 => 837,  1724 => 801,  1719 => 798,  1714 => 795,  1712 => 794,  1688 => 772,  1684 => 770,  1679 => 767,  1677 => 766,  1605 => 696,  1588 => 680,  1576 => 664,  1570 => 663,  1567 => 661,  1565 => 660,  1555 => 653,  1550 => 651,  1546 => 650,  1542 => 649,  1538 => 648,  1534 => 647,  1530 => 646,  1526 => 645,  1522 => 644,  1518 => 643,  1514 => 642,  1510 => 641,  1506 => 640,  1502 => 639,  1498 => 638,  1494 => 637,  1490 => 636,  1485 => 634,  1481 => 633,  1477 => 632,  1473 => 631,  1469 => 630,  1465 => 629,  1461 => 628,  1457 => 627,  1453 => 626,  1449 => 625,  1445 => 624,  1423 => 605,  1419 => 604,  1415 => 603,  1411 => 602,  1407 => 601,  1403 => 600,  1399 => 599,  1395 => 598,  1391 => 597,  1387 => 596,  1383 => 595,  1377 => 592,  1373 => 591,  1369 => 590,  1364 => 588,  1360 => 587,  1356 => 586,  1352 => 585,  1348 => 584,  1341 => 580,  1337 => 579,  1333 => 578,  1329 => 577,  1325 => 576,  1321 => 575,  1317 => 574,  1313 => 573,  1304 => 567,  1299 => 565,  1293 => 562,  1288 => 560,  1283 => 558,  1276 => 554,  1272 => 553,  1268 => 552,  1263 => 550,  1259 => 549,  1252 => 545,  1248 => 544,  1244 => 543,  1237 => 539,  1231 => 536,  1227 => 535,  1223 => 534,  1218 => 532,  1211 => 528,  1207 => 527,  1203 => 526,  1198 => 524,  1194 => 523,  1187 => 519,  1183 => 518,  1179 => 517,  1174 => 515,  1167 => 511,  1163 => 510,  1159 => 509,  1153 => 506,  1146 => 502,  1141 => 500,  1136 => 498,  1132 => 497,  1125 => 493,  1121 => 492,  1117 => 491,  1113 => 490,  1108 => 488,  1104 => 487,  1097 => 483,  1093 => 482,  1089 => 481,  1085 => 480,  1080 => 478,  1076 => 477,  1069 => 473,  1065 => 472,  1061 => 471,  1057 => 470,  1044 => 459,  1040 => 457,  1035 => 454,  1031 => 452,  1028 => 441,  1021 => 439,  1017 => 437,  1010 => 435,  1006 => 433,  1000 => 430,  996 => 429,  991 => 428,  989 => 427,  986 => 426,  983 => 425,  981 => 424,  978 => 423,  974 => 422,  971 => 421,  968 => 420,  966 => 419,  963 => 418,  959 => 417,  955 => 415,  952 => 414,  950 => 413,  932 => 404,  923 => 400,  918 => 397,  910 => 395,  886 => 393,  884 => 392,  878 => 391,  865 => 387,  856 => 383,  842 => 378,  833 => 374,  828 => 371,  823 => 369,  818 => 366,  816 => 365,  805 => 359,  798 => 354,  790 => 352,  770 => 350,  768 => 349,  762 => 348,  753 => 344,  744 => 340,  740 => 338,  736 => 337,  731 => 334,  729 => 333,  720 => 329,  714 => 328,  710 => 327,  701 => 323,  692 => 319,  679 => 311,  670 => 307,  661 => 303,  652 => 299,  640 => 292,  631 => 288,  622 => 284,  608 => 275,  599 => 271,  593 => 267,  583 => 259,  578 => 257,  562 => 254,  554 => 251,  548 => 250,  522 => 249,  492 => 246,  487 => 243,  466 => 242,  462 => 241,  456 => 240,  451 => 237,  429 => 236,  423 => 235,  411 => 232,  405 => 231,  393 => 228,  385 => 225,  379 => 224,  373 => 223,  367 => 222,  362 => 219,  357 => 218,  355 => 217,  341 => 205,  325 => 190,  300 => 167,  297 => 166,  293 => 164,  289 => 162,  287 => 161,  275 => 156,  265 => 149,  261 => 148,  250 => 140,  246 => 139,  240 => 136,  236 => 135,  228 => 130,  224 => 129,  217 => 125,  213 => 124,  205 => 119,  201 => 118,  190 => 110,  186 => 109,  178 => 104,  174 => 103,  166 => 98,  162 => 97,  155 => 93,  148 => 89,  144 => 88,  138 => 84,  136 => 83,  131 => 80,  110 => 61,  104 => 57,  98 => 56,  41 => 4,  35 => 3,  20 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/\"~ myExtend ~\"/base.html.twig\" %}

{% block styles %}


<style type=\"text/css\">
table#priceVar th {
  font-size:10px;
  text-transform:uppercase;
  font-weight:bold;
}
  [type=checkbox]:checked, [type=checkbox]:not(:checked){


  }
   .fstElement { font-size: 9px; }
          .fstToggleBtn { min-width: 16.5em; }

          .submitBtn { display: none; }

          .fstMultipleMode { display: block; }
          .fstMultipleMode .fstControls { width: 100%; }
          .right-sidebar-option {
      background: #F1F2F3;
}
.margin-bottom{
  margin-bottom: 0px !important;
}
.cat-name{
  font-size: 14px !important;
  font-weight: 800;
}

.img-close{
    position: absolute;
    top: -10px;
    background: #fb1e1e;
    padding: 5px;
    border-radius: 50%;
    width: 25px;
    height: 25px;
    text-align: center;
    line-height: 1;
    right: 61px;
    color: #fff;
  }

  .savefont{
    font-size: 16px;
    font-weight: 700;
  }

</style>
{% endblock %}

{% block body %}
  <!-- ============================================================== -->
  <!-- Start Page Content -->
  <!-- ============================================================== -->
  <!-- Row -->
{{ form_start(form) }}
<div class=\"\">
<div class=\"layout-px-spacing\">
  <div class=\"row layout-top-spacing\">
      <div class=\"col-md-9\">
        <div class=\"row\"><div class=\"col-md-12\">
        <div class=\"card card-outline-info\">
          <div class=\"card-header\">
            <div class=\"row mt-4 mb-4\">
              <div class=\"col-md-6\">
                <h4 class=\"pl-4\">Item Update Panel </h4>
              </div>
              <div class=\"col-md-6 pr-4\">
              </div>
            </div>
          </div>
        
        <div class=\"card-body\">
          {# {{ form_start(form) }} #}
            <div class=\"form-body\">
              <div class=\"row p-t-20\">
                <!--START-->
                {% form_theme form '@AppBundle/Themes/widget.html.twig' %}
                <div class=\"col-md-12\">
                  <div class=\"row\">
                    <div class=\"col-md-12\">
                      <div class=\"form-group\">
                        {{ form_label(form.itemName, \"Item Name\") }}
                        {{ form_row(form.itemName,{'attr':{'class':'form-control form-control-sm','placeholder':'Item Name'}}) }}
                      </div>
                    </div>
                  </div>
                  {% set arr= menuItem.category|split(',') %}  
                  <div class=\"row\">
                <div class=\"col-md-4\">
                  <div class=\"form-group\">
                    {{ form_label(form.type, \"Stock Type\") }}
                    {{ form_row(form.type,{'attr':{'class':'form-control form-control-sm'}}) }}
                  </div>  
                </div>
                <div class=\"col-md-4\">
                  <div class=\"form-group\">
                    {{ form_label(form.delivery, \"Delivery Duration\") }}
                    {{ form_row(form.delivery,{'attr':{'class':'form-control form-control-sm'}}) }}
                  </div>
                </div>
                  <div class=\"col-md-4\">
                    <div class=\"form-group\">
                      {{ form_label(form.vegType, \"Product Type\") }}
                      {{ form_row(form.vegType,{'attr':{'class':'form-control form-control-sm'}}) }}
                    </div>  
                  </div>
                </div>
                <div class=\"row\">
                  
                  <div class=\"col-md-4\">
                    <div class=\"form-group\">
                      {{ form_label(form.alert, \"Stock Notify\") }}
                      {{ form_row(form.alert,{'attr':{'class':'form-control form-control-sm','placeholder':'Stock Notify','value':'10',}}) }}
                    </div>
                  </div>
                  <div class=\"col-md-4\">
                    <div class=\"form-group\">
                      {{ form_label(form.duration, \"Return Duration\") }}
                      {{ form_row(form.duration,{'attr':{'class':'form-control form-control-sm'}}) }}
                    </div>
                  </div>
                  <div class=\"col-md-4\">
                    {{ form_label(form.salesTax, \"Gst\") }}
                    {{ form_row(form.salesTax,{'attr':{'class':'form-control form-control-sm','placeholder':'Tax'}}) }}
                  </div>
                </div>
                <div class=\"row\">
                  <div class=\"col-md-6\">
                    {{ form_label(form.itemDescription, \"Item description\") }}
                    {{ form_row(form.itemDescription,{'attr':{'class':'form-control form-control-sm','placeholder':'Doe'}}) }}
                  </div>
                  <div class=\"col-md-6\">
                    {{ form_label(form.itemShortDescription, \"Manufacturer description\") }}
                    {{ form_row(form.itemShortDescription,{'attr':{'class':'form-control form-control-sm','placeholder':'Doe'}}) }}
                  </div>
                  
                </div>  
                    <div class=\"row\">

                      <div class=\"col-md-4\">
                    <div class=\"form-group\">
                        {{ form_label(form.itemPriority, \"Item Priority\") }}
                        {{ form_row(form.itemPriority,{'attr':{'class':'form-control form-control-sm'}}) }}
                    </div>
                  </div>

                    <div class=\"col-md-4\">
                        <label class=\"d-block\">Item Active Status</label>
                        <label class=\"switch s-success mr-2 mt-2\"> 
                            <input type=\"checkbox\" {% if isActive == 1 %}checked {% endif %} class=\"form-control form-control-sm\" name=\"isActive\"  value=\"{{ isActive }}\">
                            <span class=\"slider round\"></span>
                        </label>
                    </div>

                      {% if form.type.vars.value == '1' %}
                      <div class=\"col-md-4 fishprice\" style=\"display:block\">
                        {% else %}
                        <div class=\"col-md-4 fishprice\" style=\"display:none\">
                          {% endif %}
                          <label for=\"pricess\">Price - 1 KG</label>
                          <div  class=\"form-group \"><input type=\"text\" id=\"pricess\" name=\"fishprice\" class=\"form-control form-control-sm\" placeholder=\"Price\" value=\"{{ menuItem.salePrice }}\">
                          </div>
                        </div>

                      </div>

                    </div>
                       <!--end-->
                  </div>
                </div>
              </div>
            </div>
            <!--end col-md-9 card-->
          </div>
           <div class=\"col-lg-12\">
      <div class=\"card card-outline-info\">
        <div class=\"card-header\">
          <div class=\"row mt-4 mb-4\">
           
          </div>
        </div>
        <div class=\"card-body\">
          {# {{ form_start(form) }} #}
            <div class=\"form-body\">           

                
                <div class=\"\">
                  <h3 class=\"card-title\">Price variation
                    <span class=\"pull-right\">
                      <a href=\"javascript:;\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#variation\">Add new variant</a>
                    </span>
                  </h3>
                  <hr>
                  <div class=\"table-responsive\">
                    <table class=\"table table-hovered \"  id=\"priceVar\">
                      <thead>
                        <tr>
                          {# <th>Image</th>  #}
                          <th>Variation Name </th>
                          <th>SKU</th>
                          <th>Barcode</th>
                          <th>MRP</th>
                          <th>Dis. Price</th>
                          <th>Membership. Price</th>
                          <th>Priority</th>
                          <th>Status</th> 
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody id=\"priceVariationTable\">
                        {% set count = 1 %}
                        {% for res in variation %}
                        <tr>
                          
                          <td>
                            <input type=\"hidden\" name=\"id[]\" value=\"{{ res.id }}\" class=\"0{{count}}\">
                               <input type=\"hidden\" name=\"unit[]\" value=\"{{ res.subscription }}\" class=\"unit{{count}}\">
                            <input type=\"hidden\" name=\"variation[]\" value=\"{{ res.variationName }}\" class=\"1{{count}}\">
                            <span class=\"var{{count}}\">{{ res.variationName }}</span> 
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"sku[]\" value=\"{{ res.sku }}\" class=\"2{{count}}\"><span class=\"sku{{count}}\">{{ res.sku }}</span>
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"weight[]\" value=\"{{ res.weight }}\"  class=\"w{{count}}\">
                            <input type=\"hidden\" name=\"barcode[]\" value=\"{{ res.barcode }}\"  class=\"3{{count}}\"><span class=\"barcode{{count}}\">{{ res.barcode }}</span>
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"mrp[]\" value=\"{{ res.mrp }}\"  class=\"4{{count}}\">
                            <span class=\"mrp{{count}}\">{% if form.type.vars.value == '1' %} {% set x= res.mrp * menuItem.salePrice / 100 %} {% set xx = x + menuItem.salePrice %} {% if numberFormat == 0 %}{{ xx|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ xx|number_format(2, '.', '') }}{% endif %} {% else %} {% set xx = res.mrp %} {{ xx }} {% endif %}
                            </span>
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"price[]\" value=\"{{ res.price }}\"  class=\"5{{count}}\">
                            <span class=\"price{{count}}\">
                              {% if form.type.vars.value == '1' %} {% set resp= res.price * xx / 100 %} {% set xs= res.price * resp / 100 %} {% set r = -(resp - xx) %} {% if numberFormat == 0 %}{{ r|round(2, 'floor')}}{% elseif numberFormat == 1 %}{{ r|number_format(2, '.', '') }}{% endif %} {% else %}{% set r = res.price %}  {{ r }} {% endif %}
                            </span>
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"membership[]\" value=\"{{ res.membership_price }}\"  class=\"6{{count}}\"><span class=\"membership{{count}}\">  {% if form.type.vars.value == '1' %} {% set resp= res.membership_price * xx / 100 %} {% set xs= res.membership_price * resp / 100 %} {% set member = -(resp - xx) %} {% if numberFormat == 0 %}{{ member|round(2, 'floor')}}{% elseif numberFormat == 1 %}{{ member|number_format(2, '.', '') }}{% endif %}{% else %}{% set member = res.membership_price %}  {{ member }} {% endif %}</span>
                          </td>
                          <td>
                            <input type=\"hidden\" name=\"priority[]\" value=\"{{ res.priority }}\"  class=\"7{{count}}\"><span class=\"priority{{count}}\">{{ res.priority }}</span><input type=\"hidden\" name=\"min[]\" value=\"{{ res.minItem }}\"  class=\"8{{count}}\"><input type=\"hidden\" name=\"max[]\" value=\"{{ res.maxItem }}\"  class=\"9{{count}}\"><input type=\"hidden\" name=\"hsn[]\" value=\"{{ res.hsn }}\"  class=\"10{{count}}\"><input type=\"hidden\" name=\"loyalty[]\" value=\"{{ res.loyalty }}\"  class=\"l{{count}}\">
                            <input type=\"hidden\" name=\"cost[]\" value=\"{{ res.cost }}\"  class=\"cost{{count}}\">
                               <input type=\"hidden\" name=\"net_weight[]\" value=\"{{ res.net_weight }}\"  class=\"net{{count}}\">
                          </td>
                          <td> 
                            <span class=\"stn{{ count }}\"> {% if res.status == '0' %} Active {% else %} Inactive {% endif %}</span><input type=\"hidden\" name=\"status[]\" value=\"{{ res.status }}\"  class=\"11{{count}}\">
                          </td>
                          <td>
                            <button type=\"button\"  class=\"btn btn-danger btn-sm\" data-toggle=\"modal\" data-target=\"#edit{{count}}\"><i class=\"fa fa-edit\"></i></button>&nbsp;<button type=\"button\" onclick=\"removeVariant(this)\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i></button>
                          </td>
                          <div id=\"edit{{count}}\" class=\"modal\" role=\"dialog\">
                            <div class=\"modal-dialog modal-lg\">
                              <div class=\"modal-content\">
                                <div class=\"modal-header\">
                                  <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                                </div>
                                <div class=\"modal-body\">
                                  {# <form> #}
                                      <div class=\"form-row\">

  <div class=\"form-group col-8\">
       <label for=\"variation_name\">Variation Name *</label>
  <input type=\"text\" class=\"form-control\" id=\"variation_names{{ count}}\" placeholder=\"1 Kg\" value=\"{{ res.variationName }}\"> 
</div>
  <div class=\"form-group col-4\">
       <label for=\"variation_name\">Unit</label>
  <input type=\"text\" class=\"form-control\" id=\"unit{{ count}}\" placeholder=\"1 Kg\" value=\"{{ res.subscription }}\"> 
</div>
</div>

  <div class=\"\"><br>
  <div class=\"form-row\">

  <div class=\"form-group col-4\">
    <label for=\"priority\">Priority</label>
    <input type=\"text\" class=\"form-control\" id=\"priority{{ count}}\" placeholder=\"priority\"  value=\"{{ res.priority }}\">
  </div>
      <div class=\"form-group col-4\">
    <label for=\"priority\">SKU </label>
    <input type=\"text\" class=\"form-control\" id=\"sku{{ count}}\" placeholder=\"SKU\"  value=\"{{ res.sku }}\">
  </div>
    <div class=\"form-group col-4\">
    <label for=\"priority\">HSN </label>
    <input type=\"text\" class=\"form-control\" id=\"hsn{{ count}}\" placeholder=\"HSN\"  value=\"{{ res.hsn }}\">
  </div>
  </div>
</div>
  <div class=\"form-row\">
  <div class=\"form-group col-md-3\">
    <label for=\"barcode\">barcode </label>
    <input type=\"text\" class=\"form-control\" id=\"barcode{{ count}}\" placeholder=\"barcode\"  value=\"{{ res.barcode }}\">
  </div>
     <div class=\"form-group col-md-3\">
    <label for=\"loyalty\">Loyalty </label>
    <input type=\"text\" class=\"form-control\" id=\"loyalty{{ count}}\" placeholder=\"Loyalty Points\"  value=\"{{ res.loyalty }}\">
  </div>
   <div class=\"form-group col-md-3\">
    <label for=\"barcode\">Gross Weight (in Kg) </label>
    <input type=\"text\" class=\"form-control\" id=\"weight{{ count}}\" placeholder=\"weight\"  value=\"{{ res.weight }}\">
  </div>
   <div class=\"form-group col-md-3\">
    <label for=\"barcode\">Net Weight (in Kg) </label>
    <input type=\"text\" class=\"form-control\" id=\"net_weight{{ count}}\" placeholder=\"net weight\"  value=\"{{ res.net_weight }}\">
  </div>
    
</div>
  <div class=\"form-row\">
     
  <div class=\"form-group col-md-4\">
    <label for=\"min\">Minimum Order Quantity </label>
    <input type=\"text\" class=\"form-control\" id=\"min{{ count}}\" placeholder=\"minimum order Quantity\" value=\"{{res.minItem}}\">
  </div>
  <div class=\"form-group col-md-4\">
    <label for=\"priority\">Maximum Order Quantity</label>
    <input type=\"text\" class=\"form-control\" id=\"max{{ count}}\" placeholder=\"Maximum Order Quantity\" value=\"{{res.maxItem}}\">
  </div>
   <div class=\"form-group col-md-4\">
    <label for=\"priority\">status</label>
    <select class=\"form-control\" id=\"status{{ count}}\">
      <option value='0' {% if res.status == '0' %}selected {% endif %}>Active</option>
      <option value=\"2\" {% if res.status == '2' %}selected {% endif %}>Inactive</option>
    </select>
  </div>
</div>
{% if form.type.vars.value == '1' %}

  <div class=\"form-row\" style=\"display:none;\">
    {% else %}
      <div class=\"form-row sa\">
{% endif %}  <div class=\"form-group col-md-4\">
    <label for=\"mrp\">Actual Price *</label>
    <input type=\"text\" class=\"form-control\" id=\"mrp{{ count}}\" placeholder=\"mrp\"  value=\"{{ res.mrp }}\">
  </div>
  <div class=\"form-group col-md-4\">
    <label for=\"price\">Discounted Price *</label>
    <input type=\"text\" class=\"form-control\" id=\"price{{ count}}\" placeholder=\"price\"  value=\"{{ res.price }}\">
  </div>
    <div class=\"form-group col-md-4\">
    <label for=\"price\">Cost Per Item</label>
    <input type=\"text\" class=\"form-control\" id=\"costprice{{ count}}\" placeholder=\"Cost Per Price\"  value=\"{{ res.cost }}\">
    {% if r != 0 %}
          <small class=\"text\"><b>Margin : <span class=\"margin{{ count }}\">{% set margin=(r-res.cost)/r*100 %} {% if numberFormat == 0 %}{{ margin|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ margin|number_format(2, '.', '') }}{% endif %} </span>% | Profit : <span class=\"profit{{ count }}\">{% set profit=r-res.cost %} {{ profit|round(2, 'floor') }}</span></b></small>
    {% else %}
          <small class=\"text\"><b>Margin : <span class=\"margin{{ count }}\">0</span>% | Profit : <span class=\"profit{{ count }}\">0</span></b></small>
    {% endif %}
         
  </div>
  <div class=\"form-row\">
  <div class=\"form-group col-md-12\">
    <label for=\"price\">Membership Price *</label>
    <input type=\"text\" class=\"form-control\" id=\"membership{{ count}}\" placeholder=\"price\"  value=\"{{ res.membership_price }}\">
  </div>

</div>
      </div>

{% if form.type.vars.value == '1' %}

   <div class=\"form-row fishprice\">
    {% else %}
   <div class=\"form-row fishprice\" style=\"display:none;\">

    {% endif %}  
      <div class=\"form-group col-md-6\">
    <label for=\"price\">MRP in Percentage (eg 40%) *</label>
    <input type=\"text\" class=\"form-control\" id=\"mrps{{ count}}\" placeholder=\"price\"  value=\"{{ res.mrp }}\">
  </div>
   <div class=\"form-group col-md-6\">
    <label for=\"price\">MRP </label>
    <input type=\"text\" class=\"form-control\" id=\"prs{{ count}}\" placeholder=\"price\"  value=\"{% if numberFormat == 0 %}{{ xx|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ xx|number_format(2, '.', '') }}{% endif %}\">
  </div>

       <div class=\"form-group col-md-6\">
    <label for=\"price\">Discounted Price in Percentage (eg 40%) *</label>
    <input type=\"text\" class=\"form-control\" id=\"dprice{{ count}}\" placeholder=\"price\"  value=\"{{ res.price }}\">
  </div>
   <div class=\"form-group col-md-6\">
    <label for=\"price\">Discounted Price</label>
    <input type=\"text\" class=\"form-control\" id=\"dpr{{ count}}\" placeholder=\"price\"  value=\"{% if numberFormat == 0 %}{{ r|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ r|number_format(2, '.', '') }}{% endif %}\">
  </div>
   <div class=\"form-group col-md-12\">
    <label for=\"price\">Cost Per Item</label>
    <input type=\"text\" class=\"form-control\" id=\"costpriceO{{ count}}\" placeholder=\"Cost Per Price\"  value=\"{{ res.cost }}\">
         {% if r != 0 %}
          <small class=\"text\"><b>Margin : <span class=\"margin{{ count }}\">{% set margin=(r-res.cost)/r*100 %} {% if numberFormat == 0 %}{{ margin|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ margin|number_format(2, '.', '') }}{% endif %}</span>% | Profit : <span class=\"profit{{ count }}\">{% set profit=r-res.cost %} {% if numberFormat == 0 %}{{ profit|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ profit|number_format(2, '.', '') }}{% endif %}</span></b></small>
    {% else %}
          <small class=\"text\"><b>Margin : <span class=\"margin{{ count }}\">0</span>% | Profit : <span class=\"profit{{ count }}\">0</span></b></small>
    {% endif %}
  </div>
         <div class=\"form-group col-md-6\">
    <label for=\"price\">Membership Price in Percentage (eg 40%) *</label>
    <input type=\"text\" class=\"form-control\" id=\"dmprice{{ count}}\" placeholder=\"Membership Price\"  value=\"{{ res.membership_price }}\">
  </div>
   <div class=\"form-group col-md-6\">
    <label for=\"price\">Membership Price</label>
    <input type=\"text\" class=\"form-control\" id=\"dmpr{{ count}}\" placeholder=\"Membership Price\"  value=\"{% if numberFormat == 0 %}{{ member|round(2, 'floor') }}{% elseif numberFormat == 1 %}{{ member|number_format(2, '.', '') }}{% endif %}\">
  </div>
</div>

<div class=\"form-group\">
    <label for=\"vimg\">Variation Image </label>
    <input type=\"file\" class=\"dropify\" name=\"image[]\" multiple>
  </div>
  
              {% if variation_images is empty %}
                  {% else %}
                  <div class=\"row\">

                  {% for varimg in variation_images %}

                  {% if varimg is empty %}
                  {% else %}

                    {% for img in varimg %}

                     {% if img is empty %}
                      {% else %}
                  
                      {% if res.id == img.ref %}
                        <div class=\"col-md-3 mb-2\" id=\"imgsec{{img.id}}\">
                          <img src=\"{{img.image}}\" class=\"img-responsive\" width=\"100\" height=\"100\">
                          <span class=\"img-close\" onclick=\"deleteimg({{img.id}})\"><i class=\"fa fa-close\"></i></span>
                        </div>
                      {% endif %}

                      {% endif %}

                     {% endfor %}

                    {% endif %}
                    
                  {% endfor %}

                  {# {% for varimg in variation_images %}
                     {% if varimg.image is defined %} 
                       {% if res.id == varimg.ref %}
                      <div class=\"col-md-3 mb-2\" id=\"imgsec{{varimg.id}}\">
                        <img src=\"{{varimg.image}}\" class=\"img-responsive\" width=\"100\" height=\"100\">
                        <span class=\"img-close\" onclick=\"deleteimg({{varimg.id}})\"><i class=\"fa fa-close\"></i></span>
                      </div>
                      {% endif %}
                    {% endif %}
                  {% endfor %} #}
                  </div>
                {% endif %}



<button type=\"button\" class=\"btn btn-primary\" id=\"addvar{{ count}}\">Save</button>
{# </form>  #}
    </div>
    <div class=\"modal-footer\">
      <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
    </div>
  </div>

</div>
</div>
<script type=\"text/javascript\">


\$('#costprice{{count}}').keyup(function(){
var price =\$('#costprice{{count}}').val();
var mrp =\$('#mrp{{count}}').val();
var discount =\$('#price{{count}}').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin{{count}}').html(Math.round(margin,2));
\$('.profit{{count}}').html(Math.round(profit,2));
});
\$('#price{{count}}').keyup(function(){
var price =\$('#costprice{{count}}').val();
var mrp =\$('#mrp{{count}}').val();
var discount =\$('#price{{count}}').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin{{count}}').html(Math.round(margin,2));
\$('.profit{{count}}').html(Math.round(profit,2));
});
\$('#costpriceO{{count}}').keyup(function(){
var price =\$('#costpriceO{{count}}').val();
var mrp =\$('#mrp{{count}}').val();
var discount =\$('#dpr{{count}}').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin{{count}}').html(Math.round(margin,2));
\$('.profit{{count}}').html(Math.round(profit,2));
});
\$('#mrps{{ count }}').keyup(function(){
var x=\$('#pricess').val();
var price=\$('#mrps{{ count }}').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) + eval(res);
\$('#prs{{ count }}').val(fin);

});
\$('#dprice{{ count }}').keyup(function(){
var x=\$('#prs{{ count }}').val();
var price=\$('#dprice{{ count }}').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) - eval(res);
\$('#dpr{{ count }}').val(fin);
//start cost per price code
var prices =\$('#costpriceO{{count}}').val();
var mrp =\$('#mrp{{count}}').val();
var discount =\$('#dpr{{count}}').val();
var margin=(discount-prices)/discount*100;
// var margin =marg
var profit=discount-prices;
\$('.margin{{count}}').html(Math.round(margin,2));
\$('.profit{{count}}').html(Math.round(profit,2));
});
\$('#dmprice{{ count }}').keyup(function(){
var x=\$('#prs{{ count }}').val();
var price=\$('#dmprice{{ count }}').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) - eval(res);
\$('#dmpr{{ count }}').val(fin);
});
\$('#dpr{{ count }}').keyup(function(){
var x=\$('#prs{{ count }}').val();
var price=\$('#dpr{{ count }}').val();
var res=eval(x) - eval(price);
var fin = res/eval(x)*100;
\$('#dprice{{ count }}').val(fin);


//start cost per price code
var prices =\$('#costpriceO{{count}}').val();
var mrp =\$('#mrp{{count}}').val();
var discount =\$('#dpr{{count}}').val();
var margin=(discount-prices)/discount*100;
// var margin =marg
var profit=discount-prices;
\$('.margin{{count}}').html(Math.round(margin,2));
\$('.profit{{count}}').html(Math.round(profit,2));
});
\$('#dmpr{{ count }}').keyup(function(){
var x=\$('#prs{{ count }}').val();
var price=\$('#dmpr{{ count }}').val();
var res=eval(x) - eval(price);
var fin = res/eval(x)*100;
// alert(fin);
\$('#dmprice{{ count }}').val(fin);
});
\$('#prs{{ count }}').keyup(function(){
var x=\$('#pricess').val();
var price=\$('#prs{{ count }}').val();
var res=-(eval(x) - eval(price));
var fin = res/eval(x)*100;
\$('#mrps{{ count }}').val(fin);
});
\$('#addvar{{ count}}').click(function(){
var image=\$('#image');
var x=\$('#appbundle_menuitem_type').val();

if(x=='1')
{
var variation=\$('#variation_names{{ count}}').val();
var mrp=\$('#mrps{{ count}}').val();
var price=\$('#dprice{{ count}}').val();
var membership=\$('#dmprice{{ count}}').val();
  var mrp1=\$('#prs{{ count}}').val();
var price1=\$('#dpr{{ count}}').val();
var membership1=\$('#dmpr{{ count}}').val();
var cost=\$('#costpriceO{{ count}}').val();
}
else
{
  var variation=\$('#variation_names{{ count}}').val();
  var mrp=\$('#mrp{{ count}}').val();
var price=\$('#price{{ count}}').val();
var membership=\$('#membership{{ count}}').val();
var membership1=\$('#membership{{ count}}').val();

  var mrp1=\$('#mrp{{ count}}').val();
var price1=\$('#price{{ count}}').val();
var cost=\$('#costprice{{ count}}').val();

}
var priority=\$('#priority{{ count}}').val();
var barcode=\$('#barcode{{ count}}').val();
var net=\$('#net_weight{{ count}}').val();
var min=\$('#min{{ count}}').val();
var max=\$('#max{{ count}}').val();
var sku=\$('#sku{{ count}}').val();
var hsn=\$('#hsn{{ count}}').val();
var weight=\$('#weight{{ count}}').val();
var status=\$('#status{{ count}}').val();
var loyalty=\$('#loyalty{{ count}}').val();
var unit=\$('#unit{{ count}}').val();

if(variation=='' || mrp == '' || cost == '')
{
  alert('please enter variation name or valid price!');
  return false;
}
var x=\$('#pricess').val();
if(status=='0')
{
  var statusd='Active';

}
else
{
    var statusd='Inactive';

}
// alert(membership);
\$('.var{{count}}').html(variation);
\$('.priority{{count}}').html(priority);
\$('.barcode{{count}}').html(barcode);
\$('.min{{count}}').html(min);
\$('.max{{count}}').html(max);
\$('.mrp{{count}}').html(mrp1);
\$('.price{{count}}').html(price1);
\$('.membership{{count}}').html(membership1);
\$('.sku{{count}}').html(sku);
\$('.hsn{{count}}').html(hsn);
\$('.stn{{count}}').html(statusd);

\$('.1{{count}}').val(variation);
\$('.cost{{count}}').val(cost);
\$('.net{{count}}').val(net);
\$('.2{{count}}').val(sku);
\$('.3{{count}}').val(barcode);
\$('.4{{count}}').val(mrp);
\$('.5{{count}}').val(price);
\$('.6{{count}}').val(membership);
\$('.7{{count}}').val(priority);
\$('.8{{count}}').val(min);
\$('.9{{count}}').val(max);
\$('.10{{count}}').val(hsn);
\$('.11{{count}}').val(status);
\$('.w{{count}}').val(weight);
\$('.l{{count}}').val(loyalty);
\$('.unit{{count}}').val(unit);

\$('#edit{{count}}').fadeOut();

\$('.modal-backdrop').fadeOut();

\$('.modal-open').css({'overflow': 'visible'});
});
</script>
                                          {% set count = count +1 %}
                                      </tr>
                                      {# </form> #}
                                       {% endfor %}
                                      </tbody>
                                  </table>
                              
                          </div>

</div>




                          {# <div class=\"form-actions\">
                              <button type=\"submit\" class=\"btn btn-success\"> <i class=\"fa fa-check\"></i> Save</button>
                              <button type=\"button\" class=\"btn btn-inverse\">Cancel</button>
                          </div>
                      {{ form_widget(form._token) }}
                      {{ form_end(form,{'render_rest':false}) }} #}
                  </div>
              </div>
          </div>
      </div>
      <!-- Row -->
      <!-- Modal -->
<div id=\"variation\" class=\"modal fade\" role=\"dialog\">
<div class=\"modal-dialog modal-lg\">

  <!-- Modal content-->
  <div class=\"modal-content\">
    <div class=\"modal-header\">
      <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
    </div>
    <div class=\"modal-body\">
     {# <form> #}

  <div class=\"form-row\">

   <div class=\"form-group col-8\" >

     <label for=\"variation_name \">Variation Name *</label>
    
   <input type=\"text\" class=\"form-control\" id=\"variation_names\" placeholder=\"1 Kg\"> 
</div>
   <div class=\"form-group col-4\" >

     <label for=\"variation_name \">Unit*</label>
    
   <input type=\"text\" class=\"form-control\" id=\"unit\" placeholder=\"1 Kg\"> 
</div>
    
</div>
  <div class=\"\"><br>
  <div class=\"form-row\">

  <div class=\"form-group col-4\">
    <label for=\"priority\">Priority</label>
    <input type=\"text\" class=\"form-control\" id=\"priority\" placeholder=\"priority\" value=\"0\">
  </div>
      <div class=\"form-group col-4\">
    <label for=\"priority\">SKU </label>
    <input type=\"text\" class=\"form-control\" id=\"sku\" placeholder=\"SKU\">
  </div>
     <div class=\"form-group col-4\">
    <label for=\"priority\">HSN </label>
    <input type=\"text\" class=\"form-control\" id=\"hsn\" placeholder=\"HSN\"  value=\"0\">
  </div>
  </div>
</div>

  <div class=\"form-row\">
  <div class=\"form-group col-md-3\">
    <label for=\"barcode\">barcode </label>
    <input type=\"text\" class=\"form-control\" id=\"barcode\" placeholder=\"barcode\"  value=\"0\">
  </div>
   <div class=\"form-group col-md-3\">
    <label for=\"weight\">Loyalty Points</label>
    <input type=\"text\" class=\"form-control\" id=\"loyalty\" placeholder=\"Loyalty Points\"  value=\"0\">
  </div>
   <div class=\"form-group col-md-3\">
    <label for=\"weight\">Gross Weight (in Kg) </label>
    <input type=\"text\" class=\"form-control\" id=\"weight\" placeholder=\"Gross weight\"  value=\"0\">
  </div>
   <div class=\"form-group col-md-3\">
    <label for=\"weight\">Net Weight (in Kg) </label>
    <input type=\"text\" class=\"form-control\" id=\"net_weight\" placeholder=\"net weight\"  value=\"0\">
  </div>
</div>
  <div class=\"form-row\">
  <div class=\"form-group col-md-4\">
    <label for=\"min\">Minimum Order Quantity </label>
    <input type=\"text\" class=\"form-control\" id=\"min\" placeholder=\"minimum order Quantity\" value=\"1\">
  </div>
  <div class=\"form-group col-md-4\">
    <label for=\"priority\">Maximum Order Quantity *</label>
    <input type=\"text\" class=\"form-control\" id=\"max\" placeholder=\"Maximum Order Quantity\" value=\"10\">
  </div>
  <div class=\"form-group col-md-4\">
    <label for=\"priority\">status</label>
    <select class=\"form-control\" id=\"status\">
      <option value='0'>Active</option>
      <option value=\"2\">Inactive</option>
    </select>
  </div>
</div>
{% if form.type.vars.value == '1' %}

  <div class=\"form-row\" style=\"display:none;\">
    {% else %}
      <div class=\"form-row sa\">
{% endif %}
  <div class=\"form-group col-md-4\">
    <label for=\"mrp\">Actual Price *</label>
    <input type=\"text\" class=\"form-control \" id=\"mrp\" placeholder=\"Actual Price\" value=\"0\">
  </div>
  <div class=\"form-group col-md-4\">
    <label for=\"price\">Discounted Price *</label>
    <input type=\"text\" class=\"form-control \" id=\"price\" placeholder=\"price\" value=\"0\">
  </div>
         <div class=\"form-group col-md-4\">
    <label for=\"price\">Cost Per Item</label>
    <input type=\"text\" class=\"form-control\" id=\"costprice\" placeholder=\"Cost Per Price\"  value=\"0\">
          <small class=\"text\"><b>Margin : <span class=\"margin\"></span>% | Profit : <span class=\"profit\">10</span></b></small>
  </div>
      <div class=\"row\"> 
  <div class=\"form-group col-md-12\">
    <label for=\"price\">Membership Price *</label>
    <input type=\"text\" class=\"form-control \" id=\"membership\" placeholder=\"price\" value=\"0\"> 
  </div>
</div>

</div>

{% if form.type.vars.value == '1' %}

   <div class=\"form-row fishprice\">
    {% else %}
   <div class=\"form-row fishprice\" style=\"display:none;\">

    {% endif %}
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Actual Price in Percentage (eg : 40%)</label>
    <input type=\"text\" class=\"form-control\" id=\"mrps\" placeholder=\"\">
  </div>
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Actual Price  </label>
    <input type=\"text\" class=\"form-control\" id=\"prs\" placeholder=\"\">
  </div>
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Discounted Price in Percentage (eg : 40%)</label>
    <input type=\"text\" class=\"form-control\" id=\"dprice\" placeholder=\"\">
  </div>
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Discounted Price  </label>
    <input type=\"text\" class=\"form-control\" id=\"dpr\" placeholder=\"\">
  </div>
     <div class=\"form-group col-md-12\">
    <label for=\"price\">Cost Per Item</label>
    <input type=\"text\" class=\"form-control\" id=\"costpriceO\" placeholder=\"Cost Per Price\"  value=\"0\">
          <small class=\"text\"><b>Margin : <span class=\"margin\"></span>% | Profit : <span class=\"profit\">10</span></b></small>
  </div>
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Membership Price in Percentage (eg : 40%)</label>
    <input type=\"text\" class=\"form-control\" id=\"dmprice\" placeholder=\"Membership price in %\">
  </div>
  <div class=\"form-group col-md-6\">
    <label for=\"mrp\">Membership Price  </label>
    <input type=\"text\" class=\"form-control\" id=\"dmpr\" placeholder=\"membership price\">
  </div>
</div>
<div class=\"form-group\">
    <label for=\"vimg\">Variation Image </label>
    <input type=\"file\" class=\"dropify\" name=\"image[]\" multiple>
  </div>
<button type=\"button\" class=\"btn btn-primary\" id=\"addvar\">Add</button>
{# </form>  #}
    </div>
    <div class=\"modal-footer\">
      <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
    </div>
  </div>

</div>
</div>
</div>


<div class=\"modal fade\" id=\"exampleModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
    <div class=\"modal-dialog\" role=\"document\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <h5 class=\"modal-title\" id=\"exampleModalLabel\">Upload (Allow Multiple)</h5>
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                </button>
            </div>
            <div class=\"modal-body\">
            <div class=\"custom-file-container\" data-upload-id=\"mySecondImage\">
    <label class=\"custom-file-container__image-clear\" > </label>
    <label class=\"custom-file-container__custom-file\" >
        <input type=\"file\" class=\"custom-file-container__custom-file__custom-file-input\" multiple>
        <input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"10485760\" />
        <span class=\"custom-file-container__custom-file__custom-file-control\"></span>
    </label>
    <div class=\"custom-file-container__image-preview\"></div>
</div> </div>
            <div class=\"modal-footer\">
                <button class=\"btn\" data-dismiss=\"modal\"><i class=\"flaticon-cancel-12\"></i> Discard</button>
                <button type=\"button\" class=\"btn btn-primary\">Save</button>
            </div>
        </div>
    </div>
</div>

        </div>
        <!--col-md-12 end-->

            <div class=\"col-md-3 mb-4\">
           <div class=\"h-100\">
                <div id=\"toggleAccordion\">
                     
                    
                  <div class=\"card right-sidebar-card\">
                      <div class=\"card-header\" id=\"headingOne1\">
                          <section class=\"mb-0 mt-0\">
                              <div role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#defaultAccordionOne\" aria-expanded=\"true\" aria-controls=\"defaultAccordionOne\">
                                  Category <div class=\"icons\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-down\"><polyline points=\"6 9 12 15 18 9\"></polyline></svg></div>
                              </div>
                          </section>
                      </div>
                      <div id=\"defaultAccordionOne\" class=\"collapse show\" aria-labelledby=\"headingOne1\" data-parent=\"#toggleAccordion\">
                          <div class=\"card-body right-sidebar-option\">
                            <div class=\"form-group\">
                        
                        <div id=\"toggleAccordion\">
                          <div style=\"Height:250px;overflow-x:auto\">
                            <div id=\"accordion\">
                              <div class=\" card-width\">
                              {% for ca in category %}
                              
                                <div class=\"card-header\">
                                  <section class=\"mb-0 mt-0\">
                                    <a data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#a{{ ca.id }}\"> <p class=\"mb-2 cat-name\">{{ ca.category_name }}</p></a>
                                  </section>
                                </div>
                                <div id=\"a{{ ca.id }}\" class=\"panel-collapse show\">
                                  <div class=\"\">
                                    {% for sub in ca.SubCategory %}
                                    {% if sub.nested != 0 %}
                                    <div>
                                      <b style=\"background: whitesmoke;padding:2px;width: 100% !important;color: #000;\"> {{ sub.categoryName }}</b>
                                    </div>
                                    {% for sub in sub.nested %}
                                    <div >
                                      <label class=\"checkbox\"><input type=\"checkbox\" value=\"{{ sub.id }}\" name=\"category[]\" {% if sub.id in arr %} checked {% endif %}
                                        /> {{ sub.categoryName }}
                                      </label>
                                    </div>
                                    {% endfor %}
                                    {% else %}
                                    <div >
                                      <label class=\"checkbox\"><input type=\"checkbox\" value=\"{{ sub.id }}\" name=\"category[]\" {% if sub.id in arr %} checked {% endif %}
                                        /> {{ sub.categoryName }}
                                      </label>
                                    </div>
                                    {% endif %}
                                    {% endfor %}
                                  </div>
                                </div>
                              
                              {% endfor %}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                              <!-- <select class=\"form-control form-control-sm\" name=\"payment\">
                                  <option value=\"cod\">Cash On Delivery</option>
                                  <option value=\"sod\">Swipe On Delivery</option>
                                  <option value=\"online\">online Payment</option>
                              </select> -->
                          </div>
                      </div>
                  </div>
                  <div class=\"card right-sidebar-card\">
                      <div class=\"card-header\" id=\"headingTwo1\">
                          <section class=\"mb-0 mt-0\">
                              <div role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#defaultAccordionTwo\" aria-expanded=\"true\" aria-controls=\"defaultAccordionTwo\">
                                  Featued Image<div class=\"icons\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-down\"><polyline points=\"6 9 12 15 18 9\"></polyline></svg></div>
                              </div>
                          </section>
                      </div>
                      <div id=\"defaultAccordionTwo\" class=\"collapse show\" aria-labelledby=\"headingTwo1\" data-parent=\"#toggleAccordion\">
                          <div class=\"card-body right-sidebar-option\">
                                  <div class=\"row\">
                    {% form_theme form '@AppBundle/Themes/file.html.twig' %}
                    <div class=\"form-group margin-bottom\">
                      <!-- {{ form_label(form.itemFeaturedImageFile, \"Featured image\",{'label_attr':{'class':'m-l-20'}}) }} -->
                      {% set menuItemPic = \"\" %}
                      {% if menuItem.itemFeaturedImage != null %}
                      {% set menuItemPic = '/uploads/items/images/'~ menuItem.itemFeaturedImage %}
                      {% endif %}
                      {{ form_row(form.itemFeaturedImageFile,{'attr':{'data-default-file':menuItemPic}}) }}
                    </div>
                  </div>
                          </div>
                      </div>
                  </div>
                  <div class=\"card right-sidebar-card\">
                      <div class=\"card-header\" id=\"headingThree1\">
                          <section class=\"mb-0 mt-0\">
                          <div role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#defaultAccordionThree\" aria-expanded=\"false\" aria-controls=\"defaultAccordionThree\">
                              Select Brand<div class=\"icons\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-down\"><polyline points=\"6 9 12 15 18 9\"></polyline></svg></div>
                          </div>
                          </section>
                      </div>

                     
                      <div id=\"defaultAccordionThree\" class=\"collapse show\" aria-labelledby=\"headingThree1\" data-parent=\"#toggleAccordion\">
                          <div class=\"card-body right-sidebar-option\">
                             <div class=\"row form-row\">
                      <div class=\"col-md-12 form-group margin-bottom\">
                          <div class=\"form-group\">
                      
                      <select class=\"form-control form-control-sm select\" id=\"appbundle_menuitem_brand\" name=\"appbundle_menuitem[brand]\">
                        {% for res in brands  %}
                        <option value=\"{{ res.id }}\" {% if res.id == form.vars.value.brand  %} selected {% endif %}>{{ res.categoryName }}</option>
                        {% endfor %}
                      </select>
                    </div>
                      </div>
                    </div>
                          </div>
                      </div>
                  </div>
                  <button type=\"submit\" class=\"btn btn-primary btn-sm btn-block mb-2 savefont\"> <i class=\"fa fa-check\"></i> Save</button>
                  
                </div>
            </div>
        </div>
          
                  </div>
      </div>
    </div>
                  {# <div class=\"layout-px-spacing\">
                  <div class=\"col-md-12\">
                    <div class=\"card card-outline-info\">
                      <div class=\"card-body\">
                        <div class=\"form-actions\">
                            <button type=\"submit\" class=\"btn btn-success\"> <i class=\"fa fa-check\"></i> Save</button>
                            <button type=\"button\" onclick=\"window.history.back();\" class=\"btn btn-inverse\">Back</button>
                        </div>
                      </div>
                    </div>
                    </div>
                    </div>
                      {{ form_widget(form._token) }}
                      {{ form_end(form,{'render_rest':false}) }} #}

                       {{ form_widget(form._token) }}
                      {{ form_end(form,{'render_rest':false}) }}
            

    
   {% endblock %}


{% block scripts %}

<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>
<script src=\"/assets/plugins/moment/moment.js\"></script>
<script src=\"/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js\"></script>
<script src=\"/assets/js/colorpicker.js\"></script>

<script>
\$('#appbundle_menuitem_type').change(function(){
var x=\$('#appbundle_menuitem_type').val();
if(x=='1')
{
  \$('.hides').hide().prop('required',false);
    \$('.fishprice').show();
\$('.sa').hide().prop('required',false);
}
else
{
    \$('.hides').show();
    \$('.fishprice').hide().prop('required',false);
\$('.sa').show();

}
});

\$('#costpriceO').keyup(function(){
var price =\$('#costpriceO').val();
var mrp =\$('#mrp').val();
var discount =\$('#dpr').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin').html(Math.round(margin,2));
\$('.profit').html(Math.round(profit,2));
});
\$('#costprice').keyup(function(){
var price =\$('#costprice').val();
var mrp =\$('#mrp').val();
var discount =\$('#price').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin').html(Math.round(margin,2));
\$('.profit').html(Math.round(profit,2));
});
\$('#price').keyup(function(){
var price =\$('#costprice').val();
var mrp =\$('#mrp').val();
var discount =\$('#price').val();
var margin=(discount-price)/discount*100;
// var margin =marg
var profit=discount-price;
\$('.margin').html(Math.round(margin,2));
\$('.profit').html(Math.round(profit,2));
});
\$('#mrps').keyup(function(){
var x=\$('#pricess').val();
var price=\$('#mrps').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) + eval(res);
\$('#prs').val(fin);
});
\$('#prs').keyup(function(){
var x=\$('#pricess').val();
var price=\$('#prs').val();
var res=-(eval(x) - eval(price));
var fin = res/eval(x)*100;

\$('#mrps').val(fin);
});
\$('#dprice').keyup(function(){
var x=\$('#prs').val();
var price=\$('#dprice').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) - eval(res);

\$('#dpr').val(fin);

//start cost per price code
var prices =\$('#costpriceO').val();
var mrp =\$('#mrp').val();
var discount =\$('#dpr').val();
var margin=(discount-prices)/discount*100;
// var margin =marg
var profit=discount-prices;
\$('.margin').html(Math.round(margin,2));
\$('.profit').html(Math.round(profit,2));

});
\$('#dpr').keyup(function(){
var x=\$('#prs').val();
var price=\$('#dpr').val();
var res=eval(x) - eval(price);
var fin = res/eval(x)*100;

\$('#dprice').val(fin);

//start cost per price code
var prices =\$('#costpriceO').val();
var mrp =\$('#mrp').val();
var discount =\$('#dpr').val();
var margin=(discount-prices)/discount*100;
// var margin =marg
var profit=discount-prices;
\$('.margin').html(Math.round(margin,2));
\$('.profit').html(Math.round(profit,2));
});
\$('#dmprice').keyup(function(){
var x=\$('#prs').val();
var price=\$('#dmprice').val();
var res=eval(price) * eval(x) / 100;

var fin=eval(x) - eval(res);

\$('#dmpr').val(fin);

});
\$('#dmpr').keyup(function(){
var x=\$('#prs').val();
var price=\$('#dmpr').val();
var res=eval(x) - eval(price);
var fin = res/eval(x)*100;

\$('#dmprice').val(fin);
});
\$('#addvar').click(function(){

var image=\$('#image');
var x=\$('#appbundle_menuitem_type').val();
if(x=='1')
{
var variation=\$('#variation_names').val();
var mrp=\$('#mrps').val();
var price=\$('#dprice').val();
var membership=\$('#dmprice').val();
  var mrp1=\$('#prs').val();
var price1=\$('#dpr').val();
var cost =\$('#costpriceO').val();

}
else
{
  var variation=\$('#variation_names').val();
  var mrp=\$('#mrp').val();
var price=\$('#price').val();
  var mrp1=\$('#prs').val();
var price1=\$('#dpr').val();
var membership=\$('#membership').val();
var cost =\$('#costprice').val();

}
var priority=\$('#priority').val();
var barcode=\$('#barcode').val();
var weight=\$('#weight').val();
var net=\$('#net_weight').val();
var min=\$('#min').val();
var max=\$('#max').val();

var sku=\$('#sku').val();
var hsn=\$('#hsn').val();
var unit=\$('#unit').val();
var status=\$('#status').val();
var loyalty=\$('#loyalty').val();

if(status=='0')
{
  var statusd='Active';

}
else
{
    var statusd='Inactive';

}
if(variation=='' || mrp == '' || cost == '')
{
  alert('please enter variation name or valid price!');
  return false;
}
// var x = \$(\"#image\");
//      y = x.clone();
//  x.attr(\"id\", \"fileOld\");
//  y.insertAfter(\".n\");
// priceVariationTable
var x=\$('#pricess').val();
// var price=\$('#mrps').val();
// var res=eval(price) * eval(x) / 100;

// var fin=eval(x) + eval(res);
\$('#priceVariationTable').append('<tr><td><input type=\"hidden\" name=\"variation[]\" value=\"'+variation+'\"><input type=\"hidden\" name=\"unit[]\" value=\"'+unit+'\">'+variation+'</td><td><input type=\"hidden\" name=\"hsn[]\" value=\"'+hsn+'\"><input type=\"hidden\" name=\"sku[]\" value=\"'+sku+'\">'+sku+'</td><td><input type=\"hidden\" name=\"barcode[]\" value=\"'+barcode+'\"><input type=\"hidden\" name=\"weight[]\" value=\"'+weight+'\">'+barcode+'</td><td><input type=\"hidden\" name=\"mrp[]\" value=\"'+mrp+'\">'+mrp1+'</td><td><input type=\"hidden\" name=\"price[]\" value=\"'+price+'\">'+price1+'</td><td><input type=\"hidden\" name=\"membership[]\" value=\"'+membership+'\">'+membership+'</td><td><input type=\"hidden\" name=\"priority[]\" value=\"'+priority+'\">'+priority+'<input type=\"hidden\" name=\"min[]\" value=\"'+min+'\"><input type=\"hidden\" name=\"max[]\" value=\"'+max+'\"></td><td><input type=\"hidden\" name=\"loyalty[]\" value=\"'+loyalty+'\"><input type=\"hidden\" name=\"cost[]\" value=\"'+cost+'\"><input type=\"hidden\" name=\"net_weight[]\" value=\"'+net+'\"><input type=\"hidden\" name=\"status[]\" value=\"'+status+'\">'+statusd+'</td><td><button type=\"button\" onclick=\"removeVariant(this)\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i></button></td></tr>');
var variation=\$('#variation_name').val('');
var priority=\$('#priority').val('0');
var barcode=\$('#barcode').val('');

var mrp=\$('#mrp').val(0);
var price=\$('#price').val(0);
var membership=\$('#membership').val(0);
var sku=\$('#sku').val('');
});
      \$indexMesure=1;
      \$(document).ready(function() {



          \$collectionHolder = \$('#priceVariationTable');
  
          // count the current form inputs we have (e.g. 2), use that as the new
          // index when inserting a new item (e.g. 2)
          \$indexMesure = \$collectionHolder.find(':input').length;
          // Basic
          \$('.dropify').dropify();
          // Translated
          \$('.dropify-fr').dropify({
              messages: {
                  default: 'Glissez-déposez un fichier ici ou cliquez',
                  replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                  remove: 'Supprimer',
                  error: 'Désolé, le fichier trop volumineux'
              }
          });
  
          // Used events
          var drEvent = \$('#input-file-events').dropify();
  
          drEvent.on('dropify.beforeClear', function(event, element) {
              return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
          });
  
          drEvent.on('dropify.afterClear', function(event, element) {
              alert('File deleted');
          });
  
          drEvent.on('dropify.errors', function(event, element) {
              console.log('Has Errors');
          });
  
          var drDestroy = \$('#input-file-to-destroy').dropify();
          drDestroy = drDestroy.data('dropify')
          \$('#toggleDropify').on('click', function(e) {
              e.preventDefault();
              if (drDestroy.isDropified()) {
                  drDestroy.destroy();
              } else {
                  drDestroy.init();
              }
          })
      });

  function addNewPriceVeriation(){
      \$('#priceVar').attr('style','');
          // Get the ul that holds the collection of tags
      \$collectionHolder = \$('#priceVariationTable');

      var \$newFormLi=\"\";
      var \$holder=\$('div.prototype');
      // Get the data-prototype explained earlier
      var prototype = \$holder.data('prototype');

      // get the new index
      var index = \$indexMesure;
      \$indexMesure= \$indexMesure + 1;

      // Replace '__name__' in the prototype's HTML to
      // instead be a number based on how many items we have
      var newForm = prototype.replace(/__name__/g, index);

      // increase the index with one for the next item
      \$collectionHolder.data('index', index + 1);
      
      // Display the form in the page in an li, before the \"Add a tag\" link li
      \$newFormLi = \$('#priceVariationTable').prepend(newForm);

  }

  function removeVariant(obj){
      \$(obj).parent().parent().remove();
  }

    function deleteimg(id){
    var out ={'id':id}; 

    var r = confirm(\"Do you really want to delete this image?\");
    if (r == true) {

      \$.ajax({
          type: \"POST\",
          url: \"/api/app-manager/get-functionality/delete-variation-images/\"+id,
          data: out,
          success: function (res, dataType) {
            \$('#imgsec'+id).hide().prop('required',false);
          },
          error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert('Error : ' + errorThrown);
          }
      });
     
    } else {
      
    }

  }
</script>

<script>
  
      \$(document).ready(function() {
\$('.multipleSelect').fastselect();
});
      </script>
{% endblock %}", "AppBundle:Restaurant:Menu/addNew.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Restaurant/Menu/addNew.html.twig");
    }
}

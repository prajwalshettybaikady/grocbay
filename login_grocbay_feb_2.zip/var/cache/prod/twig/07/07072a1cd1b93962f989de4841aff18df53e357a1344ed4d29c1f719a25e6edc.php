<?php

/* AppBundle:Admin:Pages/slots.html.twig */
class __TwigTemplate_80c32e210050823ec014c6f82f202532f0be5c3e4a5de0f8f4c5f60b653ccdcc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/slots.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb2129815651ee61797ecdd56f8bc475a300854db006e2346331f6637c723742 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb2129815651ee61797ecdd56f8bc475a300854db006e2346331f6637c723742->enter($__internal_fb2129815651ee61797ecdd56f8bc475a300854db006e2346331f6637c723742_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/slots.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fb2129815651ee61797ecdd56f8bc475a300854db006e2346331f6637c723742->leave($__internal_fb2129815651ee61797ecdd56f8bc475a300854db006e2346331f6637c723742_prof);

    }

    // line 3
    public function block_styles($context, array $blocks = array())
    {
        $__internal_1b10ea4cb1fed1c9bacffa9ad314863661365894dbbebea15932a9cd9c195dab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b10ea4cb1fed1c9bacffa9ad314863661365894dbbebea15932a9cd9c195dab->enter($__internal_1b10ea4cb1fed1c9bacffa9ad314863661365894dbbebea15932a9cd9c195dab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 4
        echo "

";
        
        $__internal_1b10ea4cb1fed1c9bacffa9ad314863661365894dbbebea15932a9cd9c195dab->leave($__internal_1b10ea4cb1fed1c9bacffa9ad314863661365894dbbebea15932a9cd9c195dab_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_cdf48b839b77fd05258646ec115fcbe3a2e0a2d9c0b004a7941e5dfa1963803e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cdf48b839b77fd05258646ec115fcbe3a2e0a2d9c0b004a7941e5dfa1963803e->enter($__internal_cdf48b839b77fd05258646ec115fcbe3a2e0a2d9c0b004a7941e5dfa1963803e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
    <div class=\"row\">
            <div class=\"col-lg-12\">
                <div class=\"card card-outline-info\">
                    <div class=\"card-header\">
                        <h4 class=\"m-b-0 text-white\">Manage Delivery Slots | ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["location"] ?? $this->getContext($context, "location")));
        foreach ($context['_seq'] as $context["_key"] => $context["lo"]) {
            echo twig_escape_filter($this->env, $this->getAttribute($context["lo"], "title", array()), "html", null, true);
            echo "   ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['lo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</h4>
                    </div>
                    <div class=\"card-body\">
  <form action=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create_slot", array("id" => ($context["id"] ?? $this->getContext($context, "id")))), "html", null, true);
        echo "\" method=\"POST\">
    <table class=\"table\" id=\"addvar\">
      <tr>
        <th>Start Time</th>
        <th>End Time</th>
        <th>Order Per Slot</th>
        <th><button class=\"btn btn-primary btn-sm\" id=\"variationAdd\" type=\"button\">Add Timings</button></th>
      </tr>
    ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["da"]) {
            // line 29
            echo "
          <tr><th><select class=\"form-control\" value=\"\" name=\"start[]\" required>";
            // line 30
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["time"] ?? $this->getContext($context, "time")));
            foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
                echo "<option ";
                if (($context["t"] == $this->getAttribute($context["da"], "start", array()))) {
                    echo " selected ";
                }
                echo ">";
                echo twig_escape_filter($this->env, $context["t"], "html", null, true);
                echo "</option>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "</select></th><th><select class=\"form-control\"  placeholder=\"11-00 AM\" name=\"end[]\">";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["time"] ?? $this->getContext($context, "time")));
            foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
                echo "<option ";
                if (($context["t"] == $this->getAttribute($context["da"], "end", array()))) {
                    echo " selected ";
                }
                echo ">";
                echo twig_escape_filter($this->env, $context["t"], "html", null, true);
                echo "</option>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "</select></th><th><input type=\"number\" class=\"form-control\" placeholder=\"order per slot\"  name=\"slot[]\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "orders", array()), "html", null, true);
            echo "\"></th><td><a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td></tr>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['da'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "    </table>
 

  <button type=\"submit\" class=\"btn btn-primary\" style=\"float:right;\">update</button>
  <a href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delivery_slots", array("id" => ($context["id"] ?? $this->getContext($context, "id")))), "html", null, true);
        echo "\"class=\"btn btn-primary\" id=\"variationAdd\" type=\"button\"  style=\"float:right;margin-right:10px;\">Back</a>
</form>



                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
";
        
        $__internal_cdf48b839b77fd05258646ec115fcbe3a2e0a2d9c0b004a7941e5dfa1963803e->leave($__internal_cdf48b839b77fd05258646ec115fcbe3a2e0a2d9c0b004a7941e5dfa1963803e_prof);

    }

    // line 48
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_20b9484b741a6719b0f8e16ddb164b6093b4e9328ac8926cc2b492e24fe0db14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_20b9484b741a6719b0f8e16ddb164b6093b4e9328ac8926cc2b492e24fe0db14->enter($__internal_20b9484b741a6719b0f8e16ddb164b6093b4e9328ac8926cc2b492e24fe0db14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 49
        echo "
<script>

      \$(document).ready(function(){

        var count=0;
      \$('#variationAdd').click(function(){
// alert('add');
\$('#addvar').append('<tr><th><select class=\"form-control\" value=\"\" name=\"start[]\" required>";
        // line 57
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["time"] ?? $this->getContext($context, "time")));
        foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
            echo "<option>";
            echo twig_escape_filter($this->env, $context["t"], "html", null, true);
            echo "</option>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</select></th><th><select class=\"form-control\"  placeholder=\"11-00 AM\" name=\"end[]\" value=\"\">";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["time"] ?? $this->getContext($context, "time")));
        foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
            echo "<option>";
            echo twig_escape_filter($this->env, $context["t"], "html", null, true);
            echo "</option>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</select></th><th><input type=\"number\" class=\"form-control\" placeholder=\"order per slot\"  name=\"slot[]\"></th><td><a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td></tr>');

count++;
});

// console.log(items)
//       });

      });


       function removeVariant(obj){
// \$(this).attr(\"data-usr\" , '');

        \$(obj).parent().parent().remove();

    }
    function save(x,itemname,id,parent)
    {
var id=fixed(x,itemname,id,parent);

    }

     // PICK THE VALUES FROM EACH TEXTBOX WHEN \"SUBMIT\" BUTTON IS CLICKED.
   

    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });

    
        \$(\"input[type='checkbox']\").bootstrapSwitch();
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

";
        
        $__internal_20b9484b741a6719b0f8e16ddb164b6093b4e9328ac8926cc2b492e24fe0db14->leave($__internal_20b9484b741a6719b0f8e16ddb164b6093b4e9328ac8926cc2b492e24fe0db14_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/slots.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 57,  167 => 49,  161 => 48,  143 => 36,  137 => 32,  99 => 30,  96 => 29,  92 => 28,  81 => 20,  67 => 17,  57 => 9,  51 => 8,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}

{% block styles %}


{% endblock %}

{% block body %}
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
    <div class=\"row\">
            <div class=\"col-lg-12\">
                <div class=\"card card-outline-info\">
                    <div class=\"card-header\">
                        <h4 class=\"m-b-0 text-white\">Manage Delivery Slots | {% for lo in location %}{{ lo.title }}   {% endfor %}</h4>
                    </div>
                    <div class=\"card-body\">
  <form action=\"{{ path('create_slot',{'id':id})}}\" method=\"POST\">
    <table class=\"table\" id=\"addvar\">
      <tr>
        <th>Start Time</th>
        <th>End Time</th>
        <th>Order Per Slot</th>
        <th><button class=\"btn btn-primary btn-sm\" id=\"variationAdd\" type=\"button\">Add Timings</button></th>
      </tr>
    {% for da in data %}

          <tr><th><select class=\"form-control\" value=\"\" name=\"start[]\" required>{% for t in time %}<option {% if t == da.start %} selected {% endif %}>{{ t }}</option>{% endfor %}</select></th><th><select class=\"form-control\"  placeholder=\"11-00 AM\" name=\"end[]\">{% for t in time %}<option {% if t == da.end %} selected {% endif %}>{{ t }}</option>{% endfor %}</select></th><th><input type=\"number\" class=\"form-control\" placeholder=\"order per slot\"  name=\"slot[]\" value=\"{{ da.orders }}\"></th><td><a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td></tr>
      {% endfor %}
    </table>
 

  <button type=\"submit\" class=\"btn btn-primary\" style=\"float:right;\">update</button>
  <a href=\"{{ path('delivery_slots',{'id':id}) }}\"class=\"btn btn-primary\" id=\"variationAdd\" type=\"button\"  style=\"float:right;margin-right:10px;\">Back</a>
</form>



                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
{% endblock %}

{% block scripts %}

<script>

      \$(document).ready(function(){

        var count=0;
      \$('#variationAdd').click(function(){
// alert('add');
\$('#addvar').append('<tr><th><select class=\"form-control\" value=\"\" name=\"start[]\" required>{% for t in time %}<option>{{ t }}</option>{% endfor %}</select></th><th><select class=\"form-control\"  placeholder=\"11-00 AM\" name=\"end[]\" value=\"\">{% for t in time %}<option>{{ t }}</option>{% endfor %}</select></th><th><input type=\"number\" class=\"form-control\" placeholder=\"order per slot\"  name=\"slot[]\"></th><td><a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td></tr>');

count++;
});

// console.log(items)
//       });

      });


       function removeVariant(obj){
// \$(this).attr(\"data-usr\" , '');

        \$(obj).parent().parent().remove();

    }
    function save(x,itemname,id,parent)
    {
var id=fixed(x,itemname,id,parent);

    }

     // PICK THE VALUES FROM EACH TEXTBOX WHEN \"SUBMIT\" BUTTON IS CLICKED.
   

    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });

    
        \$(\"input[type='checkbox']\").bootstrapSwitch();
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

{% endblock %}", "AppBundle:Admin:Pages/slots.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/slots.html.twig");
    }
}

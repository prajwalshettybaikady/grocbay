<?php

/* AppBundle:Admin:Pages/adminForm.html.twig */
class __TwigTemplate_a2d5cc0d7c44178e63ca244be479bf64e071203669eb0723d591fa11044e498c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/adminForm.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce8a65c0d16a3ac3e9ec4c77d1c681c83a451c89d56341ab321bf7d4e3e0bc17 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce8a65c0d16a3ac3e9ec4c77d1c681c83a451c89d56341ab321bf7d4e3e0bc17->enter($__internal_ce8a65c0d16a3ac3e9ec4c77d1c681c83a451c89d56341ab321bf7d4e3e0bc17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/adminForm.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ce8a65c0d16a3ac3e9ec4c77d1c681c83a451c89d56341ab321bf7d4e3e0bc17->leave($__internal_ce8a65c0d16a3ac3e9ec4c77d1c681c83a451c89d56341ab321bf7d4e3e0bc17_prof);

    }

    // line 3
    public function block_styles($context, array $blocks = array())
    {
        $__internal_78b0f4d2b4ba00684790d19df83b509a85f3d962cea6055b608281ce3e21f92a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78b0f4d2b4ba00684790d19df83b509a85f3d962cea6055b608281ce3e21f92a->enter($__internal_78b0f4d2b4ba00684790d19df83b509a85f3d962cea6055b608281ce3e21f92a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 4
        echo "

<link href=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.css\" rel=\"stylesheet\">

";
        
        $__internal_78b0f4d2b4ba00684790d19df83b509a85f3d962cea6055b608281ce3e21f92a->leave($__internal_78b0f4d2b4ba00684790d19df83b509a85f3d962cea6055b608281ce3e21f92a_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_4508cd72cb138147a814b9363badcf122334f77b745c8fc6283fc7b8368e3539 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4508cd72cb138147a814b9363badcf122334f77b745c8fc6283fc7b8368e3539->enter($__internal_4508cd72cb138147a814b9363badcf122334f77b745c8fc6283fc7b8368e3539_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
    ";
        // line 16
        echo "    <div class=\"row\">
            <div class=\"col-lg-12\">
                <div class=\"card card-outline-info\">
                    <div class=\"card-header\">
                        <h4 class=\"m-b-0 text-white\">User Update Panel</h4>
                    </div>
                    <div class=\"card-body\">
                        ";
        // line 23
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
                            <div class=\"form-body\">
                                <h3 class=\"card-title\">Personal Info</h3>
                                <hr>
                                <div class=\"row p-t-20\">
                                    <!--div class=\"col-md-2\">
                                        <div class=\"row\">
                                            ";
        // line 30
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/file.html.twig"));
        // line 31
        echo "                                            <div class=\"form-group\">
                                                ";
        // line 32
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "imageFile", array()), 'label', array("label_attr" => array("class" => "m-l-20"), "label" => "Profile Picture"));
        echo "
                                                ";
        // line 33
        $context["userPic"] = "";
        // line 34
        echo "                                                ";
        if (($this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "userPic", array()) != null)) {
            // line 35
            echo "                                                    ";
            $context["userPic"] = ("/uploads/user/pictures/" . $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "userPic", array()));
            // line 36
            echo "                                                ";
        }
        // line 37
        echo "                                                ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "imageFile", array()), 'row', array("attr" => array("data-default-file" => ($context["userPic"] ?? $this->getContext($context, "userPic")))));
        echo "
                                            </div>
                                        </div>
                                    </div-->
                                    ";
        // line 41
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/widget.html.twig"));
        // line 42
        echo "                                    <div class=\"col-md-12\">
                                        <div class=\"row\">
                                            <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                    ";
        // line 46
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "firstName", array()), 'label', array("label" => "First Name"));
        echo "
                                                    ";
        // line 47
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "firstName", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "John")));
        echo "
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                    ";
        // line 53
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "lastName", array()), 'label', array("label" => "Last Name"));
        echo "
                                                    ";
        // line 54
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "lastName", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Doe")));
        echo "
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                    ";
        // line 60
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "mobileNumber", array()), 'label', array("label" => "Mobile Number"));
        echo "
                                                    ";
        // line 61
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "mobileNumber", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "9865321548")));
        echo "
                                                </div>
                                            </div>
                             
                                            <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                    ";
        // line 67
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "email", array()), 'label', array("label" => "Email"));
        echo "
                                                    ";
        // line 68
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "email", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "admin@domain.com")));
        echo "
                                                </div>
                                            </div>
                                             <div class=\"col-md-6\">
                                                    ";
        // line 72
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address", array()), 'label', array("label" => "Address"));
        echo "
                                                    ";
        // line 73
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "address", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Doe", "rows" => "1")));
        echo "
                                            </div>

                                            <!--/span-->
                                            <div class=\"col-md-6\">

                                                <div class=\"form-group\">
                                               ";
        // line 80
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "userType", array()), 'label', array("label" => "User Type"));
        echo "
                                                ";
        // line 81
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "userType", array()), 'row', array("attr" => array("class" => "form-control")));
        echo "  
                                                  
                                                </div>
                                            </div>
                                       

                                            <div class=\"col-md-6\">
                                                ";
        // line 88
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "userType", array()) == "root")) {
            // line 89
            echo "
                                                <div class=\"form-group\">
                                                    <label for=\"shop\" class=\"required\">Branch</label>
                                                    <div id=\"\" class=\"form-group \">
                                                        <select id=\"shop\" name=\"shop\" class=\"form-control\">
                                                            ";
            // line 94
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["shop"] ?? $this->getContext($context, "shop")));
            foreach ($context['_seq'] as $context["_key"] => $context["sh"]) {
                // line 95
                echo "                                                            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["sh"], "id", array()), "html", null, true);
                echo "\" ";
                if ((($context["branch"] ?? $this->getContext($context, "branch")) == $this->getAttribute($context["sh"], "id", array()))) {
                    echo " selected ";
                }
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["sh"], "restaurantName", array()), "html", null, true);
                echo "</option>
                                                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sh'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 97
            echo "                                                            </select>                                                  
                                                    </div>
                                                </div>
                                                ";
        }
        // line 101
        echo "                                            </div>
                                       
                                            ";
        // line 103
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "userType", array()) != "root")) {
            // line 104
            echo "                                                <div class=\"col-md-6\">

                                                <div class=\"form-group\">
                                                <div id=\"\" class=\"form-group \">
                                             <input type=\"hidden\" name=\"shop\" value=\"";
            // line 108
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "branch", array()), "html", null, true);
            echo "\">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                           ";
        }
        // line 114
        echo "
                                             <div class=\"col-md-6\">
                                                <label class=\"d-block\">User Active Status</label>
                                                <label class=\"switch s-success mr-2 mt-3\"> 
                                                    <input type=\"checkbox\" ";
        // line 118
        if ((($context["isActive"] ?? $this->getContext($context, "isActive")) == 1)) {
            echo "checked ";
        }
        echo " class=\"form-control form-control-sm\" name=\"isActive\"  value=\"";
        echo twig_escape_filter($this->env, ($context["isActive"] ?? $this->getContext($context, "isActive")), "html", null, true);
        echo "\">
                                                    <span class=\"slider round\"></span>
                                                </label>
                                            </div>
                                    </div>
                                </div>
                                </div>
                                <!--/row-->
                                <hr>
                               <h3>Security Password Reset <b>(Leave blank to avoid resetting.)</b></h3>
<br>
                                <div class=\"row\">
                                    <div class=\"col-md-6\">
                                        <div class=\"form-group\">
                                            ";
        // line 132
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "password", array()), "first", array()), 'label', array("label" => "Password"));
        echo "
                                            ";
        // line 133
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "password", array()), "first", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "******")));
        echo "
                                        </div>
                                    </div>
                                    <div class=\"col-md-6\">
                                        <div class=\"form-group\">
                                            ";
        // line 138
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "password", array()), "second", array()), 'label', array("label" => "Confirm Password"));
        echo "
                                            ";
        // line 139
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "password", array()), "second", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "******")));
        echo "
                                        </div>
                                    </div>
                                </div>
                            </div>
                                 <div class=\"form-actions\">
                                    <button type=\"submit\" class=\"btn btn-success\"> <i class=\"fa fa-check\"></i> Save</button>
                                </div>
                          
                        ";
        // line 148
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
                        ";
        // line 149
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'rest');
        echo "
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
";
        
        $__internal_4508cd72cb138147a814b9363badcf122334f77b745c8fc6283fc7b8368e3539->leave($__internal_4508cd72cb138147a814b9363badcf122334f77b745c8fc6283fc7b8368e3539_prof);

    }

    // line 158
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_ed846c35c3e0429ca8e4048b8ebfb6e0b2bfe0455879d7bae8ca8e288baba4d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed846c35c3e0429ca8e4048b8ebfb6e0b2bfe0455879d7bae8ca8e288baba4d2->enter($__internal_ed846c35c3e0429ca8e4048b8ebfb6e0b2bfe0455879d7bae8ca8e288baba4d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 159
        echo "
<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>

<script>
    
        \$(\"input[type='checkbox']\").bootstrapSwitch();
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

";
        
        $__internal_ed846c35c3e0429ca8e4048b8ebfb6e0b2bfe0455879d7bae8ca8e288baba4d2->leave($__internal_ed846c35c3e0429ca8e4048b8ebfb6e0b2bfe0455879d7bae8ca8e288baba4d2_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/adminForm.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  332 => 159,  326 => 158,  312 => 149,  308 => 148,  296 => 139,  292 => 138,  284 => 133,  280 => 132,  259 => 118,  253 => 114,  244 => 108,  238 => 104,  236 => 103,  232 => 101,  226 => 97,  211 => 95,  207 => 94,  200 => 89,  198 => 88,  188 => 81,  184 => 80,  174 => 73,  170 => 72,  163 => 68,  159 => 67,  150 => 61,  146 => 60,  137 => 54,  133 => 53,  124 => 47,  120 => 46,  114 => 42,  112 => 41,  104 => 37,  101 => 36,  98 => 35,  95 => 34,  93 => 33,  89 => 32,  86 => 31,  84 => 30,  74 => 23,  65 => 16,  59 => 11,  53 => 10,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}

{% block styles %}


<link href=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.css\" rel=\"stylesheet\">

{% endblock %}

{% block body %}
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
    {# {{ dump(msg) }} #}
    <div class=\"row\">
            <div class=\"col-lg-12\">
                <div class=\"card card-outline-info\">
                    <div class=\"card-header\">
                        <h4 class=\"m-b-0 text-white\">User Update Panel</h4>
                    </div>
                    <div class=\"card-body\">
                        {{ form_start(form) }}
                            <div class=\"form-body\">
                                <h3 class=\"card-title\">Personal Info</h3>
                                <hr>
                                <div class=\"row p-t-20\">
                                    <!--div class=\"col-md-2\">
                                        <div class=\"row\">
                                            {% form_theme form '@AppBundle/Themes/file.html.twig' %}
                                            <div class=\"form-group\">
                                                {{ form_label(form.imageFile, \"Profile Picture\",{'label_attr':{'class':'m-l-20'}}) }}
                                                {% set userPic = \"\" %}
                                                {% if user.userPic != null %}
                                                    {% set userPic = '/uploads/user/pictures/'~user.userPic %}
                                                {% endif %}
                                                {{ form_row(form.imageFile,{'attr':{'data-default-file':userPic}}) }}
                                            </div>
                                        </div>
                                    </div-->
                                    {% form_theme form '@AppBundle/Themes/widget.html.twig' %}
                                    <div class=\"col-md-12\">
                                        <div class=\"row\">
                                            <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                    {{ form_label(form.firstName, \"First Name\") }}
                                                    {{ form_row(form.firstName,{'attr':{'class':'form-control','placeholder':'John'}}) }}
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                    {{ form_label(form.lastName, \"Last Name\") }}
                                                    {{ form_row(form.lastName,{'attr':{'class':'form-control','placeholder':'Doe'}}) }}
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                    {{ form_label(form.mobileNumber, \"Mobile Number\") }}
                                                    {{ form_row(form.mobileNumber,{'attr':{'class':'form-control','placeholder':'9865321548'}}) }}
                                                </div>
                                            </div>
                             
                                            <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                    {{ form_label(form.email, \"Email\") }}
                                                    {{ form_row(form.email,{'attr':{'class':'form-control','placeholder':'admin@domain.com'}}) }}
                                                </div>
                                            </div>
                                             <div class=\"col-md-6\">
                                                    {{ form_label(form.address, \"Address\") }}
                                                    {{ form_row(form.address,{'attr':{'class':'form-control','placeholder':'Doe','rows':'1'}}) }}
                                            </div>

                                            <!--/span-->
                                            <div class=\"col-md-6\">

                                                <div class=\"form-group\">
                                               {{ form_label(form.userType, \"User Type\") }}
                                                {{ form_row(form.userType,{\"attr\":{\"class\":\"form-control\"}}) }}  
                                                  
                                                </div>
                                            </div>
                                       

                                            <div class=\"col-md-6\">
                                                {% if app.user.userType == 'root' %}

                                                <div class=\"form-group\">
                                                    <label for=\"shop\" class=\"required\">Branch</label>
                                                    <div id=\"\" class=\"form-group \">
                                                        <select id=\"shop\" name=\"shop\" class=\"form-control\">
                                                            {% for sh in shop %}
                                                            <option value=\"{{ sh.id}}\" {% if branch == sh.id %} selected {% endif %}>{{ sh.restaurantName}}</option>
                                                            {% endfor %}
                                                            </select>                                                  
                                                    </div>
                                                </div>
                                                {% endif %}
                                            </div>
                                       
                                            {% if app.user.userType != 'root' %}
                                                <div class=\"col-md-6\">

                                                <div class=\"form-group\">
                                                <div id=\"\" class=\"form-group \">
                                             <input type=\"hidden\" name=\"shop\" value=\"{{ app.user.branch }}\">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                           {% endif %}

                                             <div class=\"col-md-6\">
                                                <label class=\"d-block\">User Active Status</label>
                                                <label class=\"switch s-success mr-2 mt-3\"> 
                                                    <input type=\"checkbox\" {% if isActive == 1 %}checked {% endif %} class=\"form-control form-control-sm\" name=\"isActive\"  value=\"{{ isActive }}\">
                                                    <span class=\"slider round\"></span>
                                                </label>
                                            </div>
                                    </div>
                                </div>
                                </div>
                                <!--/row-->
                                <hr>
                               <h3>Security Password Reset <b>(Leave blank to avoid resetting.)</b></h3>
<br>
                                <div class=\"row\">
                                    <div class=\"col-md-6\">
                                        <div class=\"form-group\">
                                            {{ form_label(form.password.first, \"Password\") }}
                                            {{ form_row(form.password.first,{'attr':{'class':'form-control','placeholder':'******'}}) }}
                                        </div>
                                    </div>
                                    <div class=\"col-md-6\">
                                        <div class=\"form-group\">
                                            {{ form_label(form.password.second, \"Confirm Password\") }}
                                            {{ form_row(form.password.second,{'attr':{'class':'form-control','placeholder':'******'}}) }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                                 <div class=\"form-actions\">
                                    <button type=\"submit\" class=\"btn btn-success\"> <i class=\"fa fa-check\"></i> Save</button>
                                </div>
                          
                        {{ form_end(form) }}
                        {{ form_rest(form) }}
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
{% endblock %}


{% block scripts %}

<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>

<script>
    
        \$(\"input[type='checkbox']\").bootstrapSwitch();
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

{% endblock %}", "AppBundle:Admin:Pages/adminForm.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/adminForm.html.twig");
    }
}

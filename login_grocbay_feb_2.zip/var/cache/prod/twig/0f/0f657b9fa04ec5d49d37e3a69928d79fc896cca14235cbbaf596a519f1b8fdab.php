<?php

/* AppBundle:Admin:Stock/stockReports.html.twig */
class __TwigTemplate_8c40a63afa010c2ceded5a4822801bf49aac212a0d4c324afd61c298056138df extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((("@AppBundle/" . ($context["myExtend"] ?? $this->getContext($context, "myExtend"))) . "/base.html.twig"), "AppBundle:Admin:Stock/stockReports.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c693dc854763175db4c42f6cce2a522dbba86adf5842d7688c76e60ab18e8793 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c693dc854763175db4c42f6cce2a522dbba86adf5842d7688c76e60ab18e8793->enter($__internal_c693dc854763175db4c42f6cce2a522dbba86adf5842d7688c76e60ab18e8793_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Stock/stockReports.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c693dc854763175db4c42f6cce2a522dbba86adf5842d7688c76e60ab18e8793->leave($__internal_c693dc854763175db4c42f6cce2a522dbba86adf5842d7688c76e60ab18e8793_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_db938d430810cef7ed8f4eea44377f3d859e29f0fd5dcf0956051e976b1a158e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db938d430810cef7ed8f4eea44377f3d859e29f0fd5dcf0956051e976b1a158e->enter($__internal_db938d430810cef7ed8f4eea44377f3d859e29f0fd5dcf0956051e976b1a158e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "
<link href=\"/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css\" rel=\"stylesheet\">
";
        
        $__internal_db938d430810cef7ed8f4eea44377f3d859e29f0fd5dcf0956051e976b1a158e->leave($__internal_db938d430810cef7ed8f4eea44377f3d859e29f0fd5dcf0956051e976b1a158e_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_67d80f421bede25962e729d227c860209c7938f073b280de6510ca582107de16 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67d80f421bede25962e729d227c860209c7938f073b280de6510ca582107de16->enter($__internal_67d80f421bede25962e729d227c860209c7938f073b280de6510ca582107de16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "<div id=\"order-report-app\">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->


    
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">Stock Reports
                       
                    </h4>
                    ";
        // line 23
        echo "                </div>
                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                            <tr>
                                <td>#</td>
                                <td>Name </td>
                                    <td>Variation </td>
                                <td>Current Stock</td>
                                <td>status</td>
                                
                            </tr>
                        </thead>
                        ";
        // line 35
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["menu"] ?? $this->getContext($context, "menu")));
        foreach ($context['_seq'] as $context["_key"] => $context["st"]) {
            // line 36
            echo "                               
                                <tr>
                                 <td>";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "id", array()), "html", null, true);
            echo "</td>
                                 <td>
                                     
                                            <a href=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_edit_menu_item", array("id" => $this->getAttribute($context["st"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "itemName", array()), "html", null, true);
            echo "</a>
                                      
                                     
                                    </td>
                                       <td>
                                     
                                            <a href=\"";
            // line 47
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_edit_menu_item", array("id" => $this->getAttribute($context["st"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "variationName", array()), "html", null, true);
            echo "</a>
                                      
                                     
                                    </td>
                                    <td>";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute($context["st"], "stock", array()), "html", null, true);
            echo "</td>
                                    <td>
                                       ";
            // line 53
            if (($this->getAttribute($context["st"], "stock", array()) <= $this->getAttribute($context["st"], "alert", array()))) {
                // line 54
                echo "                                        <b style=\"color:red;\">Stock Getting Low</b>
                                         ";
            } else {
                // line 56
                echo "                                        <b style=\"color:red;\">In Stock</b>
                                       ";
            }
            // line 58
            echo "
                                    </td>
                                </tr>
                          
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['st'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 62
        echo "</tbody>

                    </table>
                </div>
                <div class=\"card-body collapse show\">
                    
                </div>
            </div>
        </div>
    </div>

";
        
        $__internal_67d80f421bede25962e729d227c860209c7938f073b280de6510ca582107de16->leave($__internal_67d80f421bede25962e729d227c860209c7938f073b280de6510ca582107de16_prof);

    }

    // line 75
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_094500f64b0419c4fbe331cdc092b9bc6156f1dec1754341743233ddc740240c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_094500f64b0419c4fbe331cdc092b9bc6156f1dec1754341743233ddc740240c->enter($__internal_094500f64b0419c4fbe331cdc092b9bc6156f1dec1754341743233ddc740240c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 76
        echo "<script src=\"/assets/plugins/moment/moment.js\"></script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script src=\"/assets/plugins/iCheck/icheck.min.js\"></script>
<script>
    \$(document).ready(function() {
 \$('#myTable').DataTable();
    });     
    </script>
";
        
        $__internal_094500f64b0419c4fbe331cdc092b9bc6156f1dec1754341743233ddc740240c->leave($__internal_094500f64b0419c4fbe331cdc092b9bc6156f1dec1754341743233ddc740240c_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Stock/stockReports.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  170 => 76,  164 => 75,  146 => 62,  136 => 58,  132 => 56,  128 => 54,  126 => 53,  121 => 51,  112 => 47,  101 => 41,  95 => 38,  91 => 36,  87 => 35,  73 => 23,  56 => 7,  50 => 6,  41 => 3,  35 => 2,  20 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/\"~ myExtend ~\"/base.html.twig\" %}
{% block styles %}

<link href=\"/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css\" rel=\"stylesheet\">
{% endblock %}
{% block body %}
<div id=\"order-report-app\">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->


    
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"card card-default\">
                <div class=\"card-header\">
                    <div class=\"card-actions\">
                        <a class=\"btn-minimize\" data-action=\"expand\"><i class=\"mdi mdi-arrow-expand\"></i></a>                    </div>
                    <h4 class=\"card-title m-b-0\">Stock Reports
                       
                    </h4>
                    {# {{ dump(stock) }} #}
                </div>
                    <table class=\"table table-hovered\" id=\"myTable\">
                        <thead>
                            <tr>
                                <td>#</td>
                                <td>Name </td>
                                    <td>Variation </td>
                                <td>Current Stock</td>
                                <td>status</td>
                                
                            </tr>
                        </thead>
                        {% for st in menu %}
                               
                                <tr>
                                 <td>{{ st.id }}</td>
                                 <td>
                                     
                                            <a href=\"{{ path('restaurant_edit_menu_item',{'id':st.id})}}\">{{ st.itemName }}</a>
                                      
                                     
                                    </td>
                                       <td>
                                     
                                            <a href=\"{{ path('restaurant_edit_menu_item',{'id':st.id})}}\">{{ st.variationName }}</a>
                                      
                                     
                                    </td>
                                    <td>{{ st.stock }}</td>
                                    <td>
                                       {% if st.stock <= st.alert %}
                                        <b style=\"color:red;\">Stock Getting Low</b>
                                         {% else %}
                                        <b style=\"color:red;\">In Stock</b>
                                       {% endif %}

                                    </td>
                                </tr>
                          
                            {% endfor %}</tbody>

                    </table>
                </div>
                <div class=\"card-body collapse show\">
                    
                </div>
            </div>
        </div>
    </div>

{% endblock %}

{% block scripts %}
<script src=\"/assets/plugins/moment/moment.js\"></script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script src=\"/assets/plugins/iCheck/icheck.min.js\"></script>
<script>
    \$(document).ready(function() {
 \$('#myTable').DataTable();
    });     
    </script>
{% endblock %}", "AppBundle:Admin:Stock/stockReports.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Stock/stockReports.html.twig");
    }
}

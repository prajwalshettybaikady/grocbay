<?php

/* AppBundle:Admin:Pages/newSlots.html.twig */
class __TwigTemplate_24ba3dd3177fdc69bd99485af81beea27bec30273c1236b8d4b46ca447f17f7e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/newSlots.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f6538fd613941412af4e414ad9da8598f08995eb315a7f67c13b61695ea3dd6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f6538fd613941412af4e414ad9da8598f08995eb315a7f67c13b61695ea3dd6->enter($__internal_9f6538fd613941412af4e414ad9da8598f08995eb315a7f67c13b61695ea3dd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/newSlots.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9f6538fd613941412af4e414ad9da8598f08995eb315a7f67c13b61695ea3dd6->leave($__internal_9f6538fd613941412af4e414ad9da8598f08995eb315a7f67c13b61695ea3dd6_prof);

    }

    // line 3
    public function block_styles($context, array $blocks = array())
    {
        $__internal_89aa11704dece617e4e9f5481d3733c59a2ac0f60ccbc491ca553e90f0b074bf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89aa11704dece617e4e9f5481d3733c59a2ac0f60ccbc491ca553e90f0b074bf->enter($__internal_89aa11704dece617e4e9f5481d3733c59a2ac0f60ccbc491ca553e90f0b074bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 4
        echo "

<link href=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.css\" rel=\"stylesheet\">
<link href=\"/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css\" rel=\"stylesheet\">
";
        
        $__internal_89aa11704dece617e4e9f5481d3733c59a2ac0f60ccbc491ca553e90f0b074bf->leave($__internal_89aa11704dece617e4e9f5481d3733c59a2ac0f60ccbc491ca553e90f0b074bf_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_70509f14d75678510524fdec1087436a2c8c1a0936ccc32e93ad0ea7f258d3b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70509f14d75678510524fdec1087436a2c8c1a0936ccc32e93ad0ea7f258d3b4->enter($__internal_70509f14d75678510524fdec1087436a2c8c1a0936ccc32e93ad0ea7f258d3b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
    <div class=\"row\">
            <div class=\"col-lg-12\">
                <div class=\"card card-outline-info\">
                    <div class=\"card-header\">
                        <h4 class=\"m-b-0 text-white\">Manage Delivery Slots | ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["location"] ?? $this->getContext($context, "location")));
        foreach ($context['_seq'] as $context["_key"] => $context["lo"]) {
            echo twig_escape_filter($this->env, $this->getAttribute($context["lo"], "title", array()), "html", null, true);
            echo "   ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['lo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "</h4>

                    </div>
                    <div class=\"card-body\">
                    <a href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("edit_slots", array("id" => ($context["id"] ?? $this->getContext($context, "id")))), "html", null, true);
        echo "\"class=\"btn btn-primary btn-sm\"  style=\"float:right;\">Add/edit Timings</a>
    <table class=\"table\" id=\"addvar\">
      <tr>
        <th>Start Time</th>
        <th>End Time</th>
        <th>Order Per Slot</th>
       
      </tr>
    ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["da"]) {
            // line 33
            echo "
          <tr>
<td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "start", array()), "html", null, true);
            echo "</td>
<td>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "end", array()), "html", null, true);
            echo "</td>
<td>";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "orders", array()), "html", null, true);
            echo "</td>


          </tr>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['da'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        echo "    </table>



<hr>
        <table class=\"table\" id=\"myTable\">
       <thead>
        <tr>
        <th>Date</th>
        <th>Time</th>
        <th>Action</th>        
        </tr>
        </thead>
        <tbody>
       ";
        // line 56
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["slot"] ?? $this->getContext($context, "slot")));
        foreach ($context['_seq'] as $context["_key"] => $context["slots"]) {
            echo "  
       ";
            // line 57
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["status"] ?? $this->getContext($context, "status")));
            foreach ($context['_seq'] as $context["_key"] => $context["st"]) {
                echo "   
       ";
                // line 58
                if (((($this->getAttribute($context["st"], "start", array()) == $this->getAttribute($context["slots"], "start", array())) && ($this->getAttribute($context["st"], "end", array()) == $this->getAttribute($context["slots"], "end", array()))) && ($this->getAttribute($context["st"], "date", array()) == $this->getAttribute($context["slots"], "date", array())))) {
                    // line 59
                    echo "     
<tr>
<td>";
                    // line 61
                    echo twig_escape_filter($this->env, $this->getAttribute($context["slots"], "date", array()), "html", null, true);
                    echo " </td>
<td>";
                    // line 62
                    echo twig_escape_filter($this->env, $this->getAttribute($context["slots"], "start", array()), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["slots"], "end", array()), "html", null, true);
                    echo "</td>
<td><a href=\"";
                    // line 63
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("unblock_slot", array("id" => $this->getAttribute($context["st"], "id", array()), "date" => $this->getAttribute($context["slots"], "date", array()), "area" => ($context["id"] ?? $this->getContext($context, "id")))), "html", null, true);
                    echo "\" class=\"btn btn-success btn-sm\">unblock</a></td>
</tr>
";
                } else {
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['st'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['slots'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo " ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["slot"] ?? $this->getContext($context, "slot")));
        foreach ($context['_seq'] as $context["_key"] => $context["slots"]) {
            echo "  

<tr>
<td>";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute($context["slots"], "date", array()), "html", null, true);
            echo "</td>
<td>";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($context["slots"], "start", array()), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["slots"], "end", array()), "html", null, true);
            echo "</td>
<td><a href=\"";
            // line 74
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("block_slot", array("id" => $this->getAttribute($context["slots"], "id", array()), "date" => $this->getAttribute($context["slots"], "date", array()), "area" => ($context["id"] ?? $this->getContext($context, "id")))), "html", null, true);
            echo "\" class=\"btn btn-danger btn-sm\">block</a></td>
</tr>

";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['slots'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 78
        echo "
</tbody>
           </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
";
        
        $__internal_70509f14d75678510524fdec1087436a2c8c1a0936ccc32e93ad0ea7f258d3b4->leave($__internal_70509f14d75678510524fdec1087436a2c8c1a0936ccc32e93ad0ea7f258d3b4_prof);

    }

    // line 88
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_41a56fc1e75711e97ead4fc0725d2db6d94f4c061f4dcf50d81c13a36952dc65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_41a56fc1e75711e97ead4fc0725d2db6d94f4c061f4dcf50d81c13a36952dc65->enter($__internal_41a56fc1e75711e97ead4fc0725d2db6d94f4c061f4dcf50d81c13a36952dc65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 89
        echo "
<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script src=\"/assets/plugins/moment/moment.js\"></script>

<script src=\"/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js\"></script>
<script>

      \$(document).ready(function(){

    \$('#xss').bootstrapMaterialDatePicker({ format : 'HH:mm', time: true, date: false });
        var count=0;
      \$('#variationAdd').click(function(){
// alert('add');
\$('#addvar').append('<tr><th><input type=\"text\" class=\"form-control\" placeholder=\"9-00 AM\" name=\"start[]\" required></th><th><input type=\"text\" class=\"form-control\"  placeholder=\"11-00 AM\" name=\"end[]\"></th><th><input type=\"number\" class=\"form-control\" placeholder=\"order per slot\"  name=\"slot[]\"></th><td><a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td></tr>');

count++;
});

// console.log(items)
//       });

      });


       function removeVariant(obj){
// \$(this).attr(\"data-usr\" , '');

        \$(obj).parent().parent().remove();

    }
    function save(x,itemname,id,parent)
    {
var id=fixed(x,itemname,id,parent);

    }

     // PICK THE VALUES FROM EACH TEXTBOX WHEN \"SUBMIT\" BUTTON IS CLICKED.
   

    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });

    
        \$(\"input[type='checkbox']\").bootstrapSwitch();
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

";
        
        $__internal_41a56fc1e75711e97ead4fc0725d2db6d94f4c061f4dcf50d81c13a36952dc65->leave($__internal_41a56fc1e75711e97ead4fc0725d2db6d94f4c061f4dcf50d81c13a36952dc65_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/newSlots.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  232 => 89,  226 => 88,  211 => 78,  201 => 74,  195 => 73,  191 => 72,  182 => 69,  167 => 63,  161 => 62,  157 => 61,  153 => 59,  151 => 58,  145 => 57,  139 => 56,  123 => 42,  112 => 37,  108 => 36,  104 => 35,  100 => 33,  96 => 32,  85 => 24,  79 => 20,  69 => 19,  59 => 11,  53 => 10,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}

{% block styles %}


<link href=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.css\" rel=\"stylesheet\">
<link href=\"/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css\" rel=\"stylesheet\">
{% endblock %}

{% block body %}
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
    <div class=\"row\">
            <div class=\"col-lg-12\">
                <div class=\"card card-outline-info\">
                    <div class=\"card-header\">
                        <h4 class=\"m-b-0 text-white\">Manage Delivery Slots | {% for lo in location %}{{ lo.title }}   {% endfor %}
</h4>

                    </div>
                    <div class=\"card-body\">
                    <a href=\"{{ path('edit_slots',{'id':id}) }}\"class=\"btn btn-primary btn-sm\"  style=\"float:right;\">Add/edit Timings</a>
    <table class=\"table\" id=\"addvar\">
      <tr>
        <th>Start Time</th>
        <th>End Time</th>
        <th>Order Per Slot</th>
       
      </tr>
    {% for da in data %}

          <tr>
<td>{{ da.start }}</td>
<td>{{ da.end }}</td>
<td>{{ da.orders }}</td>


          </tr>
      {% endfor %}
    </table>



<hr>
        <table class=\"table\" id=\"myTable\">
       <thead>
        <tr>
        <th>Date</th>
        <th>Time</th>
        <th>Action</th>        
        </tr>
        </thead>
        <tbody>
       {% for slots in slot %}  
       {% for st in status %}   
       {% if st.start == slots.start and st.end == slots.end  and st.date == slots.date %}
     
<tr>
<td>{{ slots.date }} </td>
<td>{{ slots.start }} - {{ slots.end }}</td>
<td><a href=\"{{ path('unblock_slot',{'id':st.id,'date':slots.date,'area':id}) }}\" class=\"btn btn-success btn-sm\">unblock</a></td>
</tr>
{% else %}
{% endif %}
{% endfor %}
{% endfor %}
 {% for slots in slot %}  

<tr>
<td>{{ slots.date }}</td>
<td>{{ slots.start }} - {{ slots.end }}</td>
<td><a href=\"{{ path('block_slot',{'id':slots.id,'date':slots.date,'area':id}) }}\" class=\"btn btn-danger btn-sm\">block</a></td>
</tr>

{% endfor %}

</tbody>
           </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
{% endblock %}

{% block scripts %}

<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script src=\"/assets/plugins/moment/moment.js\"></script>

<script src=\"/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js\"></script>
<script>

      \$(document).ready(function(){

    \$('#xss').bootstrapMaterialDatePicker({ format : 'HH:mm', time: true, date: false });
        var count=0;
      \$('#variationAdd').click(function(){
// alert('add');
\$('#addvar').append('<tr><th><input type=\"text\" class=\"form-control\" placeholder=\"9-00 AM\" name=\"start[]\" required></th><th><input type=\"text\" class=\"form-control\"  placeholder=\"11-00 AM\" name=\"end[]\"></th><th><input type=\"number\" class=\"form-control\" placeholder=\"order per slot\"  name=\"slot[]\"></th><td><a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td></tr>');

count++;
});

// console.log(items)
//       });

      });


       function removeVariant(obj){
// \$(this).attr(\"data-usr\" , '');

        \$(obj).parent().parent().remove();

    }
    function save(x,itemname,id,parent)
    {
var id=fixed(x,itemname,id,parent);

    }

     // PICK THE VALUES FROM EACH TEXTBOX WHEN \"SUBMIT\" BUTTON IS CLICKED.
   

    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });

    
        \$(\"input[type='checkbox']\").bootstrapSwitch();
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

{% endblock %}", "AppBundle:Admin:Pages/newSlots.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/newSlots.html.twig");
    }
}

<?php

/* AppBundle:Admin:Firebase/sendBulk.html.twig */
class __TwigTemplate_b618100359d93842ced51c4e92b9ec8c387aadfa309131ec73ee13eb76e69222 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Firebase/sendBulk.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4b3adbc3aaf102f1f501c4640ba1e4679ec9d213de15bf06e1476aecb0e12c1d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b3adbc3aaf102f1f501c4640ba1e4679ec9d213de15bf06e1476aecb0e12c1d->enter($__internal_4b3adbc3aaf102f1f501c4640ba1e4679ec9d213de15bf06e1476aecb0e12c1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Firebase/sendBulk.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4b3adbc3aaf102f1f501c4640ba1e4679ec9d213de15bf06e1476aecb0e12c1d->leave($__internal_4b3adbc3aaf102f1f501c4640ba1e4679ec9d213de15bf06e1476aecb0e12c1d_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_307b2a0a86f342ead9d29c8ea4aed4845fd176d41b12fe52d930f40a28544c7a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_307b2a0a86f342ead9d29c8ea4aed4845fd176d41b12fe52d930f40a28544c7a->enter($__internal_307b2a0a86f342ead9d29c8ea4aed4845fd176d41b12fe52d930f40a28544c7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked){
        position: relative;
        left: auto;
        opacity: 1;
    }
     .fstElement { font-size: 9px; }
            .fstToggleBtn { min-width: 16.5em; }

            .submitBtn { display: none; }

            .fstMultipleMode { display: block; }
            .fstMultipleMode .fstControls { width: 100%; }

</style>
    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">Send Push notification
                       
                    </h4>
                </div>
                <div class=\"card-body\">
<center><span  style=\"color: red;font-size: smaller;font-weight: 400;\">
</span></center>
<div class=\"row\">
<div class=\"col-6\">
</div>
<div class=\"col-6\">
 <form method=\"post\" action=\"";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("filter_notification_user");
        echo "\" style=\"float:right\">
  <div class=\"input-group mb-4\">
<select class=\"form-control\" name=\"type\">
                          <option value=\"all\" ";
        // line 36
        if ((($context["type"] ?? $this->getContext($context, "type")) == "all")) {
            echo "selected ";
        }
        echo ">All</option>
                          <option value=\"prime\" ";
        // line 37
        if ((($context["type"] ?? $this->getContext($context, "type")) == "prime")) {
            echo "selected ";
        }
        echo ">Prime User</option>
                          <option value=\"active\" ";
        // line 38
        if ((($context["type"] ?? $this->getContext($context, "type")) == "active")) {
            echo "selected ";
        }
        echo ">Active User</option>
                          <option value=\"new\" ";
        // line 39
        if ((($context["type"] ?? $this->getContext($context, "type")) == "new")) {
            echo "selected ";
        }
        echo ">New User</option>
                            
                          </select>
                            <div class=\"input-group-append\">
    <button class=\"btn btn-primary\" type=\"submit\">Filter</button>
  </div>
</div>                 
</form>
</div>
</div>
<form method=\"post\" action=\"";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("send_notification");
        echo "\" enctype=\"multipart/form-data\">
<div class=\"row\">
                    <div class=\"col-md-6\">
                       <div class=\"form-group\">
                         <label for=\"reg\">Title</label>
                         <input type=\"text\" class=\"form-control\"   name=\"title\"  placeholder=\"Offer!\" >
                        </div> 
                        <div class=\"form-group\">
                         <label for=\"reg\">Message here *</label>
                         <textarea class=\"form-control\" rows=\"10\"  name=\"message\" required placeholder=\"message here\"></textarea>
                        </div> 
                        <div class=\"form-group\">
                         <label for=\"reg\">Notification for</label>
                         <select class=\"form-control\" id=\"xchange\" name=\"for\" >
                          <option value=\"0\">Send Custom Link</option>
                            <option value=\"1\">Redirect To Custom Products Page</option>
                             <option value=\"2\">Redirect To Custom Category Page</option>
                             <option value=\"4\">Redirect To Custom Brand Page</option>
                             <option value=\"3\">Redirect To APP</option>
                           </select>
                        </div>     
                        <div class=\"form-group\" id=\"link\">
                         <label for=\"reg\">Link</label>
                         <input type=\"text\" class=\"form-control\"   name=\"link\"  placeholder=\"www.example.com/offer\" >
                        </div>    
                         <div class=\"form-group\" id=\"category\" style=\"display:none;\">
                         <label for=\"reg\">Category</label>
                         <select class=\"multipleSelect\" multiple name=\"category[]\">
                          ";
        // line 77
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["category"] ?? $this->getContext($context, "category")));
        foreach ($context['_seq'] as $context["_key"] => $context["cat"]) {
            // line 78
            echo "                          <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["cat"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["cat"], "categoryName", array()), "html", null, true);
            echo "</option>
                          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cat'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 80
        echo "                         </select>
                        </div> 
                        <div class=\"form-group\"  id=\"items\" style=\"display:none;\">
                         <label for=\"regs\">Products</label>
                       <select class=\"dd\"  name=\"items[]\" multiple>
                          ";
        // line 85
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["items"] ?? $this->getContext($context, "items")));
        foreach ($context['_seq'] as $context["_key"] => $context["it"]) {
            // line 86
            echo "                          <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["it"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["it"], "itemName", array()), "html", null, true);
            echo "</option>
                          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['it'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 88
        echo "                         </select>
                        </div>   
                           <div class=\"form-group\"  id=\"brands\" style=\"display:none;\">
                         <label for=\"regs\">Brands</label>
                       <select class=\"dd\"  name=\"brands[]\" multiple>
                              ";
        // line 93
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["brands"] ?? $this->getContext($context, "brands")));
        foreach ($context['_seq'] as $context["_key"] => $context["br"]) {
            // line 94
            echo "                          <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["br"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["br"], "categoryName", array()), "html", null, true);
            echo "</option>
                          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['br'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 96
        echo "                         </select>
                        </div>  
                        
                        <!--                 -->
                      </div>
                       <div class=\"col-md-6\">
                     
                        <div class=\"form-group\">
                         <label for=\"reg\"></label>
                         <div class=\"box\" style=\"max-height:323px;border:2px solid #eee;  overflow-y: scroll;\">
<input id=\"myInput\" type=\"text\" placeholder=\"Search..\" class=\"form-control\">

  <table id=\"myTable\" class=\"table table-bordered table-striped\">
                            <thead>
                                <tr> 
                                    <th><div class=\"form-check\">
   <input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"selectThemAll\">
</div></th>                                    
                                    <th><div class=\"form-check\">Customer Name</div></th>
                                     <th><div class=\"form-check\">Location</div></th>
                                </tr>
                            </thead>
                            <tbody>
";
        // line 119
        $context["count"] = 0;
        // line 120
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["customer"] ?? $this->getContext($context, "customer")));
        foreach ($context['_seq'] as $context["_key"] => $context["cust"]) {
            echo " 
<tr>
 <td><input type=\"checkbox\" name=\"all[]\" class=\"tst\" value=\"";
            // line 122
            echo twig_escape_filter($this->env, $this->getAttribute($context["cust"], "id", array()), "html", null, true);
            echo "\"></td>
<td><div class=\"form-check\">
 ";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute($context["cust"], "username", array()), "html", null, true);
            echo " </label>

</td>
<td><div class=\"form-check\">
 
 ";
            // line 129
            echo twig_escape_filter($this->env, $this->getAttribute($context["cust"], "area", array()), "html", null, true);
            echo "

</div></td>
</tr>
";
            // line 133
            $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
            // line 134
            echo "
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cust'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 136
        echo "                          </tbody>
                          </table>
                         </div>
                                                   <b>Total ";
        // line 139
        echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
        echo " Customers</b>

                        </div>  
                         <div class=\"form-group\">
                          <h3 id=\"helpIcon\" data-toggle=\"modal\" data-target=\"#help\">&nbsp;&nbsp;&nbsp;<span style=\"font-size:15px;float:right;cursor:pointer\"><b>Help ?</b></span></h3>
                          <label for=\"reg\">Notification Image</label>
                          <input type=\"file\" class=\"form-control dropify\"  name=\"image\" accept=\".jpeg,.png\">
                        </div>                        
                      </div>
              
  <div class=\"clearfix\"></div>
<button type=\"submit\" class=\"btn btn-primary pull-left\">Send</button>
 </div>       
</form>
<div class=\"modal\" tabindex=\"-1\" role=\"dialog\" id=\"help\">
  <div class=\"modal-dialog\" role=\"document\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <h5 class=\"modal-title\">What is the best image size for my push notification?
</h5>
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
          <span aria-hidden=\"true\">&times;</span>
        </button>
      </div>
      <div class=\"modal-body\">
        <p>
          <b>Here are the recommended format and sizes for images in push notifications:</b>

<li>File format: Batch requires a PNG or JPEG file.</li>
<li>Size: Minimum width and height of 300px. Avoid using images wider than 2000 </li>
  <li>pixels. Also make sure that your image is not bigger than 1MB. </li>
<li>Aspect ratio: Use images in landscape format respecting a 2:1 ratio (e.g. 1000x500px).</li>
<li>Composition: Important information or the product you want to show should be in the middle of the image or as far as possible from the borders of the image.</li>
</p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_307b2a0a86f342ead9d29c8ea4aed4845fd176d41b12fe52d930f40a28544c7a->leave($__internal_307b2a0a86f342ead9d29c8ea4aed4845fd176d41b12fe52d930f40a28544c7a_prof);

    }

    // line 186
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_b824bf04c35bd5c6737702810ab63dbcf13072540361da94c1ffd58ad5b1c0d4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b824bf04c35bd5c6737702810ab63dbcf13072540361da94c1ffd58ad5b1c0d4->enter($__internal_b824bf04c35bd5c6737702810ab63dbcf13072540361da94c1ffd58ad5b1c0d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 187
        echo "<script>
\$(document).ready(function(){
  \$(\"#myInput\").on(\"keyup\", function() {
    var value = \$(this).val().toLowerCase();
    \$(\"#myTable tr\").filter(function() {
      \$(this).toggle(\$(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<script type=\"text/javascript\">

jQuery(\"[name=selectThemAll]\").click(function(source) { 
        checkboxes = jQuery('.tst');
        for(var i in checkboxes){
            checkboxes[i].checked = source.target.checked;
        }
    });
    </script>
<script>
    
        \$(document).ready(function() {
\$('.multipleSelect').fastselect();
\$('.dd').fastselect();

});
\$('#xchange').click(function(){
var x=\$('#xchange').val();
if(x==0)
{
\$('#link').show();
\$('#items').hide();
\$('#category').hide();
\$('#brands').hide();

}
if(x==1)
{
\$('#link').hide();
\$('#items').show();
\$('#category').hide();
\$('#brands').hide();

}
if(x==2)
{
\$('#link').hide();
\$('#items').hide();
\$('#category').show();
\$('#brands').hide();

}
if(x==3)
{
\$('#link').hide();
\$('#items').hide();
\$('#category').hide();
\$('#brands').hide();

}
if(x==4)
{
\$('#link').hide();
\$('#items').hide();
\$('#category').hide();
\$('#brands').show();

}
});
        </script>

";
        
        $__internal_b824bf04c35bd5c6737702810ab63dbcf13072540361da94c1ffd58ad5b1c0d4->leave($__internal_b824bf04c35bd5c6737702810ab63dbcf13072540361da94c1ffd58ad5b1c0d4_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Firebase/sendBulk.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  329 => 187,  323 => 186,  270 => 139,  265 => 136,  258 => 134,  256 => 133,  249 => 129,  241 => 124,  236 => 122,  229 => 120,  227 => 119,  202 => 96,  191 => 94,  187 => 93,  180 => 88,  169 => 86,  165 => 85,  158 => 80,  147 => 78,  143 => 77,  112 => 49,  97 => 39,  91 => 38,  85 => 37,  79 => 36,  73 => 33,  41 => 3,  35 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}
{% block body %}
<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked){
        position: relative;
        left: auto;
        opacity: 1;
    }
     .fstElement { font-size: 9px; }
            .fstToggleBtn { min-width: 16.5em; }

            .submitBtn { display: none; }

            .fstMultipleMode { display: block; }
            .fstMultipleMode .fstControls { width: 100%; }

</style>
    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">Send Push notification
                       
                    </h4>
                </div>
                <div class=\"card-body\">
<center><span  style=\"color: red;font-size: smaller;font-weight: 400;\">
</span></center>
<div class=\"row\">
<div class=\"col-6\">
</div>
<div class=\"col-6\">
 <form method=\"post\" action=\"{{ path('filter_notification_user') }}\" style=\"float:right\">
  <div class=\"input-group mb-4\">
<select class=\"form-control\" name=\"type\">
                          <option value=\"all\" {% if type == 'all' %}selected {% endif %}>All</option>
                          <option value=\"prime\" {% if type == 'prime' %}selected {% endif %}>Prime User</option>
                          <option value=\"active\" {% if type == 'active' %}selected {% endif %}>Active User</option>
                          <option value=\"new\" {% if type == 'new' %}selected {% endif %}>New User</option>
                            
                          </select>
                            <div class=\"input-group-append\">
    <button class=\"btn btn-primary\" type=\"submit\">Filter</button>
  </div>
</div>                 
</form>
</div>
</div>
<form method=\"post\" action=\"{{ path('send_notification')}}\" enctype=\"multipart/form-data\">
<div class=\"row\">
                    <div class=\"col-md-6\">
                       <div class=\"form-group\">
                         <label for=\"reg\">Title</label>
                         <input type=\"text\" class=\"form-control\"   name=\"title\"  placeholder=\"Offer!\" >
                        </div> 
                        <div class=\"form-group\">
                         <label for=\"reg\">Message here *</label>
                         <textarea class=\"form-control\" rows=\"10\"  name=\"message\" required placeholder=\"message here\"></textarea>
                        </div> 
                        <div class=\"form-group\">
                         <label for=\"reg\">Notification for</label>
                         <select class=\"form-control\" id=\"xchange\" name=\"for\" >
                          <option value=\"0\">Send Custom Link</option>
                            <option value=\"1\">Redirect To Custom Products Page</option>
                             <option value=\"2\">Redirect To Custom Category Page</option>
                             <option value=\"4\">Redirect To Custom Brand Page</option>
                             <option value=\"3\">Redirect To APP</option>
                           </select>
                        </div>     
                        <div class=\"form-group\" id=\"link\">
                         <label for=\"reg\">Link</label>
                         <input type=\"text\" class=\"form-control\"   name=\"link\"  placeholder=\"www.example.com/offer\" >
                        </div>    
                         <div class=\"form-group\" id=\"category\" style=\"display:none;\">
                         <label for=\"reg\">Category</label>
                         <select class=\"multipleSelect\" multiple name=\"category[]\">
                          {% for cat in category%}
                          <option value=\"{{ cat.id }}\">{{ cat.categoryName }}</option>
                          {% endfor %}
                         </select>
                        </div> 
                        <div class=\"form-group\"  id=\"items\" style=\"display:none;\">
                         <label for=\"regs\">Products</label>
                       <select class=\"dd\"  name=\"items[]\" multiple>
                          {% for it in items%}
                          <option value=\"{{ it.id }}\">{{ it.itemName }}</option>
                          {% endfor %}
                         </select>
                        </div>   
                           <div class=\"form-group\"  id=\"brands\" style=\"display:none;\">
                         <label for=\"regs\">Brands</label>
                       <select class=\"dd\"  name=\"brands[]\" multiple>
                              {% for br in brands%}
                          <option value=\"{{ br.id }}\">{{ br.categoryName }}</option>
                          {% endfor %}
                         </select>
                        </div>  
                        
                        <!--                 -->
                      </div>
                       <div class=\"col-md-6\">
                     
                        <div class=\"form-group\">
                         <label for=\"reg\"></label>
                         <div class=\"box\" style=\"max-height:323px;border:2px solid #eee;  overflow-y: scroll;\">
<input id=\"myInput\" type=\"text\" placeholder=\"Search..\" class=\"form-control\">

  <table id=\"myTable\" class=\"table table-bordered table-striped\">
                            <thead>
                                <tr> 
                                    <th><div class=\"form-check\">
   <input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"selectThemAll\">
</div></th>                                    
                                    <th><div class=\"form-check\">Customer Name</div></th>
                                     <th><div class=\"form-check\">Location</div></th>
                                </tr>
                            </thead>
                            <tbody>
{% set count = 0 %}
{% for cust in customer %} 
<tr>
 <td><input type=\"checkbox\" name=\"all[]\" class=\"tst\" value=\"{{ cust.id }}\"></td>
<td><div class=\"form-check\">
 {{ cust.username}} </label>

</td>
<td><div class=\"form-check\">
 
 {{ cust.area}}

</div></td>
</tr>
{% set count = count + 1 %}

{% endfor %}
                          </tbody>
                          </table>
                         </div>
                                                   <b>Total {{ count }} Customers</b>

                        </div>  
                         <div class=\"form-group\">
                          <h3 id=\"helpIcon\" data-toggle=\"modal\" data-target=\"#help\">&nbsp;&nbsp;&nbsp;<span style=\"font-size:15px;float:right;cursor:pointer\"><b>Help ?</b></span></h3>
                          <label for=\"reg\">Notification Image</label>
                          <input type=\"file\" class=\"form-control dropify\"  name=\"image\" accept=\".jpeg,.png\">
                        </div>                        
                      </div>
              
  <div class=\"clearfix\"></div>
<button type=\"submit\" class=\"btn btn-primary pull-left\">Send</button>
 </div>       
</form>
<div class=\"modal\" tabindex=\"-1\" role=\"dialog\" id=\"help\">
  <div class=\"modal-dialog\" role=\"document\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <h5 class=\"modal-title\">What is the best image size for my push notification?
</h5>
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
          <span aria-hidden=\"true\">&times;</span>
        </button>
      </div>
      <div class=\"modal-body\">
        <p>
          <b>Here are the recommended format and sizes for images in push notifications:</b>

<li>File format: Batch requires a PNG or JPEG file.</li>
<li>Size: Minimum width and height of 300px. Avoid using images wider than 2000 </li>
  <li>pixels. Also make sure that your image is not bigger than 1MB. </li>
<li>Aspect ratio: Use images in landscape format respecting a 2:1 ratio (e.g. 1000x500px).</li>
<li>Composition: Important information or the product you want to show should be in the middle of the image or as far as possible from the borders of the image.</li>
</p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>
  </div>
</div>
                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block scripts %}
<script>
\$(document).ready(function(){
  \$(\"#myInput\").on(\"keyup\", function() {
    var value = \$(this).val().toLowerCase();
    \$(\"#myTable tr\").filter(function() {
      \$(this).toggle(\$(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<script type=\"text/javascript\">

jQuery(\"[name=selectThemAll]\").click(function(source) { 
        checkboxes = jQuery('.tst');
        for(var i in checkboxes){
            checkboxes[i].checked = source.target.checked;
        }
    });
    </script>
<script>
    
        \$(document).ready(function() {
\$('.multipleSelect').fastselect();
\$('.dd').fastselect();

});
\$('#xchange').click(function(){
var x=\$('#xchange').val();
if(x==0)
{
\$('#link').show();
\$('#items').hide();
\$('#category').hide();
\$('#brands').hide();

}
if(x==1)
{
\$('#link').hide();
\$('#items').show();
\$('#category').hide();
\$('#brands').hide();

}
if(x==2)
{
\$('#link').hide();
\$('#items').hide();
\$('#category').show();
\$('#brands').hide();

}
if(x==3)
{
\$('#link').hide();
\$('#items').hide();
\$('#category').hide();
\$('#brands').hide();

}
if(x==4)
{
\$('#link').hide();
\$('#items').hide();
\$('#category').hide();
\$('#brands').show();

}
});
        </script>

{% endblock %}
", "AppBundle:Admin:Firebase/sendBulk.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Firebase/sendBulk.html.twig");
    }
}

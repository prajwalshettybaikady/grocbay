<?php

/* AppBundle:Admin:Brands/brandList.html.twig */
class __TwigTemplate_f27c0ed34efa2d9d92675ef1530ad9e0b466590405bea4d8c9a6488c4db8230a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Brands/brandList.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319474f23b59e6ae84a404c60058753b818ffc0df9a34cba4fc552fcf8423f36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319474f23b59e6ae84a404c60058753b818ffc0df9a34cba4fc552fcf8423f36->enter($__internal_319474f23b59e6ae84a404c60058753b818ffc0df9a34cba4fc552fcf8423f36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Brands/brandList.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319474f23b59e6ae84a404c60058753b818ffc0df9a34cba4fc552fcf8423f36->leave($__internal_319474f23b59e6ae84a404c60058753b818ffc0df9a34cba4fc552fcf8423f36_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_728e4d1f1281a4a03552a830f9b36a14c26f0f74680c7cdea524440e9347fd6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_728e4d1f1281a4a03552a830f9b36a14c26f0f74680c7cdea524440e9347fd6b->enter($__internal_728e4d1f1281a4a03552a830f9b36a14c26f0f74680c7cdea524440e9347fd6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "<!--nestable CSS -->
<link href=\"/assets/plugins/nestable/nestable.css\" rel=\"stylesheet\" type=\"text/css\" />

<style>
</style>

";
        
        $__internal_728e4d1f1281a4a03552a830f9b36a14c26f0f74680c7cdea524440e9347fd6b->leave($__internal_728e4d1f1281a4a03552a830f9b36a14c26f0f74680c7cdea524440e9347fd6b_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_aa9b1d55650df62292e9f088d953a066b6d843f2e40b0926dac0b7228c9339bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa9b1d55650df62292e9f088d953a066b6d843f2e40b0926dac0b7228c9339bc->enter($__internal_aa9b1d55650df62292e9f088d953a066b6d843f2e40b0926dac0b7228c9339bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "
<!-- Button trigger modal -->


<!-- Modal -->
<div class=\"modal fade\" id=\"createBrands\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\" role=\"document\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <h5 class=\"modal-title\" id=\"exampleModalLabel\">Create Brands</h5>
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
          <span aria-hidden=\"true\">&times;</span>
        </button>
      </div>
      <div class=\"modal-body\">
       ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
                    ";
        // line 27
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/widget.html.twig"));
        // line 28
        echo "                        <div class=\"form-group\">
                            ";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "categoryName", array()), 'label', array("label" => "Brand Name"));
        echo "
                            ";
        // line 30
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "categoryName", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Brand name
                            ")));
        // line 31
        echo "
                        </div>
<div class=\"form-group\">
     <div class=\"row\">
                                           ";
        // line 40
        echo "                                           ";
        // line 41
        echo "                                        </div>
</div>
                       
                        <div class=\"row\">
                                           <div class=\"col-md-12\">
                                                <label class=\"d-block\">Featured Brand</label>
                                                <label class=\"switch s-success mr-2 mt-3\"> 
                                                    <input type=\"checkbox\" ";
        // line 48
        if (($this->getAttribute(($context["category"] ?? $this->getContext($context, "category")), "parentId", array()) == 1)) {
            echo "checked ";
        }
        echo " class=\"form-control form-control-sm\" name=\"parentid\"  value=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["category"] ?? $this->getContext($context, "category")), "parentId", array()), "html", null, true);
        echo "\">
                                                    <span class=\"slider round\"></span>
                                                </label>
                                            </div>
                                        </div>
                        ";
        // line 53
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme(($context["form"] ?? $this->getContext($context, "form")), array(0 => "@AppBundle/Themes/file.html.twig"));
        // line 54
        echo "                        <div class=\"row\">
                            <div class=\"col-lg-12 col-md-12\">
                                ";
        // line 56
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "iconFile", array()), 'label', array("label" => "Brand icon"));
        echo "
                                ";
        // line 57
        $context["iconImage"] = "";
        // line 58
        echo "                                ";
        if (($this->getAttribute(($context["category"] ?? $this->getContext($context, "category")), "iconImage", array()) != null)) {
            // line 59
            echo "                                    ";
            $context["iconImage"] = ("/uploads/sub-category/icons/" . $this->getAttribute(($context["category"] ?? $this->getContext($context, "category")), "iconImage", array()));
            // line 60
            echo "                                ";
        }
        // line 61
        echo "                                ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "iconFile", array()), 'row', array("attr" => array("data-default-file" => ($context["iconImage"] ?? $this->getContext($context, "iconImage")))));
        echo "
                            </div>
                          
      
                        </div>
                        <div class=\"clearfix\"></div>
                     
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
        <button type=\"submit\" class=\"btn btn-primary\">Save changes</button>
      </div>
         ";
        // line 73
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
                        ";
        // line 74
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'rest');
        echo "
    </div>
  </div>
</div>


<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"card\">
            <div class=\"card-body\">
             <a href=\"";
        // line 84
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("export_brands");
        echo "\" class=\"btn btn-primary btn-sm\" style=\"float:right;\">Export</a>
                 <form method=\"post\" action=\"";
        // line 85
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("bulk_action_brands");
        echo "\">
                   <div class=\"row\">
           
                  
            <div class=\"col-2\">
<select class=\"form-control\" name=\"type\">
    <option  value=\"1\">Add To Featured</option>
    <option  value=\"3\">Remove From Featured</option>

    <option  value=\"2\">Delete</option>
</select>
                    </div>
                       <div class=\"col-1\">
<input type=\"submit\" class=\"btn btn-primary\" value=\"Update\">
                    </div>
                   </div>
                <table class=\"table table-hovered\" id=\"myTable\">
                    <thead>
                    <tr>
<th data-orderable=\"false\"><input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"selectThemAll\"></th>
                        <th>Id</th>
                        <th>Brand name</th>
                        <th>Featured</th>
                        <th>Action</th>
                    </tr>
                </thead>
                    
                </table>
            </div>
        </div>
    </div>
</div>
";
        
        $__internal_aa9b1d55650df62292e9f088d953a066b6d843f2e40b0926dac0b7228c9339bc->leave($__internal_aa9b1d55650df62292e9f088d953a066b6d843f2e40b0926dac0b7228c9339bc_prof);

    }

    // line 119
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_eaccfc6e7fa6695c7151a404cfde837a631e9b7a36261db0789e17ee8c8f7b08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eaccfc6e7fa6695c7151a404cfde837a631e9b7a36261db0789e17ee8c8f7b08->enter($__internal_eaccfc6e7fa6695c7151a404cfde837a631e9b7a36261db0789e17ee8c8f7b08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 120
        echo "<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
  \$(function() {
    jQuery(\"[name=selectThemAll]\").click(function(source) { 
        checkboxes = jQuery('.tst');
        for(var i in checkboxes){
            checkboxes[i].checked = source.target.checked;
        }
    });
});
  \$(document).ready(function() {
      \$('#myTable').DataTable({   
         
      'processing': true,
      'serverSide': true,
      'serverMethod': 'post',
      'ajax': {
          'url':\"";
        // line 137
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("ajax_brand_list");
        echo "\",
          'type': \"post\",
      },
      'columns': [
         { data: 'branch' },
         { data: 'id' },
         { data: 'categoryName' },
         { data: 'featured' },
         { data: 'view' },
      ],
   });
    });
</script>
<!--Nestable js -->
<script src=\"/assets/plugins/nestable/jquery.nestable.js\"></script>

<script type=\"text/javascript\">
    \$(document).ready(function() {
        // Nestable

        //updateOutput(\$('#nestable').data('output', \$('#nestable-output')));
/*
        \$('#nestable-menu').on('click', function(e) {
            var target = \$(e.target),
                action = target.data('action');
            if (action === 'expand-all') {
                \$('.dd').nestable('expandAll');
            }
            if (action === 'collapse-all') {
                \$('.dd').nestable('collapseAll');
            }
        });*/

        \$('#nestable-menu').nestable();/*
        \$('.dd').nestable('collapseAll');*/
    });
    </script>
";
        
        $__internal_eaccfc6e7fa6695c7151a404cfde837a631e9b7a36261db0789e17ee8c8f7b08->leave($__internal_eaccfc6e7fa6695c7151a404cfde837a631e9b7a36261db0789e17ee8c8f7b08_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Brands/brandList.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  246 => 137,  227 => 120,  221 => 119,  181 => 85,  177 => 84,  164 => 74,  160 => 73,  144 => 61,  141 => 60,  138 => 59,  135 => 58,  133 => 57,  129 => 56,  125 => 54,  123 => 53,  111 => 48,  102 => 41,  100 => 40,  94 => 31,  91 => 30,  87 => 29,  84 => 28,  82 => 27,  78 => 26,  61 => 11,  55 => 10,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}
{% block styles %}
<!--nestable CSS -->
<link href=\"/assets/plugins/nestable/nestable.css\" rel=\"stylesheet\" type=\"text/css\" />

<style>
</style>

{% endblock %}
{% block body %}

<!-- Button trigger modal -->


<!-- Modal -->
<div class=\"modal fade\" id=\"createBrands\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\" role=\"document\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <h5 class=\"modal-title\" id=\"exampleModalLabel\">Create Brands</h5>
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
          <span aria-hidden=\"true\">&times;</span>
        </button>
      </div>
      <div class=\"modal-body\">
       {{ form_start(form) }}
                    {% form_theme form '@AppBundle/Themes/widget.html.twig' %}
                        <div class=\"form-group\">
                            {{ form_label(form.categoryName, \"Brand Name\") }}
                            {{ form_row(form.categoryName,{'attr':{'class':'form-control','placeholder':'Brand name
                            '}}) }}
                        </div>
<div class=\"form-group\">
     <div class=\"row\">
                                           {#  <div class=\"col-md-12\">
                                                <div class=\"form-group\">
                                                  
                                                </div>
                                            </div> #}
                                           {#  #}
                                        </div>
</div>
                       
                        <div class=\"row\">
                                           <div class=\"col-md-12\">
                                                <label class=\"d-block\">Featured Brand</label>
                                                <label class=\"switch s-success mr-2 mt-3\"> 
                                                    <input type=\"checkbox\" {% if category.parentId == 1 %}checked {% endif %} class=\"form-control form-control-sm\" name=\"parentid\"  value=\"{{ category.parentId }}\">
                                                    <span class=\"slider round\"></span>
                                                </label>
                                            </div>
                                        </div>
                        {% form_theme form '@AppBundle/Themes/file.html.twig' %}
                        <div class=\"row\">
                            <div class=\"col-lg-12 col-md-12\">
                                {{ form_label(form.iconFile, \"Brand icon\") }}
                                {% set iconImage = \"\" %}
                                {% if category.iconImage != null %}
                                    {% set iconImage = '/uploads/sub-category/icons/'~category.iconImage %}
                                {% endif %}
                                {{ form_row(form.iconFile,{'attr':{'data-default-file':iconImage}}) }}
                            </div>
                          
      
                        </div>
                        <div class=\"clearfix\"></div>
                     
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
        <button type=\"submit\" class=\"btn btn-primary\">Save changes</button>
      </div>
         {{ form_end(form) }}
                        {{ form_rest(form) }}
    </div>
  </div>
</div>


<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"card\">
            <div class=\"card-body\">
             <a href=\"{{ path('export_brands') }}\" class=\"btn btn-primary btn-sm\" style=\"float:right;\">Export</a>
                 <form method=\"post\" action=\"{{ path('bulk_action_brands')}}\">
                   <div class=\"row\">
           
                  
            <div class=\"col-2\">
<select class=\"form-control\" name=\"type\">
    <option  value=\"1\">Add To Featured</option>
    <option  value=\"3\">Remove From Featured</option>

    <option  value=\"2\">Delete</option>
</select>
                    </div>
                       <div class=\"col-1\">
<input type=\"submit\" class=\"btn btn-primary\" value=\"Update\">
                    </div>
                   </div>
                <table class=\"table table-hovered\" id=\"myTable\">
                    <thead>
                    <tr>
<th data-orderable=\"false\"><input class=\"\" type=\"checkbox\" id=\"gridCheck\" name=\"selectThemAll\"></th>
                        <th>Id</th>
                        <th>Brand name</th>
                        <th>Featured</th>
                        <th>Action</th>
                    </tr>
                </thead>
                    
                </table>
            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block scripts %}
<script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
  \$(function() {
    jQuery(\"[name=selectThemAll]\").click(function(source) { 
        checkboxes = jQuery('.tst');
        for(var i in checkboxes){
            checkboxes[i].checked = source.target.checked;
        }
    });
});
  \$(document).ready(function() {
      \$('#myTable').DataTable({   
         
      'processing': true,
      'serverSide': true,
      'serverMethod': 'post',
      'ajax': {
          'url':\"{{ path('ajax_brand_list')}}\",
          'type': \"post\",
      },
      'columns': [
         { data: 'branch' },
         { data: 'id' },
         { data: 'categoryName' },
         { data: 'featured' },
         { data: 'view' },
      ],
   });
    });
</script>
<!--Nestable js -->
<script src=\"/assets/plugins/nestable/jquery.nestable.js\"></script>

<script type=\"text/javascript\">
    \$(document).ready(function() {
        // Nestable

        //updateOutput(\$('#nestable').data('output', \$('#nestable-output')));
/*
        \$('#nestable-menu').on('click', function(e) {
            var target = \$(e.target),
                action = target.data('action');
            if (action === 'expand-all') {
                \$('.dd').nestable('expandAll');
            }
            if (action === 'collapse-all') {
                \$('.dd').nestable('collapseAll');
            }
        });*/

        \$('#nestable-menu').nestable();/*
        \$('.dd').nestable('collapseAll');*/
    });
    </script>
{% endblock %}", "AppBundle:Admin:Brands/brandList.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Brands/brandList.html.twig");
    }
}

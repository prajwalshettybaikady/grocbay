<?php

/* AppBundle:Admin:Customers/create.html.twig */
class __TwigTemplate_100e064314fa1ded38fe7b193aa59e1e17092912f8d23c14bb33ffaaf620afeb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Customers/create.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_25b0edf968375da3d13f441dd0fa906995fdac9e0eb4bbb8850ad95d396029e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_25b0edf968375da3d13f441dd0fa906995fdac9e0eb4bbb8850ad95d396029e0->enter($__internal_25b0edf968375da3d13f441dd0fa906995fdac9e0eb4bbb8850ad95d396029e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Customers/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_25b0edf968375da3d13f441dd0fa906995fdac9e0eb4bbb8850ad95d396029e0->leave($__internal_25b0edf968375da3d13f441dd0fa906995fdac9e0eb4bbb8850ad95d396029e0_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_a843b87209889796a49faccf802318fd7028e0ff890754c8c2f488463495de08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a843b87209889796a49faccf802318fd7028e0ff890754c8c2f488463495de08->enter($__internal_a843b87209889796a49faccf802318fd7028e0ff890754c8c2f488463495de08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">Create Customer

                    </h4>
                </div>
                <div class=\"card-body\">
                 
<form method=\"post\" action=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("insert_customer");
        echo "\">
    <div class=\"form-row\">
    <div class=\"form-group col-md-6\">
      <label for=\"inputEmail4\">Name</label>
      <input type=\"text\" class=\"form-control\" id=\"inputEmail4\" placeholder=\"customer name\" required name=\"name\">
    </div>
    <div class=\"form-group col-md-6\">
      <label for=\"inputPassword4\">Mobile</label>
      <input type=\"text\" class=\"form-control\" id=\"inputPassword4\" placeholder=\"mobile number\" required name=\"mobile\" maxlength=\"10\">
    </div>
  </div>
  <div class=\"form-row\">
    <div class=\"form-group col-md-6\">
      <label for=\"inputEmail4\">Email</label>
      <input type=\"email\" class=\"form-control\" id=\"inputEmail4\" placeholder=\"Email\" required name=\"email\">
    </div>
        <div class=\"form-group col-md-6\">
      <label for=\"gst\">Tax Details</label>
      <input type=\"text\" class=\"form-control\" id=\"gst\" placeholder=\"Tax No.\"  name=\"gst\">
    </div>
  </div>
    <div class=\"form-row\">
  <div class=\"form-group col-md-8\">
    <label for=\"inputAddress\">Address</label>
    <textarea class=\"form-control\" id=\"inputAddress\" placeholder=\"1234 Main St\" rows=\"3\" required name=\"address\"></textarea>
  </div>
  <div class=\"form-group col-md-4\">
      <label for=\"inputState\">Address Type</label>
      <select id=\"inputState\" class=\"form-control\" name=\"type\">
        <option selected value=\"home\">Home</option>
        <option value=\"work\">Work.</option>
         <option value=\"other\">Other.</option>
      </select>
  </div>
</div>

  <button type=\"submit\" class=\"btn btn-primary\">Create</button>
</form>






                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_a843b87209889796a49faccf802318fd7028e0ff890754c8c2f488463495de08->leave($__internal_a843b87209889796a49faccf802318fd7028e0ff890754c8c2f488463495de08_prof);

    }

    // line 63
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_42c49bc639e5c2f754232445bd0489daf26905b7b4be87082aa07c23b7c4079d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42c49bc639e5c2f754232445bd0489daf26905b7b4be87082aa07c23b7c4079d->enter($__internal_42c49bc639e5c2f754232445bd0489daf26905b7b4be87082aa07c23b7c4079d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 64
        echo "
<script>
    
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

";
        
        $__internal_42c49bc639e5c2f754232445bd0489daf26905b7b4be87082aa07c23b7c4079d->leave($__internal_42c49bc639e5c2f754232445bd0489daf26905b7b4be87082aa07c23b7c4079d_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Customers/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 64,  109 => 63,  53 => 13,  41 => 3,  35 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}
{% block body %}
    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                    <h4 class=\"m-b-0 text-white\">Create Customer

                    </h4>
                </div>
                <div class=\"card-body\">
                 
<form method=\"post\" action=\"{{ path('insert_customer') }}\">
    <div class=\"form-row\">
    <div class=\"form-group col-md-6\">
      <label for=\"inputEmail4\">Name</label>
      <input type=\"text\" class=\"form-control\" id=\"inputEmail4\" placeholder=\"customer name\" required name=\"name\">
    </div>
    <div class=\"form-group col-md-6\">
      <label for=\"inputPassword4\">Mobile</label>
      <input type=\"text\" class=\"form-control\" id=\"inputPassword4\" placeholder=\"mobile number\" required name=\"mobile\" maxlength=\"10\">
    </div>
  </div>
  <div class=\"form-row\">
    <div class=\"form-group col-md-6\">
      <label for=\"inputEmail4\">Email</label>
      <input type=\"email\" class=\"form-control\" id=\"inputEmail4\" placeholder=\"Email\" required name=\"email\">
    </div>
        <div class=\"form-group col-md-6\">
      <label for=\"gst\">Tax Details</label>
      <input type=\"text\" class=\"form-control\" id=\"gst\" placeholder=\"Tax No.\"  name=\"gst\">
    </div>
  </div>
    <div class=\"form-row\">
  <div class=\"form-group col-md-8\">
    <label for=\"inputAddress\">Address</label>
    <textarea class=\"form-control\" id=\"inputAddress\" placeholder=\"1234 Main St\" rows=\"3\" required name=\"address\"></textarea>
  </div>
  <div class=\"form-group col-md-4\">
      <label for=\"inputState\">Address Type</label>
      <select id=\"inputState\" class=\"form-control\" name=\"type\">
        <option selected value=\"home\">Home</option>
        <option value=\"work\">Work.</option>
         <option value=\"other\">Other.</option>
      </select>
  </div>
</div>

  <button type=\"submit\" class=\"btn btn-primary\">Create</button>
</form>






                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block scripts %}

<script>
    
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

{% endblock %}
", "AppBundle:Admin:Customers/create.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Customers/create.html.twig");
    }
}

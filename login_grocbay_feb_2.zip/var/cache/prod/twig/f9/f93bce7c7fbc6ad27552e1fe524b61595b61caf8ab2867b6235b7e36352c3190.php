<?php

/* AppBundle:Admin:Pages/page.html.twig */
class __TwigTemplate_7d74857bd7009807531e72b18e2e4a0e8d2ee4cb2d8e3434a33819dc84d6eb2c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/page.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_221885d86e95d0ed63f68f6d3c5c7f4936c2a78303f388ef22806baa11bddf9a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_221885d86e95d0ed63f68f6d3c5c7f4936c2a78303f388ef22806baa11bddf9a->enter($__internal_221885d86e95d0ed63f68f6d3c5c7f4936c2a78303f388ef22806baa11bddf9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/page.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_221885d86e95d0ed63f68f6d3c5c7f4936c2a78303f388ef22806baa11bddf9a->leave($__internal_221885d86e95d0ed63f68f6d3c5c7f4936c2a78303f388ef22806baa11bddf9a_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_4b47ff0ecf916cc542f0211fae111c1f1ed305bdc47e7f000726c7bc192628ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b47ff0ecf916cc542f0211fae111c1f1ed305bdc47e7f000726c7bc192628ca->enter($__internal_4b47ff0ecf916cc542f0211fae111c1f1ed305bdc47e7f000726c7bc192628ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                  
                </div>
                <div class=\"card-body\">
                 
<form method=\"post\" action=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_page_details");
        echo "\">
   <div id=\"basic\" class=\"row layout-spacing layout-top-spacing\">
                        <div class=\"col-lg-12\">
                            <div class=\"statbox widget box box-shadow\">
                                <div class=\"widget-header\">
                                    <div class=\"row\">
                                        <div class=\"col-xl-12 col-md-12 col-sm-12 col-12\">
                                            <h4>";
        // line 16
        echo twig_escape_filter($this->env, ($context["heading"] ?? $this->getContext($context, "heading")), "html", null, true);
        echo "</h4>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"form-group\">
                                  <input type=\"hidden\" name=\"type\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, ($context["type"] ?? $this->getContext($context, "type")), "html", null, true);
        echo "\">
                                            <textarea class=\"form-control data\" id=\"data\" placeholder=\"about shop\"  name=\"data\" rows=\"15\">";
        // line 22
        echo twig_escape_filter($this->env, ($context["data"] ?? $this->getContext($context, "data")), "html", null, true);
        echo "</textarea>

                                  </div>
                                </div>
                              </div>
                            </div>

  <button type=\"submit\" class=\"btn btn-primary\">Save</button>


</form>
</div>
</div>






    
";
        
        $__internal_4b47ff0ecf916cc542f0211fae111c1f1ed305bdc47e7f000726c7bc192628ca->leave($__internal_4b47ff0ecf916cc542f0211fae111c1f1ed305bdc47e7f000726c7bc192628ca_prof);

    }

    // line 44
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_e83cea3c0db21192227ffc457486d68ce399a5b7a2ca2d1bd43833c0d976e849 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e83cea3c0db21192227ffc457486d68ce399a5b7a2ca2d1bd43833c0d976e849->enter($__internal_e83cea3c0db21192227ffc457486d68ce399a5b7a2ca2d1bd43833c0d976e849_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 45
        echo "
<script>    
     \$(document).ready(function() {
            \$('.data').richText();
        });
        </script>
";
        
        $__internal_e83cea3c0db21192227ffc457486d68ce399a5b7a2ca2d1bd43833c0d976e849->leave($__internal_e83cea3c0db21192227ffc457486d68ce399a5b7a2ca2d1bd43833c0d976e849_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 45,  99 => 44,  71 => 22,  67 => 21,  59 => 16,  49 => 9,  41 => 3,  35 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}
{% block body %}
            <div class=\"card card-outline-info\">
                <div class=\"card-header\">
                  
                </div>
                <div class=\"card-body\">
                 
<form method=\"post\" action=\"{{ path('update_page_details') }}\">
   <div id=\"basic\" class=\"row layout-spacing layout-top-spacing\">
                        <div class=\"col-lg-12\">
                            <div class=\"statbox widget box box-shadow\">
                                <div class=\"widget-header\">
                                    <div class=\"row\">
                                        <div class=\"col-xl-12 col-md-12 col-sm-12 col-12\">
                                            <h4>{{ heading }}</h4>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"form-group\">
                                  <input type=\"hidden\" name=\"type\" value=\"{{ type }}\">
                                            <textarea class=\"form-control data\" id=\"data\" placeholder=\"about shop\"  name=\"data\" rows=\"15\">{{ data }}</textarea>

                                  </div>
                                </div>
                              </div>
                            </div>

  <button type=\"submit\" class=\"btn btn-primary\">Save</button>


</form>
</div>
</div>






    
{% endblock %}

{% block scripts %}

<script>    
     \$(document).ready(function() {
            \$('.data').richText();
        });
        </script>
{% endblock %}
", "AppBundle:Admin:Pages/page.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/page.html.twig");
    }
}

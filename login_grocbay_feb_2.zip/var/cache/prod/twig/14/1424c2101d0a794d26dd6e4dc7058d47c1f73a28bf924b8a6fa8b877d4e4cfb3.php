<?php

/* AppBundle:Admin:AppManager/location.html.twig */
class __TwigTemplate_9053ed9548eba13a5eb0f8f0045517b92885313c1ab1029848559180f0e9a4a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:AppManager/location.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2aa8e6cddb4283607d53a4738408170c4a1adfb54f4cee1e00142486dabc4415 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2aa8e6cddb4283607d53a4738408170c4a1adfb54f4cee1e00142486dabc4415->enter($__internal_2aa8e6cddb4283607d53a4738408170c4a1adfb54f4cee1e00142486dabc4415_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:AppManager/location.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2aa8e6cddb4283607d53a4738408170c4a1adfb54f4cee1e00142486dabc4415->leave($__internal_2aa8e6cddb4283607d53a4738408170c4a1adfb54f4cee1e00142486dabc4415_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_3cc082f09268812993666b2f81f77e6c915e18a5359fa88ed11d46a85c8d002c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3cc082f09268812993666b2f81f77e6c915e18a5359fa88ed11d46a85c8d002c->enter($__internal_3cc082f09268812993666b2f81f77e6c915e18a5359fa88ed11d46a85c8d002c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "      <link href = \"https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css\"
         rel = \"stylesheet\">
      <script src = \"https://code.jquery.com/jquery-1.10.2.js\"></script>
      <script src = \"https://code.jquery.com/ui/1.10.4/jquery-ui.js\"></script>
      
      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            }); 

         });
      </script>
      <style type=\"text/css\">
           html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
  .pac-container { z-index: 10000 !important; }

      #type-selector {
        color: #fff;
        background-color: #4d90fe;
        padding: 5px 11px 0px 11px;
      }

      #type-selector label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }
      footer.footer.noprint
      {
        display: none;
      }
      </style>
      <script type=\"text/javascript\"
      src=\"https://maps.google.com/maps/api/js?sensor=false&key=AIzaSyAqpNRcHCA-YkFDmY4v_TmOAeUltT3-ezY&v=3.21.5a&libraries=drawing&signed_in=true&libraries=places,drawing\"></script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js\" integrity=\"sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=\" crossorigin=\"anonymous\"></script>
<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css\" integrity=\"sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=\" crossorigin=\"anonymous\" />
";
        // line 47
        echo "<!-- Modal -->

<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                        <span class=\"pull-right\">
                    ";
        // line 56
        echo "                          
                        </span>
                    </div>
                    <h2>Manage Delivery Location</h2>

                    <div>
                       
                        <hr>
                          <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\" style=\"float:right;\">Add New Location</a> 
 <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>#</th>
                                     <th>Title</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                              ";
        // line 75
        $context["count"] = 1;
        // line 76
        echo "                               ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["da"]) {
            // line 77
            echo "                               <tr>
                               <td>";
            // line 78
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo " </td>
                               <td>";
            // line 79
            echo twig_escape_filter($this->env, $this->getAttribute($context["da"], "title", array()), "html", null, true);
            echo "</td>
                             <td>
                              <a href=\"";
            // line 81
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("location_delete", array("id" => $this->getAttribute($context["da"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-danger btn-sm\">remove</a> <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("view_location", array("id" => $this->getAttribute($context["da"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-danger btn-sm\">edit</a></td>
                           </tr>
                        
";
            // line 84
            $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
            // line 85
            echo "                               ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['da'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 86
        echo "                            </tbody>
                        </table>
                    </div>
                   
                    </div>
     
                </div>
            </div>
    </div>
</div>

";
        // line 98
        echo "<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog modal-lg\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Add New Location</h4>
      </div>
      <div class=\"modal-body\">
        <p>
          
 <div id=\"tool\">
  <div id=\"map_canvas\" style=\" border: 2px solid #3872ac;\"></div><br>


<form method=\"post\"  action=\"";
        // line 114
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_location");
        echo "\">
<input id=\"pac-input\"  type=\"text\" placeholder=\"Search Box\" style=\"padding:2px;border-radius:2px;border:1px solid #eee\">
    <div class=\"row dis\"  style=\"\">
     <div class=\"col-12\">
      Name Of The Location  * <br>
    <input type=\"text\" name=\"location\" value=\"\" required placeholder=\"enter name of location\"  class=\"form-control\" />
  </div><hr>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Minimum Order Amount (Regular User)<br>
    <input type=\"number\" name=\"minnormal\" value=\"\" required placeholder=\"Minimum order amount\"  class=\"form-control\" />
  </div>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Delivery Charge  (Regular User)<br>
    <input type=\"number\" name=\"delnormal\" value=\"\" required placeholder=\"delivery Charge\"  class=\"form-control\" />
  </div>
<hr >
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Minimum Order Amount (Prime User)<br>
    <input type=\"text\" name=\"minprime\" value=\"\" required placeholder=\"Minimum Order Amount\"  class=\"form-control\" />
  </div>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Delivery Charge  (Prime User)<br>
    <input type=\"text\" name=\"delprime\" value=\"\" required placeholder=\"Delivery Charge\"  class=\"form-control\" />
  </div>

 <div class=\"col-4\" style=\"margin-top:20px;\">
      Minimum Order Amount (Express Delivery)<br>
    <input type=\"text\" name=\"minexpress\" value=\"\" required placeholder=\"Minimum Order Amount\"  class=\"form-control\" />
  </div>
   <div class=\"col-4\" style=\"margin-top:20px;\">
      Delivery Charge  (Express Delivery)<br>
    <input type=\"text\" name=\"delexpress\" value=\"\" required placeholder=\"Delivery Charge\"  class=\"form-control\" />
  </div>
   <div class=\"col-4\" style=\"margin-top:20px;\">
     Duration <br>(Express Delivery)<br>
    <input type=\"text\" name=\"duration\" value=\"\" required placeholder=\"Delivery Duration\"  class=\"form-control\" />
  </div>

  <div class=\"col-12\">
    <input type=\"hidden\" name=\"vertices\" id=\"vertices\"  class=\"form-control\" required=\"\" /><br>
  </div>

    <div class=\"col-4\">
          <button type=\"submit\" class=\"btn btn-primary \" id=\"save\">Create New Location</button>


  </div>
  </div>
</form>


</div>




        
       </p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
";
        
        $__internal_3cc082f09268812993666b2f81f77e6c915e18a5359fa88ed11d46a85c8d002c->leave($__internal_3cc082f09268812993666b2f81f77e6c915e18a5359fa88ed11d46a85c8d002c_prof);

    }

    // line 183
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_5ddd9954bdaa821205747cebc8023cc4c3ea68c652222e4ac1440c7ca14ffcc1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ddd9954bdaa821205747cebc8023cc4c3ea68c652222e4ac1440c7ca14ffcc1->enter($__internal_5ddd9954bdaa821205747cebc8023cc4c3ea68c652222e4ac1440c7ca14ffcc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 184
        echo "
    
    <style type=\"text/css\">
 #tool{
  width:100%;
  display:block;
}
#map_canvas {
    height: 500px;
    width:100%;
    margin-right: 10px;
    padding: 0px;
}
#info{ 
  width:100%;
  float: left;
  height: 270px;
  overflow: scroll;
}
button.undo {
    border: navajowhite;
    background: #fff;
}
    </style>
    <script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
</script>
    <script type=\"text/javascript\">

      function CenterControl(controlDiv, map) {

        // Set CSS for the control border.
        var controlUI = document.createElement('div');
        controlUI.style.backgroundColor = '#fff';
        controlUI.style.border = '2px solid #fff';
        controlUI.style.borderRadius = '3px';
        controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
        controlUI.style.cursor = 'pointer';
        controlUI.style.marginBottom = '22px';
        controlUI.style.marginTop = '5px';
        controlUI.style.textAlign = 'center';
        controlUI.title = 'Click to recenter the map';
        controlDiv.appendChild(controlUI);

        // Set CSS for the control interior.
        var controlText = document.createElement('div');
        controlText.style.color = 'rgb(25,25,25)';
                controlUI.style.backgroundColor = '#fff';

        controlText.style.fontFamily = 'Roboto,Arial,sans-serif';
        controlText.style.fontSize = '16px';
        controlText.style.lineHeight = '0px';
        controlText.style.padding = '9px';
        controlText.style.paddingRight = '5px';
        controlText.innerHTML = '<button onclick=\"removeLineSegment()\" class=\"undo\">undo</button>';
        controlUI.appendChild(controlText);

        // Setup the click event listeners: simply set the map to Chicago.
        controlUI.addEventListener('click', function() {
          map.setCenter(chicago);
        });

      }
    if(!!navigator.geolocation) {
        
  var map;
  var reset=\$('#resetPolygon');
  var geocoder;
  var polygonArray = [];
  var overlays = [];
var lastOverlay;
  var mapOptions = {
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP
          };
  map = new google.maps.Map(document.getElementById('map_canvas'), mapOptions);
  navigator.geolocation.getCurrentPosition(function(position) {
          
            var geolocate = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
            
            var infowindow = new google.maps.InfoWindow({
              map: map,
              position: geolocate,
              content:
                '<h4>You are here!!</h4>' +
                '<p>Latitude: ' + position.coords.latitude + '</p>' +
                '<p>Longitude: ' + position.coords.longitude + '</p>'
            });
            
            map.setCenter(geolocate);
            
          });      
            var centerControlDiv = document.createElement('div');
        var centerControl = new CenterControl(centerControlDiv, map);

        centerControlDiv.index = 1;
        map.controls[google.maps.ControlPosition.TOP_CENTER].push(centerControlDiv);  
} 
else
{
  document.getElementById('map_canvas').innerHTML = 'No Geolocation Support.';
}
var poly;

function initializeDrawer() {
    var input = document.getElementById('searchTextField');
  new google.maps.places.Autocomplete(input);

    var drawingManager = new google.maps.drawing.DrawingManager({
        drawingMode: google.maps.drawing.OverlayType.POLYGON,
        drawingControl: true,
        drawingControlOptions: {
            position: google.maps.ControlPosition.TOP_CENTER,
            drawingModes: [
    
            // google.maps.drawing.OverlayType.CIRCLE,
            google.maps.drawing.OverlayType.POLYGON
            ]
        },
        markerOptions: {
            icon: 'images/car-icon.png'
        },
        circleOptions: {
            fillColor: '#ffff00',
            fillOpacity: 1,
            strokeWeight: 5,
            clickable: false,
            editable: true,
            zIndex: 1
        },
        polygonOptions: {
            fillColor: '#BCDCF9',
            fillOpacity: 0.5,
            strokeWeight: 2,
            strokeColor: '#57ACF9',
            clickable: false,
            editable: true,
            draggab: 1,
            zIndex: 1

        }
    });
    drawingManager.setMap(map);
     google.maps.event.addListener(drawingManager, \"overlaycomplete\", function(event){
     overlayClickListener(event.overlay);
      overlays.push(event); // store reference to added overlay
              
    \$('#vertices').val(JSON.stringify(event.overlay.getPath().getArray()));
 
         event.overlay.overlayType = event.type;
    lastOverlay = event.overlay; // Save it
    drawingManager.setDrawingMode(null); // Return to 'hand' mode 

            });
       // SearchBox code
  // Create the search box and link it to the UI element.
  var input = document.getElementById('pac-input');
  var searchBox = new google.maps.places.SearchBox(input);
  map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

  // Bias the SearchBox results towards current map's viewport.
  map.addListener('bounds_changed', function() {
    searchBox.setBounds(map.getBounds());
  });

  var markers = [];
  // Listen for the event fired when the user selects a prediction and retrieve
  // more details for that place.
  searchBox.addListener('places_changed', function() {
    var places = searchBox.getPlaces();

    if (places.length == 0) {
      return;
    }

    // Clear out the old markers.
    markers.forEach(function(marker) {
      marker.setMap(null);
    });
    markers = [];

    // For each place, get the icon, name and location.
    var bounds = new google.maps.LatLngBounds();
    places.forEach(function(place) {
      if (!place.geometry) {
        console.log(\"Returned place contains no geometry\");
        return;
      }
      var icon = {
        url: place.icon,
        size: new google.maps.Size(71, 71),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(17, 34),
        scaledSize: new google.maps.Size(25, 25)
      };

      // Create a marker for each place.
      markers.push(new google.maps.Marker({
        map: map,
        icon: icon,
        title: place.name,
        position: place.geometry.location
      }));

      if (place.geometry.viewport) {
        // Only geocodes have viewport.
        bounds.union(place.geometry.viewport);
      } else {
        bounds.extend(place.geometry.location);
      }
    });
    map.fitBounds(bounds);
  });
        }


function overlayClickListener(overlay) {
    google.maps.event.addListener(overlay, \"mouseup\", function(event){
        \$('#vertices').val(JSON.stringify(overlay.getPath().getArray()));
    });
    }

// undo the last line segment of a polyline
function removeLineSegment() {
  
    var lastOverlay = overlays.length > 0 ? overlays[overlays.length - 1] : null;    
  if (lastOverlay && lastOverlay.type === \"polygon\") {
    var path = lastOverlay.overlay.getPath();
    path.pop(); // remove last line segment
  }
    if (lastOverlay && lastOverlay.type === \"polyline\") {
    var path = lastOverlay.overlay.getPath();
    path.pop(); // remove last line segment
  }
      if (lastOverlay && lastOverlay.type === \"rectangle\") {
    var path = lastOverlay.overlay.getPath();
    path.pop(); // remove last line segment
  }
}

// Initialize the drawer tool
google.maps.event.addDomListener(window, \"load\", initializeDrawer);
</script>
    </script>

    <script type=\"text/javascript\">
//  // This example creates a simple polygon representing the Bermuda Triangle.

//       function initMap() {
//                 var triangleCoords = [{\"lat\":19.315236306657976,\"lng\":72.85987742995746},{\"lat\":19.297739470248636,\"lng\":72.89180644607075},{\"lat\":19.278944487784745,\"lng\":72.89300807570942},{\"lat\":19.268087782413005,\"lng\":72.90073283767231},{\"lat\":19.261767876470657,\"lng\":72.87979014968403},{\"lat\":19.26549502996255,\"lng\":72.85695918654926},{\"lat\":19.280402796382898,\"lng\":72.83052333449848},{\"lat\":19.303895977968978,\"lng\":72.84820445632465}];

//         var map = new google.maps.Map(document.getElementById('map_canvas'), {
//           zoom: 5,
//           center: {lat: triangleCoords[0].lat, lng: triangleCoords[0].lng},
//           mapTypeId: 'terrain'
//         });

//         // Define the LatLng coordinates for the polygon's path.
//         var triangleCoords = [{\"lat\":19.315236306657976,\"lng\":72.85987742995746},{\"lat\":19.297739470248636,\"lng\":72.89180644607075},{\"lat\":19.278944487784745,\"lng\":72.89300807570942},{\"lat\":19.268087782413005,\"lng\":72.90073283767231},{\"lat\":19.261767876470657,\"lng\":72.87979014968403},{\"lat\":19.26549502996255,\"lng\":72.85695918654926},{\"lat\":19.280402796382898,\"lng\":72.83052333449848},{\"lat\":19.303895977968978,\"lng\":72.84820445632465}];
//         // Construct the polygon.
//         var bermudaTriangle = new google.maps.Polygon({
//           paths: triangleCoords,
//           strokeColor: '#FF0000',
//           strokeOpacity: 0.8,
//           strokeWeight: 2,
//           fillColor: '#FF0000',
//           fillOpacity: 0.35
//         });
//         bermudaTriangle.setMap(map);
//       }
</script>
";
        
        $__internal_5ddd9954bdaa821205747cebc8023cc4c3ea68c652222e4ac1440c7ca14ffcc1->leave($__internal_5ddd9954bdaa821205747cebc8023cc4c3ea68c652222e4ac1440c7ca14ffcc1_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:AppManager/location.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  262 => 184,  256 => 183,  182 => 114,  164 => 98,  151 => 86,  145 => 85,  143 => 84,  135 => 81,  130 => 79,  126 => 78,  123 => 77,  118 => 76,  116 => 75,  95 => 56,  85 => 47,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}
      <link href = \"https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css\"
         rel = \"stylesheet\">
      <script src = \"https://code.jquery.com/jquery-1.10.2.js\"></script>
      <script src = \"https://code.jquery.com/ui/1.10.4/jquery-ui.js\"></script>
      
      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            }); 

         });
      </script>
      <style type=\"text/css\">
           html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
  .pac-container { z-index: 10000 !important; }

      #type-selector {
        color: #fff;
        background-color: #4d90fe;
        padding: 5px 11px 0px 11px;
      }

      #type-selector label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }
      footer.footer.noprint
      {
        display: none;
      }
      </style>
      <script type=\"text/javascript\"
      src=\"https://maps.google.com/maps/api/js?sensor=false&key=AIzaSyAqpNRcHCA-YkFDmY4v_TmOAeUltT3-ezY&v=3.21.5a&libraries=drawing&signed_in=true&libraries=places,drawing\"></script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js\" integrity=\"sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=\" crossorigin=\"anonymous\"></script>
<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css\" integrity=\"sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=\" crossorigin=\"anonymous\" />
{# {{ dump(res) }} #}
<!-- Modal -->

<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    <div class=\"col-xs-12\">
                        <span class=\"pull-right\">
                    {#      <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\">Upload CSV</a> #}
                          
                        </span>
                    </div>
                    <h2>Manage Delivery Location</h2>

                    <div>
                       
                        <hr>
                          <a href=\"#\" class=\"btn btn-primary btn-sm\" data-toggle=\"modal\" data-target=\"#uploadCSV\" style=\"float:right;\">Add New Location</a> 
 <div class=\"table-responsive m-t-10\">
                        <table id=\"myTable\" class=\"table table-hovered\">
                            <thead>
                                <tr>
                                    <th>#</th>
                                     <th>Title</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                              {% set count = 1 %}
                               {% for da in data %}
                               <tr>
                               <td>{{ count }} </td>
                               <td>{{ da.title }}</td>
                             <td>
                              <a href=\"{{ path('location_delete',{'id':da.id}) }}\" class=\"btn btn-danger btn-sm\">remove</a> <a href=\"{{ path('view_location',{'id':da.id}) }}\" class=\"btn btn-danger btn-sm\">edit</a></td>
                           </tr>
                        
{% set count = count+1 %}
                               {% endfor %}
                            </tbody>
                        </table>
                    </div>
                   
                    </div>
     
                </div>
            </div>
    </div>
</div>

{# modal #}
<div id=\"uploadCSV\" class=\"modal fade\" role=\"dialog\">
  <div class=\"modal-dialog modal-lg\">

    <!-- Modal content-->
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
        <h4 class=\"modal-title\">Add New Location</h4>
      </div>
      <div class=\"modal-body\">
        <p>
          
 <div id=\"tool\">
  <div id=\"map_canvas\" style=\" border: 2px solid #3872ac;\"></div><br>


<form method=\"post\"  action=\"{{ path('add_location') }}\">
<input id=\"pac-input\"  type=\"text\" placeholder=\"Search Box\" style=\"padding:2px;border-radius:2px;border:1px solid #eee\">
    <div class=\"row dis\"  style=\"\">
     <div class=\"col-12\">
      Name Of The Location  * <br>
    <input type=\"text\" name=\"location\" value=\"\" required placeholder=\"enter name of location\"  class=\"form-control\" />
  </div><hr>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Minimum Order Amount (Regular User)<br>
    <input type=\"number\" name=\"minnormal\" value=\"\" required placeholder=\"Minimum order amount\"  class=\"form-control\" />
  </div>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Delivery Charge  (Regular User)<br>
    <input type=\"number\" name=\"delnormal\" value=\"\" required placeholder=\"delivery Charge\"  class=\"form-control\" />
  </div>
<hr >
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Minimum Order Amount (Prime User)<br>
    <input type=\"text\" name=\"minprime\" value=\"\" required placeholder=\"Minimum Order Amount\"  class=\"form-control\" />
  </div>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Delivery Charge  (Prime User)<br>
    <input type=\"text\" name=\"delprime\" value=\"\" required placeholder=\"Delivery Charge\"  class=\"form-control\" />
  </div>

 <div class=\"col-4\" style=\"margin-top:20px;\">
      Minimum Order Amount (Express Delivery)<br>
    <input type=\"text\" name=\"minexpress\" value=\"\" required placeholder=\"Minimum Order Amount\"  class=\"form-control\" />
  </div>
   <div class=\"col-4\" style=\"margin-top:20px;\">
      Delivery Charge  (Express Delivery)<br>
    <input type=\"text\" name=\"delexpress\" value=\"\" required placeholder=\"Delivery Charge\"  class=\"form-control\" />
  </div>
   <div class=\"col-4\" style=\"margin-top:20px;\">
     Duration <br>(Express Delivery)<br>
    <input type=\"text\" name=\"duration\" value=\"\" required placeholder=\"Delivery Duration\"  class=\"form-control\" />
  </div>

  <div class=\"col-12\">
    <input type=\"hidden\" name=\"vertices\" id=\"vertices\"  class=\"form-control\" required=\"\" /><br>
  </div>

    <div class=\"col-4\">
          <button type=\"submit\" class=\"btn btn-primary \" id=\"save\">Create New Location</button>


  </div>
  </div>
</form>


</div>




        
       </p>
      </div>
      <div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
      </div>
    </div>

  </div>
</div>
{# end modal #}
{% endblock %}

{% block scripts %}

    
    <style type=\"text/css\">
 #tool{
  width:100%;
  display:block;
}
#map_canvas {
    height: 500px;
    width:100%;
    margin-right: 10px;
    padding: 0px;
}
#info{ 
  width:100%;
  float: left;
  height: 270px;
  overflow: scroll;
}
button.undo {
    border: navajowhite;
    background: #fff;
}
    </style>
    <script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
</script>
    <script type=\"text/javascript\">

      function CenterControl(controlDiv, map) {

        // Set CSS for the control border.
        var controlUI = document.createElement('div');
        controlUI.style.backgroundColor = '#fff';
        controlUI.style.border = '2px solid #fff';
        controlUI.style.borderRadius = '3px';
        controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
        controlUI.style.cursor = 'pointer';
        controlUI.style.marginBottom = '22px';
        controlUI.style.marginTop = '5px';
        controlUI.style.textAlign = 'center';
        controlUI.title = 'Click to recenter the map';
        controlDiv.appendChild(controlUI);

        // Set CSS for the control interior.
        var controlText = document.createElement('div');
        controlText.style.color = 'rgb(25,25,25)';
                controlUI.style.backgroundColor = '#fff';

        controlText.style.fontFamily = 'Roboto,Arial,sans-serif';
        controlText.style.fontSize = '16px';
        controlText.style.lineHeight = '0px';
        controlText.style.padding = '9px';
        controlText.style.paddingRight = '5px';
        controlText.innerHTML = '<button onclick=\"removeLineSegment()\" class=\"undo\">undo</button>';
        controlUI.appendChild(controlText);

        // Setup the click event listeners: simply set the map to Chicago.
        controlUI.addEventListener('click', function() {
          map.setCenter(chicago);
        });

      }
    if(!!navigator.geolocation) {
        
  var map;
  var reset=\$('#resetPolygon');
  var geocoder;
  var polygonArray = [];
  var overlays = [];
var lastOverlay;
  var mapOptions = {
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP
          };
  map = new google.maps.Map(document.getElementById('map_canvas'), mapOptions);
  navigator.geolocation.getCurrentPosition(function(position) {
          
            var geolocate = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
            
            var infowindow = new google.maps.InfoWindow({
              map: map,
              position: geolocate,
              content:
                '<h4>You are here!!</h4>' +
                '<p>Latitude: ' + position.coords.latitude + '</p>' +
                '<p>Longitude: ' + position.coords.longitude + '</p>'
            });
            
            map.setCenter(geolocate);
            
          });      
            var centerControlDiv = document.createElement('div');
        var centerControl = new CenterControl(centerControlDiv, map);

        centerControlDiv.index = 1;
        map.controls[google.maps.ControlPosition.TOP_CENTER].push(centerControlDiv);  
} 
else
{
  document.getElementById('map_canvas').innerHTML = 'No Geolocation Support.';
}
var poly;

function initializeDrawer() {
    var input = document.getElementById('searchTextField');
  new google.maps.places.Autocomplete(input);

    var drawingManager = new google.maps.drawing.DrawingManager({
        drawingMode: google.maps.drawing.OverlayType.POLYGON,
        drawingControl: true,
        drawingControlOptions: {
            position: google.maps.ControlPosition.TOP_CENTER,
            drawingModes: [
    
            // google.maps.drawing.OverlayType.CIRCLE,
            google.maps.drawing.OverlayType.POLYGON
            ]
        },
        markerOptions: {
            icon: 'images/car-icon.png'
        },
        circleOptions: {
            fillColor: '#ffff00',
            fillOpacity: 1,
            strokeWeight: 5,
            clickable: false,
            editable: true,
            zIndex: 1
        },
        polygonOptions: {
            fillColor: '#BCDCF9',
            fillOpacity: 0.5,
            strokeWeight: 2,
            strokeColor: '#57ACF9',
            clickable: false,
            editable: true,
            draggab: 1,
            zIndex: 1

        }
    });
    drawingManager.setMap(map);
     google.maps.event.addListener(drawingManager, \"overlaycomplete\", function(event){
     overlayClickListener(event.overlay);
      overlays.push(event); // store reference to added overlay
              
    \$('#vertices').val(JSON.stringify(event.overlay.getPath().getArray()));
 
         event.overlay.overlayType = event.type;
    lastOverlay = event.overlay; // Save it
    drawingManager.setDrawingMode(null); // Return to 'hand' mode 

            });
       // SearchBox code
  // Create the search box and link it to the UI element.
  var input = document.getElementById('pac-input');
  var searchBox = new google.maps.places.SearchBox(input);
  map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

  // Bias the SearchBox results towards current map's viewport.
  map.addListener('bounds_changed', function() {
    searchBox.setBounds(map.getBounds());
  });

  var markers = [];
  // Listen for the event fired when the user selects a prediction and retrieve
  // more details for that place.
  searchBox.addListener('places_changed', function() {
    var places = searchBox.getPlaces();

    if (places.length == 0) {
      return;
    }

    // Clear out the old markers.
    markers.forEach(function(marker) {
      marker.setMap(null);
    });
    markers = [];

    // For each place, get the icon, name and location.
    var bounds = new google.maps.LatLngBounds();
    places.forEach(function(place) {
      if (!place.geometry) {
        console.log(\"Returned place contains no geometry\");
        return;
      }
      var icon = {
        url: place.icon,
        size: new google.maps.Size(71, 71),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(17, 34),
        scaledSize: new google.maps.Size(25, 25)
      };

      // Create a marker for each place.
      markers.push(new google.maps.Marker({
        map: map,
        icon: icon,
        title: place.name,
        position: place.geometry.location
      }));

      if (place.geometry.viewport) {
        // Only geocodes have viewport.
        bounds.union(place.geometry.viewport);
      } else {
        bounds.extend(place.geometry.location);
      }
    });
    map.fitBounds(bounds);
  });
        }


function overlayClickListener(overlay) {
    google.maps.event.addListener(overlay, \"mouseup\", function(event){
        \$('#vertices').val(JSON.stringify(overlay.getPath().getArray()));
    });
    }

// undo the last line segment of a polyline
function removeLineSegment() {
  
    var lastOverlay = overlays.length > 0 ? overlays[overlays.length - 1] : null;    
  if (lastOverlay && lastOverlay.type === \"polygon\") {
    var path = lastOverlay.overlay.getPath();
    path.pop(); // remove last line segment
  }
    if (lastOverlay && lastOverlay.type === \"polyline\") {
    var path = lastOverlay.overlay.getPath();
    path.pop(); // remove last line segment
  }
      if (lastOverlay && lastOverlay.type === \"rectangle\") {
    var path = lastOverlay.overlay.getPath();
    path.pop(); // remove last line segment
  }
}

// Initialize the drawer tool
google.maps.event.addDomListener(window, \"load\", initializeDrawer);
</script>
    </script>

    <script type=\"text/javascript\">
//  // This example creates a simple polygon representing the Bermuda Triangle.

//       function initMap() {
//                 var triangleCoords = [{\"lat\":19.315236306657976,\"lng\":72.85987742995746},{\"lat\":19.297739470248636,\"lng\":72.89180644607075},{\"lat\":19.278944487784745,\"lng\":72.89300807570942},{\"lat\":19.268087782413005,\"lng\":72.90073283767231},{\"lat\":19.261767876470657,\"lng\":72.87979014968403},{\"lat\":19.26549502996255,\"lng\":72.85695918654926},{\"lat\":19.280402796382898,\"lng\":72.83052333449848},{\"lat\":19.303895977968978,\"lng\":72.84820445632465}];

//         var map = new google.maps.Map(document.getElementById('map_canvas'), {
//           zoom: 5,
//           center: {lat: triangleCoords[0].lat, lng: triangleCoords[0].lng},
//           mapTypeId: 'terrain'
//         });

//         // Define the LatLng coordinates for the polygon's path.
//         var triangleCoords = [{\"lat\":19.315236306657976,\"lng\":72.85987742995746},{\"lat\":19.297739470248636,\"lng\":72.89180644607075},{\"lat\":19.278944487784745,\"lng\":72.89300807570942},{\"lat\":19.268087782413005,\"lng\":72.90073283767231},{\"lat\":19.261767876470657,\"lng\":72.87979014968403},{\"lat\":19.26549502996255,\"lng\":72.85695918654926},{\"lat\":19.280402796382898,\"lng\":72.83052333449848},{\"lat\":19.303895977968978,\"lng\":72.84820445632465}];
//         // Construct the polygon.
//         var bermudaTriangle = new google.maps.Polygon({
//           paths: triangleCoords,
//           strokeColor: '#FF0000',
//           strokeOpacity: 0.8,
//           strokeWeight: 2,
//           fillColor: '#FF0000',
//           fillOpacity: 0.35
//         });
//         bermudaTriangle.setMap(map);
//       }
</script>
{% endblock %}
", "AppBundle:Admin:AppManager/location.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/AppManager/location.html.twig");
    }
}

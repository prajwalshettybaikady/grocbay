<?php

/* @AppBundle/Themes/file.html.twig */
class __TwigTemplate_53561fd56181c13436de268a759b868b70e66c8c4fe7dcda257e2417d5e46576 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'form_row' => array($this, 'block_form_row'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8881a6f99292082f87b781dfb7a56f78a2ada01203b201422fed5d6cf35e32e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8881a6f99292082f87b781dfb7a56f78a2ada01203b201422fed5d6cf35e32e3->enter($__internal_8881a6f99292082f87b781dfb7a56f78a2ada01203b201422fed5d6cf35e32e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@AppBundle/Themes/file.html.twig"));

        // line 2
        $this->displayBlock('form_row', $context, $blocks);
        
        $__internal_8881a6f99292082f87b781dfb7a56f78a2ada01203b201422fed5d6cf35e32e3->leave($__internal_8881a6f99292082f87b781dfb7a56f78a2ada01203b201422fed5d6cf35e32e3_prof);

    }

    public function block_form_row($context, array $blocks = array())
    {
        $__internal_8875f216cec36da9195c116b2e2a8879cd414b60cbe81c17323a45698822639d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8875f216cec36da9195c116b2e2a8879cd414b60cbe81c17323a45698822639d->enter($__internal_8875f216cec36da9195c116b2e2a8879cd414b60cbe81c17323a45698822639d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 3
        ob_start();
        // line 4
        echo "
<div id=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "vars", array()), "id", array()), "html", null, true);
        echo "_form_group\" class=\"form-group ";
        echo (($this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors')) ? ("has-error") : (""));
        echo "\">

<div class=\"card\">
    <div class=\"card-body\">
        ";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget', array("attr" => array("class" => "dropify", "data-max-file-size" => "2M")));
        echo "
    </div>
</div>


  
  ";
        // line 15
        if ($this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors')) {
            // line 16
            echo "      ";
            ob_start();
            // line 17
            echo "        ";
            if (array_key_exists("errors", $context)) {
                // line 18
                echo "            ";
                if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
                    // line 19
                    echo "                ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
                    foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                        // line 20
                        echo "                <div class=\"alert alert-danger fade in\">
                    <a href=\"javascript:;\" class=\"close\" data-dismiss=\"alert\">&times;</a>
                    <strong>Error!</strong> ";
                        // line 22
                        echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                        echo ".
                </div>
                
                ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 26
                    echo "            ";
                }
                // line 27
                echo "        ";
            }
            // line 28
            echo "      ";
            echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
            // line 29
            echo "  ";
        }
        // line 30
        echo "  </div>

";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_8875f216cec36da9195c116b2e2a8879cd414b60cbe81c17323a45698822639d->leave($__internal_8875f216cec36da9195c116b2e2a8879cd414b60cbe81c17323a45698822639d_prof);

    }

    public function getTemplateName()
    {
        return "@AppBundle/Themes/file.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  100 => 30,  97 => 29,  94 => 28,  91 => 27,  88 => 26,  78 => 22,  74 => 20,  69 => 19,  66 => 18,  63 => 17,  60 => 16,  58 => 15,  49 => 9,  40 => 5,  37 => 4,  35 => 3,  23 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# app/Resources/views/template/fields.html.twig #}
{% block form_row %}
{% spaceless %}

<div id=\"{{ form.vars.id }}_form_group\" class=\"form-group {{ form_errors(form) ? \"has-error\" : \"\" }}\">

<div class=\"card\">
    <div class=\"card-body\">
        {{ form_widget(form,{'attr':{'class':'dropify','data-max-file-size':'2M'}}) }}
    </div>
</div>


  
  {% if form_errors(form) %}
      {% spaceless %}
        {% if errors is defined %}
            {% if errors|length > 0 %}
                {% for error in errors %}
                <div class=\"alert alert-danger fade in\">
                    <a href=\"javascript:;\" class=\"close\" data-dismiss=\"alert\">&times;</a>
                    <strong>Error!</strong> {{ error.message }}.
                </div>
                
                {% endfor %}
            {% endif %}
        {% endif %}
      {% endspaceless %}
  {% endif %}
  </div>

{% endspaceless %}
{% endblock form_row %}", "@AppBundle/Themes/file.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Themes/file.html.twig");
    }
}

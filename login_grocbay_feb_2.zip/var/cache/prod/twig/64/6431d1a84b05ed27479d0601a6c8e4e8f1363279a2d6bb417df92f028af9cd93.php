<?php

/* AppBundle:Admin:AppManager/viewLocation.html.twig */
class __TwigTemplate_8746aeee1884ce3ecc914bbb731d7235144396441bcf7a29f84819b73eff210e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:AppManager/viewLocation.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_887fd28b33691dfb5ac9e34760e12878d09f001986de32e6520d4d17d7e9875f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_887fd28b33691dfb5ac9e34760e12878d09f001986de32e6520d4d17d7e9875f->enter($__internal_887fd28b33691dfb5ac9e34760e12878d09f001986de32e6520d4d17d7e9875f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:AppManager/viewLocation.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_887fd28b33691dfb5ac9e34760e12878d09f001986de32e6520d4d17d7e9875f->leave($__internal_887fd28b33691dfb5ac9e34760e12878d09f001986de32e6520d4d17d7e9875f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_69c8c8b4a69833590e7ba2307f4f088fe1be61252ad6ecb95c0f40de8428a58d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_69c8c8b4a69833590e7ba2307f4f088fe1be61252ad6ecb95c0f40de8428a58d->enter($__internal_69c8c8b4a69833590e7ba2307f4f088fe1be61252ad6ecb95c0f40de8428a58d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "      <link href = \"https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css\"
         rel = \"stylesheet\">
      <script src = \"https://code.jquery.com/jquery-1.10.2.js\"></script>
      <script src = \"https://code.jquery.com/ui/1.10.4/jquery-ui.js\"></script>
      
      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
      <style type=\"text/css\">

   #map {
        height: 100%;
      }
      #type-selector {
        color: #fff;
        background-color: #4d90fe;
        padding: 5px 11px 0px 11px;
      }

      #type-selector label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }
      </style>
  
      


<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    
                    <h2>Manage Delivery Location | (";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["res"]) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "title", array()), "html", null, true);
            echo " )</h2>


<div id=\"map\" style=\" border: 2px solid #3872ac;\"></div>
</div>
<form method=\"post\"  action=\"";
            // line 49
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("update_location");
            echo "\" class=\"container\">

  <div class=\"row dis\"  style=\"\">
     <div class=\"col-12\">
      Name Of The Location  * <br>
    <input type=\"text\" name=\"location\"  required placeholder=\"enter name of location\"  class=\"form-control\"  value=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "title", array()), "html", null, true);
            echo "\" />
        <input type=\"hidden\" name=\"id\"  required placeholder=\"enter name of location\"  class=\"form-control\"  value=\"";
            // line 55
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "id", array()), "html", null, true);
            echo "\" />

  </div><hr>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Minimum Order Amount (Regular User)<br>
    <input type=\"number\" name=\"minnormal\" required placeholder=\"Minimum order amount\"  class=\"form-control\" 
    <input type=\"text\" name=\"location\"  required placeholder=\"enter name of location\"  class=\"form-control\"  value=\"";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "minimum_order_amount_normal", array()), "html", null, true);
            echo "\"  />
  </div>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Delivery Charge  (Regular User)<br>
    <input type=\"number\" name=\"delnormal\"  placeholder=\"delivery Charge\"  class=\"form-control\" value=\"";
            // line 65
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "delivery_charge_normal", array()), "html", null, true);
            echo "\" />
  </div>
<hr >
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Minimum Order Amount (Prime User)<br>
    <input type=\"text\" name=\"minprime\"  placeholder=\"Minimum Order Amount\"  class=\"form-control\"  value=\"";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "minimum_order_amount_prime", array()), "html", null, true);
            echo "\" />
  </div>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Delivery Charge  (Prime User)<br>
    <input type=\"text\" name=\"delprime\"  placeholder=\"Delivery Charge\"  class=\"form-control\"   value=\"";
            // line 74
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "delivery_charge_prime", array()), "html", null, true);
            echo "\"/>
  </div>

 <div class=\"col-4\" style=\"margin-top:20px;\">
      Minimum Order Amount (Express Delivery)<br>
    <input type=\"text\" name=\"minexpress\" required placeholder=\"Minimum Order Amount\"  class=\"form-control\"   value=\"";
            // line 79
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "minimum_order_amount_express", array()), "html", null, true);
            echo "\"/>
  </div>
   <div class=\"col-4\" style=\"margin-top:20px;\">
      Delivery Charge  (Express Delivery)<br>
    <input type=\"text\" name=\"delexpress\"  required placeholder=\"Delivery Charge\"  class=\"form-control\"  value=\"";
            // line 83
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "delivery_charge_express", array()), "html", null, true);
            echo "\"/>
  </div>
   <div class=\"col-4\" style=\"margin-top:20px;\">
    Duration (Express Delivery)<br>
    <input type=\"text\" name=\"duration\"  required placeholder=\"Delivery Duration\"  class=\"form-control\"  value=\"";
            // line 87
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "duration", array()), "html", null, true);
            echo "\"/>
  </div>

  <div class=\"col-12\">
    <input type=\"hidden\" name=\"vertices\" id=\"vertices\"  class=\"form-control\" required=\"\" value=\"";
            // line 91
            echo twig_escape_filter($this->env, $this->getAttribute($context["res"], "value", array()), "html", null, true);
            echo "\" /><br>
  </div>

    <div class=\"col-4\">
          <button type=\"submit\" class=\"btn btn-primary \" id=\"save\" style=\"margin-bottom:10px;\">Update</button><br>


  </div>
  </div>
</form>
</div>
</div>
</div>
 ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['res'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_69c8c8b4a69833590e7ba2307f4f088fe1be61252ad6ecb95c0f40de8428a58d->leave($__internal_69c8c8b4a69833590e7ba2307f4f088fe1be61252ad6ecb95c0f40de8428a58d_prof);

    }

    // line 108
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_586d269b7e5469e2bc96d3bb92f250e0a7ac5a1b6c0778a7d0070233e6e5f305 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_586d269b7e5469e2bc96d3bb92f250e0a7ac5a1b6c0778a7d0070233e6e5f305->enter($__internal_586d269b7e5469e2bc96d3bb92f250e0a7ac5a1b6c0778a7d0070233e6e5f305_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 109
        echo "
    
    <style type=\"text/css\">
 #tool{
  width:100%;
  display:block;
}
#map {
    height: 500px;
    width:100%;
    margin-right: 10px;
    padding: 0px;
}
#info{ 
  width:100%;
  float: left;
  height: 270px;
  overflow: scroll;
}
button.undo {
    border: navajowhite;
    background: #fff;
}
    </style>
    <script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
</script>
<script async defer
    src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyAqpNRcHCA-YkFDmY4v_TmOAeUltT3-ezY&callback=initMap\">
    </script>
    ";
        // line 142
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 143
            echo "   <!-- ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "title", array()), "html", null, true);
            echo "kjj -->
<!-- ";
            // line 144
            echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "value", array()), "js");
            echo " -->
    <script type=\"text/javascript\">
 // This example creates a simple polygon representing the Bermuda Triangle.

      function initMap() {
                var triangleCoords = ";
            // line 149
            echo $this->getAttribute($context["row"], "value", array());
            echo ";

        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 12,
          center: {lat: triangleCoords[0].lat, lng: triangleCoords[0].lng},
          mapTypeId: 'terrain'
        });

        // Define the LatLng coordinates for the polygon's path.
        var triangleCoords = ";
            // line 158
            echo $this->getAttribute($context["row"], "value", array());
            echo ";
        // Construct the polygon.
        var bermudaTriangle = new google.maps.Polygon({
          paths: triangleCoords,
          strokeColor: '#FF0000',
          strokeOpacity: 0.8,
          strokeWeight: 2,
          fillColor: '#FF0000',
          fillOpacity: 0.35,
          editable: true,
      clickable: true,

        });
        bermudaTriangle.setMap(map);
 //create the polygon
        var polygon = new google.maps.Polygon(bermudaTriangle);
        polygon.setMap(map);    

        //google.maps.event.addListener(polygon, \"dragend\", getPolygonCoords);
        google.maps.event.addListener(polygon.getPath(), \"insert_at\", getPolygonCoords);
        //google.maps.event.addListener(polygon.getPath(), \"remove_at\", getPolygonCoords);
        google.maps.event.addListener(polygon.getPath(), \"set_at\", getPolygonCoords);

        function getPolygonCoords() {
            var coordinates_poly = polygon.getPath().getArray();
            var newCoordinates_poly = [];
            for (var i = 0; i < coordinates_poly.length; i++){
                lat_poly = coordinates_poly[i].lat();
                lng_poly = coordinates_poly[i].lng();

                latlng_poly = [lat_poly, lng_poly];
                newCoordinates_poly.push(latlng_poly);
            }

            var str_coordinates_poly = JSON.stringify(polygon.getPath().getArray());

            document.getElementById('vertices').value = str_coordinates_poly;
        }

      }


</script>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_586d269b7e5469e2bc96d3bb92f250e0a7ac5a1b6c0778a7d0070233e6e5f305->leave($__internal_586d269b7e5469e2bc96d3bb92f250e0a7ac5a1b6c0778a7d0070233e6e5f305_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:AppManager/viewLocation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  262 => 158,  250 => 149,  242 => 144,  237 => 143,  233 => 142,  198 => 109,  192 => 108,  167 => 91,  160 => 87,  153 => 83,  146 => 79,  138 => 74,  131 => 70,  123 => 65,  116 => 61,  107 => 55,  103 => 54,  95 => 49,  83 => 44,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}

{% block body %}
      <link href = \"https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css\"
         rel = \"stylesheet\">
      <script src = \"https://code.jquery.com/jquery-1.10.2.js\"></script>
      <script src = \"https://code.jquery.com/ui/1.10.4/jquery-ui.js\"></script>
      
      <!-- Javascript -->
      <script>
         \$(function() {
            \$( \"#datepicker-13\" ).datepicker({
                  dateFormat:\"dd-mm-yy\",
            });

         });
      </script>
      <style type=\"text/css\">

   #map {
        height: 100%;
      }
      #type-selector {
        color: #fff;
        background-color: #4d90fe;
        padding: 5px 11px 0px 11px;
      }

      #type-selector label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }
      </style>
  
      


<div class=\"row\">
    <div class=\"col-12\">
        <div class=\"card\">
                <div class=\"card-body\">
                    
                    <h2>Manage Delivery Location | ({% for res in data %} {{ res.title }} )</h2>


<div id=\"map\" style=\" border: 2px solid #3872ac;\"></div>
</div>
<form method=\"post\"  action=\"{{ path('update_location') }}\" class=\"container\">

  <div class=\"row dis\"  style=\"\">
     <div class=\"col-12\">
      Name Of The Location  * <br>
    <input type=\"text\" name=\"location\"  required placeholder=\"enter name of location\"  class=\"form-control\"  value=\"{{ res.title  }}\" />
        <input type=\"hidden\" name=\"id\"  required placeholder=\"enter name of location\"  class=\"form-control\"  value=\"{{ res.id  }}\" />

  </div><hr>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Minimum Order Amount (Regular User)<br>
    <input type=\"number\" name=\"minnormal\" required placeholder=\"Minimum order amount\"  class=\"form-control\" 
    <input type=\"text\" name=\"location\"  required placeholder=\"enter name of location\"  class=\"form-control\"  value=\"{{ res.minimum_order_amount_normal  }}\"  />
  </div>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Delivery Charge  (Regular User)<br>
    <input type=\"number\" name=\"delnormal\"  placeholder=\"delivery Charge\"  class=\"form-control\" value=\"{{ res.delivery_charge_normal  }}\" />
  </div>
<hr >
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Minimum Order Amount (Prime User)<br>
    <input type=\"text\" name=\"minprime\"  placeholder=\"Minimum Order Amount\"  class=\"form-control\"  value=\"{{ res.minimum_order_amount_prime }}\" />
  </div>
   <div class=\"col-6\" style=\"margin-top:20px;\">
      Delivery Charge  (Prime User)<br>
    <input type=\"text\" name=\"delprime\"  placeholder=\"Delivery Charge\"  class=\"form-control\"   value=\"{{ res.delivery_charge_prime }}\"/>
  </div>

 <div class=\"col-4\" style=\"margin-top:20px;\">
      Minimum Order Amount (Express Delivery)<br>
    <input type=\"text\" name=\"minexpress\" required placeholder=\"Minimum Order Amount\"  class=\"form-control\"   value=\"{{ res.minimum_order_amount_express }}\"/>
  </div>
   <div class=\"col-4\" style=\"margin-top:20px;\">
      Delivery Charge  (Express Delivery)<br>
    <input type=\"text\" name=\"delexpress\"  required placeholder=\"Delivery Charge\"  class=\"form-control\"  value=\"{{ res.delivery_charge_express }}\"/>
  </div>
   <div class=\"col-4\" style=\"margin-top:20px;\">
    Duration (Express Delivery)<br>
    <input type=\"text\" name=\"duration\"  required placeholder=\"Delivery Duration\"  class=\"form-control\"  value=\"{{ res.duration }}\"/>
  </div>

  <div class=\"col-12\">
    <input type=\"hidden\" name=\"vertices\" id=\"vertices\"  class=\"form-control\" required=\"\" value=\"{{ res.value }}\" /><br>
  </div>

    <div class=\"col-4\">
          <button type=\"submit\" class=\"btn btn-primary \" id=\"save\" style=\"margin-bottom:10px;\">Update</button><br>


  </div>
  </div>
</form>
</div>
</div>
</div>
 {% endfor %}
{# end modal #}
{% endblock %}

{% block scripts %}

    
    <style type=\"text/css\">
 #tool{
  width:100%;
  display:block;
}
#map {
    height: 500px;
    width:100%;
    margin-right: 10px;
    padding: 0px;
}
#info{ 
  width:100%;
  float: left;
  height: 270px;
  overflow: scroll;
}
button.undo {
    border: navajowhite;
    background: #fff;
}
    </style>
    <script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script>
<script>
    \$(document).ready(function() {
        \$('#myTable').DataTable();
    });
</script>
<script async defer
    src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyAqpNRcHCA-YkFDmY4v_TmOAeUltT3-ezY&callback=initMap\">
    </script>
    {% for row in data %}
   <!-- {{ row.title }}kjj -->
<!-- {{ row.value|e('js')|raw }} -->
    <script type=\"text/javascript\">
 // This example creates a simple polygon representing the Bermuda Triangle.

      function initMap() {
                var triangleCoords = {{ row.value|raw }};

        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 12,
          center: {lat: triangleCoords[0].lat, lng: triangleCoords[0].lng},
          mapTypeId: 'terrain'
        });

        // Define the LatLng coordinates for the polygon's path.
        var triangleCoords = {{ row.value|raw }};
        // Construct the polygon.
        var bermudaTriangle = new google.maps.Polygon({
          paths: triangleCoords,
          strokeColor: '#FF0000',
          strokeOpacity: 0.8,
          strokeWeight: 2,
          fillColor: '#FF0000',
          fillOpacity: 0.35,
          editable: true,
      clickable: true,

        });
        bermudaTriangle.setMap(map);
 //create the polygon
        var polygon = new google.maps.Polygon(bermudaTriangle);
        polygon.setMap(map);    

        //google.maps.event.addListener(polygon, \"dragend\", getPolygonCoords);
        google.maps.event.addListener(polygon.getPath(), \"insert_at\", getPolygonCoords);
        //google.maps.event.addListener(polygon.getPath(), \"remove_at\", getPolygonCoords);
        google.maps.event.addListener(polygon.getPath(), \"set_at\", getPolygonCoords);

        function getPolygonCoords() {
            var coordinates_poly = polygon.getPath().getArray();
            var newCoordinates_poly = [];
            for (var i = 0; i < coordinates_poly.length; i++){
                lat_poly = coordinates_poly[i].lat();
                lng_poly = coordinates_poly[i].lng();

                latlng_poly = [lat_poly, lng_poly];
                newCoordinates_poly.push(latlng_poly);
            }

            var str_coordinates_poly = JSON.stringify(polygon.getPath().getArray());

            document.getElementById('vertices').value = str_coordinates_poly;
        }

      }


</script>
    {% endfor %}
{% endblock %}
", "AppBundle:Admin:AppManager/viewLocation.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/AppManager/viewLocation.html.twig");
    }
}

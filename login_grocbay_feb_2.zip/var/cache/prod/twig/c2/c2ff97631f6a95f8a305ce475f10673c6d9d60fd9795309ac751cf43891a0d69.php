<?php

/* AppBundle:Admin:Returns/returns.html.twig */
class __TwigTemplate_b4d9c36bea541c81ff47d034c32360ce9622d55264c9daa29fc3260e132f86b2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Returns/returns.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc92c1ea0f3a096861fc652bca9f88c2198b778363b2a477d8fedc48e33d6d2b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc92c1ea0f3a096861fc652bca9f88c2198b778363b2a477d8fedc48e33d6d2b->enter($__internal_dc92c1ea0f3a096861fc652bca9f88c2198b778363b2a477d8fedc48e33d6d2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Returns/returns.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dc92c1ea0f3a096861fc652bca9f88c2198b778363b2a477d8fedc48e33d6d2b->leave($__internal_dc92c1ea0f3a096861fc652bca9f88c2198b778363b2a477d8fedc48e33d6d2b_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_48c1a5ebadb0c8ca9f01eef9ffdc0f9a9515bfdc8fc36e08bac58a7e8312bd46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48c1a5ebadb0c8ca9f01eef9ffdc0f9a9515bfdc8fc36e08bac58a7e8312bd46->enter($__internal_48c1a5ebadb0c8ca9f01eef9ffdc0f9a9515bfdc8fc36e08bac58a7e8312bd46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "<link rel=\"stylesheet\" href=\"/assets/plugins/iCheck/all.css\">
<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked) {
         position: relative; 
         left: 0px; 
         opacity: 1; 
    }
</style>
";
        
        $__internal_48c1a5ebadb0c8ca9f01eef9ffdc0f9a9515bfdc8fc36e08bac58a7e8312bd46->leave($__internal_48c1a5ebadb0c8ca9f01eef9ffdc0f9a9515bfdc8fc36e08bac58a7e8312bd46_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_28e1588e68f727d926ab219e4a4814201afc528b090f979067ed441a2d050ebc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_28e1588e68f727d926ab219e4a4814201afc528b090f979067ed441a2d050ebc->enter($__internal_28e1588e68f727d926ab219e4a4814201afc528b090f979067ed441a2d050ebc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "
 <div class=\"layout-px-spacing\">
    <div class=\"row layout-top-spacing\">
        <div class=\"col-md-12 col-lg-12 col-xl-12 col-12\">
            <div class=\"card card-default\">
                <div class=\"card-body\">
                    <div class=\"col-xl-12 col-lg-12 col-md-12\">
                        <div class=\"mt-3 pl-3\">
                            <a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_return", array("id" => "0"));
        echo "\"> <span class=\"badge badge-classic badge-secondary mb-2 mr-2\">Not Assigned (";
        echo twig_escape_filter($this->env, ($context["notassigned"] ?? $this->getContext($context, "notassigned")), "html", null, true);
        echo ")</span></a>
                                <a href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_return", array("id" => "1"));
        echo "\"><span class=\"badge badge-classic badge-primary mb- mr-2\">Assigned (";
        echo twig_escape_filter($this->env, ($context["assigned"] ?? $this->getContext($context, "assigned")), "html", null, true);
        echo ")</span></a>
                            <a href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_return", array("id" => "2"));
        echo "\"><span class=\"badge badge-classic badge-info mb- mr-2\">Item Accepted (";
        echo twig_escape_filter($this->env, ($context["itemaccepted"] ?? $this->getContext($context, "itemaccepted")), "html", null, true);
        echo ")</span></a>
                            <a href=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_return", array("id" => "4"));
        echo "\"><span class=\"badge badge-classic badge-warning mb- mr-2\">Completed (";
        echo twig_escape_filter($this->env, ($context["completed"] ?? $this->getContext($context, "completed")), "html", null, true);
        echo ") </span></a>
                            <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_return", array("id" => "3"));
        echo "\"><span class=\"badge badge-classic badge-danger mb- mr-2\">Cancelled (";
        echo twig_escape_filter($this->env, ($context["cancelled"] ?? $this->getContext($context, "cancelled")), "html", null, true);
        echo ")</span></a>
                        </div>
                        <div class=\"table-responsive m-t-10\">
                            <table id=\"zero-config\" class=\"table table-bordered table-striped\">
                                <thead>
                                    <tr> 
                                        <th>#order</th>
                                        <th>Shipping</th>
                                        <th>Order Info</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["orders"] ?? $this->getContext($context, "orders")));
        foreach ($context['_seq'] as $context["_key"] => $context["order"]) {
            // line 39
            echo "                                        <tr>
                                        <td>
                                            <p>
                                                <a href=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_view_return", array("id" => $this->getAttribute($context["order"], "ref", array()))), "html", null, true);
            echo "\" title=\"Edit\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "ref", array()), "html", null, true);
            echo "</a><br>
                                                <small class=\"text-sm\">
                                                    ";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "userName", array()), "html", null, true);
            echo "<br>
                                                    ";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "mobileNo", array()), "html", null, true);
            echo "<br>
                                                </small>
                                            </p>
                                        </td>
                                        <td>
                                            <div>
                                                <small><strong class=\"text-muted\">Address</strong><br>
                                                ";
            // line 52
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "address", array()), "html", null, true);
            echo "</small>
                                            </div>
                                        </td>
                                        <td>
                                        
                                            <small>
                                                ";
            // line 58
            if (($this->getAttribute($context["order"], "mode", array()) == 0)) {
                // line 59
                echo "                                                    <span class=\"badge badge-danger\">Mode : Return</span> 
                                                ";
            } else {
                // line 61
                echo "                                                    <span class=\"badge badge-secondary\">Mode : Exchange</span>
                                                ";
            }
            // line 63
            echo "                                                <br/>
                                                <span class=\"badge outline-badge-info mt-2\"> Status :  ";
            // line 64
            if (($this->getAttribute($context["order"], "status", array()) == 0)) {
                // line 65
                echo "                                                Not Assigned
                                                    
                                                ";
            }
            // line 68
            echo "                                                ";
            if (($this->getAttribute($context["order"], "status", array()) == 1)) {
                // line 69
                echo "                                                Assigned 
                                                ";
            }
            // line 71
            echo "                                                ";
            if (($this->getAttribute($context["order"], "status", array()) == 2)) {
                // line 72
                echo "                                                    Item Accepted 
                                                ";
            }
            // line 74
            echo "                                                ";
            if (($this->getAttribute($context["order"], "status", array()) == 3)) {
                // line 75
                echo "                                                Return Cancelled
                                                ";
            }
            // line 76
            echo "</span>
                                                                                        <p>  Reason :";
            // line 77
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute($context["order"], "reason", array())), "html", null, true);
            echo "<br>
                                                                                            time and date :";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "date", array()), "html", null, true);
            echo " | ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "deliveryTime", array()), "html", null, true);
            echo "<br>
                                                </p><br>
                                        </td>
                                        <td><a class=\"btn btn-primary btn-sm\" href=\"";
            // line 81
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_view_return", array("id" => $this->getAttribute($context["order"], "ref", array()))), "html", null, true);
            echo "\">
                                            <i class=\"fa fa-edit\"></i>
                                        </a></td>
                                    </tr>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['order'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 86
        echo "                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class=\"modal fade\" id=\"todoShowListItem\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
        <div class=\"modal-content\">
            <div class=\"modal-body\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x close\" data-dismiss=\"modal\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg>
                <div class=\"compose-box\">
                    <div class=\"compose-content\">
                        <h5 class=\"task-heading\"></h5>
                        <p class=\"task-text\"></p>
                    </div>
                </div>
            </div>
            <div class=\"modal-footer\">
                <button class=\"btn\" data-dismiss=\"modal\"> <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-trash\"><polyline points=\"3 6 5 6 21 6\"></polyline><path d=\"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2\"></path></svg> Close</button>
            </div>
        </div>
    </div>
</div>          
<!-- Modal -->
<div class=\"modal fade\" id=\"addTaskModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
    <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
        <div class=\"modal-content\">
            <div class=\"modal-body\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x close\" data-dismiss=\"modal\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg>
                <div class=\"compose-box\">
                    <div class=\"compose-content\" id=\"addTaskModalTitle\">
                        <h5 class=\"\">Add Task</h5>
                        <form>
                            <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <div class=\"d-flex mail-to mb-4\">
                                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-edit-3 flaticon-notes\"><path d=\"M12 20h9\"></path><path d=\"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z\"></path></svg>
                                        <div class=\"w-100\">
                                            <input id=\"task\" type=\"text\" placeholder=\"Task\" class=\"form-control form-control-sm\" name=\"task\">
                                            <span class=\"validation-text\"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class=\"d-flex  mail-subject mb-4\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-file-text flaticon-menu-list\"><path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"></path><polyline points=\"14 2 14 8 20 8\"></polyline><line x1=\"16\" y1=\"13\" x2=\"8\" y2=\"13\"></line><line x1=\"16\" y1=\"17\" x2=\"8\" y2=\"17\"></line><polyline points=\"10 9 9 9 8 9\"></polyline></svg>
                                <div class=\"w-100\">
                                    <div id=\"taskdescription\" class=\"\"></div>
                                    <span class=\"validation-text\"></span>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
            <div class=\"modal-footer\">
                <button class=\"btn\" data-dismiss=\"modal\"><i class=\"flaticon-cancel-12\"></i> Discard</button>
                <button class=\"btn add-tsk\">Add Task</button>
                <button class=\"btn edit-tsk\">Save</button>
            </div>
        </div>
    </div>
</div>
";
        
        $__internal_28e1588e68f727d926ab219e4a4814201afc528b090f979067ed441a2d050ebc->leave($__internal_28e1588e68f727d926ab219e4a4814201afc528b090f979067ed441a2d050ebc_prof);

    }

    // line 158
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_cc53879cd446de5558b64715a5213628b38f9ce2adeee294085513b6f5280b68 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc53879cd446de5558b64715a5213628b38f9ce2adeee294085513b6f5280b68->enter($__internal_cc53879cd446de5558b64715a5213628b38f9ce2adeee294085513b6f5280b68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 159
        echo "
";
        // line 161
        echo "<script src=\"/assets/plugins/table/datatable/datatables.js\"></script>
<script src=\"/assets/plugins/iCheck/icheck.min.js\"></script>
<script>
    \$(document).ready(function() {
        //\$('#myTable').DataTable();
        //iCheck for checkbox and radio inputs
        if(\$('input[type=\"checkbox\"], input[type=\"radio\"]').length)
            \$('input[type=\"checkbox\"], input[type=\"radio\"]').iCheck({
                checkboxClass: 'icheckbox_minimal-blue',
                radioClass: 'iradio_minimal-blue'
            });

            c1 = \$('#zero-config').DataTable({
            \"oLanguage\": {
                    \"oPaginate\": { \"sPrevious\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-left\"><line x1=\"19\" y1=\"12\" x2=\"5\" y2=\"12\"></line><polyline points=\"12 19 5 12 12 5\"></polyline></svg>', \"sNext\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-right\"><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line><polyline points=\"12 5 19 12 12 19\"></polyline></svg>' },
                    \"sInfo\": \"Showing page _PAGE_ of _PAGES_\",
                    \"sSearch\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-search\"><circle cx=\"11\" cy=\"11\" r=\"8\"></circle><line x1=\"21\" y1=\"21\" x2=\"16.65\" y2=\"16.65\"></line></svg>',
                    \"sSearchPlaceholder\": \"Search...\",
                \"sLengthMenu\": \"Results :  _MENU_\",
                },
                \"stripeClasses\": [],
                \"lengthMenu\": [7, 10, 20, 50],
                \"pageLength\": 7,
                \"bLengthChange\": false,
            });
            multiCheck(c1);

        });
</script>
";
        
        $__internal_cc53879cd446de5558b64715a5213628b38f9ce2adeee294085513b6f5280b68->leave($__internal_cc53879cd446de5558b64715a5213628b38f9ce2adeee294085513b6f5280b68_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Returns/returns.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  307 => 161,  304 => 159,  298 => 158,  221 => 86,  210 => 81,  202 => 78,  198 => 77,  195 => 76,  191 => 75,  188 => 74,  184 => 72,  181 => 71,  177 => 69,  174 => 68,  169 => 65,  167 => 64,  164 => 63,  160 => 61,  156 => 59,  154 => 58,  145 => 52,  135 => 45,  131 => 44,  124 => 42,  119 => 39,  115 => 38,  97 => 25,  91 => 24,  85 => 23,  79 => 22,  73 => 21,  63 => 13,  57 => 12,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@AppBundle/Admin/base.html.twig' %}
{% block styles %}
<link rel=\"stylesheet\" href=\"/assets/plugins/iCheck/all.css\">
<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked) {
         position: relative; 
         left: 0px; 
         opacity: 1; 
    }
</style>
{% endblock %}
{% block body %}

 <div class=\"layout-px-spacing\">
    <div class=\"row layout-top-spacing\">
        <div class=\"col-md-12 col-lg-12 col-xl-12 col-12\">
            <div class=\"card card-default\">
                <div class=\"card-body\">
                    <div class=\"col-xl-12 col-lg-12 col-md-12\">
                        <div class=\"mt-3 pl-3\">
                            <a href=\"{{ path('restaurant_return',{'id':'0'}) }}\"> <span class=\"badge badge-classic badge-secondary mb-2 mr-2\">Not Assigned ({{notassigned}})</span></a>
                                <a href=\"{{ path('restaurant_return',{'id':'1'}) }}\"><span class=\"badge badge-classic badge-primary mb- mr-2\">Assigned ({{assigned}})</span></a>
                            <a href=\"{{ path('restaurant_return',{'id':'2'}) }}\"><span class=\"badge badge-classic badge-info mb- mr-2\">Item Accepted ({{itemaccepted}})</span></a>
                            <a href=\"{{ path('restaurant_return',{'id':'4'}) }}\"><span class=\"badge badge-classic badge-warning mb- mr-2\">Completed ({{completed}}) </span></a>
                            <a href=\"{{ path('restaurant_return',{'id':'3'}) }}\"><span class=\"badge badge-classic badge-danger mb- mr-2\">Cancelled ({{cancelled}})</span></a>
                        </div>
                        <div class=\"table-responsive m-t-10\">
                            <table id=\"zero-config\" class=\"table table-bordered table-striped\">
                                <thead>
                                    <tr> 
                                        <th>#order</th>
                                        <th>Shipping</th>
                                        <th>Order Info</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {% for order in orders %}
                                        <tr>
                                        <td>
                                            <p>
                                                <a href=\"{{ path('restaurant_view_return',{'id':order.ref}) }}\" title=\"Edit\">{{ order.ref }}</a><br>
                                                <small class=\"text-sm\">
                                                    {{ order.userName }}<br>
                                                    {{ order.mobileNo }}<br>
                                                </small>
                                            </p>
                                        </td>
                                        <td>
                                            <div>
                                                <small><strong class=\"text-muted\">Address</strong><br>
                                                {{ order.address }}</small>
                                            </div>
                                        </td>
                                        <td>
                                        
                                            <small>
                                                {% if order.mode == 0 %}
                                                    <span class=\"badge badge-danger\">Mode : Return</span> 
                                                {% else %}
                                                    <span class=\"badge badge-secondary\">Mode : Exchange</span>
                                                {% endif %}
                                                <br/>
                                                <span class=\"badge outline-badge-info mt-2\"> Status :  {% if order.status == 0 %}
                                                Not Assigned
                                                    
                                                {% endif %}
                                                {% if order.status == 1 %}
                                                Assigned 
                                                {% endif %}
                                                {% if order.status == 2 %}
                                                    Item Accepted 
                                                {% endif %}
                                                {% if order.status == 3 %}
                                                Return Cancelled
                                                {% endif %}</span>
                                                                                        <p>  Reason :{{ order.reason |upper }}<br>
                                                                                            time and date :{{ order.date }} | {{ order.deliveryTime }}<br>
                                                </p><br>
                                        </td>
                                        <td><a class=\"btn btn-primary btn-sm\" href=\"{{ path('restaurant_view_return',{'id':order.ref}) }}\">
                                            <i class=\"fa fa-edit\"></i>
                                        </a></td>
                                    </tr>
                                    {% endfor %}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class=\"modal fade\" id=\"todoShowListItem\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
        <div class=\"modal-content\">
            <div class=\"modal-body\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x close\" data-dismiss=\"modal\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg>
                <div class=\"compose-box\">
                    <div class=\"compose-content\">
                        <h5 class=\"task-heading\"></h5>
                        <p class=\"task-text\"></p>
                    </div>
                </div>
            </div>
            <div class=\"modal-footer\">
                <button class=\"btn\" data-dismiss=\"modal\"> <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-trash\"><polyline points=\"3 6 5 6 21 6\"></polyline><path d=\"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2\"></path></svg> Close</button>
            </div>
        </div>
    </div>
</div>          
<!-- Modal -->
<div class=\"modal fade\" id=\"addTaskModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"addTaskModalTitle\" aria-hidden=\"true\">
    <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">
        <div class=\"modal-content\">
            <div class=\"modal-body\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x close\" data-dismiss=\"modal\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line></svg>
                <div class=\"compose-box\">
                    <div class=\"compose-content\" id=\"addTaskModalTitle\">
                        <h5 class=\"\">Add Task</h5>
                        <form>
                            <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <div class=\"d-flex mail-to mb-4\">
                                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-edit-3 flaticon-notes\"><path d=\"M12 20h9\"></path><path d=\"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z\"></path></svg>
                                        <div class=\"w-100\">
                                            <input id=\"task\" type=\"text\" placeholder=\"Task\" class=\"form-control form-control-sm\" name=\"task\">
                                            <span class=\"validation-text\"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class=\"d-flex  mail-subject mb-4\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-file-text flaticon-menu-list\"><path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"></path><polyline points=\"14 2 14 8 20 8\"></polyline><line x1=\"16\" y1=\"13\" x2=\"8\" y2=\"13\"></line><line x1=\"16\" y1=\"17\" x2=\"8\" y2=\"17\"></line><polyline points=\"10 9 9 9 8 9\"></polyline></svg>
                                <div class=\"w-100\">
                                    <div id=\"taskdescription\" class=\"\"></div>
                                    <span class=\"validation-text\"></span>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
            <div class=\"modal-footer\">
                <button class=\"btn\" data-dismiss=\"modal\"><i class=\"flaticon-cancel-12\"></i> Discard</button>
                <button class=\"btn add-tsk\">Add Task</button>
                <button class=\"btn edit-tsk\">Save</button>
            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block scripts %}

{# <script src=\"/assets/plugins/datatables/jquery.dataTables.min.js\"></script> #}
<script src=\"/assets/plugins/table/datatable/datatables.js\"></script>
<script src=\"/assets/plugins/iCheck/icheck.min.js\"></script>
<script>
    \$(document).ready(function() {
        //\$('#myTable').DataTable();
        //iCheck for checkbox and radio inputs
        if(\$('input[type=\"checkbox\"], input[type=\"radio\"]').length)
            \$('input[type=\"checkbox\"], input[type=\"radio\"]').iCheck({
                checkboxClass: 'icheckbox_minimal-blue',
                radioClass: 'iradio_minimal-blue'
            });

            c1 = \$('#zero-config').DataTable({
            \"oLanguage\": {
                    \"oPaginate\": { \"sPrevious\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-left\"><line x1=\"19\" y1=\"12\" x2=\"5\" y2=\"12\"></line><polyline points=\"12 19 5 12 12 5\"></polyline></svg>', \"sNext\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-arrow-right\"><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line><polyline points=\"12 5 19 12 12 19\"></polyline></svg>' },
                    \"sInfo\": \"Showing page _PAGE_ of _PAGES_\",
                    \"sSearch\": '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-search\"><circle cx=\"11\" cy=\"11\" r=\"8\"></circle><line x1=\"21\" y1=\"21\" x2=\"16.65\" y2=\"16.65\"></line></svg>',
                    \"sSearchPlaceholder\": \"Search...\",
                \"sLengthMenu\": \"Results :  _MENU_\",
                },
                \"stripeClasses\": [],
                \"lengthMenu\": [7, 10, 20, 50],
                \"pageLength\": 7,
                \"bLengthChange\": false,
            });
            multiCheck(c1);

        });
</script>
{% endblock %}", "AppBundle:Admin:Returns/returns.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Returns/returns.html.twig");
    }
}

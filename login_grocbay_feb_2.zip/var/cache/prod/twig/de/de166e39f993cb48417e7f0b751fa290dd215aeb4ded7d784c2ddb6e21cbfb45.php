<?php

/* @AppBundle/Admin/Properties/leftSideBarAdmin.html.twig */
class __TwigTemplate_efc458cb0ecff6b1fe2ffcf8f6e502bd41123d76264095d9a885ca13cdf14e21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1f67f255f7ff392733511c807cf9cbcbd6378c3edf1aff3231139f54500299b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f67f255f7ff392733511c807cf9cbcbd6378c3edf1aff3231139f54500299b6->enter($__internal_1f67f255f7ff392733511c807cf9cbcbd6378c3edf1aff3231139f54500299b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@AppBundle/Admin/Properties/leftSideBarAdmin.html.twig"));

        // line 1
        echo "<!--  BEGIN MAIN CONTAINER  -->
<div class=\"main-container\" id=\"container\">
    <div class=\"overlay\"></div>
    <div class=\"cs-overlay\"></div>
    <div class=\"search-overlay\"></div>
    <div class=\"sidebar-wrapper sidebar-theme\">         
        <nav id=\"compactSidebar\">
            <div class=\"theme-logo\">
                <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("developer_dashboard");
        echo "\">
                    <img src=\"/assets/assets/img/logo.png\" class=\"navbar-logo\" alt=\"Grocbay\">
                </a>
            </div>
            <ul class=\"menu-categories\">
                <li class=\"menu active\">
                    <a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("developer_dashboard");
        echo "\" data-active=\"true\" class=\"menu-toggle\">
                        <div class=\"base-menu\">
                            <div class=\"base-icons\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-home\"><path d=\"M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path><polyline points=\"9 22 9 12 15 12 15 22\"></polyline></svg>
                            </div>
                        </div>
                    </a>
                    <div class=\"tooltip\"><span>Home</span></div>
                </li>
         
                <li class=\"menu menubar\">
                    <a href=\"#products\" data-active=\"false\" class=\"menu-toggle\">
                        <div class=\"base-menu\">
                            <div class=\"base-icons\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-zap\"><polygon points=\"13 2 3 14 12 14 11 22 21 10 12 10 13 2\"></polygon></svg>
                            </div>
                        </div>
                    </a>
                    <div class=\"tooltip\"><span>Products</span></div>
                </li>

               

                <li class=\"menu menubar\">
                    <a href=\"#analytics\" data-active=\"false\" class=\"menu-toggle\">
                        <div class=\"base-menu\">
                            <div class=\"base-icons\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-pie-chart\"><path d=\"M21.21 15.89A10 10 0 1 1 8 2.83\"></path><path d=\"M22 12A10 10 0 0 0 12 2v10z\"></path></svg>
                            </div>
                        </div>
                    </a>
                    <div class=\"tooltip\"><span>Analytics</span></div>
                </li>
              
                <li class=\"menu menubar\">
                    <a href=\"#settings\" data-active=\"false\" class=\"menu-toggle\">
                        <div class=\"base-menu\">
                            <div class=\"base-icons\">
                                <!--svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-file\"><path d=\"M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z\"></path><polyline points=\"13 2 13 9 20 9\"></polyline></svg-->

                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-settings\"><circle cx=\"12\" cy=\"12\" r=\"3\"></circle><path d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z\"></path></svg>
                            </div>
                        </div>
                    </a>
                    <div class=\"tooltip\"><span>Settings</span></div>
                </li>
            </ul>
        </nav>

            <div id=\"compact_submenuSidebar\" class=\"submenu-sidebar\">
              

                <div class=\"submenu\" id=\"products\">
                    <div class=\"category-info\">
                        <h5>Products</h5>
                        <!--p>Lorem ipsum dolor sit amet sed incididunt ut labore et dolore magna aliqua.</p-->
                    </div>
                    <ul class=\"submenu-list\" data-parent-element=\"#products\"> 
                        <li>
                            <a href=\"";
        // line 74
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_view_menu_item");
        echo "\">
                                <i class=\"fa fa fa-bars\"></i> Manage Products </a>
                        </li>
                       
            <li><a href=\"";
        // line 78
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("bulk_import");
        echo "\"><i class=\"fa fa-cloud-download\"></i>Import/Export Products</a></li>
        
                            <li>
                            <a href=\"";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("manage_category");
        echo "\">
                                <i class=\"fa fa-server\"></i> Manage Categories </a>
                        </li>

                                 <li><a href=\"";
        // line 85
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("brand_list");
        echo "\"><i class=\"fa fa-shopping-bag\"></i>Manage Brands</a></li>

                    </ul>
                </div>

              
                <div class=\"submenu\" id=\"analytics\">
                    <div class=\"category-info\">
                        <h5>Analytics</h5>
                        <!--p>Lorem ipsum dolor sit amet sed incididunt ut labore et dolore magna aliqua.</p-->
                    </div>
                    <ul class=\"submenu-list\" data-parent-element=\"#analytics\">
                             <li><a href=\"";
        // line 97
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("branch_report");
        echo "\"><i class=\"fa fa-bar-chart\"></i>Branch Report</a></li>
                               
                    </ul>
                </div>


         

                <div class=\"submenu\" id=\"settings\">
                    <div class=\"category-info\">
                        <h5>Settings</h5>
                        <!--p>Lorem ipsum dolor sit amet sed incididunt ut labore et dolore magna aliqua.</p-->
                    </div>
                    <ul class=\"submenu-list\" data-parent-element=\"#settings\">
                     
          <li class=\"sub-submenu\">
                            <a role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#Inventory\" aria-expanded=\"false\"><div>   <i class=\"fa fa-cog\"></i>
                            General Setting</div> <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-right\"><polyline points=\"9 18 15 12 9 6\"></polyline></svg></a>
                            <ul id=\"Inventory\" class=\"collapse\" data-parent=\"#compact_submenuSidebar\" style=\"\">
                           <li><a href=\"";
        // line 116
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_shop_details");
        echo "\">Basic Setting</a></li>
                              <li><a href=\"";
        // line 117
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sms_manage_template");
        echo "\">SMS API Keys</a></li>
                              <li><a href=\"";
        // line 118
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("site_setting");
        echo "\">Site Settings</a></li>
                            </ul>
                        </li>
<li> <a  href=\"";
        // line 121
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_list");
        echo "\" aria-expanded=\"false\"><span class=\"hide-menu\"><i class=\"fa fa-university\"></i>Manage Stores</span></a></li>

                       <li>
                        <li class=\"sub-submenu\">
                            <a role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#returns\" aria-expanded=\"false\"><div>
                                <i class=\"fa fa-user\"></i>

                            Accounts & Permissions</div> <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-right\"><polyline points=\"9 18 15 12 9 6\"></polyline></svg></a>
                            <ul id=\"returns\" class=\"collapse\" data-parent=\"#compact_submenuSidebar\" style=\"\">
                              <li><a href=\"";
        // line 130
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_list");
        echo "\">All User</a></li>
                                        <li><a href=\"";
        // line 131
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_create");
        echo "\">Create New User</a></li>
                               
                            </ul>
                        </li>
 <li class=\"sub-submenu\">
                            <a role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#pages\" aria-expanded=\"false\"><div>
                                <i class=\"fa fa-book\"></i>Pages</div> <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-right\"><polyline points=\"9 18 15 12 9 6\"></polyline></svg></a>
                            <ul id=\"pages\" class=\"collapse\" data-parent=\"#compact_submenuSidebar\" style=\"\">
                                <li><a href=\"";
        // line 139
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pages_about");
        echo "\">About Us</a></li>
                               <li><a href=\"";
        // line 140
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pages_privacy");
        echo "\">Privacy And Policy
</a></li>
                              <li><a href=\"";
        // line 142
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pages_terms");
        echo "\">Terms and Conditions</a></li>
<li><a href=\"";
        // line 143
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pages_refund");
        echo "\">Refund Policy</a></li>
<li> <a  href=\"";
        // line 144
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pages_return");
        echo "\" aria-expanded=\"false\"><span class=\"hide-menu\">Return Policy</span></a></li>
                                <li><a href=\"";
        // line 145
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pages_wallet");
        echo "\">Wallet Policy</a></li>
                               
                            </ul>
                        </li>
                     
                            <li><a href=\"";
        // line 150
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create_membership");
        echo "\">
                              <i class=\"fa fa-truck\"></i>
                           Membership Setting</a>
                        </li>
                  
                    </ul>
                </div>
            </div>
        </div>";
        
        $__internal_1f67f255f7ff392733511c807cf9cbcbd6378c3edf1aff3231139f54500299b6->leave($__internal_1f67f255f7ff392733511c807cf9cbcbd6378c3edf1aff3231139f54500299b6_prof);

    }

    public function getTemplateName()
    {
        return "@AppBundle/Admin/Properties/leftSideBarAdmin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  230 => 150,  222 => 145,  218 => 144,  214 => 143,  210 => 142,  205 => 140,  201 => 139,  190 => 131,  186 => 130,  174 => 121,  168 => 118,  164 => 117,  160 => 116,  138 => 97,  123 => 85,  116 => 81,  110 => 78,  103 => 74,  41 => 15,  32 => 9,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!--  BEGIN MAIN CONTAINER  -->
<div class=\"main-container\" id=\"container\">
    <div class=\"overlay\"></div>
    <div class=\"cs-overlay\"></div>
    <div class=\"search-overlay\"></div>
    <div class=\"sidebar-wrapper sidebar-theme\">         
        <nav id=\"compactSidebar\">
            <div class=\"theme-logo\">
                <a href=\"{{ path('developer_dashboard') }}\">
                    <img src=\"/assets/assets/img/logo.png\" class=\"navbar-logo\" alt=\"Grocbay\">
                </a>
            </div>
            <ul class=\"menu-categories\">
                <li class=\"menu active\">
                    <a href=\"{{ path('developer_dashboard') }}\" data-active=\"true\" class=\"menu-toggle\">
                        <div class=\"base-menu\">
                            <div class=\"base-icons\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-home\"><path d=\"M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path><polyline points=\"9 22 9 12 15 12 15 22\"></polyline></svg>
                            </div>
                        </div>
                    </a>
                    <div class=\"tooltip\"><span>Home</span></div>
                </li>
         
                <li class=\"menu menubar\">
                    <a href=\"#products\" data-active=\"false\" class=\"menu-toggle\">
                        <div class=\"base-menu\">
                            <div class=\"base-icons\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-zap\"><polygon points=\"13 2 3 14 12 14 11 22 21 10 12 10 13 2\"></polygon></svg>
                            </div>
                        </div>
                    </a>
                    <div class=\"tooltip\"><span>Products</span></div>
                </li>

               

                <li class=\"menu menubar\">
                    <a href=\"#analytics\" data-active=\"false\" class=\"menu-toggle\">
                        <div class=\"base-menu\">
                            <div class=\"base-icons\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-pie-chart\"><path d=\"M21.21 15.89A10 10 0 1 1 8 2.83\"></path><path d=\"M22 12A10 10 0 0 0 12 2v10z\"></path></svg>
                            </div>
                        </div>
                    </a>
                    <div class=\"tooltip\"><span>Analytics</span></div>
                </li>
              
                <li class=\"menu menubar\">
                    <a href=\"#settings\" data-active=\"false\" class=\"menu-toggle\">
                        <div class=\"base-menu\">
                            <div class=\"base-icons\">
                                <!--svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-file\"><path d=\"M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z\"></path><polyline points=\"13 2 13 9 20 9\"></polyline></svg-->

                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-settings\"><circle cx=\"12\" cy=\"12\" r=\"3\"></circle><path d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z\"></path></svg>
                            </div>
                        </div>
                    </a>
                    <div class=\"tooltip\"><span>Settings</span></div>
                </li>
            </ul>
        </nav>

            <div id=\"compact_submenuSidebar\" class=\"submenu-sidebar\">
              

                <div class=\"submenu\" id=\"products\">
                    <div class=\"category-info\">
                        <h5>Products</h5>
                        <!--p>Lorem ipsum dolor sit amet sed incididunt ut labore et dolore magna aliqua.</p-->
                    </div>
                    <ul class=\"submenu-list\" data-parent-element=\"#products\"> 
                        <li>
                            <a href=\"{{ path('restaurant_view_menu_item')}}\">
                                <i class=\"fa fa fa-bars\"></i> Manage Products </a>
                        </li>
                       
            <li><a href=\"{{ path('bulk_import')}}\"><i class=\"fa fa-cloud-download\"></i>Import/Export Products</a></li>
        
                            <li>
                            <a href=\"{{ path('manage_category')}}\">
                                <i class=\"fa fa-server\"></i> Manage Categories </a>
                        </li>

                                 <li><a href=\"{{ path('brand_list') }}\"><i class=\"fa fa-shopping-bag\"></i>Manage Brands</a></li>

                    </ul>
                </div>

              
                <div class=\"submenu\" id=\"analytics\">
                    <div class=\"category-info\">
                        <h5>Analytics</h5>
                        <!--p>Lorem ipsum dolor sit amet sed incididunt ut labore et dolore magna aliqua.</p-->
                    </div>
                    <ul class=\"submenu-list\" data-parent-element=\"#analytics\">
                             <li><a href=\"{{ path('branch_report') }}\"><i class=\"fa fa-bar-chart\"></i>Branch Report</a></li>
                               
                    </ul>
                </div>


         

                <div class=\"submenu\" id=\"settings\">
                    <div class=\"category-info\">
                        <h5>Settings</h5>
                        <!--p>Lorem ipsum dolor sit amet sed incididunt ut labore et dolore magna aliqua.</p-->
                    </div>
                    <ul class=\"submenu-list\" data-parent-element=\"#settings\">
                     
          <li class=\"sub-submenu\">
                            <a role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#Inventory\" aria-expanded=\"false\"><div>   <i class=\"fa fa-cog\"></i>
                            General Setting</div> <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-right\"><polyline points=\"9 18 15 12 9 6\"></polyline></svg></a>
                            <ul id=\"Inventory\" class=\"collapse\" data-parent=\"#compact_submenuSidebar\" style=\"\">
                           <li><a href=\"{{ path('app_shop_details') }}\">Basic Setting</a></li>
                              <li><a href=\"{{ path('sms_manage_template') }}\">SMS API Keys</a></li>
                              <li><a href=\"{{ path('site_setting') }}\">Site Settings</a></li>
                            </ul>
                        </li>
<li> <a  href=\"{{ path('restaurant_list') }}\" aria-expanded=\"false\"><span class=\"hide-menu\"><i class=\"fa fa-university\"></i>Manage Stores</span></a></li>

                       <li>
                        <li class=\"sub-submenu\">
                            <a role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#returns\" aria-expanded=\"false\"><div>
                                <i class=\"fa fa-user\"></i>

                            Accounts & Permissions</div> <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-right\"><polyline points=\"9 18 15 12 9 6\"></polyline></svg></a>
                            <ul id=\"returns\" class=\"collapse\" data-parent=\"#compact_submenuSidebar\" style=\"\">
                              <li><a href=\"{{ path('admin_list') }}\">All User</a></li>
                                        <li><a href=\"{{ path('admin_create') }}\">Create New User</a></li>
                               
                            </ul>
                        </li>
 <li class=\"sub-submenu\">
                            <a role=\"menu\" class=\"collapsed\" data-toggle=\"collapse\" data-target=\"#pages\" aria-expanded=\"false\"><div>
                                <i class=\"fa fa-book\"></i>Pages</div> <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-chevron-right\"><polyline points=\"9 18 15 12 9 6\"></polyline></svg></a>
                            <ul id=\"pages\" class=\"collapse\" data-parent=\"#compact_submenuSidebar\" style=\"\">
                                <li><a href=\"{{ path('pages_about') }}\">About Us</a></li>
                               <li><a href=\"{{ path('pages_privacy') }}\">Privacy And Policy
</a></li>
                              <li><a href=\"{{ path('pages_terms') }}\">Terms and Conditions</a></li>
<li><a href=\"{{ path('pages_refund') }}\">Refund Policy</a></li>
<li> <a  href=\"{{ path('pages_return') }}\" aria-expanded=\"false\"><span class=\"hide-menu\">Return Policy</span></a></li>
                                <li><a href=\"{{ path('pages_wallet') }}\">Wallet Policy</a></li>
                               
                            </ul>
                        </li>
                     
                            <li><a href=\"{{ path('create_membership') }}\">
                              <i class=\"fa fa-truck\"></i>
                           Membership Setting</a>
                        </li>
                  
                    </ul>
                </div>
            </div>
        </div>", "@AppBundle/Admin/Properties/leftSideBarAdmin.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Properties/leftSideBarAdmin.html.twig");
    }
}

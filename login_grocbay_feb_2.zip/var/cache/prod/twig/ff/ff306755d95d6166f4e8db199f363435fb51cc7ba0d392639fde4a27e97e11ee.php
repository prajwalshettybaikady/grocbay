<?php

/* AppBundle:Admin:AppManager/createMembership.html.twig */
class __TwigTemplate_34e08326015f3f3ee72a3aa892fb003fdeb5effd4ed314dc88ec1c64544b7848 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:AppManager/createMembership.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c818c8800acc162a3d02fb08a34e6466970162d770aca89583c35730684d2385 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c818c8800acc162a3d02fb08a34e6466970162d770aca89583c35730684d2385->enter($__internal_c818c8800acc162a3d02fb08a34e6466970162d770aca89583c35730684d2385_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:AppManager/createMembership.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c818c8800acc162a3d02fb08a34e6466970162d770aca89583c35730684d2385->leave($__internal_c818c8800acc162a3d02fb08a34e6466970162d770aca89583c35730684d2385_prof);

    }

    // line 3
    public function block_styles($context, array $blocks = array())
    {
        $__internal_b20e7b3fb5e19d5d4587dfa2d415049cb5c52f85eace09c270df1eaeaf972486 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b20e7b3fb5e19d5d4587dfa2d415049cb5c52f85eace09c270df1eaeaf972486->enter($__internal_b20e7b3fb5e19d5d4587dfa2d415049cb5c52f85eace09c270df1eaeaf972486_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 4
        echo "

<link href=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.css\" rel=\"stylesheet\">

";
        
        $__internal_b20e7b3fb5e19d5d4587dfa2d415049cb5c52f85eace09c270df1eaeaf972486->leave($__internal_b20e7b3fb5e19d5d4587dfa2d415049cb5c52f85eace09c270df1eaeaf972486_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_e97de1262dfc88d4d59f195436c7e06cd6d17aa3a3a794cba9a6698b3ced85bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e97de1262dfc88d4d59f195436c7e06cd6d17aa3a3a794cba9a6698b3ced85bb->enter($__internal_e97de1262dfc88d4d59f195436c7e06cd6d17aa3a3a794cba9a6698b3ced85bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
    <div class=\"row\">
            <div class=\"col-lg-12\">
                <div class=\"card card-outline-info\">
                    ";
        // line 19
        echo ($context["msg"] ?? $this->getContext($context, "msg"));
        echo "
                    <div class=\"card-header\">
                        <h4 class=\"m-b-0 text-white\">Create Membership Form</h4>
                    </div>
                    <div class=\"card-body\">
<form method=\"post\" action=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_membership");
        echo "\" enctype=\"multipart/form-data\">       
          <div class=\"form-body\">     
          ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["parent"] ?? $this->getContext($context, "parent")));
        foreach ($context['_seq'] as $context["_key"] => $context["pdata"]) {
            // line 27
            echo "       ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pdata'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "                  
                                <div class=\"row p-t-20\">                                
                                    <div class=\"col-md-12\">
                                        <div class=\"row\">
                                            <div class=\"col-md-12\">
                                                <div class=\"form-group\">
                                                <label for=\"name\">Membership Plan*</label>
                                                  <input type=\"text\" name=\"membership_plan\" class=\"form-control\" value=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["parent"] ?? $this->getContext($context, "parent")), 0, array()), "name", array()), "html", null, true);
        echo "\">
                                                </div>
                                                </div>
                                          </div>
                                                                      
                                         <div class=\"row\">
                                            <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                <label for=\"name\">Display Image *[Before Purchasing Membership]</label>
                                                  <input type=\"file\" name=\"image\" class=\"dropify\" data-default-file=\"/uploads/";
        // line 44
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["parent"] ?? $this->getContext($context, "parent")), 0, array()), "avator", array()), "html", null, true);
        echo "\">
                                                </div>
                                                </div>
                                                 <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                <label for=\"name\">Post Image *[After Purchasing Membership]</label>
                                                  <input type=\"file\" name=\"post_img\" class=\"dropify\" data-default-file=\"/uploads/";
        // line 50
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["parent"] ?? $this->getContext($context, "parent")), 0, array()), "post_image", array()), "html", null, true);
        echo "\">
                                                </div>
                                                </div>
                                            <!--/span-->
                                           
                                            <!--/span-->
                                        </div>      
                                       <div class=\"col-md-12\">
                                                <div class=\"form-group\">
                                                  <label for=\"name\">Description *</label>
                                                  <textarea class=\"form-control\" name=\"description\" rows=\"6\">";
        // line 60
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["parent"] ?? $this->getContext($context, "parent")), 0, array()), "description", array()), "html", null, true);
        echo "</textarea>
                                                </div>
                                            </div>
                                </div>
                                <!--/row-->
                      
                             
                             
                            </div>

        <table class=\"table\" id=\"addvar\">
        <tr>
        <th>Plan Name</th>
        <th>Duration</th>
        <th>Mrp</th>
        <th>Discounted Price</th>       
        <th></th>
          <th><button class=\"btn btn-primary btn-sm\" id=\"variationAdd\" type=\"button\">Add Variation</button></th>
        </tr>
          ";
        // line 79
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["child"] ?? $this->getContext($context, "child")));
        foreach ($context['_seq'] as $context["_key"] => $context["cdata"]) {
            // line 80
            echo "           <tr>
    <td><input type=\"hidden\"  class=\"form-control\" value=\"";
            // line 81
            echo twig_escape_filter($this->env, $this->getAttribute($context["cdata"], "id", array()), "html", null, true);
            echo "\" name=\"id[]\"><input type=\"text\"  class=\"form-control\" placeholder=\"plan name\" name=\"plan_name[]\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["cdata"], "name", array()), "html", null, true);
            echo "\"></td>
        <td>
            <select class=\"form-control\" style=\"width:100px\"  name=\"duration[]\">
                <option value=\"1\" ";
            // line 84
            if (($this->getAttribute($context["cdata"], "duration", array()) == "1")) {
                echo " selected ";
            }
            echo ">1 Month</option>
                 <option value=\"2\" ";
            // line 85
            if (($this->getAttribute($context["cdata"], "duration", array()) == "2")) {
                echo " selected ";
            }
            echo ">2 Month</option>
                  <option value=\"3\" ";
            // line 86
            if (($this->getAttribute($context["cdata"], "duration", array()) == "3")) {
                echo " selected ";
            }
            echo ">3 Month</option>
                   <option value=\"4\" ";
            // line 87
            if (($this->getAttribute($context["cdata"], "duration", array()) == "4")) {
                echo " selected ";
            }
            echo ">4 Month</option>
                    <option value=\"5\" ";
            // line 88
            if (($this->getAttribute($context["cdata"], "duration", array()) == "5")) {
                echo " selected ";
            }
            echo ">5 Month</option>
                      <option value=\"6\" ";
            // line 89
            if (($this->getAttribute($context["cdata"], "duration", array()) == "6")) {
                echo " selected ";
            }
            echo ">6 Month</option>
                       <option value=\"7\" ";
            // line 90
            if (($this->getAttribute($context["cdata"], "duration", array()) == "7")) {
                echo " selected ";
            }
            echo ">7 Month</option>
                        <option value=\"8\" ";
            // line 91
            if (($this->getAttribute($context["cdata"], "duration", array()) == "8")) {
                echo " selected ";
            }
            echo ">8 Month</option>
                        <option value=\"9\" ";
            // line 92
            if (($this->getAttribute($context["cdata"], "duration", array()) == "9")) {
                echo " selected ";
            }
            echo ">9 Month</option>
                        <option value=\"10\" ";
            // line 93
            if (($this->getAttribute($context["cdata"], "duration", array()) == "10")) {
                echo " selected ";
            }
            echo ">10 Month</option>
                        <option value=\"11\" ";
            // line 94
            if (($this->getAttribute($context["cdata"], "duration", array()) == "11")) {
                echo " selected ";
            }
            echo ">11 Month</option>
                        <option value=\"12\" ";
            // line 95
            if (($this->getAttribute($context["cdata"], "duration", array()) == "12")) {
                echo " selected ";
            }
            echo ">12 Month</option>

        </select>
    </td>
    <td><input type=\"text\"  class=\"form-control\" placeholder=\"Mrp\"  name=\"mrp[]\"  value=\"";
            // line 99
            echo twig_escape_filter($this->env, $this->getAttribute($context["cdata"], "price", array()), "html", null, true);
            echo "\"></td>
    <td><input type=\"text\"  class=\"form-control\" placeholder=\"Discounted Price\"  name=\"discounted[]\"  value=\"";
            // line 100
            echo twig_escape_filter($this->env, $this->getAttribute($context["cdata"], "discounted_price", array()), "html", null, true);
            echo "\"></td>
    <td>  <a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td>


          </tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cdata'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 106
        echo "<!--           <tr>
    <td><input type=\"hidden\"  class=\"form-control\" value=\"new\" name=\"id[]\"><input type=\"text\"  class=\"form-control\" placeholder=\"plan name\" name=\"plan_name[]\"></td>
        <td>
            <select class=\"form-control\" style=\"width:100px\"  name=\"duration[]\">
                <option value=\"1\">1 Month</option>
                 <option value=\"2\">2 Month</option>
                  <option value=\"3\">3 Month</option>
                   <option value=\"4\">4 Month</option>
                    <option value=\"5\">5 Month</option>
                      <option value=\"6\">6 Month</option>
                       <option value=\"7\">7 Month</option>
                        <option value=\"8\">8 Month</option>
                        <option value=\"9\">9 Month</option>
                        <option value=\"10\">10 Month</option>
                        <option value=\"11\">11 Month</option>
                        <option value=\"12\">12 Month</option>

        </select>
    </td>
    <td><input type=\"text\"  class=\"form-control\" placeholder=\"Mrp\"  name=\"mrp[]\"></td>
    <td><input type=\"text\"  class=\"form-control\" placeholder=\"Discounted Price\"  name=\"discounted[]\"></td>
    <td>  <a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td>


          </tr>
 -->
     
           </table>

</li>
        </ul>
      </div>
    </div>

<script>

      \$(document).ready(function(){
        var count=0;
      \$('#variationAdd').click(function(){
// alert('add');
\$('#addvar').append('</tr><tr><td><input type=\"hidden\"  class=\"form-control\" value=\"new\" name=\"id[]\"><input type=\"text\"  class=\"form-control\" placeholder=\"plan name\" name=\"plan_name[]\"></td><td><select class=\"form-control\" style=\"width:100px\"  name=\"duration[]\"><option value=\"1\">1 Month</option><option value=\"2\">2 Month</option><option value=\"3\">3 Month</option><option value=\"4\">4 Month</option><option value=\"5\">5 Month</option><option value=\"6\">6 Month</option><option value=\"7\">7 Month</option><option value=\"8\">8 Month</option><option value=\"9\">9 Month</option><option value=\"10\">10 Month</option><option value=\"11\">11 Month</option><option value=\"12\">12 Month</option></select></td><td><input type=\"text\" class=\"form-control\" placeholder=\"Mrp\"  name=\"mrp[]\"></td><td><input type=\"text\"  class=\"form-control\" placeholder=\"Discounted Price\"  name=\"discounted[]\"></td><td><a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td> </tr>');

count++;
});

// console.log(items)
//       });

      });


       function removeVariant(obj){
// \$(this).attr(\"data-usr\" , '');

        \$(obj).parent().parent().remove();

    }
    function save(x,itemname,id,parent)
    {
var id=fixed(x,itemname,id,parent);

    }

     // PICK THE VALUES FROM EACH TEXTBOX WHEN \"SUBMIT\" BUTTON IS CLICKED.
   
</script>







                            <div class=\"form-actions\">
                                <button type=\"submit\" class=\"btn btn-success\"> <i class=\"fa fa-check\"></i>Add</button>
                                <button type=\"button\" class=\"btn btn-inverse\">Cancel</button>
                            </div>
                       </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->

";
        
        $__internal_e97de1262dfc88d4d59f195436c7e06cd6d17aa3a3a794cba9a6698b3ced85bb->leave($__internal_e97de1262dfc88d4d59f195436c7e06cd6d17aa3a3a794cba9a6698b3ced85bb_prof);

    }

    // line 191
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_c7e8ea7742847fd07c67d6285f77608c1ffe4d278617bb776001c5ad6951c455 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7e8ea7742847fd07c67d6285f77608c1ffe4d278617bb776001c5ad6951c455->enter($__internal_c7e8ea7742847fd07c67d6285f77608c1ffe4d278617bb776001c5ad6951c455_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 192
        echo "
<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>

<script>
    
        \$(\"input[type='checkbox']\").bootstrapSwitch();
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

";
        
        $__internal_c7e8ea7742847fd07c67d6285f77608c1ffe4d278617bb776001c5ad6951c455->leave($__internal_c7e8ea7742847fd07c67d6285f77608c1ffe4d278617bb776001c5ad6951c455_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:AppManager/createMembership.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  360 => 192,  354 => 191,  263 => 106,  251 => 100,  247 => 99,  238 => 95,  232 => 94,  226 => 93,  220 => 92,  214 => 91,  208 => 90,  202 => 89,  196 => 88,  190 => 87,  184 => 86,  178 => 85,  172 => 84,  164 => 81,  161 => 80,  157 => 79,  135 => 60,  122 => 50,  113 => 44,  101 => 35,  92 => 28,  86 => 27,  82 => 26,  77 => 24,  69 => 19,  59 => 11,  53 => 10,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}

{% block styles %}


<link href=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.css\" rel=\"stylesheet\">

{% endblock %}

{% block body %}

    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
    <div class=\"row\">
            <div class=\"col-lg-12\">
                <div class=\"card card-outline-info\">
                    {{ msg | raw }}
                    <div class=\"card-header\">
                        <h4 class=\"m-b-0 text-white\">Create Membership Form</h4>
                    </div>
                    <div class=\"card-body\">
<form method=\"post\" action=\"{{ path('add_membership') }}\" enctype=\"multipart/form-data\">       
          <div class=\"form-body\">     
          {% for pdata in parent %}
       {% endfor %}
                  
                                <div class=\"row p-t-20\">                                
                                    <div class=\"col-md-12\">
                                        <div class=\"row\">
                                            <div class=\"col-md-12\">
                                                <div class=\"form-group\">
                                                <label for=\"name\">Membership Plan*</label>
                                                  <input type=\"text\" name=\"membership_plan\" class=\"form-control\" value=\"{{ parent.0.name }}\">
                                                </div>
                                                </div>
                                          </div>
                                                                      
                                         <div class=\"row\">
                                            <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                <label for=\"name\">Display Image *[Before Purchasing Membership]</label>
                                                  <input type=\"file\" name=\"image\" class=\"dropify\" data-default-file=\"/uploads/{{ parent.0.avator }}\">
                                                </div>
                                                </div>
                                                 <div class=\"col-md-6\">
                                                <div class=\"form-group\">
                                                <label for=\"name\">Post Image *[After Purchasing Membership]</label>
                                                  <input type=\"file\" name=\"post_img\" class=\"dropify\" data-default-file=\"/uploads/{{ parent.0.post_image }}\">
                                                </div>
                                                </div>
                                            <!--/span-->
                                           
                                            <!--/span-->
                                        </div>      
                                       <div class=\"col-md-12\">
                                                <div class=\"form-group\">
                                                  <label for=\"name\">Description *</label>
                                                  <textarea class=\"form-control\" name=\"description\" rows=\"6\">{{ parent.0.description }}</textarea>
                                                </div>
                                            </div>
                                </div>
                                <!--/row-->
                      
                             
                             
                            </div>

        <table class=\"table\" id=\"addvar\">
        <tr>
        <th>Plan Name</th>
        <th>Duration</th>
        <th>Mrp</th>
        <th>Discounted Price</th>       
        <th></th>
          <th><button class=\"btn btn-primary btn-sm\" id=\"variationAdd\" type=\"button\">Add Variation</button></th>
        </tr>
          {% for cdata in child %}
           <tr>
    <td><input type=\"hidden\"  class=\"form-control\" value=\"{{ cdata.id }}\" name=\"id[]\"><input type=\"text\"  class=\"form-control\" placeholder=\"plan name\" name=\"plan_name[]\" value=\"{{ cdata.name }}\"></td>
        <td>
            <select class=\"form-control\" style=\"width:100px\"  name=\"duration[]\">
                <option value=\"1\" {% if cdata.duration == '1' %} selected {% endif %}>1 Month</option>
                 <option value=\"2\" {% if cdata.duration == '2' %} selected {% endif %}>2 Month</option>
                  <option value=\"3\" {% if cdata.duration == '3' %} selected {% endif %}>3 Month</option>
                   <option value=\"4\" {% if cdata.duration == '4' %} selected {% endif %}>4 Month</option>
                    <option value=\"5\" {% if cdata.duration == '5' %} selected {% endif %}>5 Month</option>
                      <option value=\"6\" {% if cdata.duration == '6' %} selected {% endif %}>6 Month</option>
                       <option value=\"7\" {% if cdata.duration == '7' %} selected {% endif %}>7 Month</option>
                        <option value=\"8\" {% if cdata.duration == '8' %} selected {% endif %}>8 Month</option>
                        <option value=\"9\" {% if cdata.duration == '9' %} selected {% endif %}>9 Month</option>
                        <option value=\"10\" {% if cdata.duration == '10' %} selected {% endif %}>10 Month</option>
                        <option value=\"11\" {% if cdata.duration == '11' %} selected {% endif %}>11 Month</option>
                        <option value=\"12\" {% if cdata.duration == '12' %} selected {% endif %}>12 Month</option>

        </select>
    </td>
    <td><input type=\"text\"  class=\"form-control\" placeholder=\"Mrp\"  name=\"mrp[]\"  value=\"{{ cdata.price }}\"></td>
    <td><input type=\"text\"  class=\"form-control\" placeholder=\"Discounted Price\"  name=\"discounted[]\"  value=\"{{ cdata.discounted_price }}\"></td>
    <td>  <a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td>


          </tr>
{% endfor %}
<!--           <tr>
    <td><input type=\"hidden\"  class=\"form-control\" value=\"new\" name=\"id[]\"><input type=\"text\"  class=\"form-control\" placeholder=\"plan name\" name=\"plan_name[]\"></td>
        <td>
            <select class=\"form-control\" style=\"width:100px\"  name=\"duration[]\">
                <option value=\"1\">1 Month</option>
                 <option value=\"2\">2 Month</option>
                  <option value=\"3\">3 Month</option>
                   <option value=\"4\">4 Month</option>
                    <option value=\"5\">5 Month</option>
                      <option value=\"6\">6 Month</option>
                       <option value=\"7\">7 Month</option>
                        <option value=\"8\">8 Month</option>
                        <option value=\"9\">9 Month</option>
                        <option value=\"10\">10 Month</option>
                        <option value=\"11\">11 Month</option>
                        <option value=\"12\">12 Month</option>

        </select>
    </td>
    <td><input type=\"text\"  class=\"form-control\" placeholder=\"Mrp\"  name=\"mrp[]\"></td>
    <td><input type=\"text\"  class=\"form-control\" placeholder=\"Discounted Price\"  name=\"discounted[]\"></td>
    <td>  <a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td>


          </tr>
 -->
     
           </table>

</li>
        </ul>
      </div>
    </div>

<script>

      \$(document).ready(function(){
        var count=0;
      \$('#variationAdd').click(function(){
// alert('add');
\$('#addvar').append('</tr><tr><td><input type=\"hidden\"  class=\"form-control\" value=\"new\" name=\"id[]\"><input type=\"text\"  class=\"form-control\" placeholder=\"plan name\" name=\"plan_name[]\"></td><td><select class=\"form-control\" style=\"width:100px\"  name=\"duration[]\"><option value=\"1\">1 Month</option><option value=\"2\">2 Month</option><option value=\"3\">3 Month</option><option value=\"4\">4 Month</option><option value=\"5\">5 Month</option><option value=\"6\">6 Month</option><option value=\"7\">7 Month</option><option value=\"8\">8 Month</option><option value=\"9\">9 Month</option><option value=\"10\">10 Month</option><option value=\"11\">11 Month</option><option value=\"12\">12 Month</option></select></td><td><input type=\"text\" class=\"form-control\" placeholder=\"Mrp\"  name=\"mrp[]\"></td><td><input type=\"text\"  class=\"form-control\" placeholder=\"Discounted Price\"  name=\"discounted[]\"></td><td><a class=\"btn btn-danger \" style=\"float:right;\"  onclick=\"removeVariant(this)\" data-toggle=\"collapse\" data-parent=\"#col\"  href=\"#\" ><i class=\"fa fa-trash\"></i></a></td> </tr>');

count++;
});

// console.log(items)
//       });

      });


       function removeVariant(obj){
// \$(this).attr(\"data-usr\" , '');

        \$(obj).parent().parent().remove();

    }
    function save(x,itemname,id,parent)
    {
var id=fixed(x,itemname,id,parent);

    }

     // PICK THE VALUES FROM EACH TEXTBOX WHEN \"SUBMIT\" BUTTON IS CLICKED.
   
</script>







                            <div class=\"form-actions\">
                                <button type=\"submit\" class=\"btn btn-success\"> <i class=\"fa fa-check\"></i>Add</button>
                                <button type=\"button\" class=\"btn btn-inverse\">Cancel</button>
                            </div>
                       </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->

{% endblock %}
{% block scripts %}

<script src=\"/assets/plugins/bootstrap-switch/bootstrap-switch.min.js\"></script>

<script>
    
        \$(\"input[type='checkbox']\").bootstrapSwitch();
        \$(document).ready(function() {
            // Basic
            \$('.dropify').dropify();
            // Translated
            \$('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
    
            // Used events
            var drEvent = \$('#input-file-events').dropify();
    
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm(\"Do you really want to delete \\\"\" + element.file.name + \"\\\" ?\");
            });
    
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
    
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
    
            var drDestroy = \$('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            \$('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        });
</script>

{% endblock %}
", "AppBundle:Admin:AppManager/createMembership.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/AppManager/createMembership.html.twig");
    }
}

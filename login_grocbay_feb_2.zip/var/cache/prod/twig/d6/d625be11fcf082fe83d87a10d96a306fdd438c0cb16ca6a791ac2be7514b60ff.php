<?php

/* AppBundle:Admin:Pages/AppHome.html.twig */
class __TwigTemplate_59ae8441f404c430d5edf94c9f34b4b421f60d7b9591768bd8d6fcea996497a6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@AppBundle/Admin/base.html.twig", "AppBundle:Admin:Pages/AppHome.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@AppBundle/Admin/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b13498cfcf8877507a5cb9c86bddc7bf94623cd3edf13c4c1207308fdbe9394 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b13498cfcf8877507a5cb9c86bddc7bf94623cd3edf13c4c1207308fdbe9394->enter($__internal_0b13498cfcf8877507a5cb9c86bddc7bf94623cd3edf13c4c1207308fdbe9394_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Admin:Pages/AppHome.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0b13498cfcf8877507a5cb9c86bddc7bf94623cd3edf13c4c1207308fdbe9394->leave($__internal_0b13498cfcf8877507a5cb9c86bddc7bf94623cd3edf13c4c1207308fdbe9394_prof);

    }

    // line 2
    public function block_styles($context, array $blocks = array())
    {
        $__internal_1471964bb1f2419ba49de09bc629d5e5a3efcb96575052113003e4e0dc53c992 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1471964bb1f2419ba49de09bc629d5e5a3efcb96575052113003e4e0dc53c992->enter($__internal_1471964bb1f2419ba49de09bc629d5e5a3efcb96575052113003e4e0dc53c992_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 3
        echo "
<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked){
        position: relative;
        left: auto;
        opacity: 1;
    }
     .fstElement { font-size: 9px; }
            .fstToggleBtn { min-width: 16.5em; }

            .submitBtn { display: none; }

            .fstMultipleMode { display: block; }
            .fstMultipleMode .fstControls { width: 100%; }

</style>
";
        
        $__internal_1471964bb1f2419ba49de09bc629d5e5a3efcb96575052113003e4e0dc53c992->leave($__internal_1471964bb1f2419ba49de09bc629d5e5a3efcb96575052113003e4e0dc53c992_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_9feb5895b3202aff669e1b3d69aed77256616518406f2a313b04dce378eaecc2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9feb5895b3202aff669e1b3d69aed77256616518406f2a313b04dce378eaecc2->enter($__internal_9feb5895b3202aff669e1b3d69aed77256616518406f2a313b04dce378eaecc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 21
        echo "    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
            
                <form method=\"post\" action=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create_home_page");
        echo "\">
                <div class=\"card-body\">
<center><h4>App Home Page Setting</h4></center>
                    <div class=\"col-md-12\">
                        <div class=\"form-group\">
                         <label for=\"reg\"><input type=\"text\" name=\"featured_label\" required=\"\" placeholder=\"featured label\" class=\"form-control\" value=\"";
        // line 30
        echo twig_escape_filter($this->env, ($context["featured_label"] ?? $this->getContext($context, "featured_label")), "html", null, true);
        echo "\"></label>
                          <select class=\"multipleSelect\" multiple name=\"featured[]\">
  ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["MenuItem"] ?? $this->getContext($context, "MenuItem")));
        foreach ($context['_seq'] as $context["_key"] => $context["me"]) {
            // line 33
            echo "  <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["me"], "id", array()), "html", null, true);
            echo "\" ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["f"] ?? $this->getContext($context, "f")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == $this->getAttribute($context["me"], "id", array()))) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["me"], "itemName", array()), "html", null, true);
            echo "</option>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['me'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "    </select>
                        </div>
                        <div class=\"form-group\">
                         <label for=\"reg\"><input type=\"text\" name=\"discount_label\" required=\"\" placeholder=\"discount label\" class=\"form-control\" value=\"";
        // line 38
        echo twig_escape_filter($this->env, ($context["discount_label"] ?? $this->getContext($context, "discount_label")), "html", null, true);
        echo "\"></label>
                                 <select class=\"multipleSelect\" multiple name=\"discount[]\">
  ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["MenuItem"] ?? $this->getContext($context, "MenuItem")));
        foreach ($context['_seq'] as $context["_key"] => $context["me"]) {
            // line 41
            echo "  <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["me"], "id", array()), "html", null, true);
            echo "\"  ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["d"] ?? $this->getContext($context, "d")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == $this->getAttribute($context["me"], "id", array()))) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo " >";
            echo twig_escape_filter($this->env, $this->getAttribute($context["me"], "itemName", array()), "html", null, true);
            echo "</option>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['me'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "    </select>
                        </div>     

                  <center><b>Featured Sub Categories 1</b></center>  
                  <div class=\"form-group\">
                         <label for=\"reg\"><input type=\"text\" name=\"category_label\" required=\"\" placeholder=\"Sub Category Label\" class=\"form-control\" value=\"";
        // line 48
        echo twig_escape_filter($this->env, ($context["category_label"] ?? $this->getContext($context, "category_label")), "html", null, true);
        echo "\"></label>
                         <select class=\"multipleSelect\" multiple name=\"category[]\">
                          ";
        // line 50
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["category_list"] ?? $this->getContext($context, "category_list")));
        foreach ($context['_seq'] as $context["_key"] => $context["me"]) {
            // line 51
            echo "                          <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["me"], "id", array()), "html", null, true);
            echo "\"  ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["category"] ?? $this->getContext($context, "category")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == $this->getAttribute($context["me"], "id", array()))) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo " >";
            echo twig_escape_filter($this->env, $this->getAttribute($context["me"], "categoryName", array()), "html", null, true);
            echo "</option>
                           ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['me'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "                             </select>
                        </div>       
                  <center><b>Featured Sub Categories 2</b></center>  
                  <div class=\"form-group\">
                         <label for=\"reg\"><input type=\"text\" name=\"category_label_one\" required=\"\" placeholder=\"Sub Category Label\" class=\"form-control\" value=\"";
        // line 57
        echo twig_escape_filter($this->env, ($context["category_one_label"] ?? $this->getContext($context, "category_one_label")), "html", null, true);
        echo "\"></label>
                         <select class=\"multipleSelect\" multiple name=\"category_one[]\">
                          ";
        // line 59
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["category_list"] ?? $this->getContext($context, "category_list")));
        foreach ($context['_seq'] as $context["_key"] => $context["me"]) {
            // line 60
            echo "                          <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["me"], "id", array()), "html", null, true);
            echo "\"  ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["category_one"] ?? $this->getContext($context, "category_one")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == $this->getAttribute($context["me"], "id", array()))) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo " >";
            echo twig_escape_filter($this->env, $this->getAttribute($context["me"], "categoryName", array()), "html", null, true);
            echo "</option>
                           ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['me'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 62
        echo "                             </select>
                        </div> 
                   <center><b>Featured Sub Categories 3</b></center>  
                  <div class=\"form-group\">
                         <label for=\"reg\"><input type=\"text\" name=\"category_label_two\" required=\"\" placeholder=\"Sub Category Label\" class=\"form-control\" value=\"";
        // line 66
        echo twig_escape_filter($this->env, ($context["category_two_label"] ?? $this->getContext($context, "category_two_label")), "html", null, true);
        echo "\"></label>
                         <select class=\"multipleSelect\" multiple name=\"category_two[]\">
                          ";
        // line 68
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["category_list"] ?? $this->getContext($context, "category_list")));
        foreach ($context['_seq'] as $context["_key"] => $context["me"]) {
            // line 69
            echo "                          <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["me"], "id", array()), "html", null, true);
            echo "\"  ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["category_two"] ?? $this->getContext($context, "category_two")));
            foreach ($context['_seq'] as $context["_key"] => $context["fe"]) {
                echo " ";
                if (($context["fe"] == $this->getAttribute($context["me"], "id", array()))) {
                    echo " selected ";
                }
                echo " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo " >";
            echo twig_escape_filter($this->env, $this->getAttribute($context["me"], "categoryName", array()), "html", null, true);
            echo "</option>
                           ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['me'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 71
        echo "                             </select>
                        </div>                    
                        <div class=\"clearfix\"></div>
                        <button type=\"submit\" class=\"btn btn-primary pull-left\">Save</button><br>
  </div>
                      
                </div>
            </form>
            </div>
        </div>
    </div>
";
        
        $__internal_9feb5895b3202aff669e1b3d69aed77256616518406f2a313b04dce378eaecc2->leave($__internal_9feb5895b3202aff669e1b3d69aed77256616518406f2a313b04dce378eaecc2_prof);

    }

    // line 84
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_52de40e64864bf91edac2d1fde09031450bbd11005ee6ed882198b5ead4f8f73 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52de40e64864bf91edac2d1fde09031450bbd11005ee6ed882198b5ead4f8f73->enter($__internal_52de40e64864bf91edac2d1fde09031450bbd11005ee6ed882198b5ead4f8f73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 85
        echo "

<script>
    
   
        </script>

";
        
        $__internal_52de40e64864bf91edac2d1fde09031450bbd11005ee6ed882198b5ead4f8f73->leave($__internal_52de40e64864bf91edac2d1fde09031450bbd11005ee6ed882198b5ead4f8f73_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Admin:Pages/AppHome.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  298 => 85,  292 => 84,  274 => 71,  250 => 69,  246 => 68,  241 => 66,  235 => 62,  211 => 60,  207 => 59,  202 => 57,  196 => 53,  172 => 51,  168 => 50,  163 => 48,  156 => 43,  132 => 41,  128 => 40,  123 => 38,  118 => 35,  94 => 33,  90 => 32,  85 => 30,  77 => 25,  71 => 21,  65 => 20,  42 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@AppBundle/Admin/base.html.twig\" %}
{% block styles %}

<style>
    [type=checkbox]:checked, [type=checkbox]:not(:checked){
        position: relative;
        left: auto;
        opacity: 1;
    }
     .fstElement { font-size: 9px; }
            .fstToggleBtn { min-width: 16.5em; }

            .submitBtn { display: none; }

            .fstMultipleMode { display: block; }
            .fstMultipleMode .fstControls { width: 100%; }

</style>
{% endblock %}
{% block body %}
    <div class=\"row\">
        <div class=\"col-12\">
            <div class=\"card card-outline-info\">
            
                <form method=\"post\" action=\"{{ path('create_home_page') }}\">
                <div class=\"card-body\">
<center><h4>App Home Page Setting</h4></center>
                    <div class=\"col-md-12\">
                        <div class=\"form-group\">
                         <label for=\"reg\"><input type=\"text\" name=\"featured_label\" required=\"\" placeholder=\"featured label\" class=\"form-control\" value=\"{{ featured_label }}\"></label>
                          <select class=\"multipleSelect\" multiple name=\"featured[]\">
  {% for me in MenuItem %}
  <option value=\"{{ me.id }}\" {% for fe in f %} {% if fe == me.id %} selected {% endif %} {% endfor %}>{{ me.itemName }}</option>
  {% endfor %}
    </select>
                        </div>
                        <div class=\"form-group\">
                         <label for=\"reg\"><input type=\"text\" name=\"discount_label\" required=\"\" placeholder=\"discount label\" class=\"form-control\" value=\"{{ discount_label }}\"></label>
                                 <select class=\"multipleSelect\" multiple name=\"discount[]\">
  {% for me in MenuItem %}
  <option value=\"{{ me.id }}\"  {% for fe in d %} {% if fe == me.id %} selected {% endif %} {% endfor %} >{{ me.itemName }}</option>
  {% endfor %}
    </select>
                        </div>     

                  <center><b>Featured Sub Categories 1</b></center>  
                  <div class=\"form-group\">
                         <label for=\"reg\"><input type=\"text\" name=\"category_label\" required=\"\" placeholder=\"Sub Category Label\" class=\"form-control\" value=\"{{ category_label }}\"></label>
                         <select class=\"multipleSelect\" multiple name=\"category[]\">
                          {% for me in category_list %}
                          <option value=\"{{ me.id }}\"  {% for fe in category %} {% if fe == me.id %} selected {% endif %} {% endfor %} >{{ me.categoryName }}</option>
                           {% endfor %}
                             </select>
                        </div>       
                  <center><b>Featured Sub Categories 2</b></center>  
                  <div class=\"form-group\">
                         <label for=\"reg\"><input type=\"text\" name=\"category_label_one\" required=\"\" placeholder=\"Sub Category Label\" class=\"form-control\" value=\"{{ category_one_label }}\"></label>
                         <select class=\"multipleSelect\" multiple name=\"category_one[]\">
                          {% for me in category_list %}
                          <option value=\"{{ me.id }}\"  {% for fe in category_one %} {% if fe == me.id %} selected {% endif %} {% endfor %} >{{ me.categoryName }}</option>
                           {% endfor %}
                             </select>
                        </div> 
                   <center><b>Featured Sub Categories 3</b></center>  
                  <div class=\"form-group\">
                         <label for=\"reg\"><input type=\"text\" name=\"category_label_two\" required=\"\" placeholder=\"Sub Category Label\" class=\"form-control\" value=\"{{ category_two_label }}\"></label>
                         <select class=\"multipleSelect\" multiple name=\"category_two[]\">
                          {% for me in category_list %}
                          <option value=\"{{ me.id }}\"  {% for fe in category_two %} {% if fe == me.id %} selected {% endif %} {% endfor %} >{{ me.categoryName }}</option>
                           {% endfor %}
                             </select>
                        </div>                    
                        <div class=\"clearfix\"></div>
                        <button type=\"submit\" class=\"btn btn-primary pull-left\">Save</button><br>
  </div>
                      
                </div>
            </form>
            </div>
        </div>
    </div>
{% endblock %}

{% block scripts %}


<script>
    
   
        </script>

{% endblock %}", "AppBundle:Admin:Pages/AppHome.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Pages/AppHome.html.twig");
    }
}

<?php

/* @AppBundle/Admin/Properties/headerMainAdmin.html.twig */
class __TwigTemplate_9842cc6f5c185311f67d7126618bf6d5fcf8ae894b8156e0ff7fd425d375f1e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fc2f0345e3b353fd10fc6495b2fc57515c7e435772435cdcd9aaa79d9ef95645 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc2f0345e3b353fd10fc6495b2fc57515c7e435772435cdcd9aaa79d9ef95645->enter($__internal_fc2f0345e3b353fd10fc6495b2fc57515c7e435772435cdcd9aaa79d9ef95645_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@AppBundle/Admin/Properties/headerMainAdmin.html.twig"));

        // line 1
        echo "    <div class=\"header-container fixed-top\">
<header class=\"header navbar navbar-expand-sm\">
    <ul class=\"navbar-item flex-row\">
        <li class=\"nav-item align-self-center page-heading\">
            <div class=\"page-header\">
                        ";
        // line 6
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "userType", array()) == "root")) {
            // line 7
            echo "                        ";
        } else {
            // line 8
            echo "                <div class=\"page-title\">
                      <div class=\"spinner-border text-success align-self-center \"></div>

                </div>
                ";
        }
        // line 13
        echo "
            </div>
        </li>
    </ul>
    <a href=\"javascript:void(0);\" class=\"sidebarCollapse\" data-placement=\"bottom\"><svg
            xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
            stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
            class=\"feather feather-list\">
            <line x1=\"8\" y1=\"6\" x2=\"21\" y2=\"6\"></line>
            <line x1=\"8\" y1=\"12\" x2=\"21\" y2=\"12\"></line>
            <line x1=\"8\" y1=\"18\" x2=\"21\" y2=\"18\"></line>
            <line x1=\"3\" y1=\"6\" x2=\"3\" y2=\"6\"></line>
            <line x1=\"3\" y1=\"12\" x2=\"3\" y2=\"12\"></line>
            <line x1=\"3\" y1=\"18\" x2=\"3\" y2=\"18\"></line>
        </svg></a>
    <ul class=\"navbar-item flex-row search-ul\">
        <li class=\"nav-item align-self-center search-animated\">
            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                class=\"feather feather-search toggle-search\">
                <circle cx=\"11\" cy=\"11\" r=\"8\"></circle>
                <line x1=\"21\" y1=\"21\" x2=\"16.65\" y2=\"16.65\"></line>
            </svg>
           <form class=\"form-inline search-full form-inline search\" role=\"search\" action=\"";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("search_data");
        echo "\">
                <div class=\"search-bar\">
                    <input type=\"text\" class=\"form-control search-form-control  ml-lg-auto\"
                        placeholder=\"Type here to search\" name=\"data\">
                </div>
            </form>
        </li>
    </ul>
    <ul class=\"navbar-item flex-row navbar-dropdown\">

        ";
        // line 46
        $context["explodedURL"] = twig_split_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "server", array()), "get", array(0 => "REQUEST_URI"), "method"), "/");
        // line 47
        echo "
        ";
        // line 48
        if ($this->getAttribute(($context["explodedURL"] ?? null), 3, array(), "array", true, true)) {
            // line 49
            echo "
            ";
            // line 50
            if (($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 3, array(), "array") == "all-users")) {
                // line 51
                echo "            
            <li class=\"nav-item dropdown message-dropdown mr-4\">
                <a href=\"";
                // line 53
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("customer_create");
                echo "\" class=\"nav-link\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create Customer
                </a>
            </li>

            ";
            }
            // line 59
            echo "       ";
            if (($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 3, array(), "array") == "all-brands")) {
                // line 60
                echo "            
            <li class=\"nav-item dropdown message-dropdown mr-4\">
                <a href=\"#createBrands\" data-toggle=\"modal\" data-target=\"#createBrands\"class=\"nav-link\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create Brand
                </a>
            </li>

            ";
            }
            // line 68
            echo "            ";
            if (($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 3, array(), "array") == "orders")) {
                // line 69
                echo "
                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"";
                // line 71
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create_order");
                echo "\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create Order
                        </a>
                    </li>

            ";
            }
            // line 77
            echo "
            ";
            // line 78
            if (($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 3, array(), "array") == "all-parent-category")) {
                // line 79
                echo "
                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"";
                // line 81
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_main_create");
                echo "\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create New
                        </a>
                    </li>
            
            ";
            }
            // line 87
            echo "            ";
            if (($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 3, array(), "array") == "list-nested")) {
                // line 88
                echo "
                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"";
                // line 90
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("nested_category_create");
                echo "\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create New
                        </a>
                    </li>
            
            ";
            }
            // line 96
            echo "              ";
            if (($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 3, array(), "array") == "all-sub-category")) {
                // line 97
                echo "
                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"";
                // line 99
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_sub_create");
                echo "\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create New
                        </a>
                    </li>
            
            ";
            }
            // line 105
            echo "        ";
        }
        // line 106
        echo "
         ";
        // line 107
        if ($this->getAttribute(($context["explodedURL"] ?? null), 2, array(), "array", true, true)) {
            // line 108
            echo "
            ";
            // line 109
            if (($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 2, array(), "array") == "view-menu")) {
                // line 110
                echo "
                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"";
                // line 112
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_add_menu_item");
                echo "\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create Product
                        </a>
                    </li>

            ";
            }
            // line 118
            echo "               ";
            if (($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 2, array(), "array") == "branch")) {
                // line 119
                echo "
                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"";
                // line 121
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("restaurant_create");
                echo "\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create Branch
                        </a>
                    </li>

            ";
            }
            // line 127
            echo "
            ";
            // line 128
            if (($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 2, array(), "array") == "manage-advertisement")) {
                // line 129
                echo "
                <li class=\"nav-item dropdown message-dropdown mr-4\">
                    <a href=\"";
                // line 131
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("advertisement_new");
                echo "\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                            stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                            class=\"feather feather-plus\">
                            <line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line>
                            <line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line>
                        </svg> Create Banner
                    </a>
                </li>

            ";
            }
            // line 142
            if (($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 2, array(), "array") == "list-notification")) {
                // line 143
                echo "            
            <li class=\"nav-item dropdown message-dropdown mr-4\">
                <a href=\"";
                // line 145
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("send_push_notification", array("type" => "all"));
                echo "\" class=\"nav-link\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Send Notifcation
                </a>
            </li>

            ";
            }
            // line 151
            echo "              ";
            if ((($this->getAttribute(($context["explodedURL"] ?? $this->getContext($context, "explodedURL")), 2, array(), "array") == "promocode") &&  !$this->getAttribute(($context["explodedURL"] ?? null), 3, array(), "array", true, true))) {
                // line 152
                echo "
                <li class=\"nav-item dropdown message-dropdown mr-4\">
                    <a href=\"";
                // line 154
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_new_promocode");
                echo "\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                            stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                            class=\"feather feather-plus\">
                            <line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line>
                            <line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line>
                        </svg> Create Discount Code
                    </a>
                </li>

             ";
            }
            // line 165
            echo " 
        ";
        }
        // line 167
        echo "
        
<!--         <li class=\"nav-item dropdown notification-dropdown\">
            <a href=\"javascript:void(0);\" class=\"nav-link dropdown-toggle\" id=\"notificationDropdown\"
                data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                    stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                    class=\"feather feather-bell\">
                    <path d=\"M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9\"></path>
                    <path d=\"M13.73 21a2 2 0 0 1-3.46 0\"></path>
                </svg><span class=\"badge badge-success\"></span>
            </a>
            <div class=\"dropdown-menu position-absolute animated fadeInUp\" aria-labelledby=\"notificationDropdown\">
                <div class=\"notification-scroll\">
                    <div class=\"dropdown-item\">
                        <div class=\"media server-log\">
                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                stroke-linejoin=\"round\" class=\"feather feather-server\">
                                <rect x=\"2\" y=\"2\" width=\"20\" height=\"8\" rx=\"2\" ry=\"2\"></rect>
                                <rect x=\"2\" y=\"14\" width=\"20\" height=\"8\" rx=\"2\" ry=\"2\"></rect>
                                <line x1=\"6\" y1=\"6\" x2=\"6\" y2=\"6\"></line>
                                <line x1=\"6\" y1=\"18\" x2=\"6\" y2=\"18\"></line>
                            </svg>
                            <div class=\"media-body\">
                                <div class=\"data-info\">
                                    <h6 class=\"\">Server Rebooted</h6>
                                    <p class=\"\">45 min ago</p>
                                </div>

                                <div class=\"icon-status\">
                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                        fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" class=\"feather feather-x\">
                                        <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>
                                        <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class=\"dropdown-item\">
                        <div class=\"media \">
                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                stroke-linejoin=\"round\" class=\"feather feather-heart\">
                                <path
                                    d=\"M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z\">
                                </path>
                            </svg>
                            <div class=\"media-body\">
                                <div class=\"data-info\">
                                    <h6 class=\"\">Licence Expiring Soon</h6>
                                    <p class=\"\">8 hrs ago</p>
                                </div>

                                <div class=\"icon-status\">
                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                        fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" class=\"feather feather-x\">
                                        <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>
                                        <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class=\"dropdown-item\">
                        <div class=\"media file-upload\">
                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                stroke-linejoin=\"round\" class=\"feather feather-file-text\">
                                <path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"></path>
                                <polyline points=\"14 2 14 8 20 8\"></polyline>
                                <line x1=\"16\" y1=\"13\" x2=\"8\" y2=\"13\"></line>
                                <line x1=\"16\" y1=\"17\" x2=\"8\" y2=\"17\"></line>
                                <polyline points=\"10 9 9 9 8 9\"></polyline>
                            </svg>
                            <div class=\"media-body\">
                                <div class=\"data-info\">
                                    <h6 class=\"\">Kelly Portfolio.pdf</h6>
                                    <p class=\"\">670 kb</p>
                                </div>

                                <div class=\"icon-status\">
                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                        fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" class=\"feather feather-check\">
                                        <polyline points=\"20 6 9 17 4 12\"></polyline>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li> -->

        <li class=\"nav-item dropdown user-profile-dropdown  order-lg-0 order-1\">
            <a href=\"javascript:void(0);\" class=\"nav-link dropdown-toggle user\" id=\"userProfileDropdown\"
                data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                    stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                    class=\"feather feather-user\">
                    <path d=\"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2\"></path>
                    <circle cx=\"12\" cy=\"7\" r=\"4\"></circle>
                </svg>
            </a>
            <div class=\"dropdown-menu position-absolute animated fadeInUp\" aria-labelledby=\"userProfileDropdown\">
                <div class=\"user-profile-section\">
                    <div class=\"media mx-auto\">
                  <span style=\"
    width: 35px;
    font-size: 22px;
    font-weight: 900;
    color: #fff !important;
    background: #4156b5;
    border-radius: 50%;
    padding: -1px;
    margin-right: 5px;
    margin-left: -2px;
    text-align: center;
\"> ";
        // line 291
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, twig_first($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "firstName", array()))), "html", null, true);
        echo "</span>
                        <div class=\"media-body\">
                            <h5>";
        // line 293
        echo twig_escape_filter($this->env, (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "firstName", array()) . " ") . $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "lastName", array())), "html", null, true);
        echo "</h5>
                            <p>";
        // line 294
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "userType", array()), "html", null, true);
        echo "</p>
                        </div>
                    </div>
                </div>
                <div class=\"dropdown-item\">
                    <a href=\"";
        // line 299
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_edit", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                            stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                            class=\"feather feather-user\">
                            <path d=\"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2\"></path>
                            <circle cx=\"12\" cy=\"7\" r=\"4\"></circle>
                        </svg> <span>My Profile</span>
                    </a>
                </div>
                <div class=\"dropdown-item\">
                    <a href=\"";
        // line 309
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_logout");
        echo "\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                            stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                            class=\"feather feather-log-out\">
                            <path d=\"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4\"></path>
                            <polyline points=\"16 17 21 12 16 7\"></polyline>
                            <line x1=\"21\" y1=\"12\" x2=\"9\" y2=\"12\"></line>
                        </svg> <span>Log Out</span>
                    </a>
                </div>
            </div>
        </li>
    </ul>
</header>
</div>";
        
        $__internal_fc2f0345e3b353fd10fc6495b2fc57515c7e435772435cdcd9aaa79d9ef95645->leave($__internal_fc2f0345e3b353fd10fc6495b2fc57515c7e435772435cdcd9aaa79d9ef95645_prof);

    }

    public function getTemplateName()
    {
        return "@AppBundle/Admin/Properties/headerMainAdmin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  444 => 309,  431 => 299,  423 => 294,  419 => 293,  414 => 291,  288 => 167,  284 => 165,  270 => 154,  266 => 152,  263 => 151,  254 => 145,  250 => 143,  248 => 142,  234 => 131,  230 => 129,  228 => 128,  225 => 127,  216 => 121,  212 => 119,  209 => 118,  200 => 112,  196 => 110,  194 => 109,  191 => 108,  189 => 107,  186 => 106,  183 => 105,  174 => 99,  170 => 97,  167 => 96,  158 => 90,  154 => 88,  151 => 87,  142 => 81,  138 => 79,  136 => 78,  133 => 77,  124 => 71,  120 => 69,  117 => 68,  107 => 60,  104 => 59,  95 => 53,  91 => 51,  89 => 50,  86 => 49,  84 => 48,  81 => 47,  79 => 46,  66 => 36,  41 => 13,  34 => 8,  31 => 7,  29 => 6,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("    <div class=\"header-container fixed-top\">
<header class=\"header navbar navbar-expand-sm\">
    <ul class=\"navbar-item flex-row\">
        <li class=\"nav-item align-self-center page-heading\">
            <div class=\"page-header\">
                        {% if app.user.userType == 'root' %}
                        {% else %}
                <div class=\"page-title\">
                      <div class=\"spinner-border text-success align-self-center \"></div>

                </div>
                {% endif %}

            </div>
        </li>
    </ul>
    <a href=\"javascript:void(0);\" class=\"sidebarCollapse\" data-placement=\"bottom\"><svg
            xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
            stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
            class=\"feather feather-list\">
            <line x1=\"8\" y1=\"6\" x2=\"21\" y2=\"6\"></line>
            <line x1=\"8\" y1=\"12\" x2=\"21\" y2=\"12\"></line>
            <line x1=\"8\" y1=\"18\" x2=\"21\" y2=\"18\"></line>
            <line x1=\"3\" y1=\"6\" x2=\"3\" y2=\"6\"></line>
            <line x1=\"3\" y1=\"12\" x2=\"3\" y2=\"12\"></line>
            <line x1=\"3\" y1=\"18\" x2=\"3\" y2=\"18\"></line>
        </svg></a>
    <ul class=\"navbar-item flex-row search-ul\">
        <li class=\"nav-item align-self-center search-animated\">
            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                class=\"feather feather-search toggle-search\">
                <circle cx=\"11\" cy=\"11\" r=\"8\"></circle>
                <line x1=\"21\" y1=\"21\" x2=\"16.65\" y2=\"16.65\"></line>
            </svg>
           <form class=\"form-inline search-full form-inline search\" role=\"search\" action=\"{{ path('search_data') }}\">
                <div class=\"search-bar\">
                    <input type=\"text\" class=\"form-control search-form-control  ml-lg-auto\"
                        placeholder=\"Type here to search\" name=\"data\">
                </div>
            </form>
        </li>
    </ul>
    <ul class=\"navbar-item flex-row navbar-dropdown\">

        {% set explodedURL = app.request.server.get('REQUEST_URI')|split('/') %}

        {% if explodedURL[3] is defined %}

            {% if (explodedURL[3] == 'all-users') %}
            
            <li class=\"nav-item dropdown message-dropdown mr-4\">
                <a href=\"{{ path('customer_create') }}\" class=\"nav-link\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create Customer
                </a>
            </li>

            {% endif %}
       {% if (explodedURL[3] == 'all-brands') %}
            
            <li class=\"nav-item dropdown message-dropdown mr-4\">
                <a href=\"#createBrands\" data-toggle=\"modal\" data-target=\"#createBrands\"class=\"nav-link\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create Brand
                </a>
            </li>

            {% endif %}
            {% if (explodedURL[3] == 'orders') %}

                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"{{ path('create_order') }}\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create Order
                        </a>
                    </li>

            {% endif %}

            {% if (explodedURL[3] == 'all-parent-category') %}

                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"{{ path('category_main_create') }}\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create New
                        </a>
                    </li>
            
            {% endif %}
            {% if (explodedURL[3] == 'list-nested') %}

                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"{{ path('nested_category_create') }}\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create New
                        </a>
                    </li>
            
            {% endif %}
              {% if (explodedURL[3] == 'all-sub-category') %}

                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"{{ path('category_sub_create') }}\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create New
                        </a>
                    </li>
            
            {% endif %}
        {% endif %}

         {% if explodedURL[2] is defined %}

            {% if (explodedURL[2] == 'view-menu') %}

                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"{{ path('restaurant_add_menu_item') }}\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create Product
                        </a>
                    </li>

            {% endif %}
               {% if (explodedURL[2] == 'branch') %}

                    <li class=\"nav-item dropdown message-dropdown mr-4\">
                        <a href=\"{{ path('restaurant_create') }}\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Create Branch
                        </a>
                    </li>

            {% endif %}

            {% if (explodedURL[2] == 'manage-advertisement') %}

                <li class=\"nav-item dropdown message-dropdown mr-4\">
                    <a href=\"{{ path('advertisement_new') }}\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                            stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                            class=\"feather feather-plus\">
                            <line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line>
                            <line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line>
                        </svg> Create Banner
                    </a>
                </li>

            {% endif %}
{% if (explodedURL[2] == 'list-notification') %}
            
            <li class=\"nav-item dropdown message-dropdown mr-4\">
                <a href=\"{{ path('send_push_notification',{'type':'all'}) }}\" class=\"nav-link\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-plus\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line></svg> Send Notifcation
                </a>
            </li>

            {% endif %}
              {% if (explodedURL[2] == 'promocode') and (not(explodedURL[3] is defined)) %}

                <li class=\"nav-item dropdown message-dropdown mr-4\">
                    <a href=\"{{ path('add_new_promocode') }}\" class=\"nav-link\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                            stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                            class=\"feather feather-plus\">
                            <line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line>
                            <line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line>
                        </svg> Create Discount Code
                    </a>
                </li>

             {% endif %}
 
        {% endif %}

        
<!--         <li class=\"nav-item dropdown notification-dropdown\">
            <a href=\"javascript:void(0);\" class=\"nav-link dropdown-toggle\" id=\"notificationDropdown\"
                data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                    stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                    class=\"feather feather-bell\">
                    <path d=\"M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9\"></path>
                    <path d=\"M13.73 21a2 2 0 0 1-3.46 0\"></path>
                </svg><span class=\"badge badge-success\"></span>
            </a>
            <div class=\"dropdown-menu position-absolute animated fadeInUp\" aria-labelledby=\"notificationDropdown\">
                <div class=\"notification-scroll\">
                    <div class=\"dropdown-item\">
                        <div class=\"media server-log\">
                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                stroke-linejoin=\"round\" class=\"feather feather-server\">
                                <rect x=\"2\" y=\"2\" width=\"20\" height=\"8\" rx=\"2\" ry=\"2\"></rect>
                                <rect x=\"2\" y=\"14\" width=\"20\" height=\"8\" rx=\"2\" ry=\"2\"></rect>
                                <line x1=\"6\" y1=\"6\" x2=\"6\" y2=\"6\"></line>
                                <line x1=\"6\" y1=\"18\" x2=\"6\" y2=\"18\"></line>
                            </svg>
                            <div class=\"media-body\">
                                <div class=\"data-info\">
                                    <h6 class=\"\">Server Rebooted</h6>
                                    <p class=\"\">45 min ago</p>
                                </div>

                                <div class=\"icon-status\">
                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                        fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" class=\"feather feather-x\">
                                        <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>
                                        <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class=\"dropdown-item\">
                        <div class=\"media \">
                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                stroke-linejoin=\"round\" class=\"feather feather-heart\">
                                <path
                                    d=\"M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z\">
                                </path>
                            </svg>
                            <div class=\"media-body\">
                                <div class=\"data-info\">
                                    <h6 class=\"\">Licence Expiring Soon</h6>
                                    <p class=\"\">8 hrs ago</p>
                                </div>

                                <div class=\"icon-status\">
                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                        fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" class=\"feather feather-x\">
                                        <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>
                                        <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class=\"dropdown-item\">
                        <div class=\"media file-upload\">
                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                stroke-linejoin=\"round\" class=\"feather feather-file-text\">
                                <path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"></path>
                                <polyline points=\"14 2 14 8 20 8\"></polyline>
                                <line x1=\"16\" y1=\"13\" x2=\"8\" y2=\"13\"></line>
                                <line x1=\"16\" y1=\"17\" x2=\"8\" y2=\"17\"></line>
                                <polyline points=\"10 9 9 9 8 9\"></polyline>
                            </svg>
                            <div class=\"media-body\">
                                <div class=\"data-info\">
                                    <h6 class=\"\">Kelly Portfolio.pdf</h6>
                                    <p class=\"\">670 kb</p>
                                </div>

                                <div class=\"icon-status\">
                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"
                                        fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" class=\"feather feather-check\">
                                        <polyline points=\"20 6 9 17 4 12\"></polyline>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li> -->

        <li class=\"nav-item dropdown user-profile-dropdown  order-lg-0 order-1\">
            <a href=\"javascript:void(0);\" class=\"nav-link dropdown-toggle user\" id=\"userProfileDropdown\"
                data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                    stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                    class=\"feather feather-user\">
                    <path d=\"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2\"></path>
                    <circle cx=\"12\" cy=\"7\" r=\"4\"></circle>
                </svg>
            </a>
            <div class=\"dropdown-menu position-absolute animated fadeInUp\" aria-labelledby=\"userProfileDropdown\">
                <div class=\"user-profile-section\">
                    <div class=\"media mx-auto\">
                  <span style=\"
    width: 35px;
    font-size: 22px;
    font-weight: 900;
    color: #fff !important;
    background: #4156b5;
    border-radius: 50%;
    padding: -1px;
    margin-right: 5px;
    margin-left: -2px;
    text-align: center;
\"> {{ app.user.firstName|first|lower }}</span>
                        <div class=\"media-body\">
                            <h5>{{ app.user.firstName ~ \" \" ~ app.user.lastName }}</h5>
                            <p>{{ app.user.userType }}</p>
                        </div>
                    </div>
                </div>
                <div class=\"dropdown-item\">
                    <a href=\"{{ path('admin_edit',{'id':app.user.id})}}\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                            stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                            class=\"feather feather-user\">
                            <path d=\"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2\"></path>
                            <circle cx=\"12\" cy=\"7\" r=\"4\"></circle>
                        </svg> <span>My Profile</span>
                    </a>
                </div>
                <div class=\"dropdown-item\">
                    <a href=\"{{ path('admin_logout')}}\">
                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\"
                            stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"
                            class=\"feather feather-log-out\">
                            <path d=\"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4\"></path>
                            <polyline points=\"16 17 21 12 16 7\"></polyline>
                            <line x1=\"21\" y1=\"12\" x2=\"9\" y2=\"12\"></line>
                        </svg> <span>Log Out</span>
                    </a>
                </div>
            </div>
        </li>
    </ul>
</header>
</div>", "@AppBundle/Admin/Properties/headerMainAdmin.html.twig", "/home/grocbayc/login.grocbay.com/src/AppBundle/Resources/views/Admin/Properties/headerMainAdmin.html.twig");
    }
}
